# SXY's Corporate Club — Supabase Auth Email Templates

These six HTML files match the six template slots in **Supabase Auth → Email Templates**:

| File | Supabase slot | Subject |
|---|---|---|
| `confirm-signup.html` | Confirm signup | Confirm your SXY's Corporate Club account |
| `magic-link.html` | Magic Link | Your SXY's Corporate Club sign-in link |
| `reset-password.html` | Reset Password | Reset your SXY's Corporate Club password |
| `invite-user.html` | Invite user | You've been invited to SXY's Corporate Club |
| `change-email.html` | Change Email Address | Confirm your new email — SXY's Corporate Club |
| `reauthentication.html` | Reauthentication | Your SXY's Corporate Club verification code |

## Sender

In **Supabase → Auth → SMTP Settings**, set:
- Sender email: `no-reply@sxyscorporateclub.com`
- Sender name: `SXY's Corporate Club`

(SMTP host/user/pass stays as the Resend values you already configured.)

## Supabase template variables used

- `{{ .ConfirmationURL }}` — the action link (signup, magic link, recovery, invite, email change)
- `{{ .Token }}` — 6-digit OTP code (reauthentication)
- `{{ .Email }}` — recipient address (used in confirm-signup / reset)
- `{{ .NewEmail }}` — new address (change-email)

Paste each HTML body into the corresponding template body in the Supabase dashboard.
Subjects are above; set them in the matching "Subject heading" field.
