-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Bidding module + Channels + bid-documents bucket
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--
-- WHAT IT DOES:
--   1. Extends public.projects with category, single `budget`, deadline,
--      requirements[], rfp_url, winner_id / winner_bid_id, contract_value.
--   2. Extends public.bids with proposed_price, timeline, cover_letter,
--      years_experience, available_from, portfolio_url, documents[].
--   3. Adds public.channels + seeds #general, links public.messages.channel.
--   4. Creates the public.open_projects_with_bids view used by the browse
--      page (joins bid count + posted-by name).
--   5. Provisions a private `bid-documents` storage bucket with RLS so only
--      the bidder + admins can read each file, and the bidder can upload to
--      their own folder.
--
-- All `add column if not exists`, `create … if not exists`, and
-- `drop policy if exists` calls make the script safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Project category enum + columns -----------------------------------------
do $$ begin
  create type public.project_category as enum (
    'strategy', 'contractor', 'cleaning', 'marketing',
    'legal', 'trades', 'tech_ai', 'other'
  );
exception when duplicate_object then null; end $$;

alter table public.projects
  add column if not exists category       public.project_category not null default 'other',
  add column if not exists summary        text,
  add column if not exists description    text,
  add column if not exists budget         numeric(12,2),
  add column if not exists budget_min     numeric(12,2),
  add column if not exists budget_max     numeric(12,2),
  add column if not exists deadline       timestamptz,
  add column if not exists closes_at      timestamptz,
  add column if not exists requirements   text[] not null default '{}',
  add column if not exists rfp_url        text,
  add column if not exists posted_by      uuid references auth.users(id) on delete set null,
  add column if not exists winner_id      uuid references auth.users(id) on delete set null,
  add column if not exists winner_bid_id  uuid references public.bids(id) on delete set null,
  add column if not exists contract_value numeric(12,2);

-- Add 'reviewing' + 'awarded' to the project_status enum if missing.
do $$ begin
  alter type public.project_status add value if not exists 'reviewing';
exception when others then null; end $$;
do $$ begin
  alter type public.project_status add value if not exists 'awarded';
exception when others then null; end $$;

create index if not exists projects_category_idx on public.projects (category);
create index if not exists projects_winner_idx   on public.projects (winner_id);

-- 2. Extend bids with the proposal-form fields -------------------------------
alter table public.bids
  add column if not exists proposed_price   numeric(12,2),
  add column if not exists timeline         text,
  add column if not exists cover_letter     text,
  add column if not exists years_experience text,
  add column if not exists available_from   date,
  add column if not exists portfolio_url    text,
  add column if not exists documents        text[] not null default '{}';

-- 3. Channels (community Exchange) -------------------------------------------
create table if not exists public.channels (
  id          uuid primary key default gen_random_uuid(),
  slug        text not null unique,
  name        text not null,
  description text,
  is_system   boolean not null default false,
  created_at  timestamptz not null default now()
);

-- If an older version of public.channels already existed, make sure the
-- columns this migration relies on are present before we seed/insert.
alter table public.channels
  add column if not exists slug        text,
  add column if not exists name        text,
  add column if not exists description text,
  add column if not exists is_system   boolean not null default false,
  add column if not exists created_at  timestamptz not null default now();

-- Backfill slug for any legacy rows so we can enforce NOT NULL + UNIQUE.
update public.channels
   set slug = coalesce(slug, lower(regexp_replace(coalesce(name, id::text), '\s+', '-', 'g')));

alter table public.channels alter column slug set not null;

do $$ begin
  alter table public.channels add constraint channels_slug_key unique (slug);
exception when duplicate_table then null; when duplicate_object then null; end $$;

alter table public.channels enable row level security;

drop policy if exists "Members read channels" on public.channels;
create policy "Members read channels"
  on public.channels for select
  to authenticated
  using (true);

drop policy if exists "Admins manage channels" on public.channels;
create policy "Admins manage channels"
  on public.channels for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- Seed the default #general channel (idempotent).
-- The legacy channels table may have extra NOT NULL columns (e.g. display_name);
-- detect and populate them dynamically so this works on fresh + existing DBs.
do $$
declare
  cols  text := 'slug, name, description, is_system';
  vals  text := $v$'general', 'General', 'Club-wide announcements and chatter.', true$v$;
begin
  if exists (select 1 from information_schema.columns
             where table_schema='public' and table_name='channels' and column_name='display_name') then
    cols := cols || ', display_name';
    vals := vals || $v$, 'General'$v$;
  end if;

  execute format(
    'insert into public.channels (%s) values (%s) on conflict (slug) do nothing',
    cols, vals
  );
end $$;

-- Make sure existing messages.channel values still resolve.
-- (We keep messages.channel as text/slug — no FK so legacy rows survive.)

-- 4. Browse view: open projects + bid counts + poster name -------------------
-- Drop first because CREATE OR REPLACE VIEW can't change column shape.
drop view if exists public.open_projects_with_bids;
create view public.open_projects_with_bids as
select
  p.id,
  p.title,
  p.summary,
  p.description,
  p.category,
  p.status,
  p.budget,
  p.budget_min,
  p.budget_max,
  p.deadline,
  p.closes_at,
  p.requirements,
  p.rfp_url,
  p.posted_by,
  p.created_at,
  p.updated_at,
  poster.full_name as posted_by_name,
  coalesce(bid_counts.total, 0) as bid_count
from public.projects p
left join public.profiles poster on poster.id = p.posted_by
left join (
  select project_id, count(*)::int as total
  from public.bids
  group by project_id
) bid_counts on bid_counts.project_id = p.id;

-- The view inherits RLS from the base tables (security_invoker default in PG15+).
-- For older PG, explicit grant so authenticated users can select via PostgREST:
grant select on public.open_projects_with_bids to authenticated;

-- 5. Storage bucket: bid-documents -------------------------------------------
insert into storage.buckets (id, name, public)
values ('bid-documents', 'bid-documents', false)
on conflict (id) do nothing;

-- Path convention: {project_id}/{bidder_id}/{filename}.
-- The first two folders are extracted via storage.foldername(name).
drop policy if exists "Bidders upload to own folder" on storage.objects;
create policy "Bidders upload to own folder"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'bid-documents'
    and (storage.foldername(name))[2] = auth.uid()::text
  );

drop policy if exists "Bidders read own documents" on storage.objects;
create policy "Bidders read own documents"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'bid-documents'
    and (
      (storage.foldername(name))[2] = auth.uid()::text
      or public.has_role(auth.uid(), 'admin')
    )
  );

drop policy if exists "Bidders update own documents" on storage.objects;
create policy "Bidders update own documents"
  on storage.objects for update
  to authenticated
  using (
    bucket_id = 'bid-documents'
    and (storage.foldername(name))[2] = auth.uid()::text
  );

drop policy if exists "Bidders delete own documents" on storage.objects;
create policy "Bidders delete own documents"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'bid-documents'
    and (
      (storage.foldername(name))[2] = auth.uid()::text
      or public.has_role(auth.uid(), 'admin')
    )
  );
