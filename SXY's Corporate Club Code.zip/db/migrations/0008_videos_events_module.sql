-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Economy Bites + Events module (run after 0007)
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--
-- WHAT IT DOES:
--   1. Creates public.videos (the educational video library) with series,
--      access tiers, view + save counters, featured flag, publish flag.
--   2. Extends public.video_progress with progress_seconds, notes columns
--      (the existing table only tracks progress_pct + completed).
--   3. Creates public.video_saves so members can bookmark videos.
--   4. Extends public.events with host_name, icon_emoji, duration_min,
--      platform, recording_url, status, recording_access, registrant_count.
--   5. Creates public.event_registrations join table with RLS.
--   6. Triggers to auto-increment registrant_count on insert/delete.
--   7. RLS everywhere using existing public.user_tier() + has_role() helpers.
--
-- All `if not exists`, `add column if not exists`, and `drop policy if exists`
-- calls make the script safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. videos -------------------------------------------------------------------
do $$ begin
  create type public.video_series as enum ('business-bites', 'market-bites', 'bankruptcy-bites');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.video_access as enum ('free', 'paid', 'vip');
exception when duplicate_object then null; end $$;

create table if not exists public.videos (
  id                uuid primary key default gen_random_uuid(),
  title             text not null,
  description       text,
  icon_emoji        text not null default '▣',
  thumbnail_url     text,
  video_url         text,                          -- YouTube / Vimeo embed URL or storage URL
  duration_seconds  int not null default 0,
  series            public.video_series not null default 'business-bites',
  category          text,                          -- "Strategy" / "Finance" / etc
  access_level      public.video_access not null default 'free',
  view_count        int not null default 0,
  save_count        int not null default 0,
  is_featured       boolean not null default false,
  is_published      boolean not null default false,
  notify_on_publish boolean not null default false,
  created_by        uuid references auth.users(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists videos_series_idx     on public.videos (series);
create index if not exists videos_access_idx     on public.videos (access_level);
create index if not exists videos_published_idx  on public.videos (is_published, created_at desc);
create index if not exists videos_featured_idx   on public.videos (is_featured) where is_featured;

alter table public.videos enable row level security;

-- Tier-aware read policy. Free users only see free videos; paid/annual see
-- free+paid; VIP/admin see everything. Unpublished videos are admin-only.
create or replace function public.video_access_rank(_a public.video_access)
returns int
language sql
immutable
as $$
  select case _a when 'free' then 1 when 'paid' then 2 when 'vip' then 3 end;
$$;

-- text overload (some legacy rows / casts arrive as text rather than enum)
create or replace function public.video_access_rank(_a text)
returns int
language sql
immutable
as $$
  select case _a when 'free' then 1 when 'paid' then 2 when 'vip' then 3 else 1 end;
$$;

create or replace function public.tier_video_rank(_t text)
returns int
language sql
immutable
as $$
  select case _t
    when 'free'   then 1
    when 'paid'   then 2
    when 'annual' then 2
    when 'vip'    then 3
    else 1
  end;
$$;

drop policy if exists "Members read accessible videos" on public.videos;
create policy "Members read accessible videos"
  on public.videos for select
  to authenticated
  using (
    public.has_role(auth.uid(), 'admin')
    or (
      is_published
      and public.video_access_rank(access_level)
        <= public.tier_video_rank(public.user_tier(auth.uid()))
    )
  );

drop policy if exists "Admins manage videos" on public.videos;
create policy "Admins manage videos"
  on public.videos for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

drop trigger if exists videos_touch_updated_at on public.videos;
create trigger videos_touch_updated_at
  before update on public.videos
  for each row execute function public.touch_updated_at();

-- 2. video_progress extensions ----------------------------------------------
alter table public.video_progress
  add column if not exists progress_seconds int not null default 0,
  add column if not exists notes            text;

-- Drop old loose video_id (uuid) FK if any, then add a real FK to videos.
do $$ begin
  alter table public.video_progress
    add constraint video_progress_video_fk
    foreign key (video_id) references public.videos(id) on delete cascade;
exception when duplicate_object then null;
when others then null; end $$;

-- 3. video_saves -------------------------------------------------------------
create table if not exists public.video_saves (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  video_id   uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, video_id)
);

create index if not exists video_saves_user_idx  on public.video_saves (user_id);
create index if not exists video_saves_video_idx on public.video_saves (video_id);

alter table public.video_saves enable row level security;

drop policy if exists "Users read own saves" on public.video_saves;
create policy "Users read own saves"
  on public.video_saves for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users insert own saves" on public.video_saves;
create policy "Users insert own saves"
  on public.video_saves for insert
  to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Users delete own saves" on public.video_saves;
create policy "Users delete own saves"
  on public.video_saves for delete
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- Auto-bump videos.save_count on save / unsave.
create or replace function public.bump_video_save_count()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    update public.videos set save_count = save_count + 1 where id = new.video_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.videos set save_count = greatest(save_count - 1, 0) where id = old.video_id;
    return old;
  end if;
  return null;
end;
$$;

drop trigger if exists video_saves_count_ins on public.video_saves;
create trigger video_saves_count_ins
  after insert on public.video_saves
  for each row execute function public.bump_video_save_count();

drop trigger if exists video_saves_count_del on public.video_saves;
create trigger video_saves_count_del
  after delete on public.video_saves
  for each row execute function public.bump_video_save_count();

-- 4. events extensions -------------------------------------------------------
do $$ begin
  create type public.event_status as enum ('scheduled', 'live', 'completed', 'canceled');
exception when duplicate_object then null; end $$;

alter table public.events
  add column if not exists icon_emoji        text not null default '📅',
  add column if not exists host_name         text,
  add column if not exists duration_min      int,
  add column if not exists platform          text,                  -- Zoom / Google Meet / etc
  add column if not exists join_url          text,
  add column if not exists recording_url     text,
  add column if not exists recording_access  public.event_access,
  add column if not exists registrant_count  int not null default 0,
  add column if not exists archive_recording boolean not null default true,
  add column if not exists notify_members    boolean not null default false,
  add column if not exists post_to_general   boolean not null default false,
  add column if not exists status            public.event_status not null default 'scheduled';

create index if not exists events_status_idx on public.events (status);

-- 5. event_registrations -----------------------------------------------------
create table if not exists public.event_registrations (
  id          uuid primary key default gen_random_uuid(),
  event_id    uuid not null references public.events(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  created_at  timestamptz not null default now(),
  unique (event_id, user_id)
);

create index if not exists event_reg_event_idx on public.event_registrations (event_id);
create index if not exists event_reg_user_idx  on public.event_registrations (user_id);

alter table public.event_registrations enable row level security;

drop policy if exists "Users read own registrations" on public.event_registrations;
create policy "Users read own registrations"
  on public.event_registrations for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users register self" on public.event_registrations;
create policy "Users register self"
  on public.event_registrations for insert
  to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Users cancel own registration" on public.event_registrations;
create policy "Users cancel own registration"
  on public.event_registrations for delete
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- Auto-bump events.registrant_count on register / cancel.
create or replace function public.bump_event_registrant_count()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    update public.events set registrant_count = registrant_count + 1 where id = new.event_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.events set registrant_count = greatest(registrant_count - 1, 0) where id = old.event_id;
    return old;
  end if;
  return null;
end;
$$;

drop trigger if exists event_reg_count_ins on public.event_registrations;
create trigger event_reg_count_ins
  after insert on public.event_registrations
  for each row execute function public.bump_event_registrant_count();

drop trigger if exists event_reg_count_del on public.event_registrations;
create trigger event_reg_count_del
  after delete on public.event_registrations
  for each row execute function public.bump_event_registrant_count();
