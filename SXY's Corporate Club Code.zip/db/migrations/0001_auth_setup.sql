-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Auth setup migration  (run once)
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--   (Or via CLI: psql "$DATABASE_URL" -f db/migrations/0001_auth_setup.sql)
--
-- WHAT IT DOES:
--   1. Adds full_name / state / tier columns to public.profiles (idempotent).
--   2. Creates an `app_role` enum + `public.user_roles` table — kept SEPARATE
--      from profiles to prevent privilege-escalation attacks.
--   3. Creates `public.has_role()` SECURITY DEFINER helper for RLS policies.
--   4. Creates a `handle_new_user()` AFTER INSERT trigger on auth.users that
--      auto-creates the profile row from raw_user_meta_data (full_name, state,
--      tier) and assigns the default 'member' role. Frontend just calls
--      supabase.auth.signUp() with options.data — no client-side insert needed.
--   5. Enables RLS on profiles + user_roles with owner / admin policies.
--   6. updated_at touch trigger on profiles.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Membership tier enum -----------------------------------------------------
do $$ begin
  create type public.membership_tier as enum ('free', 'paid', 'annual', 'vip');
exception when duplicate_object then null; end $$;

-- 2. Profiles columns ---------------------------------------------------------
alter table public.profiles
  add column if not exists full_name text,
  add column if not exists email      text,
  add column if not exists state      text,
  add column if not exists tier       public.membership_tier not null default 'free',
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

-- Backfill email for any existing rows.
update public.profiles p
   set email = u.email
  from auth.users u
 where p.id = u.id and p.email is null;

-- 3. Role enum + user_roles ---------------------------------------------------
do $$ begin
  create type public.app_role as enum ('admin', 'member');
exception when duplicate_object then null; end $$;

create table if not exists public.user_roles (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  role       public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  );
$$;

-- 4. handle_new_user trigger --------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  meta_tier public.membership_tier;
begin
  begin
    meta_tier := coalesce(
      (new.raw_user_meta_data ->> 'tier')::public.membership_tier,
      'free'::public.membership_tier
    );
  exception when others then
    meta_tier := 'free';
  end;

  insert into public.profiles (id, email, full_name, state, tier)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    nullif(new.raw_user_meta_data ->> 'state', ''),
    meta_tier
  )
  on conflict (id) do update
    set email     = excluded.email,
        full_name = coalesce(excluded.full_name, public.profiles.full_name),
        state     = coalesce(excluded.state, public.profiles.state),
        tier      = excluded.tier;

  insert into public.user_roles (user_id, role)
  values (new.id, 'member')
  on conflict do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 5. RLS policies -------------------------------------------------------------
alter table public.profiles enable row level security;

drop policy if exists "Profiles are viewable by owner" on public.profiles;
create policy "Profiles are viewable by owner"
  on public.profiles for select
  using (auth.uid() = id or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Profiles updatable by owner" on public.profiles;
create policy "Profiles updatable by owner"
  on public.profiles for update
  using (auth.uid() = id or public.has_role(auth.uid(), 'admin'))
  with check (auth.uid() = id or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users read own roles" on public.user_roles;
create policy "Users read own roles"
  on public.user_roles for select
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Only admins manage roles" on public.user_roles;
create policy "Only admins manage roles"
  on public.user_roles for all
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 6. updated_at touch ---------------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at
  before update on public.profiles
  for each row execute function public.touch_updated_at();
