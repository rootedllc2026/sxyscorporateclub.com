-- 0009_videos_events_backfill.sql
-- Defensive backfill: when 0008 ran partially (table already existed from an
-- earlier attempt), some columns may be missing. Add them idempotently.

-- ─── videos ────────────────────────────────────────────────────────────────
alter table public.videos
  add column if not exists description text,
  add column if not exists icon_emoji text not null default '▣',
  add column if not exists thumbnail_url text,
  add column if not exists video_url text,
  add column if not exists duration_seconds integer not null default 0,
  add column if not exists series text not null default 'business-bites',
  add column if not exists category text,
  add column if not exists access_level text not null default 'free',
  add column if not exists view_count integer not null default 0,
  add column if not exists save_count integer not null default 0,
  add column if not exists is_featured boolean not null default false,
  add column if not exists is_published boolean not null default false,
  add column if not exists notify_on_publish boolean not null default false,
  add column if not exists created_by uuid references auth.users(id) on delete set null,
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

-- ─── events ────────────────────────────────────────────────────────────────
alter table public.events
  add column if not exists description text,
  add column if not exists icon_emoji text not null default '✦',
  add column if not exists host_name text,
  add column if not exists starts_at timestamptz,
  add column if not exists duration_min integer not null default 60,
  add column if not exists platform text,
  add column if not exists join_url text,
  add column if not exists access_level text not null default 'free',
  add column if not exists archive_recording boolean not null default true,
  add column if not exists notify_members boolean not null default true,
  add column if not exists post_to_general boolean not null default true,
  add column if not exists recording_url text,
  add column if not exists created_by uuid references auth.users(id) on delete set null,
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

-- Refresh PostgREST schema cache so the API picks up new columns immediately.
notify pgrst, 'reload schema';
