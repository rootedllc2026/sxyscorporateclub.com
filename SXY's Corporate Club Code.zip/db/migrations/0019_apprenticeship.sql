-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Apprenticeship module
--
-- Lets paid+ members publish apprenticeship programs, accept applications
-- from any signed-in member, and then run a private portal with milestones
-- and a message thread between owner + selected apprentice.
--
-- Tables:
--   apprenticeship_programs           — listings (owner = creator)
--   apprenticeship_applications       — submissions from applicants
--   apprenticeships                   — accepted programs (owner + apprentice)
--   apprenticeship_milestones         — progress tracker
--   apprenticeship_messages           — portal thread
--
-- Storage:
--   apprentice-uploads (private)      — resumes / video intros / portfolio files
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Programs -----------------------------------------------------------------
create table if not exists public.apprenticeship_programs (
  id                       uuid primary key default gen_random_uuid(),
  owner_id                 uuid not null references auth.users(id) on delete cascade,
  title                    text not null check (char_length(title) between 3 and 200),
  summary                  text not null check (char_length(summary) between 10 and 500),
  description              text not null check (char_length(description) between 10 and 8000),
  industry                 text,
  location                 text,
  duration_weeks           int check (duration_weeks between 1 and 104),
  stipend_description      text,
  start_date               date,
  -- Which application fields the owner requires from applicants:
  require_cover_note       boolean not null default true,
  require_resume           boolean not null default true,
  require_video            boolean not null default false,
  require_portfolio        boolean not null default false,
  structured_questions     jsonb not null default '[]'::jsonb,
  status                   text not null default 'open'
    check (status in ('draft', 'open', 'closed', 'archived')),
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

create index if not exists apprenticeship_programs_owner_idx
  on public.apprenticeship_programs (owner_id);
create index if not exists apprenticeship_programs_status_idx
  on public.apprenticeship_programs (status);

grant select, insert, update, delete on public.apprenticeship_programs to authenticated;
grant all on public.apprenticeship_programs to service_role;

alter table public.apprenticeship_programs enable row level security;

drop policy if exists "Anyone authed reads open programs" on public.apprenticeship_programs;
create policy "Anyone authed reads open programs"
  on public.apprenticeship_programs for select
  to authenticated
  using (status in ('open', 'closed') or owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Owners create programs" on public.apprenticeship_programs;
create policy "Owners create programs"
  on public.apprenticeship_programs for insert
  to authenticated
  with check (owner_id = auth.uid());

drop policy if exists "Owners update own programs" on public.apprenticeship_programs;
create policy "Owners update own programs"
  on public.apprenticeship_programs for update
  to authenticated
  using (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Owners delete own programs" on public.apprenticeship_programs;
create policy "Owners delete own programs"
  on public.apprenticeship_programs for delete
  to authenticated
  using (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop trigger if exists apprenticeship_programs_touch on public.apprenticeship_programs;
create trigger apprenticeship_programs_touch
  before update on public.apprenticeship_programs
  for each row execute function public.touch_updated_at();

-- 2. Applications -------------------------------------------------------------
create table if not exists public.apprenticeship_applications (
  id                       uuid primary key default gen_random_uuid(),
  program_id               uuid not null references public.apprenticeship_programs(id) on delete cascade,
  applicant_id             uuid not null references auth.users(id) on delete cascade,
  cover_note               text,
  resume_path              text,
  video_path               text,
  portfolio_links          jsonb not null default '[]'::jsonb,
  structured_answers       jsonb not null default '[]'::jsonb,
  status                   text not null default 'pending'
    check (status in ('pending', 'accepted', 'rejected', 'withdrawn')),
  decided_at               timestamptz,
  decision_note            text,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now(),
  unique (program_id, applicant_id)
);

create index if not exists apprenticeship_applications_program_idx
  on public.apprenticeship_applications (program_id);
create index if not exists apprenticeship_applications_applicant_idx
  on public.apprenticeship_applications (applicant_id);

grant select, insert, update, delete on public.apprenticeship_applications to authenticated;
grant all on public.apprenticeship_applications to service_role;

alter table public.apprenticeship_applications enable row level security;

drop policy if exists "Applicant + program owner read apps" on public.apprenticeship_applications;
create policy "Applicant + program owner read apps"
  on public.apprenticeship_applications for select
  to authenticated
  using (
    applicant_id = auth.uid()
    or exists (
      select 1 from public.apprenticeship_programs p
      where p.id = program_id and p.owner_id = auth.uid()
    )
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Applicants insert own application" on public.apprenticeship_applications;
create policy "Applicants insert own application"
  on public.apprenticeship_applications for insert
  to authenticated
  with check (applicant_id = auth.uid());

drop policy if exists "Applicant or owner update application" on public.apprenticeship_applications;
create policy "Applicant or owner update application"
  on public.apprenticeship_applications for update
  to authenticated
  using (
    applicant_id = auth.uid()
    or exists (
      select 1 from public.apprenticeship_programs p
      where p.id = program_id and p.owner_id = auth.uid()
    )
    or public.has_role(auth.uid(), 'admin')
  )
  with check (
    applicant_id = auth.uid()
    or exists (
      select 1 from public.apprenticeship_programs p
      where p.id = program_id and p.owner_id = auth.uid()
    )
    or public.has_role(auth.uid(), 'admin')
  );

drop trigger if exists apprenticeship_applications_touch on public.apprenticeship_applications;
create trigger apprenticeship_applications_touch
  before update on public.apprenticeship_applications
  for each row execute function public.touch_updated_at();

-- 3. Active apprenticeships (accepted) ----------------------------------------
create table if not exists public.apprenticeships (
  id                       uuid primary key default gen_random_uuid(),
  program_id               uuid not null references public.apprenticeship_programs(id) on delete cascade,
  application_id           uuid not null unique references public.apprenticeship_applications(id) on delete cascade,
  owner_id                 uuid not null references auth.users(id) on delete cascade,
  apprentice_id            uuid not null references auth.users(id) on delete cascade,
  status                   text not null default 'active'
    check (status in ('active', 'completed', 'ended')),
  started_at               timestamptz not null default now(),
  completed_at             timestamptz,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

create index if not exists apprenticeships_owner_idx on public.apprenticeships (owner_id);
create index if not exists apprenticeships_apprentice_idx on public.apprenticeships (apprentice_id);

grant select, insert, update, delete on public.apprenticeships to authenticated;
grant all on public.apprenticeships to service_role;

alter table public.apprenticeships enable row level security;

drop policy if exists "Participants + admin read apprenticeship" on public.apprenticeships;
create policy "Participants + admin read apprenticeship"
  on public.apprenticeships for select
  to authenticated
  using (
    owner_id = auth.uid()
    or apprentice_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Owner creates apprenticeship" on public.apprenticeships;
create policy "Owner creates apprenticeship"
  on public.apprenticeships for insert
  to authenticated
  with check (owner_id = auth.uid());

drop policy if exists "Participants update apprenticeship" on public.apprenticeships;
create policy "Participants update apprenticeship"
  on public.apprenticeships for update
  to authenticated
  using (owner_id = auth.uid() or apprentice_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (owner_id = auth.uid() or apprentice_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop trigger if exists apprenticeships_touch on public.apprenticeships;
create trigger apprenticeships_touch
  before update on public.apprenticeships
  for each row execute function public.touch_updated_at();

-- 4. Milestones ---------------------------------------------------------------
create table if not exists public.apprenticeship_milestones (
  id                       uuid primary key default gen_random_uuid(),
  apprenticeship_id        uuid not null references public.apprenticeships(id) on delete cascade,
  title                    text not null check (char_length(title) between 1 and 200),
  description              text,
  due_date                 date,
  status                   text not null default 'pending'
    check (status in ('pending', 'in_progress', 'submitted', 'approved')),
  sort_order               int not null default 0,
  submitted_at             timestamptz,
  approved_at              timestamptz,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

create index if not exists apprenticeship_milestones_appr_idx
  on public.apprenticeship_milestones (apprenticeship_id);

grant select, insert, update, delete on public.apprenticeship_milestones to authenticated;
grant all on public.apprenticeship_milestones to service_role;

alter table public.apprenticeship_milestones enable row level security;

drop policy if exists "Participants read milestones" on public.apprenticeship_milestones;
create policy "Participants read milestones"
  on public.apprenticeship_milestones for select
  to authenticated
  using (
    exists (
      select 1 from public.apprenticeships a
      where a.id = apprenticeship_id
        and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid())
    )
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Participants insert milestones" on public.apprenticeship_milestones;
create policy "Participants insert milestones"
  on public.apprenticeship_milestones for insert
  to authenticated
  with check (
    exists (
      select 1 from public.apprenticeships a
      where a.id = apprenticeship_id
        and a.owner_id = auth.uid()
    )
  );

drop policy if exists "Participants update milestones" on public.apprenticeship_milestones;
create policy "Participants update milestones"
  on public.apprenticeship_milestones for update
  to authenticated
  using (
    exists (
      select 1 from public.apprenticeships a
      where a.id = apprenticeship_id
        and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid())
    )
  )
  with check (
    exists (
      select 1 from public.apprenticeships a
      where a.id = apprenticeship_id
        and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid())
    )
  );

drop policy if exists "Owner deletes milestones" on public.apprenticeship_milestones;
create policy "Owner deletes milestones"
  on public.apprenticeship_milestones for delete
  to authenticated
  using (
    exists (
      select 1 from public.apprenticeships a
      where a.id = apprenticeship_id and a.owner_id = auth.uid()
    )
  );

drop trigger if exists apprenticeship_milestones_touch on public.apprenticeship_milestones;
create trigger apprenticeship_milestones_touch
  before update on public.apprenticeship_milestones
  for each row execute function public.touch_updated_at();

-- 5. Messages -----------------------------------------------------------------
create table if not exists public.apprenticeship_messages (
  id                       uuid primary key default gen_random_uuid(),
  apprenticeship_id        uuid not null references public.apprenticeships(id) on delete cascade,
  sender_id                uuid not null references auth.users(id) on delete cascade,
  body                     text not null check (char_length(body) between 1 and 4000),
  created_at               timestamptz not null default now()
);

create index if not exists apprenticeship_messages_appr_idx
  on public.apprenticeship_messages (apprenticeship_id, created_at);

grant select, insert on public.apprenticeship_messages to authenticated;
grant all on public.apprenticeship_messages to service_role;

alter table public.apprenticeship_messages enable row level security;

drop policy if exists "Participants read messages" on public.apprenticeship_messages;
create policy "Participants read messages"
  on public.apprenticeship_messages for select
  to authenticated
  using (
    exists (
      select 1 from public.apprenticeships a
      where a.id = apprenticeship_id
        and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid())
    )
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Participants send messages" on public.apprenticeship_messages;
create policy "Participants send messages"
  on public.apprenticeship_messages for insert
  to authenticated
  with check (
    sender_id = auth.uid()
    and exists (
      select 1 from public.apprenticeships a
      where a.id = apprenticeship_id
        and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid())
    )
  );

-- 6. Storage bucket -----------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('apprentice-uploads', 'apprentice-uploads', false)
on conflict (id) do nothing;

-- Path convention: <applicant_id>/<program_id>/<filename>
-- Applicant may write/read own folder. Program owner may read any file
-- belonging to an application submitted to their program.
drop policy if exists "Applicants upload own files" on storage.objects;
create policy "Applicants upload own files"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'apprentice-uploads'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "Applicants + program owner read uploads" on storage.objects;
create policy "Applicants + program owner read uploads"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'apprentice-uploads'
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or exists (
        select 1
        from public.apprenticeship_applications app
        join public.apprenticeship_programs p on p.id = app.program_id
        where (storage.foldername(name))[1] = app.applicant_id::text
          and (storage.foldername(name))[2] = p.id::text
          and p.owner_id = auth.uid()
      )
      or public.has_role(auth.uid(), 'admin')
    )
  );

drop policy if exists "Applicants delete own uploads" on storage.objects;
create policy "Applicants delete own uploads"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'apprentice-uploads'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
