-- Intake submissions captured from the public /intake form on
-- sxyscorporateclub.com (and the legacy sasha-intake.html on
-- sxysinvestors.com which now POSTs here too).
--
-- Anyone — logged in or not — can INSERT a row. Only admins can read /
-- update them. The form server route validates input shape before insert.

create table if not exists public.intake_submissions (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  phone text,
  business_name text,
  service_interest text not null,
  message text,
  preferred_contact text not null default 'email',
  submitted_at timestamptz not null default now(),
  status text not null default 'new'
);

create index if not exists intake_submissions_submitted_at_idx
  on public.intake_submissions (submitted_at desc);
create index if not exists intake_submissions_status_idx
  on public.intake_submissions (status);

alter table public.intake_submissions enable row level security;

-- Public can submit (anonymous + authenticated)
drop policy if exists "intake_submissions_public_insert" on public.intake_submissions;
create policy "intake_submissions_public_insert"
  on public.intake_submissions
  for insert
  to anon, authenticated
  with check (true);

-- Only admins can read submissions
drop policy if exists "intake_submissions_admin_select" on public.intake_submissions;
create policy "intake_submissions_admin_select"
  on public.intake_submissions
  for select
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- Only admins can update status (e.g. mark as contacted)
drop policy if exists "intake_submissions_admin_update" on public.intake_submissions;
create policy "intake_submissions_admin_update"
  on public.intake_submissions
  for update
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));
