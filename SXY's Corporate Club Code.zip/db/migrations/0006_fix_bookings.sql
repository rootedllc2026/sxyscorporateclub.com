-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Fix: ensure bookings table & columns exist
--
-- WHY THIS EXISTS:
--   When migration 0004 was applied, the `public.bookings` table appears to
--   have been left in an incomplete state (missing `buyer_id` column),
--   which then caused:
--     • 0004 referral policies to fail   (column "buyer_id" does not exist)
--     • 0005 stripe index to fail        (column "payment_intent_id" does not exist)
--
--   This migration is fully idempotent — it brings any partial bookings table
--   up to the expected schema, then re-applies the policies / indexes from
--   0004 and 0005 that depend on it.
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--   3. Then re-run db/migrations/0005_stripe_integration.sql (it will now succeed).
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Make sure required enums exist (safe re-creates) ------------------------
do $$ begin
  create type public.booking_status as enum (
    'pending_payment', 'confirmed', 'completed', 'cancelled', 'refunded'
  );
exception when duplicate_object then null; end $$;

-- 2. Create bookings table if it's missing entirely --------------------------
create table if not exists public.bookings (
  id                  uuid primary key default gen_random_uuid(),
  business_page_id    uuid not null references public.business_pages(id) on delete cascade,
  service_id          uuid references public.referral_services(id) on delete set null,
  buyer_id            uuid not null references auth.users(id) on delete cascade,
  provider_id         uuid not null references auth.users(id) on delete cascade,
  booked_date         date not null,
  booked_time         time,
  notes               text,
  service_amount      numeric(12,2) not null default 0,
  platform_fee        numeric(12,2) not null default 0,
  net_to_provider     numeric(12,2) not null default 0,
  total_amount        numeric(12,2) not null default 0,
  status              public.booking_status not null default 'pending_payment',
  payment_intent_id   text,
  paid_at             timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- 3. Patch any missing columns on a pre-existing partial table ---------------
alter table public.bookings
  add column if not exists business_page_id  uuid references public.business_pages(id) on delete cascade,
  add column if not exists service_id        uuid references public.referral_services(id) on delete set null,
  add column if not exists buyer_id          uuid references auth.users(id) on delete cascade,
  add column if not exists provider_id       uuid references auth.users(id) on delete cascade,
  add column if not exists booked_date       date,
  add column if not exists booked_time       time,
  add column if not exists notes             text,
  add column if not exists service_amount    numeric(12,2) not null default 0,
  add column if not exists platform_fee      numeric(12,2) not null default 0,
  add column if not exists net_to_provider   numeric(12,2) not null default 0,
  add column if not exists total_amount      numeric(12,2) not null default 0,
  add column if not exists status            public.booking_status not null default 'pending_payment',
  add column if not exists payment_intent_id text,
  add column if not exists paid_at           timestamptz,
  add column if not exists created_at        timestamptz not null default now(),
  add column if not exists updated_at        timestamptz not null default now();

-- 4. Indexes -----------------------------------------------------------------
create index if not exists bookings_page_idx           on public.bookings (business_page_id);
create index if not exists bookings_buyer_idx          on public.bookings (buyer_id);
create index if not exists bookings_provider_idx       on public.bookings (provider_id);
create index if not exists bookings_date_idx           on public.bookings (booked_date);
create index if not exists bookings_status_idx         on public.bookings (status);
create index if not exists bookings_payment_intent_idx
  on public.bookings (payment_intent_id)
  where payment_intent_id is not null;

-- 5. RLS ---------------------------------------------------------------------
alter table public.bookings enable row level security;

drop policy if exists "Buyer + provider read bookings" on public.bookings;
create policy "Buyer + provider read bookings"
  on public.bookings for select
  to authenticated
  using (
    buyer_id = auth.uid()
    or provider_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Buyers create own bookings" on public.bookings;
create policy "Buyers create own bookings"
  on public.bookings for insert
  to authenticated
  with check (buyer_id = auth.uid());

drop policy if exists "Buyer provider admin update bookings" on public.bookings;
create policy "Buyer provider admin update bookings"
  on public.bookings for update
  to authenticated
  using (
    buyer_id = auth.uid()
    or provider_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  )
  with check (
    buyer_id = auth.uid()
    or provider_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

-- 6. updated_at trigger ------------------------------------------------------
drop trigger if exists bookings_touch_updated_at on public.bookings;
create trigger bookings_touch_updated_at
  before update on public.bookings
  for each row execute function public.touch_updated_at();
