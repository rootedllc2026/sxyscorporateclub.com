-- 0017 — Prevent client-side tier escalation on profiles
--
-- Why:
--   The "Profiles updatable by owner" RLS policy lets a user update any column
--   on their own profile row, including `tier`. Without a guard, anyone with
--   the publishable Supabase key could call the REST API to set tier='vip'
--   without paying. The Stripe webhook (which assigns paid tiers) runs as
--   service_role and bypasses this trigger, so it remains unaffected.
--
-- What:
--   A BEFORE UPDATE trigger that raises an exception if `tier` changes and
--   the caller is not the service_role (i.e. not the Stripe webhook / admin
--   server function).

create or replace function public.prevent_self_tier_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Allow service_role (Stripe webhook, server-side admin paths) to change tier.
  if current_setting('role', true) = 'service_role' then
    return new;
  end if;

  -- Allow admins via has_role() check.
  if public.has_role(auth.uid(), 'admin') then
    return new;
  end if;

  -- Block any other tier change.
  if new.tier is distinct from old.tier then
    raise exception 'Tier changes are not permitted from the client. Use checkout to upgrade or contact support to downgrade.'
      using errcode = '42501';
  end if;

  return new;
end;
$$;

drop trigger if exists profiles_prevent_tier_change on public.profiles;
create trigger profiles_prevent_tier_change
  before update on public.profiles
  for each row
  execute function public.prevent_self_tier_change();
