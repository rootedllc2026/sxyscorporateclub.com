-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Referral Portal module
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--
-- WHAT IT DOES:
--   1. Creates referral category enum + page status enum.
--   2. Creates business_pages, services, reviews, bookings, payouts tables.
--   3. Adds the 'business-pages' storage bucket (public for logos/banners).
--   4. Adds RLS policies — public can read live pages/services/reviews,
--      owners manage their own page + services + payouts, bookings are
--      private to the buyer + provider + admin.
--   5. Adds a public.referrals_directory view used by the directory page.
--   6. All `if not exists` / `drop policy if exists` calls — safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Enums --------------------------------------------------------------------
do $$ begin
  create type public.referral_category as enum (
    'cleaning', 'contractor', 'strategy', 'marketing',
    'legal', 'tech_ai', 'other'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.business_page_status as enum ('pending', 'live', 'draft', 'archived');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.booking_status as enum (
    'pending_payment', 'confirmed', 'completed', 'cancelled', 'refunded'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.payout_status as enum ('requested', 'processing', 'paid', 'rejected');
exception when duplicate_object then null; end $$;

-- 2. business_pages -----------------------------------------------------------
create table if not exists public.business_pages (
  id                    uuid primary key default gen_random_uuid(),
  owner_id              uuid not null references auth.users(id) on delete cascade,
  business_name         text not null,
  category              public.referral_category not null default 'other',
  icon_emoji            text,
  description           text,
  service_area          text,
  website_url           text,
  logo_url              text,
  banner_color          text,                       -- e.g. 'teal' / hex / oklch
  starting_price        numeric(12,2),
  platform_fee_pct      numeric(5,2) not null default 10.0,
  -- Booking settings
  available_days        text[] not null default '{}', -- e.g. {Mon,Tue,...}
  start_time            time,
  end_time              time,
  session_length_min    int default 60,
  booking_lead_hours    int default 24,
  require_intake_form   boolean not null default false,
  allow_virtual         boolean not null default true,
  require_deposit       boolean not null default false,
  -- Display / status
  is_featured           boolean not null default false,
  status                public.business_page_status not null default 'pending',
  -- Aggregates (denormalized — updated by app code)
  total_bookings        int not null default 0,
  total_reviews         int not null default 0,
  avg_rating            numeric(3,2),
  total_revenue         numeric(12,2) not null default 0,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

-- Heal partial/legacy installs: CREATE TABLE IF NOT EXISTS does not add columns
-- to an existing table, so ensure every column used by policies/views exists.
alter table public.business_pages
  add column if not exists owner_id              uuid references auth.users(id) on delete cascade,
  add column if not exists business_name         text,
  add column if not exists category              public.referral_category not null default 'other',
  add column if not exists icon_emoji            text,
  add column if not exists description           text,
  add column if not exists service_area          text,
  add column if not exists website_url           text,
  add column if not exists logo_url              text,
  add column if not exists banner_color          text,
  add column if not exists starting_price        numeric(12,2),
  add column if not exists platform_fee_pct      numeric(5,2) not null default 10.0,
  add column if not exists available_days        text[] not null default '{}',
  add column if not exists start_time            time,
  add column if not exists end_time              time,
  add column if not exists session_length_min    int default 60,
  add column if not exists booking_lead_hours    int default 24,
  add column if not exists require_intake_form   boolean not null default false,
  add column if not exists allow_virtual         boolean not null default true,
  add column if not exists require_deposit       boolean not null default false,
  add column if not exists is_featured           boolean not null default false,
  add column if not exists status                public.business_page_status not null default 'pending',
  add column if not exists total_bookings        int not null default 0,
  add column if not exists total_reviews         int not null default 0,
  add column if not exists avg_rating            numeric(3,2),
  add column if not exists total_revenue         numeric(12,2) not null default 0,
  add column if not exists created_at            timestamptz not null default now(),
  add column if not exists updated_at            timestamptz not null default now();

create index if not exists business_pages_owner_idx    on public.business_pages (owner_id);
create index if not exists business_pages_status_idx   on public.business_pages (status);
create index if not exists business_pages_category_idx on public.business_pages (category);

alter table public.business_pages enable row level security;

drop policy if exists "Anyone reads live business pages" on public.business_pages;
create policy "Anyone reads live business pages"
  on public.business_pages for select
  to authenticated
  using (
    status = 'live'
    or owner_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Members create own business page" on public.business_pages;
create policy "Members create own business page"
  on public.business_pages for insert
  to authenticated
  with check (owner_id = auth.uid());

drop policy if exists "Owners update own business page" on public.business_pages;
create policy "Owners update own business page"
  on public.business_pages for update
  to authenticated
  using (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins delete business pages" on public.business_pages;
create policy "Admins delete business pages"
  on public.business_pages for delete
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- 3. services -----------------------------------------------------------------
create table if not exists public.referral_services (
  id               uuid primary key default gen_random_uuid(),
  business_page_id uuid not null references public.business_pages(id) on delete cascade,
  name             text not null,
  description      text,
  price            numeric(12,2) not null default 0,
  duration_min     int,
  sort_order       int not null default 0,
  is_active        boolean not null default true,
  created_at       timestamptz not null default now()
);

create index if not exists referral_services_page_idx on public.referral_services (business_page_id);

alter table public.referral_services enable row level security;

drop policy if exists "Anyone reads services of live pages" on public.referral_services;
create policy "Anyone reads services of live pages"
  on public.referral_services for select
  to authenticated
  using (
    exists (
      select 1 from public.business_pages bp
      where bp.id = business_page_id
        and (bp.status = 'live' or bp.owner_id = auth.uid()
             or public.has_role(auth.uid(), 'admin'))
    )
  );

drop policy if exists "Owners manage own services" on public.referral_services;
create policy "Owners manage own services"
  on public.referral_services for all
  to authenticated
  using (
    exists (
      select 1 from public.business_pages bp
      where bp.id = business_page_id
        and (bp.owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
    )
  )
  with check (
    exists (
      select 1 from public.business_pages bp
      where bp.id = business_page_id
        and (bp.owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
    )
  );

-- 4. reviews ------------------------------------------------------------------
create table if not exists public.referral_reviews (
  id               uuid primary key default gen_random_uuid(),
  business_page_id uuid not null references public.business_pages(id) on delete cascade,
  reviewer_id      uuid not null references auth.users(id) on delete cascade,
  rating           int not null check (rating between 1 and 5),
  body             text,
  created_at       timestamptz not null default now(),
  unique (business_page_id, reviewer_id)
);

create index if not exists referral_reviews_page_idx on public.referral_reviews (business_page_id);

alter table public.referral_reviews enable row level security;

drop policy if exists "Anyone reads reviews of live pages" on public.referral_reviews;
create policy "Anyone reads reviews of live pages"
  on public.referral_reviews for select
  to authenticated
  using (
    exists (
      select 1 from public.business_pages bp
      where bp.id = business_page_id and bp.status = 'live'
    )
    or reviewer_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Reviewers insert own reviews" on public.referral_reviews;
create policy "Reviewers insert own reviews"
  on public.referral_reviews for insert
  to authenticated
  with check (reviewer_id = auth.uid());

drop policy if exists "Reviewers update own reviews" on public.referral_reviews;
create policy "Reviewers update own reviews"
  on public.referral_reviews for update
  to authenticated
  using (reviewer_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (reviewer_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Reviewers delete own reviews" on public.referral_reviews;
create policy "Reviewers delete own reviews"
  on public.referral_reviews for delete
  to authenticated
  using (reviewer_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- 5. bookings -----------------------------------------------------------------
create table if not exists public.bookings (
  id                  uuid primary key default gen_random_uuid(),
  business_page_id    uuid not null references public.business_pages(id) on delete cascade,
  service_id          uuid references public.referral_services(id) on delete set null,
  buyer_id            uuid not null references auth.users(id) on delete cascade,
  provider_id         uuid not null references auth.users(id) on delete cascade,
  booked_date         date not null,
  booked_time         time,
  notes               text,
  service_amount      numeric(12,2) not null default 0,
  platform_fee        numeric(12,2) not null default 0,
  net_to_provider     numeric(12,2) not null default 0,
  total_amount        numeric(12,2) not null default 0,
  status              public.booking_status not null default 'pending_payment',
  payment_intent_id   text,                   -- Stripe PaymentIntent id (set in step 2)
  paid_at             timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create index if not exists bookings_page_idx     on public.bookings (business_page_id);
create index if not exists bookings_buyer_idx    on public.bookings (buyer_id);
create index if not exists bookings_provider_idx on public.bookings (provider_id);
create index if not exists bookings_date_idx     on public.bookings (booked_date);
create index if not exists bookings_status_idx   on public.bookings (status);

alter table public.bookings enable row level security;

drop policy if exists "Buyer + provider read bookings" on public.bookings;
create policy "Buyer + provider read bookings"
  on public.bookings for select
  to authenticated
  using (
    buyer_id = auth.uid()
    or provider_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Buyers create own bookings" on public.bookings;
create policy "Buyers create own bookings"
  on public.bookings for insert
  to authenticated
  with check (buyer_id = auth.uid());

drop policy if exists "Buyer provider admin update bookings" on public.bookings;
create policy "Buyer provider admin update bookings"
  on public.bookings for update
  to authenticated
  using (
    buyer_id = auth.uid()
    or provider_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  )
  with check (
    buyer_id = auth.uid()
    or provider_id = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

-- 6. payouts ------------------------------------------------------------------
create table if not exists public.payouts (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  amount       numeric(12,2) not null check (amount > 0),
  method       text,                       -- e.g. 'stripe', 'bank', 'paypal'
  destination  text,                       -- masked account / email
  notes        text,
  status       public.payout_status not null default 'requested',
  requested_at timestamptz not null default now(),
  processed_at timestamptz,
  created_at   timestamptz not null default now()
);

-- Heal partial/legacy payouts tables before indexes and policies reference user_id.
do $$ begin
  if to_regclass('public.payouts') is not null then
    drop policy if exists "Users read own payouts" on public.payouts;
    drop policy if exists "Users request own payouts" on public.payouts;
    drop policy if exists "Admins manage payouts" on public.payouts;
  end if;

  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'payouts' and column_name = 'user_id'
  ) then
    alter table public.payouts add column user_id uuid references auth.users(id) on delete cascade;
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'payouts' and column_name = 'member_id'
  ) then
    execute 'update public.payouts set user_id = member_id where user_id is null and member_id is not null';
    alter table public.payouts drop column if exists member_id;
  end if;
end $$;

alter table public.payouts
  add column if not exists user_id      uuid references auth.users(id) on delete cascade,
  add column if not exists amount       numeric(12,2) not null default 0,
  add column if not exists method       text,
  add column if not exists destination  text,
  add column if not exists notes        text,
  add column if not exists status       public.payout_status not null default 'requested',
  add column if not exists requested_at timestamptz not null default now(),
  add column if not exists processed_at timestamptz,
  add column if not exists created_at   timestamptz not null default now();

create index if not exists payouts_user_idx   on public.payouts (user_id);
create index if not exists payouts_status_idx on public.payouts (status);

alter table public.payouts enable row level security;

drop policy if exists "Users read own payouts" on public.payouts;
create policy "Users read own payouts"
  on public.payouts for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users request own payouts" on public.payouts;
create policy "Users request own payouts"
  on public.payouts for insert
  to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Admins manage payouts" on public.payouts;
create policy "Admins manage payouts"
  on public.payouts for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 7. Touch updated_at on business_pages + bookings ---------------------------
drop trigger if exists business_pages_touch_updated_at on public.business_pages;
create trigger business_pages_touch_updated_at
  before update on public.business_pages
  for each row execute function public.touch_updated_at();

drop trigger if exists bookings_touch_updated_at on public.bookings;
create trigger bookings_touch_updated_at
  before update on public.bookings
  for each row execute function public.touch_updated_at();

-- 8. Directory view -----------------------------------------------------------
drop view if exists public.referrals_directory;
create view public.referrals_directory as
select
  bp.id,
  bp.owner_id,
  bp.business_name,
  bp.category,
  bp.icon_emoji,
  bp.description,
  bp.service_area,
  bp.website_url,
  bp.logo_url,
  bp.banner_color,
  bp.starting_price,
  bp.platform_fee_pct,
  bp.is_featured,
  bp.status,
  bp.total_bookings,
  bp.total_reviews,
  bp.avg_rating,
  bp.total_revenue,
  bp.created_at,
  owner.full_name as owner_name,
  owner.city      as owner_city,
  owner.state     as owner_state,
  owner.avatar_color as owner_avatar_color
from public.business_pages bp
left join public.profiles owner on owner.id = bp.owner_id;

grant select on public.referrals_directory to authenticated;

-- 9. Storage bucket: business-pages (public — logos & banners) ---------------
insert into storage.buckets (id, name, public)
values ('business-pages', 'business-pages', true)
on conflict (id) do nothing;

-- Path convention: {owner_id}/{filename}
drop policy if exists "Owners upload to own folder business-pages" on storage.objects;
create policy "Owners upload to own folder business-pages"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'business-pages'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "Anyone reads business-pages assets" on storage.objects;
create policy "Anyone reads business-pages assets"
  on storage.objects for select
  to public
  using (bucket_id = 'business-pages');

drop policy if exists "Owners update own business-pages assets" on storage.objects;
create policy "Owners update own business-pages assets"
  on storage.objects for update
  to authenticated
  using (
    bucket_id = 'business-pages'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "Owners delete own business-pages assets" on storage.objects;
create policy "Owners delete own business-pages assets"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'business-pages'
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or public.has_role(auth.uid(), 'admin')
    )
  );
