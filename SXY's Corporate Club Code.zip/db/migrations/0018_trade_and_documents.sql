-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Club Directory: trade payments + booking documents
--
-- Adds:
--   1. payment_method column on bookings ('card' | 'trade')
--   2. New booking_status values 'pending_agreement' and 'agreement_declined'
--   3. trade_agreements table (one per trade-payment booking, both parties accept)
--   4. booking_documents table (service agreements, invoices, POs)
--   5. Storage bucket 'booking-documents' (private) with RLS scoped to booking
--      participants and admins.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. New booking_status enum values --------------------------------------------
do $$ begin
  alter type public.booking_status add value if not exists 'pending_agreement';
exception when others then null; end $$;

do $$ begin
  alter type public.booking_status add value if not exists 'agreement_declined';
exception when others then null; end $$;

-- 2. payment_method column on bookings ----------------------------------------
alter table public.bookings
  add column if not exists payment_method text not null default 'card'
    check (payment_method in ('card', 'trade'));

create index if not exists bookings_payment_method_idx
  on public.bookings (payment_method);

-- 3. trade_agreements ---------------------------------------------------------
create table if not exists public.trade_agreements (
  id                       uuid primary key default gen_random_uuid(),
  booking_id               uuid not null unique references public.bookings(id) on delete cascade,
  proposed_by_user_id      uuid not null references auth.users(id) on delete cascade,
  offered_description      text not null,
  requested_description    text not null,
  estimated_value_usd      numeric(12,2),
  buyer_accepted_at        timestamptz,
  provider_accepted_at     timestamptz,
  declined_at              timestamptz,
  declined_by_user_id      uuid references auth.users(id) on delete set null,
  decline_reason           text,
  completed_at             timestamptz,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

create index if not exists trade_agreements_booking_idx
  on public.trade_agreements (booking_id);

alter table public.trade_agreements enable row level security;

drop policy if exists "Participants + admin read trade agreements" on public.trade_agreements;
create policy "Participants + admin read trade agreements"
  on public.trade_agreements for select
  to authenticated
  using (
    exists (
      select 1 from public.bookings b
      where b.id = trade_agreements.booking_id
        and (b.buyer_id = auth.uid() or b.provider_id = auth.uid())
    )
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Buyer creates own trade agreement" on public.trade_agreements;
create policy "Buyer creates own trade agreement"
  on public.trade_agreements for insert
  to authenticated
  with check (
    proposed_by_user_id = auth.uid()
    and exists (
      select 1 from public.bookings b
      where b.id = trade_agreements.booking_id
        and b.buyer_id = auth.uid()
    )
  );

drop policy if exists "Participants update trade agreement" on public.trade_agreements;
create policy "Participants update trade agreement"
  on public.trade_agreements for update
  to authenticated
  using (
    exists (
      select 1 from public.bookings b
      where b.id = trade_agreements.booking_id
        and (b.buyer_id = auth.uid() or b.provider_id = auth.uid())
    )
    or public.has_role(auth.uid(), 'admin')
  )
  with check (
    exists (
      select 1 from public.bookings b
      where b.id = trade_agreements.booking_id
        and (b.buyer_id = auth.uid() or b.provider_id = auth.uid())
    )
    or public.has_role(auth.uid(), 'admin')
  );

drop trigger if exists trade_agreements_touch_updated_at on public.trade_agreements;
create trigger trade_agreements_touch_updated_at
  before update on public.trade_agreements
  for each row execute function public.touch_updated_at();

-- 4. booking_documents --------------------------------------------------------
create table if not exists public.booking_documents (
  id                uuid primary key default gen_random_uuid(),
  booking_id        uuid not null references public.bookings(id) on delete cascade,
  uploaded_by       uuid not null references auth.users(id) on delete cascade,
  storage_path      text not null,
  file_name         text not null,
  mime_type         text,
  size_bytes        bigint,
  doc_type          text not null default 'other'
    check (doc_type in ('agreement', 'invoice', 'purchase_order', 'other')),
  note              text,
  created_at        timestamptz not null default now()
);

create index if not exists booking_documents_booking_idx
  on public.booking_documents (booking_id);
create index if not exists booking_documents_uploader_idx
  on public.booking_documents (uploaded_by);

alter table public.booking_documents enable row level security;

drop policy if exists "Participants + admin read booking documents" on public.booking_documents;
create policy "Participants + admin read booking documents"
  on public.booking_documents for select
  to authenticated
  using (
    exists (
      select 1 from public.bookings b
      where b.id = booking_documents.booking_id
        and (b.buyer_id = auth.uid() or b.provider_id = auth.uid())
    )
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Participants insert booking documents" on public.booking_documents;
create policy "Participants insert booking documents"
  on public.booking_documents for insert
  to authenticated
  with check (
    uploaded_by = auth.uid()
    and exists (
      select 1 from public.bookings b
      where b.id = booking_documents.booking_id
        and (b.buyer_id = auth.uid() or b.provider_id = auth.uid())
    )
  );

drop policy if exists "Uploader or admin delete booking documents" on public.booking_documents;
create policy "Uploader or admin delete booking documents"
  on public.booking_documents for delete
  to authenticated
  using (
    uploaded_by = auth.uid()
    or public.has_role(auth.uid(), 'admin')
  );

-- 5. Storage bucket -----------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('booking-documents', 'booking-documents', false)
on conflict (id) do nothing;

-- Storage RLS — path convention: <booking_id>/<filename>
-- Participants (buyer/provider) of the booking can read/upload; uploader or
-- admin can delete.
drop policy if exists "Booking participants read documents" on storage.objects;
create policy "Booking participants read documents"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'booking-documents'
    and (
      exists (
        select 1 from public.bookings b
        where b.id::text = (storage.foldername(name))[1]
          and (b.buyer_id = auth.uid() or b.provider_id = auth.uid())
      )
      or public.has_role(auth.uid(), 'admin')
    )
  );

drop policy if exists "Booking participants upload documents" on storage.objects;
create policy "Booking participants upload documents"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'booking-documents'
    and exists (
      select 1 from public.bookings b
      where b.id::text = (storage.foldername(name))[1]
        and (b.buyer_id = auth.uid() or b.provider_id = auth.uid())
    )
  );

drop policy if exists "Uploader or admin delete documents" on storage.objects;
create policy "Uploader or admin delete documents"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'booking-documents'
    and (owner = auth.uid() or public.has_role(auth.uid(), 'admin'))
  );
