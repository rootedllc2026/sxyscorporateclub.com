-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Scheduled emails (one-shot per booking reminder)
--
-- Used by the 24h booking reminder pipeline:
--   1. Stripe webhook inserts a row when a booking is confirmed,
--      with send_at = booked_datetime - 24h.
--   2. A pg_cron job pings /api/public/process-scheduled-emails every minute.
--   3. The route claims due rows (status='pending', send_at <= now()),
--      sends them via Resend, and marks them 'sent' or 'failed'.
--
-- Failure is non-fatal: rows in 'failed' state are logged with last_error.
--
-- HOW TO APPLY:
--   1. Open Supabase SQL editor → New query → paste this whole file → Run.
-- ─────────────────────────────────────────────────────────────────────────────

do $$ begin
  create type public.scheduled_email_status as enum ('pending', 'sent', 'failed', 'cancelled');
exception when duplicate_object then null; end $$;

create table if not exists public.scheduled_emails (
  id           uuid primary key default gen_random_uuid(),
  -- Free-form discriminator the worker uses to pick the template.
  -- Currently supported: 'booking-reminder-24h'.
  kind         text not null,
  -- The booking, profile, or other entity this email is about. Used so the
  -- worker can re-fetch fresh data at send time (e.g. cancelled bookings).
  reference_id uuid,
  -- Recipient email address — denormalized so the row is sufficient to send.
  recipient    text not null,
  -- Arbitrary JSON payload the worker reads to compose the body.
  payload      jsonb not null default '{}'::jsonb,
  send_at      timestamptz not null,
  status       public.scheduled_email_status not null default 'pending',
  attempts     int  not null default 0,
  last_error   text,
  sent_at      timestamptz,
  created_at   timestamptz not null default now()
);

create index if not exists scheduled_emails_due_idx
  on public.scheduled_emails (send_at)
  where status = 'pending';

create index if not exists scheduled_emails_reference_idx
  on public.scheduled_emails (reference_id);

-- RLS: locked down. Only the service role (used by webhook + cron route)
-- ever reads/writes this table. No client policies needed.
alter table public.scheduled_emails enable row level security;
