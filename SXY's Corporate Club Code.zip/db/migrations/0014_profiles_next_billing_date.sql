-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — profiles.next_billing_date
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--
-- WHAT IT DOES:
--   Adds next_billing_date (timestamptz) to public.profiles so the Stripe
--   webhook can record subscription.current_period_end on subscription.created
--   and subscription.updated events. Idempotent.
-- ─────────────────────────────────────────────────────────────────────────────

alter table public.profiles
  add column if not exists next_billing_date timestamptz;
