-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Stripe integration columns
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--
-- WHAT IT DOES:
--   1. Adds stripe_customer_id + stripe_subscription_id + subscription_status
--      to public.profiles so the webhook can sync membership tier on
--      customer.subscription.* events.
--   2. Adds an index on stripe_customer_id (used by the webhook's lookup).
--   3. Adds an index on bookings.payment_intent_id (used by the webhook's
--      lookup when a payment_intent.succeeded / failed event arrives).
--   All idempotent — safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

alter table public.profiles
  add column if not exists stripe_customer_id     text,
  add column if not exists stripe_subscription_id text,
  add column if not exists subscription_status    text;

create unique index if not exists profiles_stripe_customer_idx
  on public.profiles (stripe_customer_id)
  where stripe_customer_id is not null;

create index if not exists bookings_payment_intent_idx
  on public.bookings (payment_intent_id)
  where payment_intent_id is not null;
