-- ─────────────────────────────────────────────────────────────────────────────
-- 0012 — Financials polish (run after 0011)
--
-- HOW TO APPLY: Supabase → SQL editor → paste this whole file → Run.
--
-- 1. Adds processed_by + bulk_action_id to payouts so we know who acted.
-- 2. Creates payout_audit_log table — append-only history of every status
--    transition (who, when, from→to, optional note).
-- 3. Trigger payouts_record_audit captures every status change automatically.
-- 4. Creates payout_methods table — members can save reusable destinations
--    (Stripe / bank / PayPal / wire) keyed by label.
-- 5. Adds refunded_at / refunded_by / refund_reason / refund_txn_id columns
--    to transactions so admins can issue refunds and we keep an audit chain.
--
-- Idempotent — safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Payouts: who acted ------------------------------------------------------
alter table public.payouts
  add column if not exists processed_by   uuid references auth.users(id) on delete set null,
  add column if not exists bulk_action_id uuid;

create index if not exists payouts_processed_by_idx on public.payouts (processed_by);

-- 2. Payout audit log --------------------------------------------------------
create table if not exists public.payout_audit_log (
  id           uuid primary key default gen_random_uuid(),
  payout_id    uuid not null references public.payouts(id) on delete cascade,
  actor_id     uuid references auth.users(id) on delete set null,
  from_status  text,
  to_status    text not null,
  note         text,
  created_at   timestamptz not null default now()
);

create index if not exists payout_audit_payout_idx on public.payout_audit_log (payout_id);
create index if not exists payout_audit_created_idx on public.payout_audit_log (created_at desc);

alter table public.payout_audit_log enable row level security;

drop policy if exists "Users read own payout audit" on public.payout_audit_log;
create policy "Users read own payout audit"
  on public.payout_audit_log for select
  to authenticated
  using (
    public.has_role(auth.uid(), 'admin')
    or exists (
      select 1 from public.payouts p
      where p.id = payout_id and p.user_id = auth.uid()
    )
  );

drop policy if exists "Admins write payout audit" on public.payout_audit_log;
create policy "Admins write payout audit"
  on public.payout_audit_log for insert
  to authenticated
  with check (public.has_role(auth.uid(), 'admin'));

-- 3. Trigger: append a row whenever status changes ---------------------------
create or replace function public.record_payout_status_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if (tg_op = 'INSERT') then
    insert into public.payout_audit_log (payout_id, actor_id, from_status, to_status, note)
    values (new.id, coalesce(new.processed_by, auth.uid()), null, new.status::text, new.notes);
    return new;
  end if;

  if new.status is distinct from old.status then
    insert into public.payout_audit_log (payout_id, actor_id, from_status, to_status, note)
    values (new.id, coalesce(new.processed_by, auth.uid()), old.status::text, new.status::text, new.notes);
  end if;
  return new;
end
$$;

drop trigger if exists payouts_record_audit_ins on public.payouts;
create trigger payouts_record_audit_ins
  after insert on public.payouts
  for each row execute function public.record_payout_status_change();

drop trigger if exists payouts_record_audit_upd on public.payouts;
create trigger payouts_record_audit_upd
  after update on public.payouts
  for each row execute function public.record_payout_status_change();

-- 4. Saved payout methods ----------------------------------------------------
create table if not exists public.payout_methods (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  label        text not null,
  method       text not null check (method in ('stripe','bank','paypal','wire')),
  destination  text not null,
  is_default   boolean not null default false,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index if not exists payout_methods_user_idx on public.payout_methods (user_id);

-- only one default per user
create unique index if not exists payout_methods_one_default
  on public.payout_methods (user_id) where is_default;

alter table public.payout_methods enable row level security;

drop policy if exists "Users read own payout methods" on public.payout_methods;
create policy "Users read own payout methods"
  on public.payout_methods for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users manage own payout methods" on public.payout_methods;
create policy "Users manage own payout methods"
  on public.payout_methods for all
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

drop trigger if exists payout_methods_touch_updated_at on public.payout_methods;
create trigger payout_methods_touch_updated_at
  before update on public.payout_methods
  for each row execute function public.touch_updated_at();

-- 5. Transactions: refund tracking ------------------------------------------
alter table public.transactions
  add column if not exists refunded_at    timestamptz,
  add column if not exists refunded_by    uuid references auth.users(id) on delete set null,
  add column if not exists refund_reason  text,
  add column if not exists refund_txn_id  uuid references public.transactions(id) on delete set null;

create index if not exists transactions_refunded_idx on public.transactions (refunded_at);

notify pgrst, 'reload schema';
