-- ─────────────────────────────────────────────────────────────────────────────
-- 0011 — Financials admin follow-ups (run after 0010)
--
-- HOW TO APPLY: Supabase → SQL editor → paste this whole file → Run.
--
-- 1. Adds destination + notes columns to payouts so the PayoutRequestModal
--    insert matches the schema. Backfills `notes` from legacy `note` if any.
-- 2. Extends payout_status enum with 'approved' and 'sent' so admins can move
--    requests through the full lifecycle (requested → approved → sent → paid).
--    Done in a separate transaction-safe block so values are usable later.
-- 3. Helper function admin_update_payout_status() — bumps processed_at when
--    the new status is terminal (paid/rejected/sent).
--
-- Idempotent — safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

alter table public.payouts
  add column if not exists destination text,
  add column if not exists notes       text;

do $$ begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='payouts' and column_name='note'
  ) then
    execute 'update public.payouts set notes = coalesce(notes, note) where note is not null';
  end if;
end $$;

do $$ begin
  alter type public.payout_status add value if not exists 'approved';
exception when duplicate_object then null; end $$;
do $$ begin
  alter type public.payout_status add value if not exists 'sent';
exception when duplicate_object then null; end $$;

create or replace function public.touch_payout_processed_at()
returns trigger
language plpgsql
as $$
begin
  if new.status is distinct from old.status
     and new.status::text in ('paid','rejected','sent') then
    new.processed_at := coalesce(new.processed_at, now());
  end if;
  return new;
end
$$;

drop trigger if exists payouts_touch_processed_at on public.payouts;
create trigger payouts_touch_processed_at
  before update on public.payouts
  for each row execute function public.touch_payout_processed_at();

notify pgrst, 'reload schema';
