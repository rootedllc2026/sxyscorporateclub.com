-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Community Exchange schema  (run after 0006)
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--
-- WHAT IT DOES:
--   1. Adds online presence + state filter columns to public.profiles
--      (last_seen_at, is_active).
--   2. Creates public.channels with public / state / vip channel types and
--      seeds the default channels referenced by the spec.
--   3. Extends public.messages with channel_id, content, embed_*, is_pinned,
--      is_announcement, dm_recipient_id, post_type. Backfills `channel_id`
--      from the legacy `channel` text column so existing data is not lost.
--   4. Creates public.reactions (one row per user / message / emoji).
--   5. Creates public.channel_visits to power per-user unread badges.
--   6. RLS: members read public + state channels; vip channels gated by tier
--      or admin; DMs only visible to participants; reactions follow the
--      message's channel access.
--   7. Enables Realtime publication on messages + reactions.
--
-- All `create … if not exists`, `add column if not exists`, and
-- `drop policy if exists` calls make the script safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

-- 0. Safety net: ensure helper functions referenced below actually exist.
-- These are defined in 0002_platform_schema.sql, but if that migration was
-- only partially applied the RLS policies in this file would fail with
-- "function public.user_tier(uuid) does not exist".
--
-- We return TEXT here (not the membership_tier enum) so this works whether
-- profiles.tier is stored as the enum OR as plain text in this database.
-- The VIP checks below compare against the literal string 'vip', which is
-- compatible with both representations.
-- Drop with cascade in case an older enum-returning version exists with
-- dependent policies (e.g. the events "Members read events for their tier"
-- policy from 0002). We recreate that policy below using the text form.
drop function if exists public.user_tier(uuid) cascade;
create function public.user_tier(_user_id uuid)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select tier::text from public.profiles where id = _user_id;
$$;

-- Recreate the events tier policy from 0002 using a text-based comparison
-- (only if the events table exists — it does after 0002).
do $$ begin
  if exists (select 1 from information_schema.tables where table_schema='public' and table_name='events') then
    execute $policy$
      drop policy if exists "Members read events for their tier" on public.events;
      create policy "Members read events for their tier"
        on public.events for select
        to authenticated
        using (
          case public.user_tier(auth.uid())
            when 'vip'    then true
            when 'annual' then access_level::text in ('free','paid','annual')
            when 'paid'   then access_level::text in ('free','paid')
            else access_level::text = 'free'
          end
          or public.has_role(auth.uid(), 'admin')
        );
    $policy$;
  end if;
end $$;

-- 1. Profile additions --------------------------------------------------------
alter table public.profiles
  add column if not exists last_seen_at timestamptz,
  add column if not exists is_active    boolean not null default true;

create index if not exists profiles_last_seen_idx on public.profiles (last_seen_at desc);
create index if not exists profiles_state_idx     on public.profiles (state);

-- 2. Channels -----------------------------------------------------------------
do $$ begin
  create type public.channel_type as enum ('public', 'state', 'vip');
exception when duplicate_object then null; end $$;

create table if not exists public.channels (
  id            uuid primary key default gen_random_uuid(),
  slug          text not null unique,
  name          text not null,
  description   text,
  channel_type  public.channel_type not null default 'public',
  icon          text,             -- emoji glyph for state / vip channels
  state_code    text,             -- e.g. 'NJ' for state channels
  display_order int  not null default 0,
  created_at    timestamptz not null default now()
);

-- Schema-drift safety: an older version of `channels` may already exist with
-- extra NOT NULL columns (display_name, tier, is_default, etc.). Backfill
-- those from the new columns so the seed insert below succeeds.
do $$
begin
  -- display_name → mirror `name`
  if exists (select 1 from information_schema.columns where table_schema='public' and table_name='channels' and column_name='display_name') then
    execute 'update public.channels set display_name = coalesce(display_name, name) where display_name is null';
    execute 'alter table public.channels alter column display_name drop not null';
  end if;
  -- tier → default to 'free' if present
  if exists (select 1 from information_schema.columns where table_schema='public' and table_name='channels' and column_name='tier') then
    execute 'alter table public.channels alter column tier drop not null';
  end if;
  -- is_default → default to false
  if exists (select 1 from information_schema.columns where table_schema='public' and table_name='channels' and column_name='is_default') then
    execute 'alter table public.channels alter column is_default set default false';
    execute 'alter table public.channels alter column is_default drop not null';
  end if;
end $$;


create index if not exists channels_type_order_idx on public.channels (channel_type, display_order);

alter table public.channels enable row level security;

drop policy if exists "Members read accessible channels" on public.channels;
create policy "Members read accessible channels"
  on public.channels for select
  to authenticated
  using (
    channel_type in ('public', 'state')
    or public.has_role(auth.uid(), 'admin')
    or (channel_type = 'vip' and public.user_tier(auth.uid()) = 'vip')
  );

drop policy if exists "Admins manage channels" on public.channels;
create policy "Admins manage channels"
  on public.channels for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- Seed channels (idempotent via on conflict do nothing on slug)
insert into public.channels (slug, name, description, channel_type, icon, state_code, display_order)
values
  ('general',         'general',         'Town square for the community',           'public', '#',  null, 10),
  ('introductions',   'introductions',   'New members say hello',                   'public', '#',  null, 20),
  ('opportunities',   'opportunities',   'Share leads & deals',                     'public', '#',  null, 30),
  ('wins',            'wins 🏆',          'Celebrate member wins',                    'public', '#',  null, 40),
  ('strategy-talk',   'strategy-talk',   'Long-form strategy threads',              'public', '#',  null, 50),
  ('contractor-hub',  'contractor-hub',  'Service providers & subs',                'public', '#',  null, 60),
  ('resources',       'resources',       'Templates, guides, links',                'public', '#',  null, 70),
  ('new-jersey',      'new-jersey',      'NJ chapter',                              'state',  '🟦', 'NJ', 10),
  ('pennsylvania',    'pennsylvania',    'PA chapter',                              'state',  '🟨', 'PA', 20),
  ('georgia',         'georgia',         'GA chapter',                              'state',  '🟥', 'GA', 30),
  ('vip-lounge',      'vip-lounge',      'VIP members only',                        'vip',    '🔒', null, 10),
  ('deal-flow',       'deal-flow',       'Curated VIP deal flow',                   'vip',    '🔒', null, 20),
  ('inner-circle',    'inner-circle',    'Inner circle conversations',              'vip',    '🔒', null, 30)
on conflict (slug) do nothing;

-- 3. Extend messages ----------------------------------------------------------
do $$ begin
  create type public.post_type as enum ('message', 'announcement', 'resource', 'poll');
exception when duplicate_object then null; end $$;

alter table public.messages
  add column if not exists channel_id        uuid references public.channels(id) on delete cascade,
  add column if not exists content           text,
  add column if not exists embed_title       text,
  add column if not exists embed_desc        text,
  add column if not exists embed_link        text,
  add column if not exists is_pinned         boolean not null default false,
  add column if not exists is_announcement   boolean not null default false,
  add column if not exists pinned_by         uuid references auth.users(id) on delete set null,
  add column if not exists pinned_at         timestamptz,
  add column if not exists dm_recipient_id   uuid references auth.users(id) on delete cascade,
  add column if not exists post_type         public.post_type not null default 'message',
  add column if not exists resource_category text,
  add column if not exists resource_visibility text,    -- 'all' | 'vip'
  add column if not exists poll_options      jsonb,
  add column if not exists poll_closes_at    timestamptz;

-- Backfill channel_id from the legacy text `channel` column (only if it exists)
do $$ begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='messages' and column_name='channel'
  ) then
    execute $sql$
      update public.messages m
      set channel_id = c.id
      from public.channels c
      where m.channel_id is null
        and m.channel is not null
        and c.slug = m.channel
    $sql$;
  end if;
end $$;

-- Mirror legacy `body` into `content` so old rows still render (only if `body` exists)
do $$ begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='messages' and column_name='body'
  ) then
    execute 'update public.messages set content = body where content is null and body is not null';
  end if;
end $$;


create index if not exists messages_channel_id_idx   on public.messages (channel_id, created_at desc);
create index if not exists messages_dm_idx           on public.messages (dm_recipient_id, sender_id, created_at desc);
create index if not exists messages_pinned_idx       on public.messages (channel_id) where is_pinned;
create index if not exists messages_announcement_idx on public.messages (created_at desc) where is_announcement;

-- Refresh RLS so DMs are scoped to participants. Public/state/vip channel
-- access falls through to the channels policy (we check via subquery).
drop policy if exists "Members read messages" on public.messages;
create policy "Members read messages"
  on public.messages for select
  to authenticated
  using (
    -- Direct messages: only sender or recipient (admin always)
    (dm_recipient_id is not null and (
      sender_id = auth.uid()
      or dm_recipient_id = auth.uid()
      or public.has_role(auth.uid(), 'admin')
    ))
    or
    -- Channel messages: must be able to read the channel itself
    (channel_id is not null and exists (
      select 1 from public.channels c
      where c.id = channel_id
        and (
          c.channel_type in ('public', 'state')
          or public.has_role(auth.uid(), 'admin')
          or (c.channel_type = 'vip' and public.user_tier(auth.uid()) = 'vip')
        )
    ))
    or
    -- Legacy rows with neither channel_id nor dm_recipient_id (back-compat)
    (channel_id is null and dm_recipient_id is null)
  );

drop policy if exists "Members write own messages" on public.messages;
create policy "Members write own messages"
  on public.messages for insert
  to authenticated
  with check (
    sender_id = auth.uid()
    and (
      -- DM: recipient must exist and not equal sender
      (dm_recipient_id is not null and dm_recipient_id <> auth.uid())
      or
      -- Channel: must be readable by this user
      (channel_id is not null and exists (
        select 1 from public.channels c
        where c.id = channel_id
          and (
            c.channel_type in ('public', 'state')
            or public.has_role(auth.uid(), 'admin')
            or (c.channel_type = 'vip' and public.user_tier(auth.uid()) = 'vip')
          )
      ))
    )
  );

-- Pin / announcement updates need admin OR the original sender editing own row.
-- The existing "Members edit own messages" policy already covers self-edit.
-- Admins can already update via has_role. No additional policy needed here.

-- 4. Reactions ----------------------------------------------------------------
create table if not exists public.reactions (
  id          uuid primary key default gen_random_uuid(),
  message_id  uuid not null references public.messages(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  emoji       text not null,
  created_at  timestamptz not null default now(),
  unique (message_id, user_id, emoji)
);

create index if not exists reactions_message_idx on public.reactions (message_id);

alter table public.reactions enable row level security;

drop policy if exists "Members read reactions" on public.reactions;
create policy "Members read reactions"
  on public.reactions for select
  to authenticated
  using (
    -- Mirror message read access
    exists (
      select 1 from public.messages m
      where m.id = message_id
        and (
          (m.dm_recipient_id is not null and (m.sender_id = auth.uid() or m.dm_recipient_id = auth.uid() or public.has_role(auth.uid(), 'admin')))
          or
          (m.channel_id is not null and exists (
            select 1 from public.channels c
            where c.id = m.channel_id
              and (
                c.channel_type in ('public', 'state')
                or public.has_role(auth.uid(), 'admin')
                or (c.channel_type = 'vip' and public.user_tier(auth.uid()) = 'vip')
              )
          ))
          or (m.channel_id is null and m.dm_recipient_id is null)
        )
    )
  );

drop policy if exists "Members add own reactions" on public.reactions;
create policy "Members add own reactions"
  on public.reactions for insert
  to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Members remove own reactions" on public.reactions;
create policy "Members remove own reactions"
  on public.reactions for delete
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- 5. Channel visits (per-user unread tracking) -------------------------------
create table if not exists public.channel_visits (
  user_id        uuid not null references auth.users(id) on delete cascade,
  channel_id     uuid not null references public.channels(id) on delete cascade,
  last_visited   timestamptz not null default now(),
  primary key (user_id, channel_id)
);

create index if not exists channel_visits_user_idx on public.channel_visits (user_id);

alter table public.channel_visits enable row level security;

drop policy if exists "Users manage own visits" on public.channel_visits;
create policy "Users manage own visits"
  on public.channel_visits for all
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- 6. Realtime publication ----------------------------------------------------
-- Add messages + reactions to the supabase_realtime publication so the
-- browser client can subscribe to INSERT / UPDATE / DELETE events.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin
      alter publication supabase_realtime add table public.messages;
    exception when duplicate_object then null; end;
    begin
      alter publication supabase_realtime add table public.reactions;
    exception when duplicate_object then null; end;
    begin
      alter publication supabase_realtime add table public.channel_visits;
    exception when duplicate_object then null; end;
  end if;
end $$;

-- Ensure full row payload on update (needed for reaction toggles & pin flips)
alter table public.messages  replica identity full;
alter table public.reactions replica identity full;
