-- ─────────────────────────────────────────────────────────────────────────────
-- 0013 — Email notification recipients on platform_settings
--
-- HOW TO APPLY: Supabase → SQL editor → paste this whole file → Run.
--
-- Adds:
--   - admin_notification_emails text[]  — comma-separated admin recipients used
--     by the Gmail notification server function for "new payout request" and
--     "weekly digest" emails. Defaults to empty array.
--
-- Idempotent — safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

alter table public.platform_settings
  add column if not exists admin_notification_emails text[] not null default '{}'::text[];

notify pgrst, 'reload schema';
