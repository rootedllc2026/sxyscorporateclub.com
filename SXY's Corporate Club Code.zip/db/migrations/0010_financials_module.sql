-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Financials module (run after 0009)
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--
-- WHAT IT DOES:
--   1. Adds available_balance + payment_method_last4 to profiles.
--   2. Expands txn_type enum with 'consulting','membership','fee'.
--   3. Adds gross_amount / fee_amount / net_amount / status / source /
--      stripe_payment_intent_id columns to transactions (defaults backfill
--      from existing `amount` so reads keep working).
--   4. Brings the existing payouts table up to spec (member_id alias, method
--      enum stays text, added 'pending'/'approved'/'sent'/'held' values).
--   5. Creates invoices table with auto-numbered INV-YYYY-MM-NNN.
--   6. Creates platform_settings (single-row config).
--   7. Creates platform_revenue_summary + member_financial_summary views.
--   8. RLS policies for all new objects.
--
-- All `if not exists` / `add column if not exists` / `do $$ … exception` blocks
-- — fully idempotent, safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Profiles: balance + masked card -----------------------------------------
alter table public.profiles
  add column if not exists available_balance     numeric(12,2) not null default 0,
  add column if not exists payment_method_last4  text;

-- 2. Ensure + expand txn_type enum -------------------------------------------
-- Defensive: if this script is run without 0002, create the base ledger enum
-- and table first so the financials migration can continue idempotently.
do $$ begin
  create type public.txn_type as enum ('referral', 'bid_award', 'payout', 'refund', 'other');
exception when duplicate_object then null; end $$;

create table if not exists public.transactions (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  txn_type     public.txn_type not null,
  amount       numeric(12,2) not null default 0,
  description  text,
  reference_id uuid,
  created_at   timestamptz not null default now()
);

-- Heal legacy schemas: ensure `user_id` exists, copy from legacy `member_id`,
-- then remove the legacy column before any policies or views reference user_id.
do $$ begin
  drop policy if exists "Users read own transactions" on public.transactions;
  drop policy if exists "Admins manage transactions" on public.transactions;

  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'transactions' and column_name = 'user_id'
  ) then
    alter table public.transactions add column user_id uuid references auth.users(id) on delete cascade;
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'transactions' and column_name = 'member_id'
  ) then
    execute 'update public.transactions set user_id = member_id where user_id is null and member_id is not null';
    alter table public.transactions drop column if exists member_id;
  end if;
end $$;

do $$ begin
  alter type public.txn_type add value if not exists 'consulting';
exception when duplicate_object then null; end $$;
do $$ begin
  alter type public.txn_type add value if not exists 'membership';
exception when duplicate_object then null; end $$;
do $$ begin
  alter type public.txn_type add value if not exists 'fee';
exception when duplicate_object then null; end $$;

-- 3. Transactions: split amount into gross / fee / net + status --------------
alter table public.transactions
  add column if not exists gross_amount             numeric(12,2),
  add column if not exists fee_amount               numeric(12,2) not null default 0,
  add column if not exists net_amount               numeric(12,2),
  add column if not exists status                   text not null default 'completed',
  add column if not exists source                   text,
  add column if not exists stripe_payment_intent_id text;

-- Backfill gross/net from legacy `amount` column so existing rows still work.
-- Guard with a column-exists check: older partial schemas may have dropped the
-- legacy `amount` column already, in which case the backfill is a no-op.
do $$ begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='transactions' and column_name='amount'
  ) then
    execute $sql$
      update public.transactions
        set gross_amount = coalesce(gross_amount, amount),
            net_amount   = coalesce(net_amount, amount - coalesce(fee_amount, 0))
        where gross_amount is null or net_amount is null
    $sql$;
  else
    -- No legacy amount column; just default the new columns to 0 where null.
    update public.transactions
      set gross_amount = coalesce(gross_amount, 0),
          net_amount   = coalesce(net_amount, 0)
      where gross_amount is null or net_amount is null;
  end if;
end $$;

create index if not exists transactions_status_idx on public.transactions (status);
create index if not exists transactions_created_idx on public.transactions (created_at desc);

-- 4. Payouts: ensure table + extend status enum ------------------------------
-- Defensive: payouts table is created in 0004, but if a prior partial run left
-- it in a broken state, recreate the essential columns idempotently.
do $$ begin
  create type public.payout_status as enum ('requested', 'processing', 'paid', 'rejected');
exception when duplicate_object then null; end $$;

-- Drop existing payout policies first. A prior partial schema can leave policies
-- referencing a missing column, which can break later ALTER/DDL statements.
do $$ begin
  if to_regclass('public.payouts') is not null then
    drop policy if exists "Users read own payouts" on public.payouts;
    drop policy if exists "Users request own payouts" on public.payouts;
    drop policy if exists "Admins manage payouts" on public.payouts;
  end if;
end $$;

create table if not exists public.payouts (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  amount       numeric(12,2) not null check (amount >= 0),
  method       text,
  note         text,
  status       public.payout_status not null default 'requested',
  requested_at timestamptz not null default now(),
  processed_at timestamptz,
  created_at   timestamptz not null default now()
);

-- Heal legacy schemas: ensure `user_id` exists, copy from legacy `member_id`,
-- then remove the legacy column before indexes, policies, and views reference it.
do $$ begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'payouts' and column_name = 'user_id'
  ) then
    alter table public.payouts add column user_id uuid references auth.users(id) on delete cascade;
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'payouts' and column_name = 'member_id'
  ) then
    execute 'update public.payouts set user_id = member_id where user_id is null and member_id is not null';
    alter table public.payouts drop column if exists member_id;
  end if;
end $$;

alter table public.payouts
  add column if not exists user_id      uuid references auth.users(id) on delete cascade,
  add column if not exists amount       numeric(12,2) not null default 0,
  add column if not exists method       text,
  add column if not exists note         text,
  add column if not exists status       public.payout_status not null default 'requested',
  add column if not exists requested_at timestamptz not null default now(),
  add column if not exists processed_at timestamptz,
  add column if not exists created_at   timestamptz not null default now();

create index if not exists payouts_user_idx   on public.payouts (user_id);
create index if not exists payouts_status_idx on public.payouts (status);

alter table public.payouts enable row level security;

drop policy if exists "Users read own payouts" on public.payouts;
create policy "Users read own payouts"
  on public.payouts for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users request own payouts" on public.payouts;
create policy "Users request own payouts"
  on public.payouts for insert
  to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Admins manage payouts" on public.payouts;
create policy "Admins manage payouts"
  on public.payouts for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- Note: 'pending', 'approved', 'sent', 'held' status values from the original
-- spec are intentionally NOT added here — Postgres forbids using a freshly
-- ALTER TYPE ADD VALUE'd enum value in the same transaction. The four base
-- statuses ('requested', 'processing', 'paid', 'rejected') cover the same flow:
--   requested → processing → paid (or rejected). Code maps accordingly.

-- 5. Invoices ----------------------------------------------------------------
do $$ begin
  create type public.invoice_status as enum ('draft', 'sent', 'paid', 'overdue', 'cancelled');
exception when duplicate_object then null; end $$;

-- Drop any existing invoices policies first so a partial schema (missing
-- user_id column) doesn't block the ALTER TABLE / heal block below.
do $$ begin
  if to_regclass('public.invoices') is not null then
    drop policy if exists "Users read own invoices" on public.invoices;
    drop policy if exists "Users create own invoices" on public.invoices;
    drop policy if exists "Users update own invoices" on public.invoices;
    drop policy if exists "Admins delete invoices" on public.invoices;
  end if;
end $$;

create table if not exists public.invoices (
  id              uuid primary key default gen_random_uuid(),
  invoice_number  text not null unique,
  user_id         uuid not null references auth.users(id) on delete cascade,
  client_name     text not null,
  description     text,
  amount          numeric(12,2) not null check (amount >= 0),
  due_date        date,
  notes           text,
  status          public.invoice_status not null default 'draft',
  issued_at       timestamptz not null default now(),
  paid_at         timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- Heal legacy schemas: ensure `user_id` exists, copy from legacy `member_id`,
-- then remove the legacy column before indexes, policies, and views reference it.
do $$ begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'invoices' and column_name = 'user_id'
  ) then
    alter table public.invoices add column user_id uuid references auth.users(id) on delete cascade;
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'invoices' and column_name = 'member_id'
  ) then
    execute 'update public.invoices set user_id = member_id where user_id is null and member_id is not null';
    alter table public.invoices drop column if exists member_id;
  end if;
end $$;

-- Ensure every expected column exists (idempotent patch for partial schemas).
alter table public.invoices
  add column if not exists invoice_number  text,
  add column if not exists user_id         uuid references auth.users(id) on delete cascade,
  add column if not exists client_name     text,
  add column if not exists description     text,
  add column if not exists amount          numeric(12,2) not null default 0,
  add column if not exists due_date        date,
  add column if not exists notes           text,
  add column if not exists status          public.invoice_status not null default 'draft',
  add column if not exists issued_at       timestamptz not null default now(),
  add column if not exists paid_at         timestamptz,
  add column if not exists created_at      timestamptz not null default now(),
  add column if not exists updated_at      timestamptz not null default now();

create index if not exists invoices_user_idx   on public.invoices (user_id);
create index if not exists invoices_status_idx on public.invoices (status);

alter table public.invoices enable row level security;

drop policy if exists "Users read own invoices" on public.invoices;
create policy "Users read own invoices"
  on public.invoices for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users create own invoices" on public.invoices;
create policy "Users create own invoices"
  on public.invoices for insert
  to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Users update own invoices" on public.invoices;
create policy "Users update own invoices"
  on public.invoices for update
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins delete invoices" on public.invoices;
create policy "Admins delete invoices"
  on public.invoices for delete
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

drop trigger if exists invoices_touch_updated_at on public.invoices;
create trigger invoices_touch_updated_at
  before update on public.invoices
  for each row execute function public.touch_updated_at();

-- Auto-generate INV-YYYY-MM-NNN on insert if the caller didn't supply one.
create or replace function public.generate_invoice_number()
returns trigger
language plpgsql
as $$
declare
  v_prefix text;
  v_next   int;
begin
  if new.invoice_number is null or new.invoice_number = '' then
    v_prefix := 'INV-' || to_char(now(), 'YYYY-MM');

    v_next := (
      select coalesce(max(
               cast(regexp_replace(inv.invoice_number, '^' || v_prefix || '-', '') as int)
             ), 0) + 1
      from public.invoices as inv
      where inv.invoice_number like v_prefix || '-%'
    );

    new.invoice_number := v_prefix || '-' || lpad(v_next::text, 3, '0');
  end if;
  return new;
end
$$;

drop trigger if exists invoices_autonumber on public.invoices;
create trigger invoices_autonumber
  before insert on public.invoices
  for each row execute function public.generate_invoice_number();

-- 6. Platform settings (single-row config) -----------------------------------
create table if not exists public.platform_settings (
  id                       int primary key default 1 check (id = 1),
  fee_pct_basic            numeric(5,2) not null default 8,
  fee_pct_standard         numeric(5,2) not null default 10,
  fee_pct_featured         numeric(5,2) not null default 12,
  payout_window_days       int not null default 7,
  payout_min_threshold     numeric(12,2) not null default 50,
  payout_default_method    text not null default 'stripe',
  notify_on_approval       boolean not null default true,
  notify_on_new_request    boolean not null default true,
  weekly_digest            boolean not null default false,
  updated_at               timestamptz not null default now()
);

insert into public.platform_settings (id) values (1) on conflict (id) do nothing;

alter table public.platform_settings enable row level security;

drop policy if exists "Anyone reads platform settings" on public.platform_settings;
create policy "Anyone reads platform settings"
  on public.platform_settings for select
  to authenticated
  using (true);

drop policy if exists "Admins update platform settings" on public.platform_settings;
create policy "Admins update platform settings"
  on public.platform_settings for update
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 7. Summary views -----------------------------------------------------------
-- IMPORTANT: Postgres forbids using a freshly ALTER TYPE ADD VALUE'd enum
-- value in the same transaction. The Supabase SQL editor wraps the entire
-- script in a single txn, so the views below cast txn_type to text before
-- comparing — that bypasses the restriction and lets us reference the new
-- 'consulting' / 'membership' / 'fee' values safely.
drop view if exists public.platform_revenue_summary;
create view public.platform_revenue_summary as
select
  -- All-time
  coalesce(sum(case when t.txn_type::text = 'membership' then t.gross_amount end), 0) as membership_revenue_total,
  coalesce(sum(case when t.txn_type::text = 'fee'        then t.gross_amount end), 0) as referral_fee_revenue_total,
  coalesce(sum(case when t.txn_type::text in ('membership','fee') then t.gross_amount end), 0) as total_revenue,
  -- Month to date
  coalesce(sum(case when t.txn_type::text in ('membership','fee') and t.created_at >= date_trunc('month', now()) then t.gross_amount end), 0) as revenue_mtd,
  coalesce(sum(case when t.txn_type::text = 'membership' and t.created_at >= date_trunc('month', now()) then t.gross_amount end), 0) as membership_mtd,
  coalesce(sum(case when t.txn_type::text = 'fee'        and t.created_at >= date_trunc('month', now()) then t.gross_amount end), 0) as referral_fee_mtd,
  -- Pending payouts (uses base enum values defined in 0004)
  (select coalesce(sum(amount), 0) from public.payouts where status in ('requested','processing')) as pending_payouts_total,
  (select count(*) from public.payouts where status in ('requested','processing')) as pending_payouts_count
from public.transactions t;

grant select on public.platform_revenue_summary to authenticated;

drop view if exists public.member_financial_summary;
create view public.member_financial_summary as
select
  p.id                           as member_id,
  p.full_name,
  p.email,
  p.tier,
  p.avatar_color,
  p.available_balance,
  coalesce(b.booking_count, 0)   as booking_count,
  coalesce(t.gross_total, 0)     as gross_earned,
  coalesce(t.fee_total, 0)       as fees_paid,
  coalesce(t.net_total, 0)       as net_earned,
  coalesce(po.pending_total, 0)  as pending_payouts
from public.profiles p
left join (
  select provider_id, count(*) as booking_count
  from public.bookings
  where status in ('confirmed','completed')
  group by provider_id
) b on b.provider_id = p.id
left join (
  select user_id,
    sum(case when txn_type::text in ('referral','consulting','bid_award') then gross_amount else 0 end) as gross_total,
    sum(fee_amount) as fee_total,
    sum(case when txn_type::text in ('referral','consulting','bid_award') then net_amount else 0 end) as net_total
  from public.transactions
  group by user_id
) t on t.user_id = p.id
left join (
  select user_id, sum(amount) as pending_total
  from public.payouts
  where status in ('requested','processing')
  group by user_id
) po on po.user_id = p.id;

grant select on public.member_financial_summary to authenticated;

-- Done.
notify pgrst, 'reload schema';
