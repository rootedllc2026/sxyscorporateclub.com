-- ─────────────────────────────────────────────────────────────────────────────
-- SXY's Corporate Club — Platform schema migration  (run once after 0001)
--
-- HOW TO APPLY:
--   1. Open https://supabase.com/dashboard/project/oltfsybpgyleucyfmmrd
--   2. SQL editor → New query → paste this whole file → Run
--   (Or via CLI: psql "$DATABASE_URL" -f db/migrations/0002_platform_schema.sql)
--
-- WHAT IT DOES:
--   1. Extends public.profiles with bio / business_name / city / industry /
--      website_url / avatar_color (idempotent).
--   2. Creates the core platform tables used by the dashboard:
--        projects, bids, transactions, messages, video_progress, events.
--   3. Enables RLS on every new table with sensible owner / member /
--      admin policies (uses the existing public.has_role() function from 0001).
--
-- All `create … if not exists`, `add column if not exists`, and
-- `drop policy if exists` calls make the script safe to re-run.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Profile additions --------------------------------------------------------
alter table public.profiles
  add column if not exists bio           text,
  add column if not exists business_name text,
  add column if not exists city          text,
  add column if not exists industry      text,
  add column if not exists website_url   text,
  add column if not exists avatar_color  text not null default 'teal';

-- 2. Projects (admin-posted opportunities members bid on) --------------------
do $$ begin
  create type public.project_status as enum ('open', 'in_review', 'awarded', 'closed');
exception when duplicate_object then null; end $$;

create table if not exists public.projects (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  summary       text,
  description   text,
  budget_min    numeric(12,2),
  budget_max    numeric(12,2),
  status        public.project_status not null default 'open',
  posted_by     uuid references auth.users(id) on delete set null,
  closes_at     timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists projects_status_idx   on public.projects (status);
create index if not exists projects_closes_at_ix on public.projects (closes_at);

alter table public.projects enable row level security;

drop policy if exists "Members read open projects" on public.projects;
create policy "Members read open projects"
  on public.projects for select
  to authenticated
  using (status <> 'closed' or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins manage projects" on public.projects;
create policy "Admins manage projects"
  on public.projects for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 3. Bids ---------------------------------------------------------------------
do $$ begin
  create type public.bid_status as enum ('draft', 'submitted', 'shortlisted', 'awarded', 'rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.bids (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references public.projects(id) on delete cascade,
  bidder_id   uuid not null references auth.users(id) on delete cascade,
  amount      numeric(12,2),
  proposal    text,
  status      public.bid_status not null default 'submitted',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (project_id, bidder_id)
);

create index if not exists bids_bidder_idx  on public.bids (bidder_id);
create index if not exists bids_project_idx on public.bids (project_id);
create index if not exists bids_status_idx  on public.bids (status);

alter table public.bids enable row level security;

drop policy if exists "Bidders read own bids" on public.bids;
create policy "Bidders read own bids"
  on public.bids for select
  to authenticated
  using (bidder_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Bidders insert own bids" on public.bids;
create policy "Bidders insert own bids"
  on public.bids for insert
  to authenticated
  with check (bidder_id = auth.uid());

drop policy if exists "Bidders update own bids" on public.bids;
create policy "Bidders update own bids"
  on public.bids for update
  to authenticated
  using (bidder_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (bidder_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins delete bids" on public.bids;
create policy "Admins delete bids"
  on public.bids for delete
  to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- 4. Transactions (earnings ledger) ------------------------------------------
do $$ begin
  create type public.txn_type as enum ('referral', 'bid_award', 'payout', 'refund', 'other');
exception when duplicate_object then null; end $$;

create table if not exists public.transactions (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  txn_type     public.txn_type not null,
  amount       numeric(12,2) not null default 0,
  description  text,
  reference_id uuid,
  created_at   timestamptz not null default now()
);

create index if not exists transactions_user_idx on public.transactions (user_id);
create index if not exists transactions_type_idx on public.transactions (txn_type);

alter table public.transactions enable row level security;

drop policy if exists "Users read own transactions" on public.transactions;
create policy "Users read own transactions"
  on public.transactions for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins manage transactions" on public.transactions;
create policy "Admins manage transactions"
  on public.transactions for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 5. Messages (community Exchange) -------------------------------------------
create table if not exists public.messages (
  id          uuid primary key default gen_random_uuid(),
  channel     text not null default 'general',
  sender_id   uuid not null references auth.users(id) on delete cascade,
  body        text not null,
  created_at  timestamptz not null default now()
);

-- Heal partial/legacy installs: CREATE TABLE IF NOT EXISTS does not add columns
-- to an existing table, so ensure every column referenced below exists first.
alter table public.messages
  add column if not exists channel    text not null default 'general',
  add column if not exists sender_id  uuid references auth.users(id) on delete cascade,
  add column if not exists body       text not null default '',
  add column if not exists created_at timestamptz not null default now();

create index if not exists messages_channel_idx on public.messages (channel, created_at desc);
create index if not exists messages_sender_idx  on public.messages (sender_id);

alter table public.messages enable row level security;

drop policy if exists "Members read messages" on public.messages;
create policy "Members read messages"
  on public.messages for select
  to authenticated
  using (true);

drop policy if exists "Members write own messages" on public.messages;
create policy "Members write own messages"
  on public.messages for insert
  to authenticated
  with check (sender_id = auth.uid());

drop policy if exists "Members edit own messages" on public.messages;
create policy "Members edit own messages"
  on public.messages for update
  to authenticated
  using (sender_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (sender_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Members delete own messages" on public.messages;
create policy "Members delete own messages"
  on public.messages for delete
  to authenticated
  using (sender_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- 6. Video progress (Economy Bites watch tracking) ---------------------------
create table if not exists public.video_progress (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  video_id     uuid not null,
  progress_pct numeric(5,2) not null default 0,
  completed    boolean not null default false,
  updated_at   timestamptz not null default now(),
  unique (user_id, video_id)
);

create index if not exists video_progress_user_idx on public.video_progress (user_id);

alter table public.video_progress enable row level security;

drop policy if exists "Users read own video progress" on public.video_progress;
create policy "Users read own video progress"
  on public.video_progress for select
  to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users upsert own video progress" on public.video_progress;
create policy "Users upsert own video progress"
  on public.video_progress for insert
  to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Users update own video progress" on public.video_progress;
create policy "Users update own video progress"
  on public.video_progress for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- 7. Events & Webinars --------------------------------------------------------
do $$ begin
  create type public.event_access as enum ('free', 'paid', 'annual', 'vip');
exception when duplicate_object then null; end $$;

create table if not exists public.events (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  description   text,
  starts_at     timestamptz not null,
  ends_at       timestamptz,
  location      text,
  meeting_url   text,
  access_level  public.event_access not null default 'free',
  created_by    uuid references auth.users(id) on delete set null,
  created_at    timestamptz not null default now()
);

create index if not exists events_starts_at_idx on public.events (starts_at);
create index if not exists events_access_idx    on public.events (access_level);

alter table public.events enable row level security;

-- Tier ranking helper so we can compare access levels with a single check.
create or replace function public.tier_rank(_tier public.membership_tier)
returns int
language sql
immutable
as $$
  select case _tier
    when 'free'   then 1
    when 'paid'   then 2
    when 'annual' then 3
    when 'vip'    then 4
  end;
$$;

create or replace function public.event_rank(_access public.event_access)
returns int
language sql
immutable
as $$
  select case _access
    when 'free'   then 1
    when 'paid'   then 2
    when 'annual' then 3
    when 'vip'    then 4
  end;
$$;

-- DROP first so reruns can change the return type (CREATE OR REPLACE forbids that).
drop function if exists public.user_tier(uuid) cascade;
create function public.user_tier(_user_id uuid)
returns public.membership_tier
language sql
stable
security definer
set search_path = public
as $$
  select tier::text::public.membership_tier from public.profiles where id = _user_id;
$$;

drop policy if exists "Members read events for their tier" on public.events;
create policy "Members read events for their tier"
  on public.events for select
  to authenticated
  using (
    public.event_rank(access_level::text::public.event_access) <= public.tier_rank(public.user_tier(auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Admins manage events" on public.events;
create policy "Admins manage events"
  on public.events for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 8. Touch updated_at on projects + bids -------------------------------------
drop trigger if exists projects_touch_updated_at on public.projects;
create trigger projects_touch_updated_at
  before update on public.projects
  for each row execute function public.touch_updated_at();

drop trigger if exists bids_touch_updated_at on public.bids;
create trigger bids_touch_updated_at
  before update on public.bids
  for each row execute function public.touch_updated_at();
