/**
 * Server function: cancel the current user's Stripe subscription.
 *
 * 1. Reads the caller's Supabase JWT from the cookie / Authorization header
 *    forwarded by TanStack Start.
 * 2. Verifies it via supabaseAdmin.auth.getUser(jwt) → resolves the user_id.
 * 3. Loads stripe_subscription_id from public.profiles.
 * 4. Calls Stripe REST API directly with `fetch` (no Node-only SDK) to
 *    cancel the subscription.
 * 5. Mirrors the new status into public.profiles.
 */
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";

function readBearerOrCookieJwt(): string | null {
  const auth = getRequestHeader("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) return auth.slice(7);
  const cookie = getRequestHeader("cookie") ?? "";
  // Supabase v2 stores the session as sb-<project-ref>-auth-token cookie.
  const match = cookie.match(/sb-[^=]+-auth-token=([^;]+)/);
  if (!match) return null;
  try {
    const decoded = decodeURIComponent(match[1]);
    // The cookie value is a JSON array starting with `["<access-token>", …]`
    const arr = JSON.parse(decoded);
    return Array.isArray(arr) ? arr[0] : decoded;
  } catch {
    return null;
  }
}

export const cancelMyMembership = createServerFn({ method: "POST" }).handler(
  async () => {
    const jwt = readBearerOrCookieJwt();
    if (!jwt) throw new Error("Not signed in.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const stripeKey = process.env.STRIPE_SECRET_KEY;
    if (!stripeKey)
      throw new Error("STRIPE_SECRET_KEY missing — Stripe not configured.");

    const { data: userData, error: userErr } =
      await supabaseAdmin.auth.getUser(jwt);
    if (userErr || !userData?.user) throw new Error("Invalid session.");
    const userId = userData.user.id;

    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("stripe_subscription_id")
      .eq("id", userId)
      .maybeSingle();

    const subId = profile?.stripe_subscription_id;
    if (!subId) throw new Error("No active Stripe subscription on file.");

    const res = await fetch(
      `https://api.stripe.com/v1/subscriptions/${subId}`,
      {
        method: "DELETE",
        headers: { Authorization: `Bearer ${stripeKey}` },
      },
    );
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Stripe cancel failed: ${res.status} ${text}`);
    }

    const json = (await res.json()) as { status?: string };

    await supabaseAdmin
      .from("profiles")
      .update({ subscription_status: json.status ?? "canceled" })
      .eq("id", userId);

    return { ok: true, status: json.status ?? "canceled" };
  },
);
