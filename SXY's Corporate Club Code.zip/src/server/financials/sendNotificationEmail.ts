/**
 * Server function: send a transactional notification email via the user's
 * connected Gmail account using the Lovable connector gateway.
 *
 * Why a server function?
 *   - The Gmail send call requires LOVABLE_API_KEY + GOOGLE_MAIL_API_KEY,
 *     which only exist on the server.
 *   - The caller's Supabase JWT is verified before any send to prevent
 *     anonymous abuse — only signed-in users can trigger notifications.
 *
 * Used by:
 *   - PayoutRequestModal (notifies admins of a new request)
 *   - financials.admin.payouts (notifies the member when approved / paid)
 */
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";

interface SendNotificationInput {
  to: string | string[];
  subject: string;
  /** Plain-text body. HTML body is auto-derived (line breaks → <br>). */
  body: string;
  /** Optional friendlier "From" display name. Defaults to "SXY Notifications". */
  fromName?: string;
}

function readBearerOrCookieJwt(): string | null {
  const auth = getRequestHeader("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) return auth.slice(7);
  const cookie = getRequestHeader("cookie") ?? "";
  const match = cookie.match(/sb-[^=]+-auth-token=([^;]+)/);
  if (!match) return null;
  try {
    const decoded = decodeURIComponent(match[1]);
    const arr = JSON.parse(decoded);
    return Array.isArray(arr) ? arr[0] : decoded;
  } catch {
    return null;
  }
}

/** Encodes a UTF-8 string to base64url (RFC 4648 §5). */
function base64UrlEncode(input: string): string {
  // Use Buffer when available (Workers + Node), fallback to btoa.
  const b64 =
    typeof Buffer !== "undefined"
      ? Buffer.from(input, "utf-8").toString("base64")
      : btoa(unescape(encodeURIComponent(input)));
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Build a multipart/alternative RFC 2822 message with text + HTML parts. */
function buildRawEmail(opts: {
  to: string;
  subject: string;
  body: string;
  fromName: string;
}): string {
  const boundary = `b_${Math.random().toString(36).slice(2)}`;
  const htmlBody = opts.body
    .split("\n")
    .map((line) => line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"))
    .join("<br>");
  const lines = [
    `From: ${opts.fromName} <me>`,
    `To: ${opts.to}`,
    `Subject: ${opts.subject}`,
    "MIME-Version: 1.0",
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    "",
    `--${boundary}`,
    'Content-Type: text/plain; charset="UTF-8"',
    "Content-Transfer-Encoding: 7bit",
    "",
    opts.body,
    "",
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: 7bit",
    "",
    `<div style="font-family:system-ui,sans-serif;font-size:14px;color:#1a1a1a;line-height:1.5">${htmlBody}</div>`,
    "",
    `--${boundary}--`,
  ];
  return lines.join("\r\n");
}

export const sendNotificationEmail = createServerFn({ method: "POST" })
  .inputValidator((input: SendNotificationInput) => {
    if (!input || typeof input !== "object") throw new Error("Bad input.");
    const recipients = Array.isArray(input.to) ? input.to : [input.to];
    const cleaned = recipients.map((r) => String(r ?? "").trim()).filter(Boolean);
    if (cleaned.length === 0) throw new Error("At least one recipient required.");
    if (!input.subject?.trim()) throw new Error("Subject required.");
    if (!input.body?.trim()) throw new Error("Body required.");
    return {
      to: cleaned,
      subject: input.subject.trim(),
      body: input.body,
      fromName: input.fromName?.trim() || "SXY Notifications",
    };
  })
  .handler(async ({ data }) => {
    // 1. Verify caller is signed in.
    const jwt = readBearerOrCookieJwt();
    if (!jwt) throw new Error("Not signed in.");
    const { data: userData, error: userErr } =
      await supabaseAdmin.auth.getUser(jwt);
    if (userErr || !userData?.user) throw new Error("Invalid session.");

    // 2. Build a server-side recipient allow-list. Authenticated members are
    //    only permitted to email:
    //      a) the configured admin notification addresses (platform_settings)
    //      b) their own account email
    //    Any recipient outside this list is silently dropped to prevent the
    //    function being abused as a generic email relay / phishing vector.
    const callerEmail = userData.user.email?.toLowerCase().trim() ?? "";
    const { data: settings } = await supabaseAdmin
      .from("platform_settings")
      .select("admin_notification_emails")
      .eq("id", 1)
      .maybeSingle();
    const adminEmails = (settings?.admin_notification_emails ?? []).map(
      (e: string) => e.toLowerCase().trim(),
    );
    const allowList = new Set<string>([...adminEmails, callerEmail].filter(Boolean));

    const allowedRecipients = data.to.filter((r) =>
      allowList.has(r.toLowerCase().trim()),
    );
    if (allowedRecipients.length === 0) {
      throw new Error(
        "No allowed recipients. Notifications can only be sent to admins or your own address.",
      );
    }

    // 3. Verify connector secrets are configured.
    const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY missing — Gmail not configured.");
    }
    const GOOGLE_MAIL_API_KEY = process.env.GOOGLE_MAIL_API_KEY;
    if (!GOOGLE_MAIL_API_KEY) {
      throw new Error(
        "GOOGLE_MAIL_API_KEY missing — Gmail connector not linked.",
      );
    }

    // 4. Send to each allowed recipient.
    const results: { to: string; messageId?: string }[] = [];
    for (const recipient of allowedRecipients) {
      const raw = buildRawEmail({
        to: recipient,
        subject: data.subject,
        body: data.body,
        fromName: data.fromName,
      });
      const res = await fetch(`${GATEWAY_URL}/users/me/messages/send`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "X-Connection-Api-Key": GOOGLE_MAIL_API_KEY,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ raw: base64UrlEncode(raw) }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Gmail send failed [${res.status}]: ${text}`);
      }
      const json = (await res.json()) as { id?: string };
      results.push({ to: recipient, messageId: json.id });
    }

    return { ok: true, sent: results.length, results };
  });
