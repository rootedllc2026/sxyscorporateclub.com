/**
 * Server-only Resend client + transactional email helpers.
 *
 * All transactional sends in the app go through `sendResendEmail()`. The
 * function is intentionally tiny — branded HTML wrapping and per-event
 * subject/body composition live in `src/lib/email/templates.ts` so that
 * the same templates can be reused from server functions, the Stripe
 * webhook, and the scheduled-reminder cron route without coupling to the
 * Resend SDK shape.
 *
 * Why no SDK?
 *   The official `resend` npm package targets Node + bundles dependencies
 *   that are awkward in the Cloudflare Worker SSR runtime. The HTTP API is
 *   trivial — a single POST to /emails — so we hit it via fetch directly.
 */

const RESEND_ENDPOINT = "https://api.resend.com/emails";

/** Production "From:" header — verified domain in Resend. */
export const FROM_ADDRESS =
  "SXY's Corporate Club <welcome@sxyscorporateclub.com>";

/** Admin recipients for booking notifications. */
export const ADMIN_NOTIFICATION_RECIPIENTS = [
  "admin@sxysinvestors.com",
  "strategy@sxysinvestors.com",
];

export interface ResendSendOptions {
  to: string | string[];
  subject: string;
  html: string;
  /** Optional plain-text fallback. Auto-derived from the HTML if omitted. */
  text?: string;
  replyTo?: string;
  /** Tag the message in Resend logs (e.g. "booking-confirmation"). */
  tag?: string;
}

/**
 * Send an email via Resend's REST API. Throws on non-2xx so the caller can
 * decide whether to surface or swallow (most webhook callers should swallow
 * to avoid Stripe retries on email failure — the primary action already
 * succeeded).
 */
export async function sendResendEmail(
  opts: ResendSendOptions,
): Promise<{ id: string }> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    throw new Error("RESEND_API_KEY missing — cannot send transactional email.");
  }

  const recipients = Array.isArray(opts.to) ? opts.to : [opts.to];
  const cleaned = recipients.map((r) => r.trim()).filter(Boolean);
  if (cleaned.length === 0) {
    throw new Error("Resend send requires at least one recipient.");
  }

  const body: Record<string, unknown> = {
    from: FROM_ADDRESS,
    to: cleaned,
    subject: opts.subject,
    html: opts.html,
    text: opts.text ?? stripHtml(opts.html),
  };
  if (opts.replyTo) body.reply_to = opts.replyTo;
  if (opts.tag) body.tags = [{ name: "category", value: opts.tag }];

  const res = await fetch(RESEND_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Resend send failed [${res.status}]: ${text}`);
  }

  return (await res.json()) as { id: string };
}

/** Crude HTML → text fallback. Adequate for a one-line plain-text alt body. */
function stripHtml(html: string): string {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<br\s*\/?>(\s*)/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}
