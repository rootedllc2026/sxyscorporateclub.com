/**
 * Branded HTML email templates for SXY's Corporate Club.
 *
 * Each builder takes a typed payload and returns `{ subject, html }` ready
 * to hand to `sendResendEmail()`. Keeping templates colocated makes it
 * easy to audit copy and tweak styling in one place.
 *
 * The shared `wrap()` produces a charcoal/teal/gold themed shell that
 * mirrors the in-app brand (Playfair display, gold accent, dark surface
 * hint). Inline styles are required for Gmail/Outlook compatibility.
 */

const CALENDLY_LINK = "https://calendly.com/rootedllc2026/30min";
const APP_BASE_URL = "https://www.sxyscorporateclub.com";

interface WrapOptions {
  preheader?: string;
  /** Optional CTA button shown after the body. */
  cta?: { label: string; href: string };
}

function wrap(title: string, bodyHtml: string, opts: WrapOptions = {}): string {
  const cta = opts.cta
    ? `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:28px 0 8px;">
         <tr>
           <td bgcolor="#C9A24A" style="border-radius:8px;">
             <a href="${escapeAttr(opts.cta.href)}"
                style="display:inline-block;padding:12px 24px;font-family:Georgia,serif;
                       font-size:14px;font-weight:600;color:#1a1a1a;text-decoration:none;
                       letter-spacing:0.02em;">
               ${escapeHtml(opts.cta.label)}
             </a>
           </td>
         </tr>
       </table>`
    : "";

  const preheader = opts.preheader
    ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">
         ${escapeHtml(opts.preheader)}
       </div>`
    : "";

  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title></head>
<body style="margin:0;padding:0;background:#f4f1ea;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#1a1a1a;">
${preheader}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f1ea;padding:32px 16px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0"
           style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden;
                  box-shadow:0 4px 20px rgba(0,0,0,0.06);">
      <tr>
        <td style="background:#1a1a1a;padding:24px 32px;text-align:center;">
          <p style="margin:0;font-family:Georgia,serif;font-size:22px;color:#C9A24A;letter-spacing:0.02em;">
            SXY's Corporate Club
          </p>
          <p style="margin:4px 0 0;font-size:10px;letter-spacing:0.25em;text-transform:uppercase;color:#7a8c8e;">
            Member Portal
          </p>
        </td>
      </tr>
      <tr>
        <td style="padding:32px;">
          <h1 style="margin:0 0 16px;font-family:Georgia,serif;font-size:24px;color:#1a1a1a;">
            ${escapeHtml(title)}
          </h1>
          <div style="font-size:15px;line-height:1.6;color:#3a3a3a;">
            ${bodyHtml}
          </div>
          ${cta}
        </td>
      </tr>
      <tr>
        <td style="background:#fafaf6;padding:20px 32px;border-top:1px solid #e8e4d8;
                   font-size:12px;color:#888;text-align:center;">
          <p style="margin:0 0 4px;">SXY's Economic Roots LLC</p>
          <p style="margin:0;">
            <a href="${APP_BASE_URL}" style="color:#7a8c8e;text-decoration:none;">
              www.sxyscorporateclub.com
            </a>
          </p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body></html>`;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
function escapeAttr(s: string): string {
  return escapeHtml(s);
}
function p(text: string): string {
  return `<p style="margin:0 0 14px;">${escapeHtml(text)}</p>`;
}
function firstName(full?: string | null): string {
  if (!full) return "there";
  return full.trim().split(/\s+/)[0] ?? "there";
}
function fmtMoney(amount: number | string | null | undefined): string {
  const n = Number(amount ?? 0);
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(n);
}
function fmtDateTime(date?: string | null, time?: string | null): string {
  if (!date) return "—";
  const d = new Date(`${date}T${time ?? "00:00"}:00`);
  if (Number.isNaN(d.getTime())) return [date, time].filter(Boolean).join(" ");
  const dateStr = d.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  });
  if (!time) return dateStr;
  const timeStr = d.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
  return `${dateStr} at ${timeStr}`;
}

/* ─── Email builders ────────────────────────────────────────────────────── */

export interface BookingConfirmedPayload {
  clientFullName?: string | null;
  serviceName: string;
  providerName: string;
  bookedDate: string;       // YYYY-MM-DD
  bookedTime?: string | null; // HH:MM
}

export function buildBookingConfirmed(p1: BookingConfirmedPayload) {
  const subject = "Your booking is confirmed — SXY's Corporate Club";
  const body = `
    ${p(`Hi ${firstName(p1.clientFullName)},`)}
    ${p(`Your booking for ${p1.serviceName} with ${p1.providerName} on ${fmtDateTime(p1.bookedDate, p1.bookedTime)} is confirmed.`)}
    ${p(`To add this to your calendar and receive a meeting link, schedule via Calendly. Your provider will also reach out to confirm details.`)}
  `;
  return {
    subject,
    html: wrap("Your booking is confirmed", body, {
      preheader: `Booking confirmed: ${p1.serviceName} with ${p1.providerName}`,
      cta: { label: "Schedule via Calendly", href: CALENDLY_LINK },
    }),
  };
}

export interface BookingAdminNotifyPayload {
  clientFullName: string;
  clientEmail: string;
  clientPhone?: string | null;
  serviceName: string;
  bookedDate: string;
  bookedTime?: string | null;
  totalAmount: number;
  netAmount: number;
}

export function buildBookingAdminNotification(p1: BookingAdminNotifyPayload) {
  const subject = `New booking — ${p1.clientFullName} booked ${p1.serviceName}`;
  const body = `
    ${p(`A new booking just came in.`)}
    <table cellpadding="0" cellspacing="0" style="margin:0 0 16px;font-size:14px;">
      <tr><td style="padding:4px 16px 4px 0;color:#888;">Client</td><td>${escapeHtml(p1.clientFullName)}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#888;">Email</td><td>${escapeHtml(p1.clientEmail)}</td></tr>
      ${p1.clientPhone ? `<tr><td style="padding:4px 16px 4px 0;color:#888;">Phone</td><td>${escapeHtml(p1.clientPhone)}</td></tr>` : ""}
      <tr><td style="padding:4px 16px 4px 0;color:#888;">Service</td><td>${escapeHtml(p1.serviceName)}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#888;">When</td><td>${escapeHtml(fmtDateTime(p1.bookedDate, p1.bookedTime))}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#888;">Booking amount</td><td>${escapeHtml(fmtMoney(p1.totalAmount))}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#888;">Net after platform fee</td><td><strong>${escapeHtml(fmtMoney(p1.netAmount))}</strong></td></tr>
    </table>
  `;
  return {
    subject,
    html: wrap("New booking received", body, {
      preheader: `${p1.clientFullName} booked ${p1.serviceName}`,
    }),
  };
}

export interface BookingReminderPayload {
  clientFullName?: string | null;
  serviceName: string;
  bookedDate: string;
  bookedTime?: string | null;
}

export function buildBookingReminder(p1: BookingReminderPayload) {
  const subject = "Reminder: Your session is tomorrow — SXY's Corporate Club";
  const body = `
    ${p(`Hi ${firstName(p1.clientFullName)},`)}
    ${p(`Quick reminder — your ${p1.serviceName} session is scheduled for ${fmtDateTime(p1.bookedDate, p1.bookedTime)}.`)}
    ${p(`Reply to this email if you need to reschedule.`)}
  `;
  return {
    subject,
    html: wrap("Your session is tomorrow", body, {
      preheader: `Reminder: ${p1.serviceName} tomorrow`,
      cta: { label: "Open Calendly", href: CALENDLY_LINK },
    }),
  };
}

type Tier = "free" | "paid" | "annual" | "vip";

const TIER_LABELS: Record<Tier, string> = {
  free: "Free Member",
  paid: "Investing Member",
  annual: "Annual Member",
  vip: "VIP Member",
};

const TIER_PERKS: Record<Tier, string[]> = {
  free: [
    "Community access + Business Bites",
    "Browse open projects",
    "Connect with fellow members",
  ],
  paid: [
    "Everything in Free",
    "Submit bids on projects",
    "Full referral portal access",
    "Member directory + DMs",
  ],
  annual: [
    "Everything in Investing — billed yearly for the best value",
    "All referral portal features",
    "Priority support",
  ],
  vip: [
    "All platform features",
    "Economy Bites VIP series",
    "Inner-circle deal flow",
    "Strategy session credits",
  ],
};

export interface MembershipWelcomePayload {
  fullName?: string | null;
  tier: Tier;
}

export function buildMembershipWelcome(p1: MembershipWelcomePayload) {
  const tierLabel = TIER_LABELS[p1.tier];
  const perks = TIER_PERKS[p1.tier]
    .map(
      (perk) =>
        `<li style="margin-bottom:6px;">${escapeHtml(perk)}</li>`,
    )
    .join("");
  const subject = "Welcome to SXY's Corporate Club 🎉";
  const body = `
    ${p(`Hi ${firstName(p1.fullName)},`)}
    ${p(`Welcome to the club! You're now a ${tierLabel} — here's what you can do right away:`)}
    <ul style="margin:0 0 16px;padding-left:20px;">${perks}</ul>
    <p style="margin:18px 0 0;font-size:14px;">
      <a href="${APP_BASE_URL}/dashboard" style="color:#7a8c8e;">Dashboard</a>
      &nbsp;·&nbsp;
      <a href="${APP_BASE_URL}/community" style="color:#7a8c8e;">Community</a>
      &nbsp;·&nbsp;
      <a href="${APP_BASE_URL}/economy-bites" style="color:#7a8c8e;">Economy Bites</a>
    </p>
  `;
  return {
    subject,
    html: wrap(`Welcome, ${firstName(p1.fullName)}`, body, {
      preheader: `You're in. Here's what your ${tierLabel} membership unlocks.`,
      cta: { label: "Open your dashboard", href: `${APP_BASE_URL}/dashboard` },
    }),
  };
}

export interface MembershipUpgradePayload {
  fullName?: string | null;
  tier: Tier;
}

export function buildMembershipUpgrade(p1: MembershipUpgradePayload) {
  const tierLabel = TIER_LABELS[p1.tier];
  const perks = TIER_PERKS[p1.tier]
    .map((perk) => `<li style="margin-bottom:6px;">${escapeHtml(perk)}</li>`)
    .join("");
  const subject = "Your membership has been upgraded — SXY's Corporate Club";
  const body = `
    ${p(`Hi ${firstName(p1.fullName)},`)}
    ${p(`Your membership is now ${tierLabel}. Here's what you have access to:`)}
    <ul style="margin:0 0 16px;padding-left:20px;">${perks}</ul>
  `;
  return {
    subject,
    html: wrap("Membership upgraded", body, {
      preheader: `You've been upgraded to ${tierLabel}.`,
      cta: { label: "Open dashboard", href: `${APP_BASE_URL}/dashboard` },
    }),
  };
}

export interface PayoutApprovedPayload {
  fullName?: string | null;
  amount: number | string;
  method?: string | null;
}

export function buildPayoutApproved(p1: PayoutApprovedPayload) {
  const subject = "Your payout has been approved — SXY's Corporate Club";
  const body = `
    ${p(`Hi ${firstName(p1.fullName)},`)}
    ${p(`Your payout request for ${fmtMoney(p1.amount)} has been approved.`)}
    ${p1.method ? p(`Payment method: ${p1.method}`) : ""}
    ${p(`You can expect funds to arrive within 5 business days.`)}
  `;
  return {
    subject,
    html: wrap("Payout approved", body, {
      preheader: `Your ${fmtMoney(p1.amount)} payout is on its way.`,
      cta: { label: "View financials", href: `${APP_BASE_URL}/financials` },
    }),
  };
}

/* ─── Intake form (public sxysinvestors.com / /intake) ─────────────────── */

export interface IntakeClientPayload {
  fullName: string;
}

export function buildIntakeClientConfirmation(p1: IntakeClientPayload) {
  const subject = "We received your inquiry — SXY's Corporate Club";
  const body = `
    ${p(`Hi ${firstName(p1.fullName)},`)}
    ${p(`Thank you for reaching out — we've received your inquiry and one of our strategists will be in touch within 1 business day.`)}
    ${p(`In the meantime, you can book your free 30-minute Club Chat directly via Calendly using the button below.`)}
  `;
  return {
    subject,
    html: wrap("Thanks for reaching out", body, {
      preheader: "We received your inquiry — book your free Club Chat now.",
      cta: { label: "Book a Club Chat", href: CALENDLY_LINK },
    }),
  };
}

export interface IntakeAdminPayload {
  fullName: string;
  email: string;
  phone?: string | null;
  businessName?: string | null;
  serviceInterest: string;
  message?: string | null;
  preferredContact: string;
  submittedAt: string;
}

export function buildIntakeAdminNotification(p1: IntakeAdminPayload) {
  const subject = `New intake submission — ${p1.fullName}`;
  const row = (label: string, value: string | null | undefined) =>
    value
      ? `<tr><td style="padding:4px 16px 4px 0;color:#888;vertical-align:top;">${escapeHtml(label)}</td><td style="vertical-align:top;">${escapeHtml(value)}</td></tr>`
      : "";
  const body = `
    ${p(`A new intake submission just arrived.`)}
    <table cellpadding="0" cellspacing="0" style="margin:0 0 16px;font-size:14px;">
      ${row("Full name", p1.fullName)}
      ${row("Email", p1.email)}
      ${row("Phone", p1.phone)}
      ${row("Business name", p1.businessName)}
      ${row("Service interest", p1.serviceInterest)}
      ${row("Preferred contact", p1.preferredContact)}
      ${row("Submitted", new Date(p1.submittedAt).toLocaleString("en-US"))}
    </table>
    ${p1.message ? `<p style="margin:0 0 8px;color:#888;font-size:13px;">Message</p><div style="padding:12px 14px;background:#fafaf6;border-left:3px solid #C9A24A;border-radius:4px;font-size:14px;white-space:pre-wrap;">${escapeHtml(p1.message)}</div>` : ""}
  `;
  return {
    subject,
    html: wrap("New intake submission", body, {
      preheader: `${p1.fullName} — ${p1.serviceInterest}`,
    }),
  };
}
