/**
 * Server function: downgrade the calling user's profile tier to "free".
 *
 * Why a server function?
 *   The profiles table has a BEFORE UPDATE trigger (migration 0017) that
 *   blocks any non-service_role caller from changing the tier column. The
 *   client-side Supabase SDK runs as the authenticated user (anon key + JWT)
 *   and therefore cannot write to tier directly. This server function uses
 *   supabaseAdmin (service_role) after verifying the caller's JWT, then
 *   forces tier='free'. It can never set a paid tier — that path is
 *   exclusively owned by the Stripe webhook.
 */
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";

function readBearerOrCookieJwt(): string | null {
  const auth = getRequestHeader("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) return auth.slice(7);
  const cookie = getRequestHeader("cookie") ?? "";
  const match = cookie.match(/sb-[^=]+-auth-token=([^;]+)/);
  if (!match) return null;
  try {
    const decoded = decodeURIComponent(match[1]);
    const arr = JSON.parse(decoded);
    return Array.isArray(arr) ? arr[0] : decoded;
  } catch {
    return null;
  }
}

export const downgradeToFree = createServerFn({ method: "POST" }).handler(
  async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const jwt = readBearerOrCookieJwt();
    if (!jwt) throw new Error("Not signed in.");
    if (!jwt) throw new Error("Not signed in.");
    const { data: userData, error: userErr } =
      await supabaseAdmin.auth.getUser(jwt);
    if (userErr || !userData?.user) throw new Error("Invalid session.");

    const userId = userData.user.id;

    // Hardcoded "free" — this function physically cannot grant a paid tier.
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ tier: "free" })
      .eq("id", userId);

    if (error) throw new Error(error.message);
    return { ok: true };
  },
);
