import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const SetPasswordInput = z.object({
  email: z.string().email().max(255).trim().toLowerCase(),
  newPassword: z.string().min(12).max(128),
  reason: z.string().max(500).optional(),
});

export const adminSetUserPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SetPasswordInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // Verify caller is admin (server-side check; client cannot spoof)
    const { data: isAdmin, error: roleErr } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (roleErr) throw new Error("Authorization check failed");
    if (!isAdmin) throw new Error("Forbidden: admin role required");

    // Lazy import service-role client so it never leaks to the client bundle
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Lookup target user by email
    const { data: list, error: listErr } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 200,
    });
    if (listErr) throw new Error("User lookup failed");
    const target = list.users.find(
      (u) => u.email?.toLowerCase() === data.email,
    );
    if (!target) throw new Error("No user found with that email");

    // Update password
    const { error: updErr } = await supabaseAdmin.auth.admin.updateUserById(
      target.id,
      { password: data.newPassword },
    );
    if (updErr) throw new Error(updErr.message);

    // Audit log
    await supabaseAdmin.from("admin_password_set_log").insert({
      admin_user_id: userId,
      target_user_id: target.id,
      target_email: data.email,
      reason: data.reason ?? null,
    });

    return { ok: true, targetUserId: target.id };
  });
