/**
 * Shared helpers for the Events & Webinars module.
 */
import type { MembershipTier } from "@/integrations/supabase/AuthContext";

export type EventAccess = "free" | "paid" | "annual" | "vip";
export type EventStatus = "scheduled" | "live" | "completed" | "canceled";

export interface EventRow {
  id: string;
  title: string;
  description: string | null;
  icon_emoji: string;
  host_name: string | null;
  starts_at: string;
  ends_at: string | null;
  duration_min: number | null;
  location: string | null;
  meeting_url: string | null;
  platform: string | null;
  join_url: string | null;
  recording_url: string | null;
  recording_access: EventAccess | null;
  access_level: EventAccess;
  status: EventStatus;
  registrant_count: number;
  archive_recording: boolean;
  notify_members: boolean;
  post_to_general: boolean;
  created_by: string | null;
  created_at: string;
}

const tierRank: Record<MembershipTier, number> = {
  free: 1,
  paid: 2,
  annual: 3,
  vip: 4,
};
const accessRank: Record<EventAccess, number> = {
  free: 1,
  paid: 2,
  annual: 3,
  vip: 4,
};

export function canAccessEvent(
  access: EventAccess,
  tier: MembershipTier | null,
  isAdmin: boolean,
): boolean {
  if (isAdmin) return true;
  return accessRank[access] <= tierRank[tier ?? "free"];
}

export function isWithin24h(startsAt: string): boolean {
  const t = new Date(startsAt).getTime();
  const diff = t - Date.now();
  return diff > 0 && diff < 24 * 60 * 60 * 1000;
}

export interface Countdown {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  total: number;
}

export function computeCountdown(startsAt: string): Countdown {
  const total = Math.max(0, new Date(startsAt).getTime() - Date.now());
  const seconds = Math.floor(total / 1000);
  return {
    days: Math.floor(seconds / 86400),
    hours: Math.floor((seconds % 86400) / 3600),
    minutes: Math.floor((seconds % 3600) / 60),
    seconds: seconds % 60,
    total,
  };
}

export function formatCountdown(c: Countdown): string {
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${pad(c.days)}:${pad(c.hours)}:${pad(c.minutes)}:${pad(c.seconds)}`;
}

export function formatEventDateTime(startsAt: string): string {
  const d = new Date(startsAt);
  return d.toLocaleString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}
