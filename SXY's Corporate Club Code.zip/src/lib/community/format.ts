/**
 * Helpers for the Community Exchange — relative time stamps, role badges,
 * grouping consecutive messages, and lightweight markdown rendering for
 * **bold** + line breaks.
 */
import * as React from "react";
import type { MembershipTier } from "@/integrations/supabase/AuthContext";

const MIN = 60_000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

export function formatRelativeTime(iso: string): string {
  const ts = new Date(iso).getTime();
  const now = Date.now();
  const diff = now - ts;
  if (diff < 60_000) return "just now";
  if (diff < HOUR) {
    const mins = Math.floor(diff / MIN);
    return `${mins} min${mins === 1 ? "" : "s"} ago`;
  }
  const today = new Date();
  const sameDay =
    new Date(ts).toDateString() === today.toDateString();
  if (sameDay) {
    return `Today ${new Date(ts).toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    })}`;
  }
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (new Date(ts).toDateString() === yesterday.toDateString()) {
    return `Yesterday ${new Date(ts).toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    })}`;
  }
  return new Date(ts).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}

export function formatDayDivider(iso: string): string {
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === yesterday.toDateString()) return "Yesterday";
  return d.toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });
}

export function shouldGroupWithPrev(
  curr: { sender_id: string; created_at: string },
  prev: { sender_id: string; created_at: string } | undefined,
): boolean {
  if (!prev) return false;
  if (prev.sender_id !== curr.sender_id) return false;
  const dt =
    new Date(curr.created_at).getTime() - new Date(prev.created_at).getTime();
  return dt < 5 * MIN;
}

export function isNewDay(
  curr: { created_at: string },
  prev: { created_at: string } | undefined,
): boolean {
  if (!prev) return true;
  return (
    new Date(curr.created_at).toDateString() !==
    new Date(prev.created_at).toDateString()
  );
}

export interface RoleBadge {
  label: string;
  className: string;
}

export function roleBadge(opts: {
  isAdmin?: boolean | null;
  tier?: MembershipTier | null;
}): RoleBadge {
  if (opts.isAdmin) {
    return {
      label: "Admin",
      className:
        "border-[color:var(--border-gold)] bg-[color:var(--gold-glow)] text-gold-light",
    };
  }
  if (opts.tier === "vip") {
    return {
      label: "VIP",
      className:
        "border-border-teal bg-[color:var(--teal-glow)] text-teal-light",
    };
  }
  return {
    label: "Member",
    className: "border-border-base bg-charcoal-card text-text-muted",
  };
}

/**
 * Render light markdown: `**bold**` + preserve line breaks.
 * Returns an array of React nodes safe to splat into JSX.
 */
export function renderMessageBody(text: string): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  const lines = text.split("\n");
  lines.forEach((line, lineIdx) => {
    const parts = line.split(/(\*\*[^*]+\*\*)/g);
    parts.forEach((part, partIdx) => {
      const key = `${lineIdx}-${partIdx}`;
      if (part.startsWith("**") && part.endsWith("**")) {
        out.push(
          React.createElement(
            "strong",
            { key, className: "font-semibold text-text-primary" },
            part.slice(2, -2),
          ),
        );
      } else if (part) {
        out.push(React.createElement(React.Fragment, { key }, part));
      }
    });
    if (lineIdx < lines.length - 1) {
      out.push(React.createElement("br", { key: `br-${lineIdx}` }));
    }
  });
  return out;
}

export function presenceDot(lastSeenAt: string | null): {
  className: string;
  label: string;
} {
  if (!lastSeenAt)
    return { className: "bg-text-dim", label: "Offline" };
  const dt = Date.now() - new Date(lastSeenAt).getTime();
  if (dt < 5 * MIN) return { className: "bg-emerald-400", label: "Online" };
  if (dt < 30 * MIN)
    return { className: "bg-amber-400", label: "Recently active" };
  return { className: "bg-text-dim", label: "Offline" };
}
