/**
 * Shared types for the Community Exchange feature.
 */
import type { MembershipTier } from "@/integrations/supabase/AuthContext";

export type ChannelType = "public" | "state" | "vip";
export type PostType = "message" | "announcement" | "resource" | "poll";

export interface CommunityChannel {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  channel_type: ChannelType;
  icon: string | null;
  state_code: string | null;
  display_order: number;
}

export interface CommunityProfileLite {
  id: string;
  full_name: string | null;
  email: string | null;
  avatar_color: string;
  state: string | null;
  tier: MembershipTier;
  last_seen_at: string | null;
  is_active: boolean;
  is_admin?: boolean;
}

export interface CommunityReaction {
  id: string;
  message_id: string;
  user_id: string;
  emoji: string;
}

export interface CommunityMessage {
  id: string;
  channel_id: string | null;
  sender_id: string;
  content: string | null;
  body: string | null;
  embed_title: string | null;
  embed_desc: string | null;
  embed_link: string | null;
  is_pinned: boolean;
  is_announcement: boolean;
  pinned_by: string | null;
  pinned_at: string | null;
  dm_recipient_id: string | null;
  post_type: PostType;
  resource_category: string | null;
  resource_visibility: string | null;
  poll_options: unknown;
  poll_closes_at: string | null;
  created_at: string;
}

export interface MessageWithSender extends CommunityMessage {
  sender: CommunityProfileLite | null;
  reactions: CommunityReaction[];
}

export type ChannelOrUpgradeGate =
  | { kind: "channel"; channel: CommunityChannel }
  | { kind: "gate"; channel: CommunityChannel; reason: "vip" };
