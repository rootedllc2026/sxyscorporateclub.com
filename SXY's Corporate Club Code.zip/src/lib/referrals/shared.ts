/**
 * Shared helpers for the Referral Portal — category catalog, formatters,
 * fee math, and small types. Kept under /lib/ so the file-based router
 * doesn't pick it up as a route.
 */

export type ReferralCategoryId =
  | "all"
  | "cleaning"
  | "contractor"
  | "strategy"
  | "marketing"
  | "legal"
  | "tech_ai"
  | "other";

export interface ReferralCategoryMeta {
  id: ReferralCategoryId;
  label: string;
  emoji: string;
}

export const REFERRAL_CATEGORIES: ReferralCategoryMeta[] = [
  { id: "all",        label: "All",          emoji: "✦" },
  { id: "cleaning",   label: "Cleaning",     emoji: "🧼" },
  { id: "contractor", label: "Contractor",   emoji: "🛠" },
  { id: "strategy",   label: "Strategy",     emoji: "🧭" },
  { id: "marketing",  label: "Marketing",    emoji: "📣" },
  { id: "legal",      label: "Legal",        emoji: "⚖️" },
  { id: "tech_ai",    label: "Tech/AI",      emoji: "🤖" },
];

/** Bookable categories (excludes "all" for select inputs). */
export const REFERRAL_BOOKABLE_CATEGORIES: ReferralCategoryMeta[] =
  REFERRAL_CATEGORIES.filter((c) => c.id !== "all");

export function refCategoryEmoji(id: string | null | undefined): string {
  return REFERRAL_CATEGORIES.find((c) => c.id === id)?.emoji ?? "🏷️";
}

export function refCategoryLabel(id: string | null | undefined): string {
  return REFERRAL_CATEGORIES.find((c) => c.id === id)?.label ?? "Other";
}

export const USD = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

export const USD_2 = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

export function formatPrice(value: number | string | null | undefined): string {
  if (value == null) return "—";
  const n = Number(value);
  if (!Number.isFinite(n) || n === 0) return "—";
  return USD.format(n);
}

/**
 * Standard Club Directory transaction fee charged on every booking made
 * through the platform. VIP members get a reduced rate. The fee is added
 * on top of the service price at checkout — it is not deducted from what
 * the provider receives. Both buyer tier and provider tier are irrelevant
 * to the *provider's* net; only the buyer's tier determines the fee they
 * pay on top.
 *
 * Source of truth: change here only. UI labels read from these constants.
 */
export const CLUB_FEE_PCT = 3;
export const CLUB_FEE_PCT_VIP = 2;

/** Returns the fee % the given member tier pays at Club Directory checkout. */
export function clubFeePctForTier(
  tier: string | null | undefined,
): number {
  return tier === "vip" ? CLUB_FEE_PCT_VIP : CLUB_FEE_PCT;
}

/** Compute the booking total + breakdown given a service amount and fee %. */
export function bookingMath(
  serviceAmount: number,
  feePct: number,
): { service: number; fee: number; total: number; net: number } {
  const service = Math.max(0, Number(serviceAmount) || 0);
  const pct = Math.max(0, Number(feePct) || 0);
  const fee = Math.round(service * pct) / 100;
  return {
    service,
    fee,
    total: service + fee,
    net: service - fee,
  };
}

export const DAYS_OF_WEEK = [
  { id: "Mon", label: "Mon" },
  { id: "Tue", label: "Tue" },
  { id: "Wed", label: "Wed" },
  { id: "Thu", label: "Thu" },
  { id: "Fri", label: "Fri" },
  { id: "Sat", label: "Sat" },
  { id: "Sun", label: "Sun" },
] as const;

export type DayId = (typeof DAYS_OF_WEEK)[number]["id"];

const DAY_INDEX: Record<DayId, number> = {
  Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6,
};

export function dayLabelFromDate(date: Date): DayId {
  const idx = date.getDay();
  return (Object.keys(DAY_INDEX) as DayId[]).find(
    (k) => DAY_INDEX[k] === idx,
  ) ?? "Mon";
}

/** Generate "HH:MM" slot strings between start/end at length intervals. */
export function generateTimeSlots(
  startTime: string | null | undefined,
  endTime: string | null | undefined,
  lengthMin: number | null | undefined,
): string[] {
  if (!startTime || !endTime) return [];
  const len = Math.max(15, Number(lengthMin) || 60);
  const [sh, sm] = startTime.split(":").map(Number);
  const [eh, em] = endTime.split(":").map(Number);
  if ([sh, sm, eh, em].some((n) => Number.isNaN(n))) return [];
  const startMin = sh * 60 + sm;
  const endMin = eh * 60 + em;
  const out: string[] = [];
  for (let m = startMin; m + len <= endMin; m += len) {
    const hh = String(Math.floor(m / 60)).padStart(2, "0");
    const mm = String(m % 60).padStart(2, "0");
    out.push(`${hh}:${mm}`);
  }
  return out;
}

export function pageStatusVariant(
  status: string,
): "teal" | "gold" | "green" | "gray" | "amber" | "red" {
  switch (status) {
    case "live":      return "green";
    case "pending":   return "amber";
    case "draft":     return "gray";
    case "archived":  return "gray";
    default:          return "gray";
  }
}

export function bookingStatusVariant(
  status: string,
): "teal" | "gold" | "green" | "gray" | "amber" | "red" {
  switch (status) {
    case "confirmed":          return "teal";
    case "completed":          return "green";
    case "pending_payment":    return "amber";
    case "pending_agreement":  return "amber";
    case "agreement_declined": return "red";
    case "cancelled":          return "red";
    case "refunded":           return "gray";
    default:                   return "gray";
  }
}

export function bookingStatusLabel(status: string): string {
  switch (status) {
    case "pending_payment":    return "Pending payment";
    case "pending_agreement":  return "Awaiting trade acceptance";
    case "agreement_declined": return "Trade declined";
    case "confirmed":          return "Confirmed";
    case "completed":          return "Completed";
    case "cancelled":          return "Cancelled";
    case "refunded":           return "Refunded";
    default:                   return status;
  }
}

/** Banner colors keyed off category — used as gradient bg on cards. */
export function categoryBannerGradient(category: string | null | undefined): string {
  switch (category) {
    case "cleaning":
      return "linear-gradient(135deg, oklch(0.55 0.085 210), oklch(0.72 0.115 215))";
    case "contractor":
      return "linear-gradient(135deg, oklch(0.74 0.115 85), oklch(0.84 0.115 88))";
    case "strategy":
      return "linear-gradient(135deg, oklch(0.55 0.085 270), oklch(0.72 0.115 280))";
    case "marketing":
      return "linear-gradient(135deg, oklch(0.65 0.18 25), oklch(0.78 0.18 30))";
    case "legal":
      return "linear-gradient(135deg, oklch(0.45 0.08 270), oklch(0.55 0.10 250))";
    case "tech_ai":
      return "linear-gradient(135deg, oklch(0.55 0.12 145), oklch(0.72 0.14 160))";
    default:
      return "linear-gradient(135deg, oklch(0.30 0.04 210), oklch(0.45 0.07 215))";
  }
}
