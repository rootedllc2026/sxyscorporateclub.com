/**
 * Shared bidding-module helpers — category catalog, formatters, and small
 * Supabase row types. Kept out of the route files so the file-based router
 * doesn't pick them up as a child route.
 *
 * NOTE: file lives under /routes/bidding/ but starts with `_` — TanStack
 * Router ignores any file/directory beginning with `_` for routing purposes,
 * making this a safe colocation spot.
 */

export type CategoryId =
  | "all"
  | "strategy"
  | "contractor"
  | "cleaning"
  | "marketing"
  | "legal"
  | "trades"
  | "tech_ai";

export interface CategoryMeta {
  id: CategoryId;
  label: string;
  emoji: string;
}

export const CATEGORIES: CategoryMeta[] = [
  { id: "all",        label: "All",          emoji: "✦" },
  { id: "strategy",   label: "Strategy",     emoji: "🧭" },
  { id: "contractor", label: "Contractor",   emoji: "🛠" },
  { id: "cleaning",   label: "Cleaning",     emoji: "🧼" },
  { id: "marketing",  label: "Marketing",    emoji: "📣" },
  { id: "legal",      label: "Legal",        emoji: "⚖️" },
  { id: "trades",     label: "HVAC/Trades",  emoji: "🔧" },
  { id: "tech_ai",    label: "Tech/AI",      emoji: "🤖" },
];

export function categoryEmoji(id: string | null | undefined): string {
  return CATEGORIES.find((c) => c.id === id)?.emoji ?? "📦";
}

export function categoryLabel(id: string | null | undefined): string {
  return CATEGORIES.find((c) => c.id === id)?.label ?? "Other";
}

export const BID_CURRENCY = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

export function formatBudget(
  budget: number | string | null,
  budgetMin?: number | string | null,
  budgetMax?: number | string | null,
): string {
  const b = budget != null ? Number(budget) : NaN;
  if (!Number.isNaN(b) && b > 0) return BID_CURRENCY.format(b);
  const lo = budgetMin != null ? Number(budgetMin) : NaN;
  const hi = budgetMax != null ? Number(budgetMax) : NaN;
  if (!Number.isNaN(lo) && !Number.isNaN(hi)) {
    return `${BID_CURRENCY.format(lo)} – ${BID_CURRENCY.format(hi)}`;
  }
  if (!Number.isNaN(lo)) return `From ${BID_CURRENCY.format(lo)}`;
  if (!Number.isNaN(hi)) return `Up to ${BID_CURRENCY.format(hi)}`;
  return "TBD";
}

/** Effective budget number used for averages / sums. */
export function budgetNumber(row: {
  budget: number | string | null;
  budget_min: number | string | null;
  budget_max: number | string | null;
}): number | null {
  if (row.budget != null) return Number(row.budget);
  const lo = row.budget_min != null ? Number(row.budget_min) : null;
  const hi = row.budget_max != null ? Number(row.budget_max) : null;
  if (lo != null && hi != null) return (lo + hi) / 2;
  return lo ?? hi ?? null;
}

export function timeUntil(iso: string | null): string {
  if (!iso) return "No deadline";
  const ms = new Date(iso).getTime() - Date.now();
  if (ms < 0) return "Closed";
  const day = 24 * 60 * 60 * 1000;
  const days = Math.round(ms / day);
  if (days >= 7) return `${Math.floor(days / 7)}w left`;
  if (days >= 1) return `${days}d left`;
  const hours = Math.round(ms / (60 * 60 * 1000));
  return `${Math.max(1, hours)}h left`;
}

export function statusTagVariant(status: string): "teal" | "gold" | "green" | "gray" {
  switch (status) {
    case "open":      return "teal";
    case "reviewing": return "gold";
    case "awarded":   return "green";
    default:          return "gray";
  }
}

export function statusLabel(status: string): string {
  switch (status) {
    case "open":      return "Open";
    case "reviewing": return "In Review";
    case "in_review": return "In Review";
    case "awarded":   return "Awarded";
    case "closed":    return "Closed";
    default:          return status;
  }
}

export function bidStatusVariant(status: string): "teal" | "gold" | "green" | "red" | "gray" {
  switch (status) {
    case "submitted":   return "teal";
    case "shortlisted": return "gold";
    case "awarded":     return "green";
    case "rejected":    return "red";
    case "draft":       return "gray";
    default:            return "gray";
  }
}
