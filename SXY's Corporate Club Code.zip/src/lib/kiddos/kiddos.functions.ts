/**
 * Kiddos server functions: all credit-affecting operations live here so they
 * can run with the service_role and bypass the client-block triggers on
 * kiddo_wallets / credit_ledger / redemptions.
 *
 * Auth: we use the same JWT-from-header pattern as downgradeToFree (project
 * does not wire `attachSupabaseAuth` globally yet).
 */
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";

function readBearerJwt(): string | null {
  const auth = getRequestHeader("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) return auth.slice(7);
  const cookie = getRequestHeader("cookie") ?? "";
  const m = cookie.match(/sb-[^=]+-auth-token=([^;]+)/);
  if (!m) return null;
  try {
    const decoded = decodeURIComponent(m[1]);
    const arr = JSON.parse(decoded);
    return Array.isArray(arr) ? arr[0] : decoded;
  } catch {
    return null;
  }
}

async function getCallerId(): Promise<string> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const jwt = readBearerJwt();
  if (!jwt) throw new Error("Not signed in.");
  const { data, error } = await supabaseAdmin.auth.getUser(jwt);
  if (error || !data?.user) throw new Error("Invalid session.");
  return data.user.id;
}

async function assertIsParentOf(parentId: string, childId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("parent_child_links")
    .select("id")
    .eq("parent_user_id", parentId)
    .eq("child_user_id", childId)
    .eq("status", "active")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("You are not linked to that child.");
}

async function ensureWallet(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await supabaseAdmin
    .from("kiddo_wallets")
    .upsert({ user_id: userId }, { onConflict: "user_id" });
}

async function adjustWallet(
  userId: string,
  delta: number,
  reason:
    | "parent_load"
    | "allowance"
    | "chore_reward"
    | "redemption_buy"
    | "redemption_sell"
    | "refund"
    | "adjustment",
  extras: { note?: string; chore_id?: string; redeemable_id?: string; counterparty_user_id?: string } = {},
) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await ensureWallet(userId);
  const { data: wallet, error: wErr } = await supabaseAdmin
    .from("kiddo_wallets")
    .select("balance_credits, lifetime_earned, lifetime_spent")
    .eq("user_id", userId)
    .single();
  if (wErr || !wallet) throw new Error("Wallet missing.");
  const next = wallet.balance_credits + delta;
  if (next < 0) throw new Error("Not enough credits.");
  const earned = delta > 0 ? wallet.lifetime_earned + delta : wallet.lifetime_earned;
  const spent = delta < 0 ? wallet.lifetime_spent + Math.abs(delta) : wallet.lifetime_spent;
  const { error: uErr } = await supabaseAdmin
    .from("kiddo_wallets")
    .update({ balance_credits: next, lifetime_earned: earned, lifetime_spent: spent })
    .eq("user_id", userId);
  if (uErr) throw new Error(uErr.message);
  const { error: lErr } = await supabaseAdmin.from("credit_ledger").insert({
    user_id: userId,
    delta_credits: delta,
    reason,
    note: extras.note ?? null,
    chore_id: extras.chore_id ?? null,
    redeemable_id: extras.redeemable_id ?? null,
    counterparty_user_id: extras.counterparty_user_id ?? null,
  });
  if (lErr) throw new Error(lErr.message);
}

/* -------------------- Parent: create child account -------------------- */

export const createChildAccount = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        displayName: z.string().min(1).max(60),
        dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        loginEmail: z.string().email(),
        tempPassword: z.string().min(8).max(72),
        avatarEmoji: z.string().max(8).optional(),
        relationship: z.string().max(40).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const parentId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const dob = new Date(data.dateOfBirth);
    const ageMs = Date.now() - dob.getTime();
    const age = Math.floor(ageMs / (365.25 * 24 * 3600 * 1000));
    if (age < 10 || age > 18) throw new Error("Kiddos is for ages 10–18.");
    const band: "under_13" | "teen" = age < 13 ? "under_13" : "teen";

    const { data: created, error: cErr } = await supabaseAdmin.auth.admin.createUser({
      email: data.loginEmail,
      password: data.tempPassword,
      email_confirm: true,
      user_metadata: { display_name: data.displayName, kiddo: true },
    });
    if (cErr || !created?.user) throw new Error(cErr?.message ?? "Could not create child account.");
    const childId = created.user.id;

    const { error: pErr } = await supabaseAdmin
      .from("profiles")
      .upsert({ id: childId, full_name: data.displayName, email: data.loginEmail }, { onConflict: "id" });
    if (pErr) {
      // best-effort cleanup
      await supabaseAdmin.auth.admin.deleteUser(childId);
      throw new Error(pErr.message);
    }

    const { error: kErr } = await supabaseAdmin.from("kiddo_profiles").insert({
      id: childId,
      display_name: data.displayName,
      date_of_birth: data.dateOfBirth,
      age_band: band,
      avatar_emoji: data.avatarEmoji ?? "🧒",
      parental_consent_at: new Date().toISOString(),
    });
    if (kErr) throw new Error(kErr.message);

    const { error: lErr } = await supabaseAdmin.from("parent_child_links").insert({
      parent_user_id: parentId,
      child_user_id: childId,
      status: "active",
      relationship: data.relationship ?? "parent",
    });
    if (lErr) throw new Error(lErr.message);

    await ensureWallet(childId);

    return { ok: true, childId };
  });

/* -------------------- Parent: load credits into child wallet -------------------- */

export const loadCredits = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        childId: z.string().uuid(),
        amount: z.number().int().positive().max(10_000),
        note: z.string().max(200).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const parentId = await getCallerId();
    await assertIsParentOf(parentId, data.childId);
    await adjustWallet(data.childId, data.amount, "parent_load", {
      note: data.note ?? "Parent load",
      counterparty_user_id: parentId,
    });
    return { ok: true };
  });

/* -------------------- Parent: create chore -------------------- */

export const createChore = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        childId: z.string().uuid(),
        title: z.string().min(1).max(120),
        description: z.string().max(500).optional(),
        rewardCredits: z.number().int().positive().max(10_000),
        dueAt: z.string().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const parentId = await getCallerId();
    await assertIsParentOf(parentId, data.childId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("chores").insert({
      parent_user_id: parentId,
      child_user_id: data.childId,
      title: data.title,
      description: data.description ?? null,
      reward_credits: data.rewardCredits,
      due_at: data.dueAt ?? null,
      status: "open",
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* -------------------- Kid: submit chore -------------------- */

export const submitChore = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ choreId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const childId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: chore, error } = await supabaseAdmin
      .from("chores")
      .select("id, status, child_user_id")
      .eq("id", data.choreId)
      .single();
    if (error || !chore) throw new Error("Chore not found.");
    if (chore.child_user_id !== childId) throw new Error("Not your chore.");
    if (chore.status !== "open") throw new Error("Chore is not open.");
    const { error: uErr } = await supabaseAdmin
      .from("chores")
      .update({ status: "submitted" })
      .eq("id", data.choreId);
    if (uErr) throw new Error(uErr.message);
    return { ok: true };
  });

/* -------------------- Parent: approve chore → credit child -------------------- */

export const approveChore = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ choreId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const parentId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: chore, error } = await supabaseAdmin
      .from("chores")
      .select("id, status, child_user_id, parent_user_id, reward_credits, title")
      .eq("id", data.choreId)
      .single();
    if (error || !chore) throw new Error("Chore not found.");
    if (chore.parent_user_id !== parentId) throw new Error("Not your chore to approve.");
    if (chore.status === "approved") return { ok: true };
    await adjustWallet(chore.child_user_id, chore.reward_credits, "chore_reward", {
      note: `Chore: ${chore.title}`,
      chore_id: chore.id,
      counterparty_user_id: parentId,
    });
    const { error: uErr } = await supabaseAdmin
      .from("chores")
      .update({ status: "approved", approved_at: new Date().toISOString() })
      .eq("id", data.choreId);
    if (uErr) throw new Error(uErr.message);
    return { ok: true };
  });

/* -------------------- Kid: create redeemable listing -------------------- */

export const createRedeemable = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        title: z.string().min(1).max(80),
        description: z.string().max(300).optional(),
        priceCredits: z.number().int().positive().max(100_000),
        quantity: z.number().int().positive().max(999).default(1),
        category: z.string().max(40).optional(),
        imageEmoji: z.string().max(8).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const ownerId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("redeemables").insert({
      owner_user_id: ownerId,
      title: data.title,
      description: data.description ?? null,
      price_credits: data.priceCredits,
      quantity: data.quantity,
      category: data.category ?? null,
      image_emoji: data.imageEmoji ?? "🎁",
      status: "active",
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* -------------------- Kid: redeem (buy) -------------------- */

export const redeemItem = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ redeemableId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const buyerId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: item, error } = await supabaseAdmin
      .from("redeemables")
      .select("id, owner_user_id, price_credits, quantity, status, title")
      .eq("id", data.redeemableId)
      .single();
    if (error || !item) throw new Error("Item not found.");
    if (item.status !== "active" || item.quantity < 1) throw new Error("Item not available.");
    if (item.owner_user_id === buyerId) throw new Error("Can't redeem your own listing.");

    // Debit buyer, credit seller, record redemption.
    await adjustWallet(buyerId, -item.price_credits, "redemption_buy", {
      note: `Redeem: ${item.title}`,
      redeemable_id: item.id,
      counterparty_user_id: item.owner_user_id,
    });
    await adjustWallet(item.owner_user_id, item.price_credits, "redemption_sell", {
      note: `Sold: ${item.title}`,
      redeemable_id: item.id,
      counterparty_user_id: buyerId,
    });

    const nextQty = item.quantity - 1;
    const { error: rErr } = await supabaseAdmin
      .from("redeemables")
      .update({ quantity: nextQty, status: nextQty === 0 ? "sold" : "active" })
      .eq("id", item.id);
    if (rErr) throw new Error(rErr.message);

    const { error: redErr } = await supabaseAdmin.from("redemptions").insert({
      redeemable_id: item.id,
      buyer_user_id: buyerId,
      seller_user_id: item.owner_user_id,
      price_credits: item.price_credits,
      status: "pending",
    });
    if (redErr) throw new Error(redErr.message);

    return { ok: true };
  });

/* -------------------- Seller: mark redemption fulfilled -------------------- */

export const fulfillRedemption = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ redemptionId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const sellerId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: r, error } = await supabaseAdmin
      .from("redemptions")
      .select("id, seller_user_id, status")
      .eq("id", data.redemptionId)
      .single();
    if (error || !r) throw new Error("Redemption not found.");
    if (r.seller_user_id !== sellerId) throw new Error("Not your redemption.");
    if (r.status !== "pending") throw new Error("Already settled.");
    const { error: uErr } = await supabaseAdmin
      .from("redemptions")
      .update({ status: "fulfilled", fulfilled_at: new Date().toISOString() })
      .eq("id", r.id);
    if (uErr) throw new Error(uErr.message);
    return { ok: true };
  });

/* -------------------- Kid: savings goals -------------------- */

export const createSavingsGoal = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        title: z.string().min(1).max(80),
        targetCredits: z.number().int().positive().max(1_000_000),
        targetDate: z.string().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const userId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("savings_goals").insert({
      user_id: userId,
      title: data.title,
      target_credits: data.targetCredits,
      target_date: data.targetDate ?? null,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ==================== Videos & kid businesses ==================== */

async function isAdmin(userId: string): Promise<boolean> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  return !!data;
}

/** Kid (or parent on their behalf) submits a video. Always starts pending_parent
 *  unless an admin uploads an official video (auto-approved + published). */
export const submitKiddoVideo = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        title: z.string().min(1).max(120),
        description: z.string().max(1000).optional(),
        topic: z.string().max(60).optional(),
        videoUrl: z.string().url().max(500).optional(),
        storagePath: z.string().max(500).optional(),
        thumbnailUrl: z.string().url().max(500).optional(),
        durationSeconds: z.number().int().min(0).max(600),
        kind: z.enum(["official", "kid_submission"]).default("kid_submission"),
        creatorUserId: z.string().uuid().optional(),
      })
      .refine((v) => !!v.videoUrl || !!v.storagePath, { message: "videoUrl or storagePath required" })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const callerId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const admin = await isAdmin(callerId);

    let kind = data.kind;
    let creator = data.creatorUserId ?? callerId;

    if (kind === "official") {
      if (!admin) throw new Error("Only admins can publish official videos.");
      creator = data.creatorUserId ?? callerId;
    } else if (creator !== callerId) {
      // parent submitting on behalf of child
      await assertIsParentOf(callerId, creator);
    }

    const isOfficial = kind === "official";
    const row = {
      creator_user_id: creator,
      kind,
      title: data.title,
      description: data.description ?? null,
      topic: data.topic ?? null,
      video_url: data.videoUrl ?? null,
      storage_path: data.storagePath ?? null,
      thumbnail_url: data.thumbnailUrl ?? null,
      duration_seconds: data.durationSeconds,
      status: isOfficial ? ("approved" as const) : ("pending_parent" as const),
      is_published: isOfficial,
      parent_approved_at: isOfficial ? new Date().toISOString() : null,
      admin_approved_at: isOfficial ? new Date().toISOString() : null,
      admin_approved_by: isOfficial ? callerId : null,
    };

    const { data: inserted, error } = await supabaseAdmin
      .from("kiddo_videos")
      .insert(row)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { ok: true, id: inserted!.id };
  });

/** Parent approves their child's video → moves to pending_admin. */
export const parentApproveVideo = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ videoId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const parentId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: v, error } = await supabaseAdmin
      .from("kiddo_videos")
      .select("id, creator_user_id, status")
      .eq("id", data.videoId)
      .single();
    if (error || !v) throw new Error("Video not found.");
    if (!v.creator_user_id) throw new Error("No creator on this video.");
    await assertIsParentOf(parentId, v.creator_user_id);
    if (v.status !== "pending_parent") throw new Error("Not awaiting parent approval.");
    const { error: uErr } = await supabaseAdmin
      .from("kiddo_videos")
      .update({
        status: "pending_admin",
        parent_approved_by: parentId,
        parent_approved_at: new Date().toISOString(),
      })
      .eq("id", v.id);
    if (uErr) throw new Error(uErr.message);
    return { ok: true };
  });

/** Admin approves → publish. */
export const adminApproveVideo = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ videoId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const callerId = await getCallerId();
    if (!(await isAdmin(callerId))) throw new Error("Admins only.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("kiddo_videos")
      .update({
        status: "approved",
        is_published: true,
        admin_approved_by: callerId,
        admin_approved_at: new Date().toISOString(),
      })
      .eq("id", data.videoId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Parent or admin can reject. */
export const rejectKiddoVideo = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ videoId: z.string().uuid(), reason: z.string().max(300).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const callerId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: v, error } = await supabaseAdmin
      .from("kiddo_videos")
      .select("id, creator_user_id")
      .eq("id", data.videoId)
      .single();
    if (error || !v) throw new Error("Video not found.");
    const admin = await isAdmin(callerId);
    if (!admin && v.creator_user_id) await assertIsParentOf(callerId, v.creator_user_id);
    const { error: uErr } = await supabaseAdmin
      .from("kiddo_videos")
      .update({
        status: "rejected",
        is_published: false,
        rejection_reason: data.reason ?? null,
      })
      .eq("id", v.id);
    if (uErr) throw new Error(uErr.message);
    return { ok: true };
  });

/** Record a view; on first view by this viewer, award the creator credits_per_view. */
export const recordVideoView = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ videoId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const viewerId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: v, error } = await supabaseAdmin
      .from("kiddo_videos")
      .select("id, creator_user_id, credits_per_view, status, is_published, title")
      .eq("id", data.videoId)
      .single();
    if (error || !v) throw new Error("Video not found.");
    if (v.status !== "approved" || !v.is_published) throw new Error("Video not available.");

    // Try to insert a view row; unique(video_id, viewer_user_id) protects against double-credit.
    const { error: ivErr } = await supabaseAdmin
      .from("kiddo_video_views")
      .insert({
        video_id: v.id,
        viewer_user_id: viewerId,
        credits_awarded:
          v.creator_user_id && v.creator_user_id !== viewerId ? v.credits_per_view : 0,
      });
    if (ivErr) {
      // already viewed — silent OK
      if (/duplicate key/i.test(ivErr.message)) return { ok: true, awarded: 0 };
      throw new Error(ivErr.message);
    }

    // bump view count
    await supabaseAdmin
      .from("kiddo_videos")
      .update({ view_count: (await getViewCount(v.id)) })
      .eq("id", v.id);

    let awarded = 0;
    if (v.creator_user_id && v.creator_user_id !== viewerId && v.credits_per_view > 0) {
      await adjustWallet(v.creator_user_id, v.credits_per_view, "adjustment", {
        note: `View: ${v.title}`,
        counterparty_user_id: viewerId,
      });
      awarded = v.credits_per_view;
    }
    return { ok: true, awarded };
  });

async function getViewCount(videoId: string): Promise<number> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { count } = await supabaseAdmin
    .from("kiddo_video_views")
    .select("id", { count: "exact", head: true })
    .eq("video_id", videoId);
  return count ?? 0;
}

/* ---------- Kid business pages ---------- */

export const upsertKidBusinessPage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        ownerUserId: z.string().uuid().optional(),
        name: z.string().min(1).max(80),
        tagline: z.string().max(160).optional(),
        description: z.string().max(1000).optional(),
        emoji: z.string().max(8).optional(),
        category: z.string().max(40).optional(),
        youtubeUrl: z
          .string()
          .url()
          .max(300)
          .regex(/youtube\.com|youtu\.be/i, "Must be a YouTube URL")
          .optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const callerId = await getCallerId();
    const owner = data.ownerUserId ?? callerId;
    if (owner !== callerId) await assertIsParentOf(callerId, owner);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const row = {
      owner_user_id: owner,
      name: data.name,
      tagline: data.tagline ?? null,
      description: data.description ?? null,
      emoji: data.emoji ?? "🏪",
      category: data.category ?? null,
      youtube_url: data.youtubeUrl ?? null,
      status: "pending_parent" as const,
    };
    if (data.id) {
      const { error } = await supabaseAdmin
        .from("kid_business_pages")
        .update(row)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { ok: true, id: data.id };
    }
    const { data: inserted, error } = await supabaseAdmin
      .from("kid_business_pages")
      .insert(row)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { ok: true, id: inserted!.id };
  });

export const parentApproveBusiness = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ pageId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const parentId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: p, error } = await supabaseAdmin
      .from("kid_business_pages")
      .select("id, owner_user_id, status")
      .eq("id", data.pageId)
      .single();
    if (error || !p) throw new Error("Page not found.");
    await assertIsParentOf(parentId, p.owner_user_id);
    if (p.status !== "pending_parent") throw new Error("Not awaiting parent.");
    const { error: uErr } = await supabaseAdmin
      .from("kid_business_pages")
      .update({
        status: "pending_admin",
        parent_approved_by: parentId,
        parent_approved_at: new Date().toISOString(),
      })
      .eq("id", p.id);
    if (uErr) throw new Error(uErr.message);
    return { ok: true };
  });

export const adminApproveBusiness = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ pageId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const callerId = await getCallerId();
    if (!(await isAdmin(callerId))) throw new Error("Admins only.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("kid_business_pages")
      .update({
        status: "approved",
        admin_approved_by: callerId,
        admin_approved_at: new Date().toISOString(),
      })
      .eq("id", data.pageId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const rejectKidBusinessPage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ pageId: z.string().uuid(), reason: z.string().max(300).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const callerId = await getCallerId();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: p, error } = await supabaseAdmin
      .from("kid_business_pages")
      .select("id, owner_user_id")
      .eq("id", data.pageId)
      .single();
    if (error || !p) throw new Error("Page not found.");
    if (!(await isAdmin(callerId))) await assertIsParentOf(callerId, p.owner_user_id);
    const { error: uErr } = await supabaseAdmin
      .from("kid_business_pages")
      .update({ status: "rejected", rejection_reason: data.reason ?? null })
      .eq("id", p.id);
    if (uErr) throw new Error(uErr.message);
    return { ok: true };
  });

/** Returns a short-lived signed URL for an uploaded video in `kiddo-videos`. */
export const signKiddoVideoUrl = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ path: z.string().min(1).max(500) }).parse(input))
  .handler(async ({ data }) => {
    await getCallerId(); // require auth
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error } = await supabaseAdmin.storage
      .from("kiddo-videos")
      .createSignedUrl(data.path, 60 * 60);
    if (error || !signed) throw new Error(error?.message ?? "Could not sign URL.");
    return { url: signed.signedUrl };
  });

