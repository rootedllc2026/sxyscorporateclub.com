/** Convert any YouTube / Vimeo URL into a player embed URL. Returns null if unrecognized. */
export function toEmbedUrl(input: string): string | null {
  try {
    const u = new URL(input.trim());
    if (u.hostname.includes("youtube.com")) {
      const id = u.searchParams.get("v");
      if (id) return `https://www.youtube.com/embed/${id}`;
      // /embed/... or /shorts/...
      const parts = u.pathname.split("/").filter(Boolean);
      if (parts[0] === "embed" && parts[1]) return `https://www.youtube.com/embed/${parts[1]}`;
      if (parts[0] === "shorts" && parts[1]) return `https://www.youtube.com/embed/${parts[1]}`;
    }
    if (u.hostname === "youtu.be") {
      const id = u.pathname.replace(/^\//, "");
      if (id) return `https://www.youtube.com/embed/${id}`;
    }
    if (u.hostname.includes("vimeo.com")) {
      const id = u.pathname.split("/").filter(Boolean).pop();
      if (id) return `https://player.vimeo.com/video/${id}`;
    }
    return input;
  } catch {
    return null;
  }
}

export function isUploadedVideo(url: string): boolean {
  return /\.(mp4|webm|mov)(\?|$)/i.test(url);
}
