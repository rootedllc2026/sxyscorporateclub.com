/**
 * Client-reachable server function. Server-only imports happen lazily
 * inside .handler() so the client bundle never resolves src/server/*.
 */
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";

type EmailEvent =
  | {
      kind: "membership-welcome";
      to: string;
      fullName?: string | null;
      tier: "free" | "paid" | "annual" | "vip";
    }
  | {
      kind: "payout-approved";
      to: string;
      fullName?: string | null;
      amount: number;
      method?: string | null;
    }
  | {
      kind: "booking-admin-notification";
      clientFullName: string;
      clientEmail: string;
      clientPhone?: string | null;
      serviceName: string;
      bookedDate: string;
      bookedTime?: string | null;
      totalAmount: number;
      netAmount: number;
    };

function readBearerOrCookieJwt(): string | null {
  const auth = getRequestHeader("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) return auth.slice(7);
  const cookie = getRequestHeader("cookie") ?? "";
  const match = cookie.match(/sb-[^=]+-auth-token=([^;]+)/);
  if (!match) return null;
  try {
    const decoded = decodeURIComponent(match[1]);
    const arr = JSON.parse(decoded);
    return Array.isArray(arr) ? arr[0] : decoded;
  } catch {
    return null;
  }
}

export const sendTransactionalEmail = createServerFn({ method: "POST" })
  .inputValidator((input: EmailEvent): EmailEvent => {
    if (!input || typeof input !== "object" || !("kind" in input)) {
      throw new Error("Bad input.");
    }
    return input;
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { sendResendEmail, ADMIN_NOTIFICATION_RECIPIENTS } = await import(
      "@/server/email/resend"
    );
    const {
      buildMembershipWelcome,
      buildPayoutApproved,
      buildBookingAdminNotification,
    } = await import("@/server/email/templates");

    const jwt = readBearerOrCookieJwt();
    if (!jwt) throw new Error("Not signed in.");
    const { data: userData, error: userErr } =
      await supabaseAdmin.auth.getUser(jwt);
    if (userErr || !userData?.user) throw new Error("Invalid session.");

    if (data.kind === "payout-approved") {
      const { data: roleRow } = await supabaseAdmin
        .from("user_roles")
        .select("role")
        .eq("user_id", userData.user.id)
        .eq("role", "admin")
        .maybeSingle();
      if (!roleRow) throw new Error("Forbidden — admin only.");
    }

    switch (data.kind) {
      case "membership-welcome": {
        const { subject, html } = buildMembershipWelcome({
          fullName: data.fullName,
          tier: data.tier,
        });
        return await sendResendEmail({
          to: data.to,
          subject,
          html,
          tag: "membership-welcome",
        });
      }
      case "payout-approved": {
        const { subject, html } = buildPayoutApproved({
          fullName: data.fullName,
          amount: data.amount,
          method: data.method,
        });
        return await sendResendEmail({
          to: data.to,
          subject,
          html,
          tag: "payout-approved",
        });
      }
      case "booking-admin-notification": {
        const { subject, html } = buildBookingAdminNotification({
          clientFullName: data.clientFullName,
          clientEmail: data.clientEmail,
          clientPhone: data.clientPhone,
          serviceName: data.serviceName,
          bookedDate: data.bookedDate,
          bookedTime: data.bookedTime,
          totalAmount: data.totalAmount,
          netAmount: data.netAmount,
        });
        return await sendResendEmail({
          to: ADMIN_NOTIFICATION_RECIPIENTS,
          subject,
          html,
          replyTo: data.clientEmail,
          tag: "booking-admin-notification",
        });
      }
    }
  });
