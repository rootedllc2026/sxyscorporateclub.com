/**
 * Thin client wrapper around the sendTransactionalEmail server function.
 * Best-effort: failures are logged and swallowed so the primary user
 * action (signup, payout approval) is never blocked by a Resend hiccup.
 */
import { sendTransactionalEmail } from "@/lib/email/sendTransactionalEmail.functions";

type Args = Parameters<typeof sendTransactionalEmail>[0]["data"];

export async function sendEmail(args: Args): Promise<boolean> {
  try {
    await sendTransactionalEmail({ data: args });
    return true;
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn("[sendEmail] failed:", err instanceof Error ? err.message : err);
    return false;
  }
}
