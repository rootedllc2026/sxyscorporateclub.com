/**
 * Shared types + helpers for the Apprenticeship module.
 */
import type { MembershipTier } from "@/integrations/supabase/AuthContext";

export type ProgramStatus = "draft" | "open" | "closed" | "archived";
export type ApplicationStatus =
  | "pending"
  | "accepted"
  | "rejected"
  | "withdrawn";
export type MilestoneStatus =
  | "pending"
  | "in_progress"
  | "submitted"
  | "approved";

export interface StructuredQuestion {
  id: string;
  prompt: string;
  [key: string]: string;
}

export interface StructuredAnswer {
  id: string;
  answer: string;
  [key: string]: string;
}

export interface ApprenticeshipProgram {
  id: string;
  owner_id: string;
  title: string;
  summary: string;
  description: string;
  industry: string | null;
  location: string | null;
  duration_weeks: number | null;
  stipend_description: string | null;
  start_date: string | null;
  require_cover_note: boolean;
  require_resume: boolean;
  require_video: boolean;
  require_portfolio: boolean;
  structured_questions: StructuredQuestion[];
  status: ProgramStatus;
  created_at: string;
  updated_at: string;
}

export const PAID_TIERS: MembershipTier[] = ["paid", "annual", "vip"];

export function isPaidTier(tier: MembershipTier | null | undefined): boolean {
  return !!tier && PAID_TIERS.includes(tier);
}

export function applicationStatusLabel(s: ApplicationStatus): string {
  return {
    pending: "Pending review",
    accepted: "Accepted",
    rejected: "Not selected",
    withdrawn: "Withdrawn",
  }[s];
}

export function milestoneStatusLabel(s: MilestoneStatus): string {
  return {
    pending: "Not started",
    in_progress: "In progress",
    submitted: "Submitted for review",
    approved: "Approved",
  }[s];
}

export function newQuestionId(): string {
  return `q_${Math.random().toString(36).slice(2, 10)}`;
}
