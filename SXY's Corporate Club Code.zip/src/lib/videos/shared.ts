/**
 * Shared types & helpers for the Economy Bites module.
 *
 * The videos table uses three series and three access tiers. Membership tiers
 * map to access tiers for gating reads in the UI (RLS in the DB enforces the
 * server-side rule — these helpers are just for nicer UX / lock overlays).
 */
import type { MembershipTier } from "@/integrations/supabase/AuthContext";

export type VideoSeries = "business-bites" | "market-bites" | "bankruptcy-bites";
export type VideoAccess = "free" | "paid" | "vip";

export interface VideoRow {
  id: string;
  title: string;
  description: string | null;
  icon_emoji: string;
  thumbnail_url: string | null;
  video_url: string | null;
  duration_seconds: number;
  series: VideoSeries;
  category: string | null;
  access_level: VideoAccess;
  view_count: number;
  save_count: number;
  is_featured: boolean;
  is_published: boolean;
  notify_on_publish: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface VideoProgressRow {
  id: string;
  user_id: string;
  video_id: string;
  progress_pct: number;
  progress_seconds: number;
  notes: string | null;
  completed: boolean;
  updated_at: string;
}

const tierRank: Record<MembershipTier, number> = {
  free: 1,
  paid: 2,
  annual: 2,
  vip: 3,
};
const accessRank: Record<VideoAccess, number> = {
  free: 1,
  paid: 2,
  vip: 3,
};

/** Can the user actually watch this video, or should we lock it? */
export function canAccessVideo(
  access: VideoAccess,
  tier: MembershipTier | null,
  isAdmin: boolean,
): boolean {
  if (isAdmin) return true;
  return accessRank[access] <= tierRank[tier ?? "free"];
}

export const SERIES_META: Record<
  VideoSeries,
  { title: string; emoji: string; tag: string; access: VideoAccess; gradient: string; ring: string }
> = {
  "business-bites": {
    title: "Business Bites",
    emoji: "💼",
    tag: "Free Access · All Members",
    access: "free",
    gradient: "linear-gradient(135deg, oklch(0.55 0.085 210 / 0.65), oklch(0.22 0.035 215 / 0.9))",
    ring: "border-border-teal",
  },
  "market-bites": {
    title: "Market Bites",
    emoji: "📈",
    tag: "VIP Access · Educational Only",
    access: "vip",
    gradient: "linear-gradient(135deg, oklch(0.42 0.09 85 / 0.85), oklch(0.18 0.025 85 / 0.95))",
    ring: "border-border-gold",
  },
  "bankruptcy-bites": {
    title: "Bankruptcy Bites",
    emoji: "⚖️",
    tag: "VIP Access · Educational Only",
    access: "vip",
    gradient: "linear-gradient(135deg, #1e1230, #120a20)",
    ring: "border-[oklch(0.45_0.15_295/0.5)]",
  },
};

export const CATEGORY_FILTERS = [
  "All",
  "Strategy",
  "Finance",
  "Legal Basics",
  "AI & Tech",
  "Marketing",
  "Free Only",
] as const;

export function formatDuration(secs: number): string {
  if (!secs || secs < 0) return "—";
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  if (m >= 60) {
    const h = Math.floor(m / 60);
    return `${h}h ${m % 60}m`;
  }
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function isNewVideo(created_at: string): boolean {
  const t = new Date(created_at).getTime();
  return Date.now() - t < 7 * 24 * 60 * 60 * 1000;
}

/**
 * Best-effort extractor that turns a YouTube / Vimeo URL into an embed URL.
 * Falls back to the original URL if we don't recognise it (Storage signed
 * URLs go straight through and play in <video>). If the caller accidentally
 * pasted a full <iframe ... src="..."> snippet we pull the src out first.
 */
export function toEmbedUrl(input: string): string {
  // Defensive: if someone pasted an <iframe ...> tag, extract the src URL.
  const iframeMatch = input.match(/<iframe[^>]*\ssrc=["']([^"']+)["']/i);
  const url = iframeMatch ? iframeMatch[1] : input.trim();
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtube.com")) {
      const id = u.searchParams.get("v");
      if (id) return `https://www.youtube.com/embed/${id}`;
    }
    if (u.hostname === "youtu.be") {
      return `https://www.youtube.com/embed${u.pathname}`;
    }
    if (u.hostname.includes("vimeo.com")) {
      const id = u.pathname.split("/").filter(Boolean).pop();
      if (id) return `https://player.vimeo.com/video/${id}`;
    }
    return url;
  } catch {
    return url;
  }
}

export function isVideoFile(url: string): boolean {
  return /\.(mp4|webm|mov|m3u8)(\?|$)/i.test(url);
}
