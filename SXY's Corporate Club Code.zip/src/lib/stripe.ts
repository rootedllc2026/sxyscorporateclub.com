/**
 * Stripe client-side configuration for SXY's Corporate Club.
 *
 * The publishable key is safe to expose in client bundles — it can only
 * create tokens / start Checkout Sessions, not read or modify Stripe data.
 * The secret key (sk_...) lives in the STRIPE_SECRET_KEY runtime secret
 * and is used only by server code (see src/routes/api.public.stripe-webhook.ts
 * and src/server/financials/cancelMembership.ts).
 *
 * Lovable does not use .env files, so the publishable key is hardcoded here.
 * Replace with the live key (pk_live_...) when going to production.
 */
export const STRIPE_PUBLISHABLE_KEY =
  "pk_test_51T8rGPGx9ULzMHr9nh3vAbJSKIKcT1uGRgt3irovl28fiJwRsWcPcdHEPEmimTLz1RjHq5AHzQAUlMVBP0CdpddW00eXeCXRmh";
