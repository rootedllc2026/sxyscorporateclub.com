/**
 * Tiny CSV serializer + browser download helper. Used for /financials/transactions
 * "Export CSV" and the admin "Export Statement" actions.
 */

function escapeCell(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function rowsToCsv<T extends Record<string, unknown>>(
  rows: T[],
  headers: { key: keyof T; label: string }[],
): string {
  const head = headers.map((h) => escapeCell(h.label)).join(",");
  const body = rows
    .map((r) => headers.map((h) => escapeCell(r[h.key])).join(","))
    .join("\n");
  return `${head}\n${body}`;
}

export function downloadCsv(filename: string, csv: string) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
