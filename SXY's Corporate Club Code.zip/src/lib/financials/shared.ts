/**
 * Shared types, formatters, and small helpers used by every /financials route.
 */
import type { MembershipTier } from "@/integrations/supabase/AuthContext";

export type TxnType =
  | "referral"
  | "consulting"
  | "membership"
  | "fee"
  | "bid_award"
  | "payout"
  | "refund"
  | "other";

export type TxnStatus = "completed" | "pending" | "failed" | "refunded";

export interface TransactionRow {
  id: string;
  user_id: string;
  txn_type: TxnType;
  amount: number;
  gross_amount: number | null;
  fee_amount: number | null;
  net_amount: number | null;
  description: string | null;
  source: string | null;
  status: TxnStatus | string;
  reference_id: string | null;
  stripe_payment_intent_id: string | null;
  refunded_at: string | null;
  refunded_by: string | null;
  refund_reason: string | null;
  refund_txn_id: string | null;
  created_at: string;
}

export type PayoutStatus =
  | "requested"
  | "pending"
  | "approved"
  | "sent"
  | "held"
  | "processing"
  | "paid"
  | "rejected";

export interface PayoutRow {
  id: string;
  user_id: string;
  amount: number;
  method: string | null;
  destination: string | null;
  notes: string | null;
  status: PayoutStatus;
  requested_at: string;
  processed_at: string | null;
  processed_by: string | null;
  bulk_action_id: string | null;
  created_at: string;
}

export interface PayoutAuditEntry {
  id: string;
  payout_id: string;
  actor_id: string | null;
  from_status: string | null;
  to_status: string;
  note: string | null;
  created_at: string;
  actor_name?: string | null;
  actor_email?: string | null;
}

export type PayoutMethodKind = "stripe" | "bank" | "paypal" | "wire";

export interface PayoutMethodRow {
  id: string;
  user_id: string;
  label: string;
  method: PayoutMethodKind;
  destination: string;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface InvoiceRow {
  id: string;
  invoice_number: string;
  user_id: string;
  client_name: string;
  description: string | null;
  amount: number;
  due_date: string | null;
  notes: string | null;
  status: "draft" | "sent" | "paid" | "overdue" | "cancelled";
  issued_at: string;
  paid_at: string | null;
  created_at: string;
}

export interface PlatformSettingsRow {
  id: number;
  fee_pct_basic: number;
  fee_pct_standard: number;
  fee_pct_featured: number;
  payout_window_days: number;
  payout_min_threshold: number;
  payout_default_method: string;
  notify_on_approval: boolean;
  notify_on_new_request: boolean;
  weekly_digest: boolean;
  admin_notification_emails: string[];
  updated_at: string;
}

export interface MemberFinancialRow {
  member_id: string;
  full_name: string | null;
  email: string | null;
  tier: MembershipTier | null;
  avatar_color: string | null;
  available_balance: number;
  booking_count: number;
  gross_earned: number;
  fees_paid: number;
  net_earned: number;
  pending_payouts: number;
}

export interface PlatformRevenueSummary {
  membership_revenue_total: number;
  referral_fee_revenue_total: number;
  total_revenue: number;
  revenue_mtd: number;
  membership_mtd: number;
  referral_fee_mtd: number;
  pending_payouts_total: number;
  pending_payouts_count: number;
}

// ─── Formatters ────────────────────────────────────────────────────────────

export const usd = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 2,
});

export const usdCompact = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

export function formatMoney(n: number | string | null | undefined) {
  return usd.format(Number(n ?? 0));
}

export function formatDate(iso: string | null | undefined) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatMonth(iso: string | Date) {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleDateString(undefined, { month: "short", year: "2-digit" });
}

// ─── Type / status visuals ────────────────────────────────────────────────

export function txnTypeLabel(t: TxnType | string): string {
  switch (t) {
    case "referral":
      return "Referral";
    case "consulting":
      return "Consulting";
    case "membership":
      return "Membership";
    case "fee":
      return "Platform Fee";
    case "bid_award":
      return "Bid Award";
    case "payout":
      return "Payout";
    case "refund":
      return "Refund";
    default:
      return "Other";
  }
}

export type TagVariant = "teal" | "gold" | "green" | "red" | "gray" | "amber";

export function txnTypeTone(t: TxnType | string): TagVariant {
  switch (t) {
    case "referral":
    case "consulting":
    case "bid_award":
      return "green";
    case "membership":
    case "fee":
    case "refund":
      return "red";
    case "payout":
      return "gold";
    default:
      return "gray";
  }
}

export function statusTone(s: string): TagVariant {
  switch (s) {
    case "completed":
    case "paid":
    case "sent":
      return "green";
    case "pending":
    case "requested":
    case "approved":
    case "processing":
    case "draft":
      return "amber";
    case "failed":
    case "rejected":
    case "refunded":
    case "cancelled":
    case "overdue":
    case "held":
      return "red";
    default:
      return "gray";
  }
}

// ─── Membership tier metadata used by /financials/membership ─────────────

export interface TierMeta {
  key: MembershipTier;
  name: string;
  monthlyPriceUsd: number;
  annualPriceUsd: number | null;
  features: string[];
}

export const TIERS: TierMeta[] = [
  {
    key: "free",
    name: "Free Visitor",
    monthlyPriceUsd: 0,
    annualPriceUsd: 0,
    features: [
      "Public Economy Bites",
      "Free events RSVP",
      "Community read-only",
    ],
  },
  {
    key: "paid",
    name: "Monthly Member",
    monthlyPriceUsd: 29,
    annualPriceUsd: null,
    features: [
      "All paid Economy Bites",
      "Bidding portal access",
      "Community posting",
      "Monthly webinars",
    ],
  },
  {
    key: "annual",
    name: "Annual Member",
    monthlyPriceUsd: 24,
    annualPriceUsd: 288,
    features: [
      "Everything in Monthly",
      "Annual recordings library",
      "20% off referral fees",
      "Priority bidding",
    ],
  },
  {
    key: "vip",
    name: "VIP",
    monthlyPriceUsd: 99,
    annualPriceUsd: 999,
    features: [
      "Everything in Annual",
      "VIP-only events & bites",
      "Direct intros",
      "1:1 quarterly reviews",
    ],
  },
];

// ─── Date range helpers ───────────────────────────────────────────────────

export type DateRangeKey = "all" | "month" | "3months" | "year";

export function dateRangeStart(range: DateRangeKey): string | null {
  const now = new Date();
  switch (range) {
    case "month":
      return new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    case "3months": {
      const d = new Date(now);
      d.setMonth(d.getMonth() - 3);
      return d.toISOString();
    }
    case "year":
      return new Date(now.getFullYear(), 0, 1).toISOString();
    default:
      return null;
  }
}

// ─── Group transactions into the last N months for charts ────────────────

export interface MonthlyBucket {
  month: string;
  monthIso: string;
  referral: number;
  consulting: number;
  fees: number;
}

export function groupByMonth(
  rows: TransactionRow[],
  monthsBack = 8,
): MonthlyBucket[] {
  const now = new Date();
  const buckets: MonthlyBucket[] = [];
  for (let i = monthsBack - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({
      month: formatMonth(d),
      monthIso: d.toISOString(),
      referral: 0,
      consulting: 0,
      fees: 0,
    });
  }
  for (const r of rows) {
    const created = new Date(r.created_at);
    const idx = buckets.findIndex((b) => {
      const bd = new Date(b.monthIso);
      return (
        bd.getFullYear() === created.getFullYear() &&
        bd.getMonth() === created.getMonth()
      );
    });
    if (idx === -1) continue;
    const gross = Number(r.gross_amount ?? r.amount ?? 0);
    const fee = Number(r.fee_amount ?? 0);
    if (r.txn_type === "referral") buckets[idx].referral += gross;
    else if (r.txn_type === "consulting") buckets[idx].consulting += gross;
    if (r.txn_type === "fee") buckets[idx].fees += gross;
    else if (fee) buckets[idx].fees += fee;
  }
  return buckets;
}
