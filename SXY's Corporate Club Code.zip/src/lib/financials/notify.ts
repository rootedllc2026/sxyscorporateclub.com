/**
 * Thin client helper around the sendNotificationEmail server function.
 *
 * Notification sends are best-effort: a failure should never block the
 * primary action (e.g. submitting a payout request). On error we toast and
 * log but never throw — the caller's success path continues.
 */
import { sendNotificationEmail } from "@/server/financials/sendNotificationEmail";
import { toast } from "sonner";

interface NotifyOptions {
  to: string | string[];
  subject: string;
  body: string;
  fromName?: string;
  /** When true (default), surface a soft toast on failure. */
  toastOnError?: boolean;
}

export async function notifyByEmail(opts: NotifyOptions): Promise<boolean> {
  const recipients = Array.isArray(opts.to) ? opts.to : [opts.to];
  const cleaned = recipients.map((r) => (r ?? "").trim()).filter(Boolean);
  if (cleaned.length === 0) return false;
  try {
    await sendNotificationEmail({
      data: {
        to: cleaned,
        subject: opts.subject,
        body: opts.body,
        fromName: opts.fromName,
      },
    });
    return true;
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    // eslint-disable-next-line no-console
    console.warn("[notifyByEmail] send failed:", message);
    if (opts.toastOnError !== false) {
      toast.warning("Email notification couldn't be sent.", {
        description: message,
      });
    }
    return false;
  }
}
