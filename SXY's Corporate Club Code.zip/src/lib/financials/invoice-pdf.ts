/**
 * Generate a simple SXY-branded invoice PDF using jsPDF. Pure client-side —
 * no server function needed.
 */
import { jsPDF } from "jspdf";
import { formatDate, formatMoney, type InvoiceRow } from "./shared";

export function downloadInvoicePdf(
  invoice: InvoiceRow,
  issuerName: string | null | undefined,
) {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 56;

  // Header band
  doc.setFillColor(13, 122, 140); // teal-deep
  doc.rect(0, 0, pageWidth, 8, "F");

  doc.setFont("times", "italic");
  doc.setTextColor(201, 168, 76); // gold
  doc.setFontSize(20);
  doc.text("SXY's", margin, 60);
  doc.setFont("times", "normal");
  doc.setTextColor(60, 60, 60);
  doc.setFontSize(11);
  doc.text("Corporate Club", margin + 50, 60);

  doc.setFont("helvetica", "bold");
  doc.setTextColor(20, 20, 20);
  doc.setFontSize(28);
  doc.text("INVOICE", pageWidth - margin, 60, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(90, 90, 90);
  doc.text(invoice.invoice_number, pageWidth - margin, 80, { align: "right" });

  // Meta table
  let y = 130;
  doc.setFontSize(10);
  doc.setTextColor(120, 120, 120);
  doc.text("ISSUED", margin, y);
  doc.text("DUE", margin + 140, y);
  doc.text("STATUS", margin + 280, y);
  doc.text("AMOUNT DUE", pageWidth - margin, y, { align: "right" });
  y += 16;
  doc.setFontSize(12);
  doc.setTextColor(20, 20, 20);
  doc.text(formatDate(invoice.issued_at), margin, y);
  doc.text(formatDate(invoice.due_date), margin + 140, y);
  doc.text(invoice.status.toUpperCase(), margin + 280, y);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(201, 168, 76);
  doc.text(formatMoney(invoice.amount), pageWidth - margin, y + 4, {
    align: "right",
  });

  // Bill to / from
  y += 50;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(120, 120, 120);
  doc.text("BILL TO", margin, y);
  doc.text("FROM", pageWidth / 2, y);
  y += 16;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(12);
  doc.setTextColor(20, 20, 20);
  doc.text(invoice.client_name || "—", margin, y);
  doc.text(issuerName || "Member", pageWidth / 2, y);

  // Line items
  y += 50;
  doc.setFillColor(245, 245, 245);
  doc.rect(margin, y - 12, pageWidth - margin * 2, 24, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(80, 80, 80);
  doc.text("DESCRIPTION", margin + 8, y + 4);
  doc.text("AMOUNT", pageWidth - margin - 8, y + 4, { align: "right" });
  y += 32;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(20, 20, 20);
  const description = invoice.description || "Professional services";
  const lines = doc.splitTextToSize(description, pageWidth - margin * 2 - 120);
  doc.text(lines, margin + 8, y);
  doc.text(formatMoney(invoice.amount), pageWidth - margin - 8, y, {
    align: "right",
  });

  y += Math.max(20, lines.length * 14) + 12;
  doc.setDrawColor(220, 220, 220);
  doc.line(margin, y, pageWidth - margin, y);
  y += 24;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Total", pageWidth - margin - 100, y, { align: "right" });
  doc.setTextColor(201, 168, 76);
  doc.text(formatMoney(invoice.amount), pageWidth - margin - 8, y, {
    align: "right",
  });

  // Notes
  if (invoice.notes) {
    y += 50;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(120, 120, 120);
    doc.text("NOTES", margin, y);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    doc.setTextColor(50, 50, 50);
    const noteLines = doc.splitTextToSize(invoice.notes, pageWidth - margin * 2);
    doc.text(noteLines, margin, y + 16);
  }

  // Footer
  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  doc.text(
    "SXY's Economic Roots LLC · Rooted LLC",
    pageWidth / 2,
    doc.internal.pageSize.getHeight() - 30,
    { align: "center" },
  );

  doc.save(`${invoice.invoice_number}.pdf`);
}
