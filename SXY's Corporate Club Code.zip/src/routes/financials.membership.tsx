/**
 * /financials/membership — current plan, tier comparison, billing history.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { cancelMyMembership } from "@/server/financials/cancelMembership";
import {
  formatDate,
  formatMoney,
  TIERS,
  type TransactionRow,
} from "@/lib/financials/shared";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/financials/membership")({
  head: () => ({ meta: [{ title: "Membership — SXY's Corporate Club" }] }),
  component: MembershipRoute,
});

function MembershipRoute() {
  const { userProfile, refreshProfile } = useAuth();
  const tier = userProfile?.tier ?? "free";
  const tierMeta = TIERS.find((t) => t.key === tier) ?? TIERS[0];
  const subStatus =
    (userProfile as unknown as { subscription_status?: string | null })
      ?.subscription_status ?? null;
  const last4 =
    (userProfile as unknown as { payment_method_last4?: string | null })
      ?.payment_method_last4 ?? null;

  const [confirming, setConfirming] = React.useState(false);
  const [cancelling, setCancelling] = React.useState(false);

  const { data: history = [] } = useQuery({
    queryKey: ["financials", "membershipHistory", userProfile?.id],
    enabled: !!userProfile,
    queryFn: async () => {
      const { data } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", userProfile!.id)
        .eq("txn_type", "membership")
        .order("created_at", { ascending: false });
      return (data ?? []) as TransactionRow[];
    },
  });

  const totalPaid = history.reduce(
    (s, t) => s + Number(t.gross_amount ?? t.amount ?? 0),
    0,
  );

  async function handleCancel() {
    setCancelling(true);
    try {
      await cancelMyMembership();
      toast.success("Membership cancelled. Access continues until period end.");
      await refreshProfile();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Cancel failed");
    } finally {
      setCancelling(false);
      setConfirming(false);
    }
  }

  return (
    <AppLayout title="Membership & Billing">
      <div className="space-y-6">
        <FinancialsNav />

        {/* Current plan */}
        <SxyCard accent>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim">
                Current plan
              </p>
              <h2 className="font-display text-2xl text-teal-light">
                {tierMeta.name}
              </h2>
              <div className="mt-2 flex items-center gap-2">
                <Tag
                  variant={
                    subStatus === "active" || subStatus === null
                      ? "green"
                      : "red"
                  }
                >
                  {subStatus ?? (tier === "free" ? "Free" : "Active")}
                </Tag>
                <span className="text-sm text-text-muted">
                  {tierMeta.monthlyPriceUsd > 0
                    ? `${formatMoney(tierMeta.monthlyPriceUsd)} / month`
                    : "Free"}
                </span>
              </div>
              <p className="mt-3 text-xs text-text-dim">
                Total paid to date:{" "}
                <span className="text-text-primary">{formatMoney(totalPaid)}</span>
                {last4 ? ` · Card •••• ${last4}` : ""}
              </p>
            </div>
            <div className="flex gap-2">
              <SxyButton
                variant="outline"
                size="sm"
                onClick={() =>
                  toast.info("Card update via Stripe Elements coming soon.")
                }
              >
                Update payment method
              </SxyButton>
              {tier !== "free" ? (
                <SxyButton
                  variant="danger"
                  size="sm"
                  onClick={() => setConfirming(true)}
                >
                  Cancel membership
                </SxyButton>
              ) : null}
            </div>
          </div>
        </SxyCard>

        {/* Tier comparison */}
        <section>
          <h2 className="font-display text-lg text-teal-light">Compare tiers</h2>
          <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {TIERS.map((t) => (
              <SxyCard
                key={t.key}
                className={cn(
                  "flex flex-col gap-3",
                  t.key === tier && "border-border-teal",
                )}
              >
                <div>
                  <p className="font-display text-base text-teal-light">
                    {t.name}
                  </p>
                  <p className="font-editorial text-2xl text-gold">
                    {t.monthlyPriceUsd === 0
                      ? "Free"
                      : `${formatMoney(t.monthlyPriceUsd)}/mo`}
                  </p>
                  {t.annualPriceUsd && t.annualPriceUsd > 0 ? (
                    <p className="text-[11px] text-text-dim">
                      {formatMoney(t.annualPriceUsd)} billed annually
                    </p>
                  ) : null}
                </div>
                <ul className="space-y-1 text-xs text-text-muted">
                  {t.features.map((f) => (
                    <li key={f} className="flex gap-2">
                      <span className="text-teal-light">✓</span> {f}
                    </li>
                  ))}
                </ul>
                {t.key === tier ? (
                  <Tag variant="teal" className="self-start">
                    Current
                  </Tag>
                ) : null}
              </SxyCard>
            ))}
          </div>
        </section>

        {/* Billing history */}
        <SxyCard accent>
          <h2 className="font-display text-lg text-teal-light">
            Billing history
          </h2>
          <table className="mt-4 w-full text-sm">
            <thead className="text-[10px] uppercase tracking-wider text-text-dim">
              <tr className="border-b border-border-base/40">
                <th className="py-2 text-left">Date</th>
                <th className="py-2 text-left">Description</th>
                <th className="py-2 text-right">Amount</th>
                <th className="py-2 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {history.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-6 text-center text-text-dim">
                    No membership charges on record.
                  </td>
                </tr>
              ) : (
                history.map((t) => (
                  <tr key={t.id} className="border-b border-border-base/30">
                    <td className="py-2 text-text-muted">
                      {formatDate(t.created_at)}
                    </td>
                    <td className="py-2 text-text-primary">
                      {t.description ?? "Membership charge"}
                    </td>
                    <td className="py-2 text-right text-danger">
                      − {formatMoney(t.gross_amount ?? t.amount)}
                    </td>
                    <td className="py-2">
                      <Tag variant="green">{t.status}</Tag>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </SxyCard>
      </div>

      {/* Cancel confirmation */}
      {confirming ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
          <SxyCard className="max-w-md space-y-4">
            <h3 className="font-display text-xl text-teal-light">
              Cancel your membership?
            </h3>
            <p className="text-sm text-text-muted">
              You'll keep access until the end of your current billing period.
              You can resubscribe at any time.
            </p>
            <div className="flex justify-end gap-2">
              <SxyButton
                variant="outline"
                size="sm"
                onClick={() => setConfirming(false)}
                disabled={cancelling}
              >
                Keep membership
              </SxyButton>
              <SxyButton
                variant="danger"
                size="sm"
                onClick={handleCancel}
                disabled={cancelling}
              >
                {cancelling ? "Cancelling…" : "Cancel membership"}
              </SxyButton>
            </div>
          </SxyCard>
        </div>
      ) : null}
    </AppLayout>
  );
}
