import * as React from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { sendEmail } from "@/lib/email/send";

export const Route = createFileRoute("/auth/callback")({
  head: () => ({ meta: [{ title: "Signing In — SXY's Corporate Club" }] }),
  component: AuthCallback,
});

/**
 * Handles redirects from Supabase auth emails (signup confirmation, magic
 * links, password recovery).
 *
 * Two flows can land here:
 *   1. PKCE flow — URL has `?code=...` query param. We must explicitly call
 *      exchangeCodeForSession() to trade the code for a session.
 *   2. Implicit flow — tokens arrive in the URL hash (#access_token=...).
 *      detectSessionInUrl: true (in client.ts) handles this automatically.
 *
 * After we have a session we route based on intent:
 *   - type=recovery   → /update-password
 *   - tier === free   → /dashboard
 *   - tier === paid|annual|vip → /checkout?tier=...
 *   - no session      → /login
 */
function AuthCallback() {
  const navigate = useNavigate();
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;

    async function run() {
      if (typeof window === "undefined") return;

      const url = new URL(window.location.href);
      const code = url.searchParams.get("code");
      const hash = window.location.hash ?? "";
      const isRecovery =
        /[#&?]type=recovery(\b|$)/.test(hash) ||
        url.searchParams.get("type") === "recovery";

      // PKCE: exchange ?code=... for a session.
      if (code) {
        const { error: exchErr } =
          await supabase.auth.exchangeCodeForSession(code);
        if (cancelled) return;
        if (exchErr) {
          setError(exchErr.message);
          return;
        }
        // Clean the URL so the code isn't reused on refresh.
        window.history.replaceState(
          {},
          "",
          window.location.pathname,
        );
      }

      const { data, error: getErr } = await supabase.auth.getSession();
      if (cancelled) return;

      if (getErr) {
        setError(getErr.message);
        return;
      }

      if (isRecovery) {
        await navigate({ to: "/update-password", replace: true });
        return;
      }

      if (!data.session) {
        await navigate({ to: "/login", replace: true });
        return;
      }

      // Route paid tiers to checkout, free to dashboard.
      const tier = (data.session.user.user_metadata?.tier ?? "free") as
        | "free"
        | "paid"
        | "annual"
        | "vip";

      // Best-effort welcome email — fire once per user (dedup via localStorage).
      try {
        const userId = data.session.user.id;
        const key = `sxy-welcome-${userId}`;
        if (
          typeof window !== "undefined" &&
          !window.localStorage.getItem(key)
        ) {
          window.localStorage.setItem(key, "1");
          void sendEmail({
            kind: "membership-welcome",
            to: data.session.user.email ?? "",
            fullName:
              (data.session.user.user_metadata?.full_name as string) ?? null,
            tier,
          });
        }
      } catch {}

      if (tier === "paid" || tier === "annual" || tier === "vip") {
        await navigate({
          to: "/checkout",
          search: { tier },
          replace: true,
        });
      } else {
        await navigate({ to: "/dashboard", replace: true });
      }
    }

    void run();
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-charcoal">
      <div className="text-center">
        <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-teal-deep/30 border-t-teal-mid" />
        <p className="mt-4 text-sm text-text-muted">
          {error ?? "Finishing sign-in…"}
        </p>
      </div>
    </div>
  );
}
