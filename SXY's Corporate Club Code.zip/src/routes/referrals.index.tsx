import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { StatTile } from "@/components/sxy/StatTile";
import { FilterChip } from "@/components/sxy/FilterChip";
import { Tag } from "@/components/sxy/Tag";
import { cn } from "@/lib/utils";
import {
  REFERRAL_CATEGORIES,
  type ReferralCategoryId,
  USD,
  categoryBannerGradient,
  formatPrice,
  refCategoryEmoji,
  refCategoryLabel,
} from "@/lib/referrals/shared";

const directorySearchSchema = z.object({
  category: z
    .enum([
      "all", "cleaning", "contractor", "strategy",
      "marketing", "legal", "tech_ai", "other",
    ])
    .optional()
    .default("all"),
  q: z.string().optional().default(""),
});

export const Route = createFileRoute("/referrals/")({
  head: () => ({ meta: [{ title: "Business Directory — SXY's Corporate Club" }] }),
  validateSearch: directorySearchSchema,
  component: DirectoryPage,
});

function DirectoryPage() {
  return (
    <AppLayout
      title="Business Directory"
      actions={
        <div className="flex items-center gap-3">
          <SxyButton variant="outline" size="sm" asChild>
            <Link to="/referrals/my-page">My Bookings</Link>
          </SxyButton>
          <SxyButton variant="gold" size="sm" asChild>
            <Link to="/referrals/request">+ Request My Page</Link>
          </SxyButton>
        </div>
      }
    >
      <DirectoryContent />
    </AppLayout>
  );
}

function DirectoryContent() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const { isAdmin } = useAuth();

  const setCategory = (id: ReferralCategoryId) =>
    navigate({ search: (prev: typeof search) => ({ ...prev, category: id }) });
  const setQuery = (q: string) =>
    navigate({ search: (prev: typeof search) => ({ ...prev, q }) });

  const { data: stats } = useQuery({
    queryKey: ["referrals", "stats", isAdmin],
    queryFn: async () => {
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);
      const sinceISO = startOfMonth.toISOString();

      const [pagesRes, bookingsRes, ratingRes, revenueRes] = await Promise.all([
        supabase
          .from("business_pages")
          .select("id", { count: "exact", head: true })
          .eq("status", "live"),
        supabase
          .from("bookings")
          .select("id", { count: "exact", head: true })
          .gte("created_at", sinceISO),
        supabase
          .from("business_pages")
          .select("avg_rating")
          .eq("status", "live")
          .not("avg_rating", "is", null),
        isAdmin
          ? supabase
              .from("bookings")
              .select("platform_fee")
              .gte("created_at", sinceISO)
          : Promise.resolve({ data: [] as { platform_fee: number }[] }),
      ]);

      const ratings = ((ratingRes as any).data ?? [])
        .map((r: any) => Number(r.avg_rating))
        .filter((n: number) => Number.isFinite(n) && n > 0);
      const avgRating =
        ratings.length > 0
          ? ratings.reduce((s: number, n: number) => s + n, 0) / ratings.length
          : 0;

      const platformRev = ((revenueRes as any).data ?? []).reduce(
        (s: number, r: any) => s + Number(r.platform_fee ?? 0),
        0,
      );

      return {
        pages: pagesRes.count ?? 0,
        bookings: bookingsRes.count ?? 0,
        avgRating,
        platformRev,
      };
    },
  });

  const { data: pages, isLoading } = useQuery({
    queryKey: ["referrals", "list", search.category, search.q],
    queryFn: async () => {
      let query = supabase
        .from("referrals_directory")
        .select("*")
        .eq("status", "live")
        .order("is_featured", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(60);
      if (search.category !== "all") {
        query = query.eq("category", search.category);
      }
      if (search.q && search.q.trim().length > 0) {
        query = query.ilike("business_name", `%${search.q.trim()}%`);
      }
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <div className="space-y-8">
      {/* Stats */}
      <section
        className={cn(
          "grid gap-4 sm:grid-cols-2",
          isAdmin ? "lg:grid-cols-4" : "lg:grid-cols-3",
        )}
      >
        <StatTile label="Listed Businesses" value={String(stats?.pages ?? 0)} />
        <StatTile label="Bookings This Month" value={String(stats?.bookings ?? 0)} />
        {isAdmin ? (
          <StatTile
            label="Platform Revenue"
            value={stats?.platformRev ? USD.format(stats.platformRev) : "$0"}
          />
        ) : null}
        <StatTile
          label="Avg Rating"
          value={
            stats?.avgRating
              ? `${stats.avgRating.toFixed(1)} ★`
              : "—"
          }
        />
      </section>

      {/* Filter bar */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          {REFERRAL_CATEGORIES.map((cat) => (
            <FilterChip
              key={cat.id}
              active={search.category === cat.id}
              onClick={() => setCategory(cat.id)}
            >
              <span aria-hidden>{cat.emoji}</span>
              {cat.label}
            </FilterChip>
          ))}
        </div>
        <div className="relative max-w-md">
          <input
            type="search"
            value={search.q}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search businesses by name…"
            className="w-full rounded-full border border-border-base/60 bg-charcoal-card px-4 py-2.5 pl-10 text-sm text-text-primary placeholder:text-text-dim focus:border-border-teal focus:outline-none"
          />
          <span
            aria-hidden
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-text-dim"
          >
            🔍
          </span>
        </div>
      </section>

      {/* Cards */}
      <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {isLoading ? (
          <SxyCard>
            <p className="text-sm text-text-muted">Loading businesses…</p>
          </SxyCard>
        ) : pages && pages.length > 0 ? (
          pages.map((page: any) => (
            <BusinessCard key={page.id} page={page} />
          ))
        ) : (
          <SxyCard accent className="md:col-span-2 xl:col-span-3">
            <p className="font-display text-lg text-teal-light">
              No businesses match your filters
            </p>
            <p className="mt-2 text-sm text-text-muted">
              Be the first — request your page from the top of this screen.
            </p>
          </SxyCard>
        )}
      </section>
    </div>
  );
}

function BusinessCard({ page }: { page: any }) {
  const location = [page.owner_city, page.owner_state]
    .filter(Boolean)
    .join(", ");
  const hasRating = page.avg_rating != null && Number(page.avg_rating) > 0;
  return (
    <div
      className={cn(
        "sxy-card sxy-card-hover flex flex-col overflow-hidden p-0",
        page.is_featured && "border-2 border-gold",
      )}
    >
      {/* Banner */}
      <div
        className="relative flex h-28 items-center justify-center"
        style={{ backgroundImage: categoryBannerGradient(page.category) }}
      >
        <span aria-hidden className="text-5xl drop-shadow-lg">
          {page.icon_emoji ?? refCategoryEmoji(page.category)}
        </span>
        {page.is_featured ? (
          <Tag
            variant="gold"
            className="absolute right-3 top-3 px-2 py-0.5 text-[10px]"
          >
            ★ Featured
          </Tag>
        ) : null}
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg leading-snug text-text-primary">
          {page.business_name}
        </h3>
        <p className="mt-1 text-xs text-text-dim">
          {page.owner_name ?? "Member"}{location ? ` · ${location}` : ""}
        </p>
        {page.description ? (
          <p className="mt-3 line-clamp-2 text-sm text-text-muted">
            {page.description}
          </p>
        ) : null}

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Tag variant="teal">{refCategoryLabel(page.category)}</Tag>
          {hasRating ? (
            <span className="inline-flex items-center gap-1 text-xs text-gold">
              ★ {Number(page.avg_rating).toFixed(1)}
            </span>
          ) : null}
        </div>

        <div className="mt-5 flex items-baseline justify-between">
          <p className="text-[10px] uppercase tracking-[0.18em] text-text-dim">
            Starting at
          </p>
          <p className="font-editorial text-2xl text-gold">
            {formatPrice(page.starting_price)}
          </p>
        </div>

        <div className="mt-4 flex gap-2">
          <SxyButton variant="outline" size="sm" className="flex-1" asChild>
            <Link to="/referrals/$id" params={{ id: page.id }}>
              View Page
            </Link>
          </SxyButton>
          <SxyButton variant="gold" size="sm" className="flex-1" asChild>
            <Link
              to="/referrals/$id"
              params={{ id: page.id }}
              search={{ book: 1 }}
            >
              Book Now
            </Link>
          </SxyButton>
        </div>

        {/* Stats strip */}
        <div className="mt-4 grid grid-cols-3 gap-1 border-t border-border-base/50 pt-3 text-center">
          <Stat label="bookings" value={page.total_bookings ?? 0} />
          <Stat label="reviews"  value={page.total_reviews ?? 0} />
          <Stat label="fee"      value={`${Number(page.platform_fee_pct ?? 0)}%`} />
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <p className="font-display text-sm text-text-primary">{value}</p>
      <p className="text-[9px] uppercase tracking-wider text-text-dim">{label}</p>
    </div>
  );
}
