/**
 * /financials/admin/members — full table of every member's financial position.
 * Search by name/email, sort by net earned. Reads from
 * public.member_financial_summary view (admin-readable).
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Input } from "@/components/ui/input";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { Tag } from "@/components/sxy/Tag";
import { supabase } from "@/integrations/supabase/client";
import {
  formatMoney,
  type MemberFinancialRow,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/admin/members")({
  head: () => ({ meta: [{ title: "Member Financials — SXY's Corporate Club" }] }),
  component: MembersAdminRoute,
});

type SortKey = "net" | "gross" | "balance" | "pending" | "name";

function MembersAdminRoute() {
  return (
    <AdminRoute>
      <AppLayout title="Member Financials">
        <MembersInner />
      </AppLayout>
    </AdminRoute>
  );
}

function MembersInner() {
  const [q, setQ] = React.useState("");
  const [sort, setSort] = React.useState<SortKey>("net");

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["financials", "admin", "members"],
    queryFn: async () => {
      const { data } = await supabase
        .from("member_financial_summary")
        .select("*");
      return (data ?? []) as MemberFinancialRow[];
    },
  });

  const filtered = React.useMemo(() => {
    const term = q.trim().toLowerCase();
    const list = term
      ? rows.filter((r) =>
          [r.full_name, r.email]
            .filter(Boolean)
            .some((v) => v!.toLowerCase().includes(term)),
        )
      : rows;
    const sorted = [...list].sort((a, b) => {
      switch (sort) {
        case "gross":
          return Number(b.gross_earned) - Number(a.gross_earned);
        case "balance":
          return Number(b.available_balance) - Number(a.available_balance);
        case "pending":
          return Number(b.pending_payouts) - Number(a.pending_payouts);
        case "name":
          return (a.full_name ?? "").localeCompare(b.full_name ?? "");
        default:
          return Number(b.net_earned) - Number(a.net_earned);
      }
    });
    return sorted;
  }, [rows, q, sort]);

  const sortOptions: { key: SortKey; label: string }[] = [
    { key: "net", label: "Net earned" },
    { key: "gross", label: "Gross" },
    { key: "balance", label: "Balance" },
    { key: "pending", label: "Pending payouts" },
    { key: "name", label: "Name" },
  ];

  return (
    <div className="space-y-8">
      <FinancialsNav />

      <SxyCard accent>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-lg text-teal-light">
            All members ({filtered.length})
          </h2>
          <div className="flex flex-wrap items-center gap-2">
            <Input
              placeholder="Search name or email…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="h-9 w-56"
            />
            <div className="flex items-center gap-1">
              {sortOptions.map((o) => (
                <button
                  key={o.key}
                  onClick={() => setSort(o.key)}
                  className={`rounded-full border px-3 py-1 text-[10px] font-semibold uppercase tracking-wider transition-colors ${
                    sort === o.key
                      ? "border-border-teal bg-[color:var(--teal-glow)] text-teal-light"
                      : "border-transparent text-text-muted hover:text-teal-light"
                  }`}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-[10px] uppercase tracking-wider text-text-dim">
              <tr className="border-b border-border-base/40">
                <th className="py-2 text-left font-semibold">Member</th>
                <th className="py-2 text-left font-semibold">Tier</th>
                <th className="py-2 text-right font-semibold">Bookings</th>
                <th className="py-2 text-right font-semibold">Gross</th>
                <th className="py-2 text-right font-semibold">Fees</th>
                <th className="py-2 text-right font-semibold">Net</th>
                <th className="py-2 text-right font-semibold">Balance</th>
                <th className="py-2 text-right font-semibold">Pending</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-text-dim">
                    Loading…
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-text-dim">
                    No members match your search.
                  </td>
                </tr>
              ) : (
                filtered.map((m) => (
                  <tr
                    key={m.member_id}
                    className="border-b border-border-base/30 last:border-0"
                  >
                    <td className="py-3 text-text-primary">
                      <div className="font-medium">{m.full_name ?? "—"}</div>
                      <div className="text-[11px] text-text-dim">
                        {m.email ?? ""}
                      </div>
                    </td>
                    <td className="py-3">
                      <Tag
                        variant={
                          m.tier === "vip"
                            ? "gold"
                            : m.tier === "annual"
                              ? "teal"
                              : m.tier === "paid"
                                ? "green"
                                : "gray"
                        }
                      >
                        {(m.tier ?? "free").toUpperCase()}
                      </Tag>
                    </td>
                    <td className="py-3 text-right text-text-muted">
                      {m.booking_count}
                    </td>
                    <td className="py-3 text-right text-text-primary">
                      {formatMoney(m.gross_earned)}
                    </td>
                    <td className="py-3 text-right text-danger">
                      {formatMoney(m.fees_paid)}
                    </td>
                    <td className="py-3 text-right font-semibold text-success">
                      {formatMoney(m.net_earned)}
                    </td>
                    <td className="py-3 text-right text-gold">
                      {formatMoney(m.available_balance)}
                    </td>
                    <td className="py-3 text-right text-text-muted">
                      {formatMoney(m.pending_payouts)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </SxyCard>
    </div>
  );
}
