import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { adminSetUserPassword } from "@/lib/admin/admin-users.functions";
import { toast } from "sonner";

function AdminSetPasswordPage() {
  const setPassword = useServerFn(adminSetUserPassword);
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw.length < 12) {
      toast.error("Password must be at least 12 characters.");
      return;
    }
    if (!confirm(`Set a new password for ${email}? This action is logged.`)) return;
    setBusy(true);
    try {
      await setPassword({ data: { email, newPassword: pw, reason: reason || undefined } });
      toast.success(`Password updated for ${email}`);
      setPw("");
      setReason("");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to set password");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AdminRoute>
      <AppLayout title="Set User Password">
        <div className="max-w-xl space-y-6">
          <SxyCard accent>
            <h2 className="font-display text-xl text-teal-light">Admin: set a user password</h2>
            <p className="mt-2 text-sm text-text-muted">
              Use only when a user cannot reset their own password. Every action is recorded in
              the admin audit log with your identity, the target user, and an optional reason.
              Share the new password through a secure channel and instruct the user to change it
              on next sign-in.
            </p>
          </SxyCard>

          <SxyCard>
            <form onSubmit={onSubmit} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wide text-text-muted">
                  User email
                </label>
                <input
                  type="email"
                  required
                  autoComplete="off"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-border-base/60 bg-charcoal-soft px-3 py-2 text-sm"
                  placeholder="user@example.com"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wide text-text-muted">
                  New password (min 12 chars)
                </label>
                <input
                  type="text"
                  required
                  minLength={12}
                  maxLength={128}
                  autoComplete="new-password"
                  value={pw}
                  onChange={(e) => setPw(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-border-base/60 bg-charcoal-soft px-3 py-2 font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wide text-text-muted">
                  Reason (optional, for the audit log)
                </label>
                <input
                  type="text"
                  maxLength={500}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-border-base/60 bg-charcoal-soft px-3 py-2 text-sm"
                  placeholder="e.g. user can't access reset email"
                />
              </div>
              <button
                type="submit"
                disabled={busy}
                className="rounded-lg bg-teal-light px-4 py-2 text-sm font-medium text-charcoal-deep disabled:opacity-60"
              >
                {busy ? "Setting…" : "Set password"}
              </button>
            </form>
          </SxyCard>
        </div>
      </AppLayout>
    </AdminRoute>
  );
}

export const Route = createFileRoute("/admin/set-password")({
  head: () => ({ meta: [{ title: "Set User Password — Admin" }] }),
  component: AdminSetPasswordPage,
});
