import * as React from "react";
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { AvatarBadge } from "@/components/layout/Avatar";
import { cn } from "@/lib/utils";
import {
  BID_CURRENCY,
  bidStatusVariant,
  categoryEmoji,
  categoryLabel,
  formatBudget,
  statusLabel,
  statusTagVariant,
} from "@/lib/bidding/shared";

export const Route = createFileRoute("/bidding/admin")({
  head: () => ({ meta: [{ title: "Review & Award — SXY's Corporate Club" }] }),
  component: AdminReviewPage,
});

function AdminReviewPage() {
  const { isAdmin, isLoading } = useAuth();
  return (
    <AppLayout title="Review & Award">
      {isLoading ? (
        <SxyCard>
          <p className="text-sm text-text-muted">Checking access…</p>
        </SxyCard>
      ) : !isAdmin ? (
        <SxyCard accent>
          <h2 className="font-display text-xl text-teal-light">
            Admins only
          </h2>
          <p className="mt-2 text-sm text-text-muted">
            This page is for project owners reviewing submitted bids.
          </p>
          <SxyButton variant="primary" size="sm" className="mt-4" asChild>
            <Link to="/bidding">Back to projects</Link>
          </SxyButton>
        </SxyCard>
      ) : (
        <AdminReviewContent />
      )}
    </AppLayout>
  );
}

type WinnerCelebration = {
  projectTitle: string;
  bidderName: string;
  amount: number;
};

function AdminReviewContent() {
  const router = useRouter();
  const [selectedBidByProject, setSelectedBidByProject] = React.useState<
    Record<string, string>
  >({});
  const [announcements, setAnnouncements] = React.useState<
    Record<string, string>
  >({});
  const [publishing, setPublishing] = React.useState<string | null>(null);
  const [celebration, setCelebration] = React.useState<WinnerCelebration | null>(null);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["bidding", "admin-review"],
    queryFn: async () => {
      const { data: projects, error } = await supabase
        .from("projects")
        .select("*")
        .in("status", ["closed", "reviewing"])
        .order("closes_at", { ascending: true, nullsFirst: false });
      if (error) throw error;
      if (!projects || projects.length === 0) return { projects: [], bidsByProject: {} };

      const ids = projects.map((p: any) => p.id);
      const { data: bids } = await supabase
        .from("bids")
        .select(
          "id, project_id, bidder_id, amount, proposed_price, cover_letter, status, created_at, profiles!bids_bidder_id_fkey(full_name, email, avatar_color)",
        )
        .in("project_id", ids)
        .order("created_at", { ascending: false });

      const bidsByProject: Record<string, any[]> = {};
      for (const b of bids ?? []) {
        const arr = bidsByProject[(b as any).project_id] ?? [];
        arr.push(b);
        bidsByProject[(b as any).project_id] = arr;
      }
      return { projects, bidsByProject };
    },
  });

  async function handlePublish(project: any) {
    const winnerBidId = selectedBidByProject[project.id];
    if (!winnerBidId) {
      toast.error("Pick a winning bid first.");
      return;
    }
    const winnerBid = (data?.bidsByProject[project.id] ?? []).find(
      (b: any) => b.id === winnerBidId,
    );
    if (!winnerBid) return;

    const message = announcements[project.id]?.trim();
    setPublishing(project.id);
    try {
      const winnerAmount = Number(winnerBid.proposed_price ?? winnerBid.amount ?? 0);

      // 1. Update project: status awarded + winner refs.
      const { error: pErr } = await supabase
        .from("projects")
        .update({
          status: "awarded",
          winner_id: winnerBid.bidder_id,
          winner_bid_id: winnerBidId,
          contract_value: winnerAmount,
        })
        .eq("id", project.id);
      if (pErr) throw pErr;

      // 2. Mark winner awarded.
      const { error: wErr } = await supabase
        .from("bids")
        .update({ status: "awarded" })
        .eq("id", winnerBidId);
      if (wErr) throw wErr;

      // 3. Reject all other bids for this project.
      const { error: rErr } = await supabase
        .from("bids")
        .update({ status: "rejected" })
        .eq("project_id", project.id)
        .neq("id", winnerBidId);
      if (rErr) throw rErr;

      // 4. Post announcement into #general.
      const { data: { user } } = await supabase.auth.getUser();
      const winnerName = winnerBid.profiles?.full_name ?? "a member";
      const body =
        message && message.length > 0
          ? message
          : `🏆 ${winnerName} just won "${project.title}" with a ${BID_CURRENCY.format(winnerAmount)} bid. Congrats!`;
      if (user) {
        await supabase.from("messages").insert({
          channel: "general",
          sender_id: user.id,
          body,
        });
      }

      setCelebration({
        projectTitle: project.title,
        bidderName: winnerName,
        amount: winnerAmount,
      });
      void refetch();
      void router.invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't publish award");
    } finally {
      setPublishing(null);
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-text-muted">
          Projects in review. Pick a winner, optionally write an announcement,
          then publish.
        </p>
        <SxyButton variant="outline" size="sm" asChild>
          <Link to="/bidding/awarded">View awarded history →</Link>
        </SxyButton>
      </div>

      {isLoading ? (
        <SxyCard>
          <p className="text-sm text-text-muted">Loading projects in review…</p>
        </SxyCard>
      ) : !data || data.projects.length === 0 ? (
        <SxyCard accent>
          <h2 className="font-display text-lg text-teal-light">
            Nothing to review
          </h2>
          <p className="mt-2 text-sm text-text-muted">
            When projects close they'll appear here for award selection.
          </p>
        </SxyCard>
      ) : (
        data.projects.map((project: any) => {
          const bids = data.bidsByProject[project.id] ?? [];
          const selected = selectedBidByProject[project.id];
          return (
            <SxyCard key={project.id} accent>
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span aria-hidden className="text-xl">
                      {categoryEmoji(project.category)}
                    </span>
                    <Tag variant={statusTagVariant(project.status)}>
                      {statusLabel(project.status)}
                    </Tag>
                    <Tag variant="gray">{categoryLabel(project.category)}</Tag>
                  </div>
                  <h2 className="mt-2 font-display text-xl text-text-primary">
                    {project.title}
                  </h2>
                  <p className="mt-1 text-xs text-text-dim">
                    Closed{" "}
                    {project.closes_at
                      ? new Date(project.closes_at).toLocaleDateString()
                      : "—"}
                    {" · "}Budget{" "}
                    {formatBudget(
                      project.budget,
                      project.budget_min,
                      project.budget_max,
                    )}
                  </p>
                </div>
              </div>

              <ul className="mt-5 space-y-2">
                {bids.length === 0 ? (
                  <li className="rounded-lg border border-dashed border-border-base/60 p-4 text-center text-sm text-text-dim">
                    No bids submitted.
                  </li>
                ) : (
                  bids.map((b: any) => {
                    const isSelected = selected === b.id;
                    return (
                      <li
                        key={b.id}
                        className={cn(
                          "flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3",
                          isSelected
                            ? "border-gold bg-[color:var(--gold-glow)]"
                            : "border-border-base/60 bg-charcoal-card",
                        )}
                      >
                        <div className="flex min-w-0 items-center gap-3">
                          <AvatarBadge
                            name={b.profiles?.full_name ?? "Member"}
                            colorKey={b.profiles?.avatar_color ?? "teal"}
                            size={32}
                          />
                          <div className="min-w-0">
                            <p className="truncate text-sm text-text-primary">
                              {b.profiles?.full_name ?? "Member"}
                            </p>
                            <p className="line-clamp-1 text-xs text-text-dim">
                              {b.cover_letter ?? "No cover letter"}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <p className="font-mono text-sm text-text-primary">
                            {BID_CURRENCY.format(
                              Number(b.proposed_price ?? b.amount ?? 0),
                            )}
                          </p>
                          <Tag variant={bidStatusVariant(b.status)}>
                            {b.status}
                          </Tag>
                          <SxyButton
                            variant={isSelected ? "gold" : "outline"}
                            size="sm"
                            onClick={() =>
                              setSelectedBidByProject((prev) => ({
                                ...prev,
                                [project.id]: b.id,
                              }))
                            }
                          >
                            {isSelected ? "Selected" : "Select"}
                          </SxyButton>
                        </div>
                      </li>
                    );
                  })
                )}
              </ul>

              {selected ? (
                <div className="mt-5 space-y-3">
                  <label className="flex flex-col gap-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-text-muted">
                      Announcement (optional)
                    </span>
                    <textarea
                      rows={3}
                      maxLength={1000}
                      value={announcements[project.id] ?? ""}
                      onChange={(e) =>
                        setAnnouncements((prev) => ({
                          ...prev,
                          [project.id]: e.target.value,
                        }))
                      }
                      placeholder="Custom note posted to #general (defaults to a celebration message)."
                      className="w-full rounded-lg border border-border-base/60 bg-charcoal-card px-3 py-2 text-sm text-text-primary placeholder:text-text-dim focus:border-border-teal focus:outline-none"
                    />
                  </label>
                  <SxyButton
                    variant="gold"
                    size="default"
                    disabled={publishing === project.id}
                    onClick={() => handlePublish(project)}
                  >
                    {publishing === project.id
                      ? "Publishing…"
                      : "Publish Announcement"}
                  </SxyButton>
                </div>
              ) : null}
            </SxyCard>
          );
        })
      )}

      {celebration ? (
        <CelebrationModal
          celebration={celebration}
          onClose={() => setCelebration(null)}
        />
      ) : null}
    </div>
  );
}

function CelebrationModal({
  celebration,
  onClose,
}: {
  celebration: WinnerCelebration;
  onClose: () => void;
}) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 grid place-items-center bg-charcoal/80 px-4 backdrop-blur"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border-gold bg-charcoal-soft p-8 text-center shadow-[var(--shadow-card)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="pointer-events-none absolute inset-0 opacity-30">
          <div className="absolute -left-10 top-10 h-32 w-32 rounded-full bg-gold/30 blur-3xl" />
          <div className="absolute -right-10 bottom-10 h-32 w-32 rounded-full bg-teal-mid/30 blur-3xl" />
        </div>
        <div
          className="relative mx-auto grid h-20 w-20 place-items-center rounded-full text-5xl"
          style={{
            backgroundImage: "var(--gradient-gold)",
            animation: "sxy-trophy-float 2.4s ease-in-out infinite",
          }}
          aria-hidden
        >
          🏆
        </div>
        <h3 className="relative mt-5 font-display text-2xl text-gold-light">
          Winner announced!
        </h3>
        <p className="relative mt-2 text-sm text-text-muted">
          <span className="font-semibold text-text-primary">
            {celebration.bidderName}
          </span>{" "}
          won{" "}
          <span className="font-editorial italic text-teal-light">
            {celebration.projectTitle}
          </span>{" "}
          for{" "}
          <span className="font-mono text-gold">
            {BID_CURRENCY.format(celebration.amount)}
          </span>
          .
        </p>
        <div className="relative mt-6 flex justify-center gap-3">
          <SxyButton variant="primary" size="sm" onClick={onClose}>
            Done
          </SxyButton>
          <SxyButton variant="outline" size="sm" asChild>
            <Link to="/bidding/awarded">View awarded</Link>
          </SxyButton>
        </div>
        <style>{`
          @keyframes sxy-trophy-float {
            0%, 100% { transform: translateY(0) rotate(-3deg); }
            50%      { transform: translateY(-10px) rotate(3deg); }
          }
        `}</style>
      </div>
    </div>
  );
}
