import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Tag } from "@/components/sxy/Tag";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import type { ApprenticeshipProgram } from "@/lib/apprenticeship/shared";

export const Route = createFileRoute("/apprenticeship/$id")({
  head: () => ({ meta: [{ title: "Apprenticeship — SXY's Corporate Club" }] }),
  component: ProgramDetail,
});

function ProgramDetail() {
  const { id } = Route.useParams();
  const { currentUser } = useAuth();

  const { data: program, isLoading } = useQuery({
    queryKey: ["apprenticeship", "program", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("apprenticeship_programs")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as ApprenticeshipProgram | null;
    },
  });

  const { data: existingApp } = useQuery({
    queryKey: ["apprenticeship", "myapp", id, currentUser?.id],
    enabled: !!currentUser,
    queryFn: async () => {
      const { data } = await supabase
        .from("apprenticeship_applications")
        .select("id, status")
        .eq("program_id", id)
        .eq("applicant_id", currentUser!.id)
        .maybeSingle();
      return data;
    },
  });

  if (isLoading) {
    return <AppLayout title="Apprenticeship"><p>Loading…</p></AppLayout>;
  }
  if (!program) {
    return (
      <AppLayout title="Apprenticeship">
        <SxyCard>
          <p>Program not found.</p>
          <div className="mt-3">
            <SxyButton variant="outline" size="sm" asChild>
              <Link to="/apprenticeship">Back to listings</Link>
            </SxyButton>
          </div>
        </SxyCard>
      </AppLayout>
    );
  }

  const isOwner = currentUser?.id === program.owner_id;

  return (
    <AppLayout title={program.title}>
      <div className="mx-auto max-w-3xl space-y-5">
        <SxyCard accent>
          <div className="flex flex-wrap gap-2">
            {program.industry ? <Tag variant="teal">{program.industry}</Tag> : null}
            {program.location ? <Tag variant="gray">{program.location}</Tag> : null}
            {program.duration_weeks ? (
              <Tag variant="gold">{program.duration_weeks} weeks</Tag>
            ) : null}
            {program.start_date ? (
              <Tag variant="gray">Starts {program.start_date}</Tag>
            ) : null}
          </div>
          <h1 className="mt-3 font-display text-3xl text-text-primary">
            {program.title}
          </h1>
          <p className="mt-2 text-base text-text-muted">{program.summary}</p>
          {program.stipend_description ? (
            <p className="mt-3 text-sm text-gold-light">
              Compensation: {program.stipend_description}
            </p>
          ) : null}
        </SxyCard>

        <SxyCard>
          <p className="sxy-section-label">About this program</p>
          <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-text-muted">
            {program.description}
          </p>
        </SxyCard>

        <SxyCard>
          <p className="sxy-section-label">What you'll submit</p>
          <ul className="mt-3 space-y-1.5 text-sm text-text-muted">
            {program.require_cover_note && <li>· Cover note</li>}
            {program.require_resume && <li>· Resume / CV (PDF or doc)</li>}
            {program.require_video && <li>· Short video introduction</li>}
            {program.require_portfolio && <li>· Portfolio links</li>}
            {program.structured_questions.length > 0 && (
              <li>· {program.structured_questions.length} short-answer questions</li>
            )}
          </ul>

          <div className="mt-5 flex justify-end gap-2">
            {isOwner ? (
              <SxyButton variant="outline" size="sm" asChild>
                <Link to="/apprenticeship/manage">Manage applicants</Link>
              </SxyButton>
            ) : existingApp ? (
              <Tag variant="gold">
                Application: {existingApp.status}
              </Tag>
            ) : (
              <SxyButton variant="gold" size="sm" asChild>
                <Link to="/apprenticeship/$id/apply" params={{ id: program.id }}>
                  Apply now
                </Link>
              </SxyButton>
            )}
          </div>
        </SxyCard>
      </div>
    </AppLayout>
  );
}
