import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Tag } from "@/components/sxy/Tag";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  milestoneStatusLabel,
  type MilestoneStatus,
} from "@/lib/apprenticeship/shared";
import { toast } from "sonner";

export const Route = createFileRoute("/apprenticeship/portal/$id")({
  head: () => ({ meta: [{ title: "Apprenticeship Portal — SXY's Corporate Club" }] }),
  component: PortalPage,
});

interface Apprenticeship {
  id: string;
  program_id: string;
  owner_id: string;
  apprentice_id: string;
  status: string;
  started_at: string;
}

interface Milestone {
  id: string;
  apprenticeship_id: string;
  title: string;
  description: string | null;
  due_date: string | null;
  status: MilestoneStatus;
  sort_order: number;
}

interface Message {
  id: string;
  sender_id: string;
  body: string;
  created_at: string;
}

function PortalPage() {
  const { id } = Route.useParams();
  const { currentUser } = useAuth();
  const qc = useQueryClient();

  const { data: appr } = useQuery({
    queryKey: ["appr", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("apprenticeships")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as Apprenticeship | null;
    },
  });

  const { data: programTitle } = useQuery({
    queryKey: ["appr-program", appr?.program_id],
    enabled: !!appr,
    queryFn: async () => {
      const { data } = await supabase
        .from("apprenticeship_programs")
        .select("title")
        .eq("id", appr!.program_id)
        .maybeSingle();
      return (data as { title: string } | null)?.title ?? "Program";
    },
  });

  const { data: milestones } = useQuery({
    queryKey: ["appr-ms", id],
    queryFn: async () => {
      const { data } = await supabase
        .from("apprenticeship_milestones")
        .select("*")
        .eq("apprenticeship_id", id)
        .order("sort_order", { ascending: true });
      return (data as Milestone[]) ?? [];
    },
  });

  const { data: messages } = useQuery({
    queryKey: ["appr-msgs", id],
    queryFn: async () => {
      const { data } = await supabase
        .from("apprenticeship_messages")
        .select("*")
        .eq("apprenticeship_id", id)
        .order("created_at", { ascending: true });
      return (data as Message[]) ?? [];
    },
    refetchInterval: 15000,
  });

  if (!appr) {
    return <AppLayout title="Portal"><p>Loading…</p></AppLayout>;
  }

  const isOwner = currentUser?.id === appr.owner_id;
  const isApprentice = currentUser?.id === appr.apprentice_id;

  return (
    <AppLayout
      title={programTitle ?? "Apprenticeship Portal"}
      actions={
        <Tag variant={appr.status === "active" ? "green" : "gray"}>
          {appr.status}
        </Tag>
      }
    >
      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <MilestonesPanel
          milestones={milestones ?? []}
          isOwner={isOwner}
          isApprentice={isApprentice}
          apprId={id}
          onChange={() => qc.invalidateQueries({ queryKey: ["appr-ms", id] })}
        />
        <MessagesPanel
          messages={messages ?? []}
          apprId={id}
          currentUserId={currentUser?.id ?? ""}
          ownerId={appr.owner_id}
          onSent={() => qc.invalidateQueries({ queryKey: ["appr-msgs", id] })}
        />
      </div>
      {isOwner && appr.status === "active" && (
        <div className="mt-6 flex justify-end">
          <SxyButton
            variant="outline"
            size="sm"
            onClick={async () => {
              await supabase
                .from("apprenticeships")
                .update({ status: "completed", completed_at: new Date().toISOString() })
                .eq("id", id);
              toast.success("Marked complete");
              qc.invalidateQueries({ queryKey: ["appr", id] });
            }}
          >
            Mark apprenticeship complete
          </SxyButton>
        </div>
      )}
      <div className="mt-6">
        <SxyButton variant="ghost" size="sm" asChild>
          <Link to="/apprenticeship/manage">← Back</Link>
        </SxyButton>
      </div>
    </AppLayout>
  );
}

function MilestonesPanel({
  milestones,
  isOwner,
  isApprentice,
  apprId,
  onChange,
}: {
  milestones: Milestone[];
  isOwner: boolean;
  isApprentice: boolean;
  apprId: string;
  onChange: () => void;
}) {
  const [title, setTitle] = React.useState("");
  const [desc, setDesc] = React.useState("");
  const [due, setDue] = React.useState("");

  const add = async () => {
    if (title.trim().length < 1) return;
    const { error } = await supabase.from("apprenticeship_milestones").insert({
      apprenticeship_id: apprId,
      title: title.trim(),
      description: desc.trim() || null,
      due_date: due || null,
      sort_order: milestones.length,
    });
    if (error) toast.error(error.message);
    else {
      setTitle(""); setDesc(""); setDue("");
      onChange();
    }
  };

  const setStatus = async (m: Milestone, status: MilestoneStatus) => {
    const patch: Record<string, unknown> = { status };
    if (status === "submitted") patch.submitted_at = new Date().toISOString();
    if (status === "approved") patch.approved_at = new Date().toISOString();
    const { error } = await supabase
      .from("apprenticeship_milestones")
      .update(patch as never)
      .eq("id", m.id);
    if (error) toast.error(error.message);
    else onChange();
  };

  return (
    <SxyCard>
      <p className="sxy-section-label">Milestones</p>
      <div className="mt-3 space-y-3">
        {milestones.length === 0 && (
          <p className="text-sm text-text-muted">No milestones yet.</p>
        )}
        {milestones.map((m) => (
          <div
            key={m.id}
            className="rounded-lg border border-border-base/60 bg-charcoal-card p-3"
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold text-text-primary">{m.title}</p>
                {m.description && (
                  <p className="mt-1 text-xs text-text-muted">{m.description}</p>
                )}
                {m.due_date && (
                  <p className="mt-1 text-[11px] text-text-dim">
                    Due {m.due_date}
                  </p>
                )}
              </div>
              <Tag
                variant={
                  m.status === "approved"
                    ? "green"
                    : m.status === "submitted"
                    ? "gold"
                    : m.status === "in_progress"
                    ? "teal"
                    : "gray"
                }
              >
                {milestoneStatusLabel(m.status)}
              </Tag>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {isApprentice && m.status === "pending" && (
                <SxyButton variant="outline" size="sm" onClick={() => setStatus(m, "in_progress")}>
                  Start
                </SxyButton>
              )}
              {isApprentice && (m.status === "in_progress" || m.status === "pending") && (
                <SxyButton variant="gold" size="sm" onClick={() => setStatus(m, "submitted")}>
                  Mark submitted
                </SxyButton>
              )}
              {isOwner && m.status === "submitted" && (
                <SxyButton variant="gold" size="sm" onClick={() => setStatus(m, "approved")}>
                  Approve
                </SxyButton>
              )}
              {isOwner && m.status !== "pending" && m.status !== "approved" && (
                <SxyButton variant="ghost" size="sm" onClick={() => setStatus(m, "pending")}>
                  Reset
                </SxyButton>
              )}
            </div>
          </div>
        ))}
      </div>
      {isOwner && (
        <div className="mt-5 space-y-2 border-t border-border-base/40 pt-4">
          <p className="sxy-section-label">Add milestone</p>
          <Label>Title</Label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} />
          <Label>Description</Label>
          <Textarea rows={2} value={desc} onChange={(e) => setDesc(e.target.value)} />
          <Label>Due date</Label>
          <Input type="date" value={due} onChange={(e) => setDue(e.target.value)} />
          <SxyButton variant="outline" size="sm" onClick={add}>
            + Add
          </SxyButton>
        </div>
      )}
    </SxyCard>
  );
}

function MessagesPanel({
  messages,
  apprId,
  currentUserId,
  ownerId,
  onSent,
}: {
  messages: Message[];
  apprId: string;
  currentUserId: string;
  ownerId: string;
  onSent: () => void;
}) {
  const [body, setBody] = React.useState("");
  const [sending, setSending] = React.useState(false);

  const send = async () => {
    if (body.trim().length < 1) return;
    setSending(true);
    const { error } = await supabase.from("apprenticeship_messages").insert({
      apprenticeship_id: apprId,
      sender_id: currentUserId,
      body: body.trim(),
    });
    setSending(false);
    if (error) toast.error(error.message);
    else {
      setBody("");
      onSent();
    }
  };

  return (
    <SxyCard>
      <p className="sxy-section-label">Messages</p>
      <div className="mt-3 max-h-[420px] space-y-2 overflow-y-auto pr-1">
        {messages.length === 0 && (
          <p className="text-sm text-text-muted">No messages yet — say hi.</p>
        )}
        {messages.map((m) => {
          const mine = m.sender_id === currentUserId;
          const isOwner = m.sender_id === ownerId;
          return (
            <div
              key={m.id}
              className={`rounded-lg px-3 py-2 text-sm ${
                mine
                  ? "ml-8 bg-[color:var(--teal-glow)] text-teal-light"
                  : "mr-8 bg-charcoal-card text-text-primary"
              }`}
            >
              <p className="text-[10px] uppercase tracking-wider text-text-dim">
                {isOwner ? "Mentor" : "Apprentice"} ·{" "}
                {new Date(m.created_at).toLocaleString()}
              </p>
              <p className="mt-1 whitespace-pre-wrap">{m.body}</p>
            </div>
          );
        })}
      </div>
      <div className="mt-3 space-y-2 border-t border-border-base/40 pt-3">
        <Textarea
          rows={3}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Write a message…"
          maxLength={4000}
        />
        <div className="flex justify-end">
          <SxyButton variant="gold" size="sm" onClick={send} disabled={sending}>
            {sending ? "Sending…" : "Send"}
          </SxyButton>
        </div>
      </div>
    </SxyCard>
  );
}
