/**
 * /financials/admin/platform — Admin Platform Revenue dashboard.
 *
 * Top KPIs from public.platform_revenue_summary (all-time + MTD), plus a
 * client-side date range picker that re-derives a filtered revenue stat,
 * monthly stacked bar, and donut from the membership+fee transaction list.
 * Top earners table from public.member_financial_summary.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { StatTile } from "@/components/sxy/StatTile";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { supabase } from "@/integrations/supabase/client";
import {
  dateRangeStart,
  formatMoney,
  groupByMonth,
  type DateRangeKey,
  type MemberFinancialRow,
  type PlatformRevenueSummary,
  type TransactionRow,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/admin/platform")({
  head: () => ({ meta: [{ title: "Platform Revenue — SXY's Corporate Club" }] }),
  component: PlatformRevenueAdminRoute,
});

const RANGE_LABEL: Record<DateRangeKey, string> = {
  all: "All time",
  month: "This month",
  "3months": "Last 3 months",
  year: "This year",
};

function PlatformRevenueAdminRoute() {
  return (
    <AdminRoute>
      <AppLayout title="Platform Revenue">
        <PlatformRevenueInner />
      </AppLayout>
    </AdminRoute>
  );
}

function PlatformRevenueInner() {
  const [range, setRange] = React.useState<DateRangeKey>("all");

  const { data: summary } = useQuery({
    queryKey: ["financials", "admin", "platformSummary"],
    queryFn: async () => {
      const { data } = await supabase
        .from("platform_revenue_summary")
        .select("*")
        .single();
      return (data ?? null) as PlatformRevenueSummary | null;
    },
  });

  const { data: txns = [] } = useQuery({
    queryKey: ["financials", "admin", "txns"],
    queryFn: async () => {
      const { data } = await supabase
        .from("transactions")
        .select("*")
        .in("txn_type", ["membership", "fee"])
        .order("created_at", { ascending: false })
        .limit(2000);
      return (data ?? []) as TransactionRow[];
    },
  });

  const { data: topEarners = [] } = useQuery({
    queryKey: ["financials", "admin", "topEarners"],
    queryFn: async () => {
      const { data } = await supabase
        .from("member_financial_summary")
        .select("*")
        .order("net_earned", { ascending: false })
        .limit(8);
      return (data ?? []) as MemberFinancialRow[];
    },
  });

  // Client-side filter on txns by selected range.
  const filteredTxns = React.useMemo(() => {
    const since = dateRangeStart(range);
    if (!since) return txns;
    const sinceTime = new Date(since).getTime();
    return txns.filter((t) => new Date(t.created_at).getTime() >= sinceTime);
  }, [txns, range]);

  const filteredTotals = React.useMemo(() => {
    let membership = 0;
    let fees = 0;
    for (const t of filteredTxns) {
      const gross = Number(t.gross_amount ?? t.amount ?? 0);
      if (t.txn_type === "membership") membership += gross;
      else if (t.txn_type === "fee") fees += gross;
    }
    return { membership, fees, total: membership + fees };
  }, [filteredTxns]);

  const monthly = React.useMemo(() => groupByMonth(filteredTxns, 8), [filteredTxns]);
  const breakdown = React.useMemo(() => {
    return [
      {
        name: "Membership",
        value: filteredTotals.membership,
        color: "var(--teal-mid)",
      },
      {
        name: "Referral Fees",
        value: filteredTotals.fees,
        color: "var(--gold)",
      },
    ].filter((d) => d.value > 0);
  }, [filteredTotals]);

  return (
    <div className="space-y-8">
      <FinancialsNav />

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile
          label="Total Revenue (all-time)"
          value={formatMoney(summary?.total_revenue ?? 0)}
        />
        <StatTile
          label="Revenue MTD"
          value={formatMoney(summary?.revenue_mtd ?? 0)}
        />
        <StatTile
          label="Membership MTD"
          value={formatMoney(summary?.membership_mtd ?? 0)}
        />
        <StatTile
          label="Pending Payouts"
          value={formatMoney(summary?.pending_payouts_total ?? 0)}
          delta={`${summary?.pending_payouts_count ?? 0} requests`}
          deltaTone="neutral"
        />
      </section>

      <SxyCard accent>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-lg text-teal-light">
              Revenue in range
            </h2>
            <p className="text-xs text-text-muted">
              {RANGE_LABEL[range]} · {filteredTxns.length} transactions
            </p>
          </div>
          <Select
            value={range}
            onValueChange={(v) => setRange(v as DateRangeKey)}
          >
            <SelectTrigger className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All time</SelectItem>
              <SelectItem value="month">This month</SelectItem>
              <SelectItem value="3months">Last 3 months</SelectItem>
              <SelectItem value="year">This year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          <StatTile
            label="Total"
            value={formatMoney(filteredTotals.total)}
          />
          <StatTile
            label="Membership"
            value={formatMoney(filteredTotals.membership)}
          />
          <StatTile
            label="Referral fees"
            value={formatMoney(filteredTotals.fees)}
          />
        </div>
      </SxyCard>

      <section className="grid gap-6 lg:grid-cols-3">
        <SxyCard accent className="lg:col-span-2">
          <h2 className="font-display text-lg text-teal-light">
            Monthly platform revenue
          </h2>
          <div className="mt-4 h-72 w-full">
            <ResponsiveContainer>
              <BarChart data={monthly}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="oklch(1 0 0 / 0.06)"
                />
                <XAxis
                  dataKey="month"
                  tick={{ fill: "#a0c4cc", fontSize: 11 }}
                />
                <YAxis tick={{ fill: "#a0c4cc", fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    background: "#111",
                    border: "1px solid oklch(1 0 0 / 0.1)",
                    borderRadius: 8,
                    color: "#eee",
                  }}
                  formatter={(v: number) => formatMoney(v)}
                />
                <Legend wrapperStyle={{ color: "#a0c4cc", fontSize: 11 }} />
                <Bar
                  dataKey="fees"
                  stackId="a"
                  fill="var(--gold)"
                  name="Fees + Membership"
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SxyCard>

        <SxyCard accent>
          <h2 className="font-display text-lg text-teal-light">Mix</h2>
          <div className="mt-4 h-72 w-full">
            {breakdown.length === 0 ? (
              <div className="grid h-full place-items-center text-sm text-text-dim">
                No revenue in range.
              </div>
            ) : (
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={breakdown}
                    dataKey="value"
                    innerRadius={55}
                    outerRadius={90}
                    paddingAngle={3}
                  >
                    {breakdown.map((entry, idx) => (
                      <Cell key={idx} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "#111",
                      border: "1px solid oklch(1 0 0 / 0.1)",
                      borderRadius: 8,
                      color: "#eee",
                    }}
                    formatter={(v: number) => formatMoney(v)}
                  />
                  <Legend wrapperStyle={{ color: "#a0c4cc", fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </SxyCard>
      </section>

      <SxyCard accent>
        <h2 className="font-display text-lg text-teal-light">Top earners</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-[10px] uppercase tracking-wider text-text-dim">
              <tr className="border-b border-border-base/40">
                <th className="py-2 text-left font-semibold">Member</th>
                <th className="py-2 text-left font-semibold">Tier</th>
                <th className="py-2 text-right font-semibold">Bookings</th>
                <th className="py-2 text-right font-semibold">Gross</th>
                <th className="py-2 text-right font-semibold">Fees</th>
                <th className="py-2 text-right font-semibold">Net</th>
              </tr>
            </thead>
            <tbody>
              {topEarners.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-text-dim">
                    No earnings yet.
                  </td>
                </tr>
              ) : (
                topEarners.map((m) => (
                  <tr
                    key={m.member_id}
                    className="border-b border-border-base/30 last:border-0"
                  >
                    <td className="py-3 text-text-primary">
                      {m.full_name ?? m.email ?? "—"}
                    </td>
                    <td className="py-3 text-text-muted uppercase tracking-wider text-[10px]">
                      {m.tier ?? "free"}
                    </td>
                    <td className="py-3 text-right text-text-muted">
                      {m.booking_count}
                    </td>
                    <td className="py-3 text-right text-text-primary">
                      {formatMoney(m.gross_earned)}
                    </td>
                    <td className="py-3 text-right text-danger">
                      {formatMoney(m.fees_paid)}
                    </td>
                    <td className="py-3 text-right font-semibold text-success">
                      {formatMoney(m.net_earned)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </SxyCard>
    </div>
  );
}
