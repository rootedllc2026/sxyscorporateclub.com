import * as React from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { z } from "zod";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { isPaidTier, newQuestionId, type StructuredQuestion } from "@/lib/apprenticeship/shared";
import { toast } from "sonner";

export const Route = createFileRoute("/apprenticeship/create")({
  head: () => ({ meta: [{ title: "Post Apprenticeship — SXY's Corporate Club" }] }),
  component: CreateProgramPage,
});

const schema = z.object({
  title: z.string().trim().min(3).max(200),
  summary: z.string().trim().min(10).max(500),
  description: z.string().trim().min(10).max(8000),
  industry: z.string().trim().max(80).optional(),
  location: z.string().trim().max(120).optional(),
  duration_weeks: z.coerce.number().int().min(1).max(104).optional(),
  stipend_description: z.string().trim().max(500).optional(),
  start_date: z.string().optional(),
});

function CreateProgramPage() {
  const { currentUser, userTier, isAdmin } = useAuth();
  const navigate = useNavigate();
  const allowed = isAdmin || isPaidTier(userTier);

  const [form, setForm] = React.useState({
    title: "",
    summary: "",
    description: "",
    industry: "",
    location: "",
    duration_weeks: "",
    stipend_description: "",
    start_date: "",
  });
  const [requires, setRequires] = React.useState({
    cover_note: true,
    resume: true,
    video: false,
    portfolio: false,
  });
  const [questions, setQuestions] = React.useState<StructuredQuestion[]>([]);
  const [saving, setSaving] = React.useState(false);

  if (!allowed) {
    return (
      <AppLayout title="Post Apprenticeship">
        <SxyCard accent>
          <h2 className="font-display text-2xl text-text-primary">
            Paid members only
          </h2>
          <p className="mt-2 text-sm text-text-muted">
            Posting an apprenticeship requires an Investing Member plan or
            higher.
          </p>
          <div className="mt-4">
            <SxyButton variant="gold" size="sm" asChild>
              <Link to="/membership">Upgrade</Link>
            </SxyButton>
          </div>
        </SxyCard>
      </AppLayout>
    );
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check the form");
      return;
    }
    setSaving(true);
    const { data, error } = await supabase
      .from("apprenticeship_programs")
      .insert({
        owner_id: currentUser.id,
        title: parsed.data.title,
        summary: parsed.data.summary,
        description: parsed.data.description,
        industry: parsed.data.industry || null,
        location: parsed.data.location || null,
        duration_weeks: parsed.data.duration_weeks ?? null,
        stipend_description: parsed.data.stipend_description || null,
        start_date: parsed.data.start_date || null,
        require_cover_note: requires.cover_note,
        require_resume: requires.resume,
        require_video: requires.video,
        require_portfolio: requires.portfolio,
        structured_questions: questions.filter((q) => q.prompt.trim()),
        status: "open",
      })
      .select("id")
      .single();
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Program posted");
    navigate({ to: "/apprenticeship/$id", params: { id: data.id } });
  };

  return (
    <AppLayout title="Post an Apprenticeship">
      <form onSubmit={onSubmit} className="mx-auto max-w-3xl space-y-5">
        <SxyCard>
          <div className="grid gap-4">
            <div>
              <Label>Program title</Label>
              <Input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. HVAC Field Apprentice — Summer 2026"
                maxLength={200}
              />
            </div>
            <div>
              <Label>Summary (one-liner)</Label>
              <Input
                value={form.summary}
                onChange={(e) => setForm({ ...form, summary: e.target.value })}
                placeholder="Short description shown on the listings page"
                maxLength={500}
              />
            </div>
            <div>
              <Label>Full description</Label>
              <Textarea
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
                placeholder="What will the apprentice learn? Expectations, schedule, outcomes."
                rows={8}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Industry</Label>
                <Input
                  value={form.industry}
                  onChange={(e) =>
                    setForm({ ...form, industry: e.target.value })
                  }
                  placeholder="Trades, Marketing, Tech…"
                />
              </div>
              <div>
                <Label>Location</Label>
                <Input
                  value={form.location}
                  onChange={(e) =>
                    setForm({ ...form, location: e.target.value })
                  }
                  placeholder="City, State or Remote"
                />
              </div>
              <div>
                <Label>Duration (weeks)</Label>
                <Input
                  type="number"
                  min={1}
                  max={104}
                  value={form.duration_weeks}
                  onChange={(e) =>
                    setForm({ ...form, duration_weeks: e.target.value })
                  }
                />
              </div>
              <div>
                <Label>Start date</Label>
                <Input
                  type="date"
                  value={form.start_date}
                  onChange={(e) =>
                    setForm({ ...form, start_date: e.target.value })
                  }
                />
              </div>
            </div>
            <div>
              <Label>Stipend / compensation</Label>
              <Input
                value={form.stipend_description}
                onChange={(e) =>
                  setForm({ ...form, stipend_description: e.target.value })
                }
                placeholder="e.g. $20/hr, unpaid + mentorship, equity stipend"
              />
            </div>
          </div>
        </SxyCard>

        <SxyCard>
          <p className="sxy-section-label">Application requirements</p>
          <p className="mt-1 text-xs text-text-dim">
            Choose what every applicant must submit.
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {(
              [
                ["cover_note", "Cover note"],
                ["resume", "Resume / CV upload"],
                ["video", "Video intro upload"],
                ["portfolio", "Portfolio / links"],
              ] as const
            ).map(([key, label]) => (
              <label
                key={key}
                className="flex cursor-pointer items-center gap-3 rounded-lg border border-border-base/60 bg-charcoal-card px-4 py-3"
              >
                <Checkbox
                  checked={requires[key]}
                  onCheckedChange={(v) =>
                    setRequires((r) => ({ ...r, [key]: v === true }))
                  }
                />
                <span className="text-sm text-text-primary">{label}</span>
              </label>
            ))}
          </div>
        </SxyCard>

        <SxyCard>
          <div className="flex items-center justify-between">
            <div>
              <p className="sxy-section-label">Custom questions (optional)</p>
              <p className="mt-1 text-xs text-text-dim">
                Add up to 5 short-answer questions for applicants.
              </p>
            </div>
            {questions.length < 5 ? (
              <SxyButton
                type="button"
                variant="outline"
                size="sm"
                onClick={() =>
                  setQuestions((qs) => [
                    ...qs,
                    { id: newQuestionId(), prompt: "" },
                  ])
                }
              >
                + Question
              </SxyButton>
            ) : null}
          </div>
          <div className="mt-4 space-y-3">
            {questions.map((q, i) => (
              <div key={q.id} className="flex items-center gap-2">
                <span className="text-xs text-text-dim">Q{i + 1}</span>
                <Input
                  value={q.prompt}
                  onChange={(e) =>
                    setQuestions((qs) =>
                      qs.map((x) =>
                        x.id === q.id ? { ...x, prompt: e.target.value } : x,
                      ),
                    )
                  }
                  placeholder="e.g. Why do you want this apprenticeship?"
                />
                <SxyButton
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    setQuestions((qs) => qs.filter((x) => x.id !== q.id))
                  }
                >
                  Remove
                </SxyButton>
              </div>
            ))}
          </div>
        </SxyCard>

        <div className="flex justify-end gap-2">
          <SxyButton type="button" variant="ghost" size="sm" asChild>
            <Link to="/apprenticeship">Cancel</Link>
          </SxyButton>
          <SxyButton type="submit" variant="gold" size="sm" disabled={saving}>
            {saving ? "Posting…" : "Post program"}
          </SxyButton>
        </div>
      </form>
    </AppLayout>
  );
}
