import * as React from "react";
import {
  createFileRoute,
  Link,
  notFound,
  useNavigate,
} from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { cn } from "@/lib/utils";
import {
  USD_2,
  bookingMath,
  categoryBannerGradient,
  clubFeePctForTier,
  CLUB_FEE_PCT,
  CLUB_FEE_PCT_VIP,
  dayLabelFromDate,
  formatPrice,
  generateTimeSlots,
  refCategoryEmoji,
  refCategoryLabel,
} from "@/lib/referrals/shared";

const detailSearchSchema = z.object({
  book: z.coerce.number().optional(),
});

export const Route = createFileRoute("/referrals/$id")({
  head: () => ({ meta: [{ title: "Business — SXY's Corporate Club" }] }),
  validateSearch: detailSearchSchema,
  component: BusinessDetailPage,
  errorComponent: ({ error }) => (
    <AppLayout title="Business">
      <SxyCard accent>
        <p className="text-sm text-text-muted">{error.message}</p>
      </SxyCard>
    </AppLayout>
  ),
  notFoundComponent: () => (
    <AppLayout title="Not found">
      <SxyCard accent>
        <h2 className="font-display text-xl text-teal-light">Business not found</h2>
        <p className="mt-2 text-sm text-text-muted">It may have been removed.</p>
        <div className="mt-4">
          <SxyButton variant="primary" size="sm" asChild>
            <Link to="/referrals">Back to directory</Link>
          </SxyButton>
        </div>
      </SxyCard>
    </AppLayout>
  ),
});

function BusinessDetailPage() {
  const { id } = Route.useParams();
  return (
    <AppLayout title="Business Details">
      <DetailContent pageId={id} />
    </AppLayout>
  );
}

function DetailContent({ pageId }: { pageId: string }) {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [bookingOpen, setBookingOpen] = React.useState(!!search.book);

  React.useEffect(() => {
    if (search.book) setBookingOpen(true);
  }, [search.book]);

  const { data: page, isLoading } = useQuery({
    queryKey: ["referrals", "page", pageId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("business_pages")
        .select("*")
        .eq("id", pageId)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw notFound();
      const { data: ownerData } = await supabase
        .from("profiles")
        .select("full_name, city, state, avatar_color")
        .eq("id", data.owner_id)
        .maybeSingle();
      return { ...data, profiles: ownerData ?? null };
    },
  });

  const { data: services } = useQuery({
    queryKey: ["referrals", "services", pageId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("referral_services")
        .select("*")
        .eq("business_page_id", pageId)
        .eq("is_active", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: reviews } = useQuery({
    queryKey: ["referrals", "reviews", pageId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("referral_reviews")
        .select("*")
        .eq("business_page_id", pageId)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      if (!data || data.length === 0) return [];
      const ids = Array.from(new Set(data.map((r) => r.reviewer_id).filter(Boolean))) as string[];
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", ids);
      const map = new Map((profs ?? []).map((p) => [p.id, p]));
      return data.map((r) => ({ ...r, profiles: r.reviewer_id ? map.get(r.reviewer_id) ?? null : null }));
    },
  });

  if (isLoading || !page) {
    return (
      <SxyCard>
        <p className="text-sm text-text-muted">Loading business…</p>
      </SxyCard>
    );
  }

  const owner = (page.profiles ?? {}) as { full_name?: string | null; city?: string | null; state?: string | null; avatar_color?: string | null };
  const location = [owner.city, owner.state].filter(Boolean).join(", ");

  const closeBooking = () => {
    setBookingOpen(false);
    if (search.book) {
      void navigate({ to: "/referrals/$id", params: { id: pageId }, search: {} });
    }
  };

  return (
    <div className="space-y-8">
      {/* Hero banner */}
      <section
        className="overflow-hidden rounded-2xl border border-border-teal/60"
      >
        <div
          className="relative flex h-40 items-center justify-center"
          style={{ backgroundImage: categoryBannerGradient(page.category) }}
        >
          <span aria-hidden className="text-7xl drop-shadow-2xl">
            {page.icon_emoji ?? refCategoryEmoji(page.category)}
          </span>
          {page.is_featured ? (
            <Tag
              variant="gold"
              className="absolute right-4 top-4 px-3 py-1 text-xs"
            >
              ★ Featured
            </Tag>
          ) : null}
        </div>
      </section>

      {/* Two-column body */}
      <section className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        {/* Left */}
        <div className="space-y-6">
          <SxyCard accent>
            <h1 className="font-display text-3xl text-text-primary">
              {page.business_name}
            </h1>
            <p className="mt-2 text-sm text-text-dim">
              {owner.full_name ?? "Member"}{location ? ` · ${location}` : ""}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Tag variant="teal">{refCategoryLabel(page.category)}</Tag>
              {page.service_area ? (
                <Tag variant="gray">📍 {page.service_area}</Tag>
              ) : null}
              {page.allow_virtual ? <Tag variant="gray">💻 Virtual OK</Tag> : null}
            </div>
            {page.description ? (
              <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-text-primary">
                {page.description}
              </p>
            ) : null}
            {page.website_url ? (
              <p className="mt-4 text-xs">
                <a
                  href={page.website_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-teal-light underline-offset-2 hover:underline"
                >
                  {page.website_url} ↗
                </a>
              </p>
            ) : null}
          </SxyCard>

          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">Services</h2>
            <ul className="mt-4 divide-y divide-border-base/40">
              {services && services.length > 0 ? (
                services.map((s: any) => (
                  <li
                    key={s.id}
                    className="flex items-start justify-between gap-4 py-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-text-primary">
                        {s.name}
                      </p>
                      {s.description ? (
                        <p className="mt-1 text-xs text-text-muted">
                          {s.description}
                        </p>
                      ) : null}
                    </div>
                    <p className="font-mono text-sm text-gold">
                      {formatPrice(s.price)}
                    </p>
                  </li>
                ))
              ) : (
                <li className="py-4 text-center text-xs text-text-dim">
                  No services listed yet.
                </li>
              )}
            </ul>
          </SxyCard>

          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">Reviews</h2>
            <ul className="mt-4 space-y-4">
              {reviews && reviews.length > 0 ? (
                reviews.map((r: any) => (
                  <li
                    key={r.id}
                    className="rounded-lg border border-border-base/40 bg-charcoal-soft p-4"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium text-text-primary">
                        {r.profiles?.full_name ?? "Member"}
                      </p>
                      <p className="text-xs text-gold">
                        {"★".repeat(r.rating)}
                        <span className="text-text-dim">{"★".repeat(5 - r.rating)}</span>
                      </p>
                    </div>
                    <p className="mt-1 text-[10px] uppercase tracking-wider text-text-dim">
                      {new Date(r.created_at).toLocaleDateString(undefined, {
                        month: "short", day: "numeric", year: "numeric",
                      })}
                    </p>
                    {r.body ? (
                      <p className="mt-2 text-sm text-text-muted">{r.body}</p>
                    ) : null}
                  </li>
                ))
              ) : (
                <li className="rounded-lg border border-dashed border-border-base/60 p-4 text-center text-xs text-text-dim">
                  No reviews yet — book a session and be the first to review.
                </li>
              )}
            </ul>
          </SxyCard>
        </div>

        {/* Sidebar */}
        <aside className="space-y-6">
          <SxyCard accent>
            <p className="sxy-section-label">Book this provider</p>
            <p className="mt-3 text-[10px] uppercase tracking-[0.18em] text-text-dim">
              Starting at
            </p>
            <p className="font-editorial text-3xl text-gold">
              {formatPrice(page.starting_price)}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3 text-center">
              <div className="rounded-lg border border-border-base/40 bg-charcoal-soft p-3">
                <p className="font-display text-xl text-text-primary">
                  {page.total_bookings ?? 0}
                </p>
                <p className="text-[9px] uppercase tracking-wider text-text-dim">
                  bookings
                </p>
              </div>
              <div className="rounded-lg border border-border-base/40 bg-charcoal-soft p-3">
                <p className="font-display text-xl text-gold">
                  {page.avg_rating ? `${Number(page.avg_rating).toFixed(1)} ★` : "—"}
                </p>
                <p className="text-[9px] uppercase tracking-wider text-text-dim">
                  rating
                </p>
              </div>
            </div>
            <p className="mt-4 rounded-lg border border-border-gold/40 bg-[color:var(--gold-glow)] p-3 text-[11px] text-gold-light">
              A {CLUB_FEE_PCT}% Club platform fee ({CLUB_FEE_PCT_VIP}% for VIP
              members) is added to the service price at checkout. Providers
              keep 100% of their listed rate.
            </p>
            <div className="mt-5 space-y-2">
              <SxyButton
                variant="gold"
                size="lg"
                className="w-full"
                onClick={() => setBookingOpen(true)}
              >
                Book Now
              </SxyButton>
              <SxyButton variant="outline" size="default" className="w-full" asChild>
                <Link to="/exchange">Message Provider</Link>
              </SxyButton>
              <SxyButton variant="ghost" size="sm" className="w-full" asChild>
                <Link to="/referrals">← Back to directory</Link>
              </SxyButton>
            </div>
          </SxyCard>
        </aside>
      </section>

      {bookingOpen ? (
        <BookingModal
          page={page}
          services={services ?? []}
          onClose={closeBooking}
        />
      ) : null}
    </div>
  );
}

// ──────────────────────────── Booking Modal ──────────────────────────────────

function BookingModal({
  page,
  services,
  onClose,
}: {
  page: any;
  services: any[];
  onClose: () => void;
}) {
  const { currentUser, userTier } = useAuth();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [serviceId, setServiceId] = React.useState<string>(services[0]?.id ?? "");
  const [date, setDate] = React.useState<string>("");
  const [time, setTime] = React.useState<string>("");
  const [notes, setNotes] = React.useState<string>("");
  const [paymentMethod, setPaymentMethod] = React.useState<"card" | "trade">("card");
  const [tradeOffered, setTradeOffered] = React.useState<string>("");
  const [tradeRequested, setTradeRequested] = React.useState<string>("");
  const [tradeValue, setTradeValue] = React.useState<string>("");
  const [submitting, setSubmitting] = React.useState(false);

  const selectedService = services.find((s) => s.id === serviceId);
  const serviceAmount =
    Number(selectedService?.price ?? page.starting_price ?? 0) || 0;
  // Fee is determined by the *buyer's* tier — VIPs pay 2%, everyone else 3%.
  // We intentionally ignore page.platform_fee_pct so the policy is uniform
  // across the directory and can't be raised per-listing.
  const buyerFeePct = clubFeePctForTier(userTier);
  const math = bookingMath(serviceAmount, buyerFeePct);

  // May 2026 calendar grid
  const year = 2026;
  const monthIdx = 4; // May (0-based)
  const monthName = "May 2026";
  const firstDay = new Date(year, monthIdx, 1);
  const startWeekday = firstDay.getDay(); // 0=Sun
  const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();
  const cells: Array<{ day: number; date: string; available: boolean } | null> = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  const availableDays: string[] = Array.isArray(page.available_days)
    ? page.available_days
    : [];
  for (let d = 1; d <= daysInMonth; d++) {
    const dt = new Date(year, monthIdx, d);
    const dayLabel = dayLabelFromDate(dt);
    const iso = `${year}-${String(monthIdx + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    const allowed = availableDays.length === 0 || availableDays.includes(dayLabel);
    cells.push({ day: d, date: iso, available: allowed });
  }

  // Existing bookings on this date — to mark slots taken
  const { data: takenSlots } = useQuery({
    queryKey: ["referrals", "taken-slots", page.id, date],
    enabled: !!date,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("booked_time")
        .eq("business_page_id", page.id)
        .eq("booked_date", date)
        .neq("status", "cancelled");
      if (error) throw error;
      return new Set(((data ?? []) as any[]).map((b) => b.booked_time));
    },
  });

  const slots = React.useMemo(
    () => generateTimeSlots(page.start_time, page.end_time, page.session_length_min),
    [page.start_time, page.end_time, page.session_length_min],
  );

  async function handleConfirm() {
    if (!currentUser) {
      toast.error("Please sign in first");
      return;
    }
    if (!date || !time) {
      toast.error("Pick a date and time");
      return;
    }
    if (paymentMethod === "card" && math.service <= 0) {
      toast.error("This service has no price set");
      return;
    }
    if (paymentMethod === "trade") {
      if (!tradeOffered.trim() || !tradeRequested.trim()) {
        toast.error("Describe what you're offering and what you'd like in return");
        return;
      }
    }
    setSubmitting(true);
    try {
      const initialStatus =
        paymentMethod === "trade" ? "pending_agreement" : "pending_payment";
      const { data: bookingRow, error } = await supabase
        .from("bookings")
        .insert({
          business_page_id: page.id,
          service_id: serviceId || null,
          buyer_id: currentUser.id,
          provider_id: page.owner_id,
          booked_date: date,
          booked_time: time,
          notes: notes.trim() || null,
          service_amount: paymentMethod === "trade" ? 0 : math.service,
          platform_fee: paymentMethod === "trade" ? 0 : math.fee,
          net_to_provider: paymentMethod === "trade" ? 0 : math.net,
          total_amount: paymentMethod === "trade" ? 0 : math.total,
          status: initialStatus,
          payment_method: paymentMethod,
        })
        .select("id")
        .single();
      if (error) throw error;

      if (paymentMethod === "trade" && bookingRow) {
        const estValue = Number(tradeValue);
        const { error: tErr } = await supabase.from("trade_agreements").insert({
          booking_id: bookingRow.id,
          proposed_by_user_id: currentUser.id,
          offered_description: tradeOffered.trim(),
          requested_description: tradeRequested.trim(),
          estimated_value_usd:
            Number.isFinite(estValue) && estValue > 0 ? estValue : null,
          buyer_accepted_at: new Date().toISOString(),
        });
        if (tErr) throw tErr;
        toast.success("Trade proposal sent — awaiting provider acceptance.");
        void queryClient.invalidateQueries({ queryKey: ["referrals"] });
        onClose();
        void navigate({ to: "/bookings/$id", params: { id: bookingRow.id } });
        return;
      }

      toast.success("Booking saved as pending payment. Stripe checkout coming next.");
      void queryClient.invalidateQueries({ queryKey: ["referrals"] });
      onClose();
      if (bookingRow) {
        void navigate({ to: "/bookings/$id", params: { id: bookingRow.id } });
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't save booking");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border-teal/60 bg-charcoal-card p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="sxy-section-label">Book a session</p>
            <h2 className="mt-1 font-display text-2xl text-text-primary">
              {page.business_name}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-border-base/60 px-3 py-1 text-xs text-text-muted hover:border-border-teal hover:text-text-primary"
          >
            ✕
          </button>
        </div>

        {/* Service select */}
        <div className="mt-5 space-y-4">
          <FormRow label="Service">
            <select
              value={serviceId}
              onChange={(e) => setServiceId(e.target.value)}
              className={inputCls}
              disabled={services.length === 0}
            >
              {services.length === 0 ? (
                <option value="">No services available</option>
              ) : null}
              {services.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} — {formatPrice(s.price)}
                </option>
              ))}
            </select>
          </FormRow>

          {/* Calendar */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
              Select a date — {monthName}
            </p>
            <div className="mt-2 grid grid-cols-7 gap-1 rounded-lg border border-border-base/40 bg-charcoal-soft p-2">
              {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
                <p
                  key={`h-${i}`}
                  className="py-1 text-center text-[10px] font-semibold uppercase tracking-wider text-text-dim"
                >
                  {d}
                </p>
              ))}
              {cells.map((cell, i) =>
                cell == null ? (
                  <span key={`e-${i}`} />
                ) : (
                  <button
                    key={cell.date}
                    type="button"
                    onClick={() => {
                      if (!cell.available) return;
                      setDate(cell.date);
                      setTime("");
                    }}
                    disabled={!cell.available}
                    className={cn(
                      "rounded-md py-2 text-xs transition",
                      cell.available
                        ? "text-text-primary hover:bg-[color:var(--teal-glow)]"
                        : "cursor-not-allowed text-text-dim opacity-40",
                      date === cell.date &&
                        "bg-[image:var(--gradient-teal)] font-semibold text-text-primary",
                    )}
                  >
                    {cell.day}
                  </button>
                ),
              )}
            </div>
          </div>

          {/* Time slots */}
          {date ? (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
                Select a time
              </p>
              <div className="mt-2 grid grid-cols-4 gap-2 sm:grid-cols-6">
                {slots.length === 0 ? (
                  <p className="col-span-full text-xs text-text-dim">
                    Provider hasn't set their daily hours yet.
                  </p>
                ) : (
                  slots.map((slot) => {
                    const taken = takenSlots?.has(slot);
                    return (
                      <button
                        key={slot}
                        type="button"
                        disabled={taken}
                        onClick={() => setTime(slot)}
                        className={cn(
                          "rounded-md border px-2 py-1.5 text-xs transition",
                          taken
                            ? "cursor-not-allowed border-border-base/30 text-text-dim line-through opacity-50"
                            : time === slot
                            ? "border-gold bg-[color:var(--gold-glow)] text-gold-light"
                            : "border-border-base/60 text-text-muted hover:border-border-teal hover:text-text-primary",
                        )}
                      >
                        {slot}
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          ) : null}

          {/* Notes */}
          <FormRow label="Notes for provider (optional)">
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              maxLength={500}
              placeholder="Anything they should know before the session"
              className={cn(inputCls, "resize-y leading-relaxed")}
            />
          </FormRow>

          {/* Payment method */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
              Payment method
            </p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPaymentMethod("card")}
                className={cn(
                  "rounded-lg border px-3 py-3 text-left text-xs transition",
                  paymentMethod === "card"
                    ? "border-gold bg-[color:var(--gold-glow)] text-gold-light"
                    : "border-border-base/60 text-text-muted hover:border-border-teal",
                )}
              >
                <p className="font-semibold">💳 Pay with card</p>
                <p className="mt-1 text-[10px] text-text-dim">Stripe checkout</p>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod("trade")}
                className={cn(
                  "rounded-lg border px-3 py-3 text-left text-xs transition",
                  paymentMethod === "trade"
                    ? "border-teal bg-[color:var(--teal-glow)] text-teal-light"
                    : "border-border-base/60 text-text-muted hover:border-border-teal",
                )}
              >
                <p className="font-semibold">🤝 Trade goods/services</p>
                <p className="mt-1 text-[10px] text-text-dim">Barter agreement</p>
              </button>
            </div>
          </div>

          {paymentMethod === "trade" ? (
            <div className="space-y-3 rounded-lg border border-border-teal/40 bg-[color:var(--teal-glow)] p-4">
              <FormRow label="What you're offering in trade">
                <textarea
                  value={tradeOffered}
                  onChange={(e) => setTradeOffered(e.target.value)}
                  rows={2}
                  maxLength={500}
                  placeholder="e.g. 4 hours of graphic design work, 2 cases of inventory, etc."
                  className={cn(inputCls, "resize-y")}
                />
              </FormRow>
              <FormRow label="What you'd like in return (the service you're booking)">
                <textarea
                  value={tradeRequested}
                  onChange={(e) => setTradeRequested(e.target.value)}
                  rows={2}
                  maxLength={500}
                  placeholder="Describe the service/goods you're requesting from this provider"
                  className={cn(inputCls, "resize-y")}
                />
              </FormRow>
              <FormRow label="Estimated value (USD, optional)">
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={tradeValue}
                  onChange={(e) => setTradeValue(e.target.value)}
                  className={inputCls}
                  placeholder="0.00"
                />
              </FormRow>
              <p className="text-[10px] text-text-dim">
                No money will move through the platform. Both parties must accept
                the trade before the booking is confirmed.
              </p>
            </div>
          ) : (
            <div className="rounded-lg border border-border-gold/40 bg-[color:var(--gold-glow)] p-4 text-sm">
              <Row label="Service" value={USD_2.format(math.service)} />
              <Row
                label={`Club fee (${buyerFeePct}%${userTier === "vip" ? " · VIP rate" : ""})`}
                value={USD_2.format(math.fee)}
              />
              <div className="mt-2 flex items-baseline justify-between border-t border-border-gold/40 pt-2">
                <p className="font-display text-base text-gold-light">Total</p>
                <p className="font-display text-2xl text-gold">
                  {USD_2.format(math.total)}
                </p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between gap-3 pt-2">
            <SxyButton variant="ghost" size="default" onClick={onClose}>
              Cancel
            </SxyButton>
            <SxyButton
              variant={paymentMethod === "trade" ? "primary" : "gold"}
              size="default"
              disabled={
                submitting ||
                !date ||
                !time ||
                (paymentMethod === "card" && math.service <= 0)
              }
              onClick={handleConfirm}
            >
              {submitting
                ? "Saving…"
                : paymentMethod === "trade"
                ? "Send trade proposal"
                : "Confirm & Pay"}
            </SxyButton>
          </div>
          {paymentMethod === "card" ? (
            <p className="text-center text-[10px] text-text-dim">
              Stripe checkout will be added in the next build step. Bookings
              currently save as <code>pending_payment</code>.
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function FormRow({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
        {label}
      </p>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-0.5 text-xs">
      <span className="text-text-muted">{label}</span>
      <span className="font-mono text-text-primary">{value}</span>
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-border-base/60 bg-charcoal-soft px-3 py-2 text-sm text-text-primary placeholder:text-text-dim focus:border-border-teal focus:outline-none";
