import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Tag } from "@/components/sxy/Tag";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  applicationStatusLabel,
  type ApplicationStatus,
  type ApprenticeshipProgram,
  type StructuredAnswer,
} from "@/lib/apprenticeship/shared";
import { toast } from "sonner";

export const Route = createFileRoute("/apprenticeship/manage")({
  head: () => ({ meta: [{ title: "Manage Apprenticeships — SXY's Corporate Club" }] }),
  component: ManagePage,
});

interface ApplicationRow {
  id: string;
  program_id: string;
  applicant_id: string;
  cover_note: string | null;
  resume_path: string | null;
  video_path: string | null;
  portfolio_links: string[];
  structured_answers: StructuredAnswer[];
  status: ApplicationStatus;
  created_at: string;
}

function ManagePage() {
  const { currentUser } = useAuth();
  const qc = useQueryClient();

  const { data } = useQuery({
    queryKey: ["apprenticeship", "owned", currentUser?.id],
    enabled: !!currentUser,
    queryFn: async () => {
      const { data: programs } = await supabase
        .from("apprenticeship_programs")
        .select("*")
        .eq("owner_id", currentUser!.id)
        .order("created_at", { ascending: false });
      const programIds = (programs ?? []).map((p) => p.id);
      const { data: apps } = await supabase
        .from("apprenticeship_applications")
        .select("*")
        .in("program_id", programIds.length ? programIds : ["00000000-0000-0000-0000-000000000000"])
        .order("created_at", { ascending: false });
      const { data: actives } = await supabase
        .from("apprenticeships")
        .select("id, program_id, apprentice_id, status")
        .eq("owner_id", currentUser!.id);
      return {
        programs: (programs ?? []) as unknown as ApprenticeshipProgram[],
        apps: (apps ?? []) as unknown as ApplicationRow[],
        actives: actives ?? [],
      };
    },
  });

  const accept = async (app: ApplicationRow) => {
    const { data: ins, error } = await supabase
      .from("apprenticeships")
      .insert({
        program_id: app.program_id,
        application_id: app.id,
        owner_id: currentUser!.id,
        apprentice_id: app.applicant_id,
      })
      .select("id")
      .single();
    if (error) {
      toast.error(error.message);
      return;
    }
    await supabase
      .from("apprenticeship_applications")
      .update({ status: "accepted", decided_at: new Date().toISOString() })
      .eq("id", app.id);
    toast.success("Apprentice accepted — portal opened");
    qc.invalidateQueries({ queryKey: ["apprenticeship"] });
    void ins;
  };

  const reject = async (app: ApplicationRow) => {
    const { error } = await supabase
      .from("apprenticeship_applications")
      .update({ status: "rejected", decided_at: new Date().toISOString() })
      .eq("id", app.id);
    if (error) toast.error(error.message);
    else {
      toast.success("Application declined");
      qc.invalidateQueries({ queryKey: ["apprenticeship"] });
    }
  };

  const downloadFile = async (path: string) => {
    const { data, error } = await supabase.storage
      .from("apprentice-uploads")
      .createSignedUrl(path, 300);
    if (error) {
      toast.error(error.message);
      return;
    }
    window.open(data.signedUrl, "_blank");
  };

  return (
    <AppLayout
      title="Manage Apprenticeships"
      actions={
        <SxyButton variant="gold" size="sm" asChild>
          <Link to="/apprenticeship/create">+ Post Program</Link>
        </SxyButton>
      }
    >
      <div className="space-y-6">
        {data?.programs.length === 0 && (
          <SxyCard>
            <p className="text-sm text-text-muted">
              You haven't posted any programs yet.
            </p>
          </SxyCard>
        )}

        {data?.programs.map((p) => {
          const apps = data.apps.filter((a) => a.program_id === p.id);
          const active = data.actives.filter((a) => a.program_id === p.id);
          return (
            <SxyCard key={p.id}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-xl text-text-primary">
                    {p.title}
                  </h3>
                  <p className="text-xs text-text-dim">
                    {apps.length} application{apps.length === 1 ? "" : "s"} ·{" "}
                    {active.length} active apprenticeship
                    {active.length === 1 ? "" : "s"}
                  </p>
                </div>
                <SxyButton variant="outline" size="sm" asChild>
                  <Link to="/apprenticeship/$id" params={{ id: p.id }}>
                    View listing
                  </Link>
                </SxyButton>
              </div>

              {active.length > 0 && (
                <div className="mt-4 space-y-2">
                  {active.map((a) => (
                    <div
                      key={a.id}
                      className="flex items-center justify-between rounded-lg border border-border-base/60 bg-charcoal-card px-4 py-3"
                    >
                      <span className="text-sm text-text-primary">
                        Active apprenticeship
                      </span>
                      <SxyButton variant="gold" size="sm" asChild>
                        <Link to="/apprenticeship/portal/$id" params={{ id: a.id }}>
                          Open portal →
                        </Link>
                      </SxyButton>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-4 space-y-3">
                {apps.length === 0 ? (
                  <p className="text-xs text-text-dim">No applications yet.</p>
                ) : (
                  apps.map((app) => (
                    <div
                      key={app.id}
                      className="rounded-lg border border-border-base/60 bg-charcoal-card p-4"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <code className="text-xs text-text-dim">
                          Applicant: {app.applicant_id.slice(0, 8)}…
                        </code>
                        <Tag
                          variant={
                            app.status === "accepted"
                              ? "green"
                              : app.status === "rejected"
                              ? "red"
                              : "gold"
                          }
                        >
                          {applicationStatusLabel(app.status)}
                        </Tag>
                      </div>
                      {app.cover_note && (
                        <p className="mt-3 whitespace-pre-wrap text-sm text-text-muted">
                          {app.cover_note}
                        </p>
                      )}
                      {app.structured_answers.length > 0 && (
                        <div className="mt-3 space-y-2 text-xs text-text-muted">
                          {app.structured_answers.map((a) => {
                            const q = p.structured_questions.find(
                              (qq) => qq.id === a.id,
                            );
                            return (
                              <div key={a.id}>
                                <p className="font-semibold text-text-primary">
                                  {q?.prompt ?? "Question"}
                                </p>
                                <p>{a.answer}</p>
                              </div>
                            );
                          })}
                        </div>
                      )}
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        {app.resume_path && (
                          <SxyButton
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => downloadFile(app.resume_path!)}
                          >
                            Resume
                          </SxyButton>
                        )}
                        {app.video_path && (
                          <SxyButton
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => downloadFile(app.video_path!)}
                          >
                            Video
                          </SxyButton>
                        )}
                        {app.portfolio_links.map((l) => (
                          <a
                            key={l}
                            href={l}
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs text-teal-light underline"
                          >
                            {l}
                          </a>
                        ))}
                      </div>
                      {app.status === "pending" && (
                        <div className="mt-4 flex justify-end gap-2">
                          <SxyButton
                            variant="ghost"
                            size="sm"
                            onClick={() => reject(app)}
                          >
                            Decline
                          </SxyButton>
                          <SxyButton
                            variant="gold"
                            size="sm"
                            onClick={() => accept(app)}
                          >
                            Accept
                          </SxyButton>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </SxyCard>
          );
        })}
      </div>
    </AppLayout>
  );
}
