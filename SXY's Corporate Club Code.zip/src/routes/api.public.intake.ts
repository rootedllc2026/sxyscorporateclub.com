/**
 * Public intake form endpoint — POST /api/public/intake
 *
 * Receives intake submissions from:
 *   - The /intake page on sxyscorporateclub.com (in-app form)
 *   - The legacy sasha-intake.html on sxysinvestors.com (cross-origin POST)
 *
 * No auth required. CORS open so the legacy site can post here directly.
 *
 * Side effects on success:
 *   1. Inserts a row in `intake_submissions`
 *   2. Sends a branded confirmation to the client
 *   3. Notifies admin@ + strategy@sxysinvestors.com
 *
 * Email failures don't roll back the insert — the submission is the
 * source of truth and we'd rather log the email failure than lose a lead.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  sendResendEmail,
  ADMIN_NOTIFICATION_RECIPIENTS,
} from "@/server/email/resend";
import {
  buildIntakeClientConfirmation,
  buildIntakeAdminNotification,
} from "@/server/email/templates";

const SERVICE_INTERESTS = [
  "Strategy Session",
  "Entity Formation",
  "AI Integration",
  "Financial Literacy Workshop",
  "General Inquiry",
] as const;

const intakeSchema = z.object({
  full_name: z.string().trim().min(1).max(120),
  email: z.string().trim().toLowerCase().email().max(255),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  business_name: z.string().trim().max(160).optional().or(z.literal("")),
  service_interest: z.enum(SERVICE_INTERESTS),
  message: z.string().trim().max(4000).optional().or(z.literal("")),
  preferred_contact: z.enum(["email", "phone"]).default("email"),
});

// NOTE: We intentionally do NOT accept any caller-supplied recipient list.
// Earlier versions allowed a `notify_emails` override so the legacy site
// could pass admin addresses, but that turned the endpoint into an open
// email relay (any unauthenticated caller could send branded SXY notification
// emails to arbitrary inboxes). Admin notifications now always go to the
// hardcoded ADMIN_NOTIFICATION_RECIPIENTS list.

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function jsonResponse(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...CORS_HEADERS,
    },
  });
}

export const Route = createFileRoute("/api/public/intake")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS_HEADERS }),

      POST: async ({ request }) => {
        // Accept JSON or classic HTML form posts (the legacy site uses a form)
        let raw: Record<string, unknown> = {};
        const ctype = request.headers.get("content-type") ?? "";
        try {
          if (ctype.includes("application/json")) {
            raw = await request.json();
          } else {
            const fd = await request.formData();
            raw = Object.fromEntries(fd.entries());
          }
        } catch {
          return jsonResponse({ error: "Invalid request body." }, 400);
        }

        const parsed = intakeSchema.safeParse(raw);
        if (!parsed.success) {
          return jsonResponse(
            { error: "Validation failed", details: parsed.error.flatten() },
            400,
          );
        }

        const v = parsed.data;
        const phone = v.phone?.trim() || null;
        const businessName = v.business_name?.trim() || null;
        const message = v.message?.trim() || null;

        const { data: inserted, error } = await supabaseAdmin
          .from("intake_submissions")
          .insert({
            full_name: v.full_name,
            email: v.email,
            phone,
            business_name: businessName,
            service_interest: v.service_interest,
            message,
            preferred_contact: v.preferred_contact,
            status: "new",
          })
          .select("id, submitted_at")
          .single();

        if (error || !inserted) {
          console.error("[intake] insert failed:", error);
          return jsonResponse(
            { error: "Could not save submission. Please try again." },
            500,
          );
        }

        // Fire-and-forget emails. We don't await sequentially; if one fails
        // we still want the other (and the response) to go through.
        const clientEmail = (async () => {
          const { subject, html } = buildIntakeClientConfirmation({
            fullName: v.full_name,
          });
          await sendResendEmail({
            to: v.email,
            subject,
            html,
            tag: "intake-confirmation",
          });
        })().catch((e) =>
          console.warn("[intake] client email failed:", e instanceof Error ? e.message : e),
        );

        const adminRecipients = ADMIN_NOTIFICATION_RECIPIENTS;

        const adminEmail = (async () => {
          const { subject, html } = buildIntakeAdminNotification({
            fullName: v.full_name,
            email: v.email,
            phone,
            businessName,
            serviceInterest: v.service_interest,
            message,
            preferredContact: v.preferred_contact,
            submittedAt: inserted.submitted_at,
          });
          await sendResendEmail({
            to: adminRecipients,
            subject,
            html,
            replyTo: v.email,
            tag: "intake-admin-notification",
          });
        })().catch((e) =>
          console.warn("[intake] admin email failed:", e instanceof Error ? e.message : e),
        );

        await Promise.allSettled([clientEmail, adminEmail]);

        return jsonResponse({ ok: true, id: inserted.id }, 200);
      },
    },
  },
});
