/**
 * /financials — My Overview (member view)
 *
 * Hero balance card · 4 stat tiles · monthly bar chart · revenue donut ·
 * recent transactions table. All data live from Supabase.
 *
 * Admin-only views live under /financials/admin/* and are linked from the
 * FinancialsNav tabs at the top of the page.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { StatTile } from "@/components/sxy/StatTile";
import { Tag } from "@/components/sxy/Tag";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { PayoutRequestModal } from "@/components/financials/PayoutRequestModal";
import { SavedPayoutMethods } from "@/components/financials/SavedPayoutMethods";
import { TransactionDetailModal } from "@/components/financials/TransactionDetailModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  formatDate,
  formatMoney,
  groupByMonth,
  statusTone,
  txnTypeLabel,
  txnTypeTone,
  type PayoutRow,
  type TransactionRow,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/")({
  head: () => ({ meta: [{ title: "My Financials — SXY's Corporate Club" }] }),
  component: FinancialsRoute,
});

function FinancialsRoute() {
  const [payoutOpen, setPayoutOpen] = React.useState(false);
  const [detailTxn, setDetailTxn] = React.useState<TransactionRow | null>(null);
  const { currentUser, userProfile } = useAuth();
  const userId = currentUser?.id;

  const availableBalance = Number(
    (userProfile as unknown as { available_balance?: number })
      ?.available_balance ?? 0,
  );

  const { data: pendingPayouts = 0 } = useQuery({
    queryKey: ["financials", "pendingPayoutsCount", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { count } = await supabase
        .from("payouts")
        .select("id", { count: "exact", head: true })
        .eq("user_id", userId!)
        .in("status", ["pending", "requested", "approved"]);
      return count ?? 0;
    },
  });

  const { data: txns = [] } = useQuery({
    queryKey: ["financials", "txns", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", userId!)
        .order("created_at", { ascending: false });
      return (data ?? []) as TransactionRow[];
    },
  });

  const { data: nextPayout } = useQuery({
    queryKey: ["financials", "nextPayout", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data } = await supabase
        .from("payouts")
        .select("*")
        .eq("user_id", userId!)
        .eq("status", "approved")
        .order("requested_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      return (data ?? null) as PayoutRow | null;
    },
  });

  // Aggregates derived in-memory to avoid extra round-trips.
  const totals = React.useMemo(() => {
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    let totalEarned = 0;
    let totalFees = 0;
    let thisMonthNet = 0;
    let referralAllTime = 0;
    let membershipAllTime = 0;

    for (const t of txns) {
      const gross = Number(t.gross_amount ?? t.amount ?? 0);
      const fee = Number(t.fee_amount ?? 0);
      const net = Number(t.net_amount ?? gross - fee);
      const created = new Date(t.created_at);
      if (t.txn_type === "referral" || t.txn_type === "consulting") {
        totalEarned += gross;
      }
      if (t.txn_type === "fee" || fee > 0) totalFees += fee || gross;
      if (created >= monthStart) thisMonthNet += net;
      if (t.txn_type === "referral") referralAllTime += gross;
      if (t.txn_type === "membership") membershipAllTime += gross;
    }
    return {
      totalEarned,
      totalFees,
      thisMonthNet,
      referralAllTime,
      membershipAllTime,
    };
  }, [txns]);

  const monthly = React.useMemo(() => groupByMonth(txns, 8), [txns]);
  const breakdown = React.useMemo(() => {
    const data = [
      { name: "Referral", value: totals.referralAllTime, color: "var(--teal-mid)" },
      { name: "Consulting", value: txns
          .filter((t) => t.txn_type === "consulting")
          .reduce((s, t) => s + Number(t.gross_amount ?? t.amount ?? 0), 0),
        color: "var(--gold)" },
      { name: "Fees Paid", value: totals.totalFees, color: "var(--red)" },
    ];
    return data.filter((d) => d.value > 0);
  }, [txns, totals]);

  const recent = txns.slice(0, 6);

  return (
    <AppLayout
      title="My Overview"
      actions={
        <div className="flex items-center gap-2">
          <SxyButton variant="outline" size="sm" onClick={() => setPayoutOpen(true)}>
            Payouts ({pendingPayouts})
          </SxyButton>
          <SxyButton variant="gold" size="sm" onClick={() => setPayoutOpen(true)}>
            Request Payout
          </SxyButton>
        </div>
      }
    >
      <div className="space-y-8">
        <FinancialsNav />

        {/* Balance hero */}
        <section
          className="grid gap-px overflow-hidden rounded-2xl border border-border-teal/40 md:grid-cols-3"
          style={{
            backgroundImage:
              "linear-gradient(135deg, var(--teal-deep), var(--charcoal-soft) 75%)",
          }}
        >
          <div className="space-y-3 p-7">
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim">
              Available Balance
            </p>
            <p className="font-editorial text-[38px] leading-none text-gold">
              {formatMoney(availableBalance)}
            </p>
            <SxyButton variant="gold" size="sm" onClick={() => setPayoutOpen(true)}>
              Request Payout
            </SxyButton>
          </div>
          <div className="space-y-3 p-7">
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim">
              Total Earned
            </p>
            <p className="font-editorial text-[38px] leading-none text-text-primary">
              {formatMoney(totals.totalEarned)}
            </p>
            <p className="text-xs text-text-muted">All-time referral + consulting</p>
          </div>
          <div className="space-y-3 p-7">
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim">
              Platform Fees Paid
            </p>
            <p className="font-editorial text-[38px] leading-none text-danger">
              {formatMoney(totals.totalFees)}
            </p>
            <p className="text-xs text-text-muted">All-time platform deductions</p>
          </div>
        </section>

        {/* Stat tiles */}
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatTile label="This Month (net)" value={formatMoney(totals.thisMonthNet)} />
          <StatTile label="Referral Earnings" value={formatMoney(totals.referralAllTime)} />
          <StatTile
            label="Membership Paid"
            value={`− ${formatMoney(totals.membershipAllTime)}`}
          />
          <StatTile
            label="Next Payout Est"
            value={
              nextPayout
                ? formatDate(nextPayout.requested_at)
                : "—"
            }
            delta={nextPayout ? formatMoney(nextPayout.amount) : undefined}
            deltaTone="up"
          />
        </section>

        {/* Charts */}
        <section className="grid gap-6 lg:grid-cols-2">
          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Monthly earnings
            </h2>
            <div className="mt-4 h-72 w-full">
              <ResponsiveContainer>
                <BarChart data={monthly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)" />
                  <XAxis dataKey="month" tick={{ fill: "#a0c4cc", fontSize: 11 }} />
                  <YAxis tick={{ fill: "#a0c4cc", fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{
                      background: "#111",
                      border: "1px solid oklch(1 0 0 / 0.1)",
                      borderRadius: 8,
                      color: "#eee",
                    }}
                  />
                  <Legend wrapperStyle={{ color: "#a0c4cc", fontSize: 11 }} />
                  <Bar dataKey="referral" stackId="a" fill="var(--teal-mid)" name="Referral" />
                  <Bar dataKey="consulting" stackId="a" fill="var(--gold)" name="Consulting" />
                  <Bar dataKey="fees" stackId="a" fill="var(--red)" name="Fees" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </SxyCard>
          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Revenue breakdown
            </h2>
            <div className="mt-4 h-72 w-full">
              {breakdown.length === 0 ? (
                <div className="grid h-full place-items-center text-sm text-text-dim">
                  No transactions yet.
                </div>
              ) : (
                <ResponsiveContainer>
                  <PieChart>
                    <Pie
                      data={breakdown}
                      dataKey="value"
                      innerRadius={60}
                      outerRadius={95}
                      paddingAngle={3}
                    >
                      {breakdown.map((entry, idx) => (
                        <Cell key={idx} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: "#111",
                        border: "1px solid oklch(1 0 0 / 0.1)",
                        borderRadius: 8,
                        color: "#eee",
                      }}
                      formatter={(value: number) => formatMoney(value)}
                    />
                    <Legend wrapperStyle={{ color: "#a0c4cc", fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </SxyCard>
        </section>

        {/* Recent transactions */}
        <SxyCard accent>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg text-teal-light">
              Recent transactions
            </h2>
            <Tag variant="gray">Last 6</Tag>
          </div>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[10px] uppercase tracking-wider text-text-dim">
                <tr className="border-b border-border-base/40">
                  <th className="py-2 text-left font-semibold">Date</th>
                  <th className="py-2 text-left font-semibold">Description</th>
                  <th className="py-2 text-left font-semibold">Type</th>
                  <th className="py-2 text-right font-semibold">Amount</th>
                  <th className="py-2 text-left font-semibold">Status</th>
                  <th className="py-2 text-right font-semibold"></th>
                </tr>
              </thead>
              <tbody>
                {recent.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-text-dim">
                      No transactions yet.
                    </td>
                  </tr>
                ) : (
                  recent.map((t) => {
                    const net = Number(
                      t.net_amount ??
                        Number(t.gross_amount ?? t.amount ?? 0) -
                          Number(t.fee_amount ?? 0),
                    );
                    const isNeg =
                      t.txn_type === "fee" ||
                      t.txn_type === "membership" ||
                      net < 0;
                    return (
                      <tr
                        key={t.id}
                        className="border-b border-border-base/30 last:border-0"
                      >
                        <td className="py-3 text-text-muted">
                          {formatDate(t.created_at)}
                        </td>
                        <td className="py-3 text-text-primary">
                          {t.description ?? "—"}
                        </td>
                        <td className="py-3">
                          <Tag variant={txnTypeTone(t.txn_type)}>
                            {txnTypeLabel(t.txn_type)}
                          </Tag>
                        </td>
                        <td
                          className={`py-3 text-right font-semibold ${
                            isNeg ? "text-danger" : "text-success"
                          }`}
                        >
                          {isNeg ? "−" : "+"}
                          {formatMoney(Math.abs(net))}
                        </td>
                        <td className="py-3">
                          <Tag variant={statusTone(t.status)}>{t.status}</Tag>
                        </td>
                        <td className="py-3 text-right">
                          <SxyButton
                            variant="ghost"
                            size="sm"
                            onClick={() => setDetailTxn(t)}
                          >
                            View
                          </SxyButton>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </SxyCard>

        <SavedPayoutMethods />
      </div>

      <PayoutRequestModal
        open={payoutOpen}
        onOpenChange={setPayoutOpen}
        availableBalance={availableBalance}
      />
      <TransactionDetailModal
        txn={detailTxn}
        onClose={() => setDetailTxn(null)}
      />
    </AppLayout>
  );
}
