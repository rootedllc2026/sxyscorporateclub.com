import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type MembershipTier } from "@/integrations/supabase/AuthContext";
import { AuthShell, AuthError, AuthSuccess } from "@/components/auth/AuthShell";
import {
  AuthInput,
  AuthSelect,
  Field,
} from "@/components/auth/AuthInput";
import { SxyButton } from "@/components/sxy/SxyButton";
import { sendEmail } from "@/lib/email/send";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Sign Up — SXY's Corporate Club" },
      {
        name: "description",
        content:
          "Create your SXY's Corporate Club account. Connect with entrepreneurs, bid on projects, grow your business.",
      },
    ],
  }),
  component: SignupPage,
});

const STATES = [
  { value: "PA", label: "Pennsylvania" },
  { value: "NJ", label: "New Jersey" },
  { value: "GA", label: "Georgia" },
  { value: "Virtual", label: "Virtual (nationwide)" },
  { value: "Other", label: "Other" },
];

const TIERS: Array<{
  id: MembershipTier;
  name: string;
  price: string;
  blurb: string;
}> = [
  {
    id: "free",
    name: "Free Member",
    price: "$0",
    blurb: "Community access + Business Bites + browse projects",
  },
  {
    id: "paid",
    name: "Investing Member",
    price: "$9/month",
    blurb: "Everything free + referral portal + submit bids",
  },
  {
    id: "annual",
    name: "Annual Member",
    price: "$89/year",
    blurb: "Same as Investing — best value yearly plan",
  },
  {
    id: "vip",
    name: "VIP",
    price: "$49/month",
    blurb: "All features + Economy Bites VIP + deal flow + inner circle",
  },
];

const signupSchema = z.object({
  full_name: z.string().trim().min(2, "Please enter your full name").max(120),
  email: z.string().trim().email("Enter a valid email").max(255),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .max(128),
  state: z.enum(["PA", "NJ", "GA", "Virtual", "Other"], {
    errorMap: () => ({ message: "Pick your region" }),
  }),
  tier: z.enum(["free", "paid", "annual", "vip"]),
});

function SignupPage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [tier, setTier] = React.useState<MembershipTier>("free");
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [success, setSuccess] = React.useState<string | null>(null);

  // Already logged in? Bounce to dashboard.
  React.useEffect(() => {
    if (isAuthenticated) void navigate({ to: "/dashboard" });
  }, [isAuthenticated, navigate]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const fd = new FormData(e.currentTarget);
    const parsed = signupSchema.safeParse({
      full_name: fd.get("full_name"),
      email: fd.get("email"),
      password: fd.get("password"),
      state: fd.get("state"),
      tier,
    });

    if (!parsed.success) {
      setError(parsed.error.errors[0]?.message ?? "Invalid input");
      return;
    }

    setSubmitting(true);
    try {
      // emailRedirectTo so the email-confirmation link comes back to our app.
      // Production → sxysinvestors.com. Preview → the lovable preview URL.
      // Any other origin (custom previews, localhost) falls back to its own origin.
      const PROD_CALLBACK = "https://sxysinvestors.com/auth/callback";
      const PREVIEW_CALLBACK =
        "https://id-preview--56254af5-2e92-4fe6-af18-7b725325f934.lovable.app/auth/callback";
      let redirectTo: string | undefined;
      if (typeof window !== "undefined") {
        const host = window.location.hostname;
        if (host === "sxysinvestors.com" || host === "www.sxysinvestors.com") {
          redirectTo = PROD_CALLBACK;
        } else if (
          host === "id-preview--56254af5-2e92-4fe6-af18-7b725325f934.lovable.app"
        ) {
          redirectTo = PREVIEW_CALLBACK;
        } else {
          redirectTo = `${window.location.origin}/auth/callback`;
        }
      }

      const { data, error: signUpError } = await supabase.auth.signUp({
        email: parsed.data.email,
        password: parsed.data.password,
        options: {
          emailRedirectTo: redirectTo,
          // The handle_new_user() trigger reads these and inserts the profile.
          data: {
            full_name: parsed.data.full_name,
            state: parsed.data.state,
            tier: parsed.data.tier,
          },
        },
      });

      if (signUpError) {
        // Friendlier copy for the most common case.
        if (
          signUpError.message.toLowerCase().includes("already registered") ||
          signUpError.message.toLowerCase().includes("user already")
        ) {
          setError(
            "An account with that email already exists. Try signing in instead.",
          );
        } else {
          setError(signUpError.message);
        }
        return;
      }

      // If email confirmation is required, the session is null.
      if (!data.session) {
        setSuccess(
          "Check your email for a confirmation link to finish setting up your account.",
        );
        return;
      }

      // Logged in immediately. Fire welcome email (best-effort, async) and route by tier.
      void sendEmail({
        kind: "membership-welcome",
        to: parsed.data.email,
        fullName: parsed.data.full_name,
        tier: parsed.data.tier,
      });
      try {
        if (typeof window !== "undefined") {
          window.localStorage.setItem(
            `sxy-welcome-${data.user?.id ?? parsed.data.email}`,
            "1",
          );
        }
      } catch {}

      if (parsed.data.tier === "free") {
        toast.success("Welcome to the club!");
        await navigate({ to: "/dashboard" });
      } else {
        await navigate({
          to: "/checkout",
          search: { tier: parsed.data.tier },
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthShell
      title="Join the Club"
      subtitle="Connect. Bid. Grow. Build."
      wide
      footer={
        <>
          Already a member?{" "}
          <Link to="/login" className="text-gold hover:text-gold-light">
            Sign in
          </Link>
        </>
      }
    >
      <form onSubmit={onSubmit} className="space-y-5" noValidate>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Full name" htmlFor="full_name">
            <AuthInput
              id="full_name"
              name="full_name"
              type="text"
              autoComplete="name"
              required
              placeholder="Jane Builder"
            />
          </Field>
          <Field label="Email address" htmlFor="email">
            <AuthInput
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              placeholder="you@business.com"
            />
          </Field>
          <Field label="Password" htmlFor="password" hint="Minimum 8 characters">
            <AuthInput
              id="password"
              name="password"
              type="password"
              autoComplete="new-password"
              minLength={8}
              required
              placeholder="••••••••"
            />
          </Field>
          <Field label="Region" htmlFor="state">
            <AuthSelect id="state" name="state" required defaultValue="">
              <option value="" disabled>
                Choose your state
              </option>
              {STATES.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </AuthSelect>
          </Field>
        </div>

        {/* Tier selector */}
        <div className="space-y-3 pt-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
            Choose your membership
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            {TIERS.map((t) => {
              const selected = tier === t.id;
              return (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => setTier(t.id)}
                  aria-pressed={selected}
                  className={cn(
                    "group relative rounded-2xl border p-4 text-left transition",
                    selected
                      ? "border-gold bg-gold/5"
                      : "border-border-base bg-charcoal hover:border-border-teal",
                  )}
                  style={
                    selected
                      ? {
                          boxShadow:
                            "0 0 0 1px var(--gold), 0 8px 24px oklch(0.74 0.115 85 / 0.18)",
                        }
                      : undefined
                  }
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span
                      className={cn(
                        "font-editorial text-lg",
                        selected ? "text-gold-light" : "text-text-primary",
                      )}
                    >
                      {t.name}
                    </span>
                    <span
                      className={cn(
                        "text-sm font-semibold",
                        selected ? "text-gold" : "text-teal-light",
                      )}
                    >
                      {t.price}
                    </span>
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-text-muted">
                    {t.blurb}
                  </p>
                  {selected && (
                    <div className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-charcoal">
                      <svg
                        viewBox="0 0 20 20"
                        fill="currentColor"
                        className="h-3 w-3"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.704 5.296a1 1 0 010 1.414l-7.5 7.5a1 1 0 01-1.414 0l-3.5-3.5a1 1 0 111.414-1.414L8.5 12.086l6.79-6.79a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <AuthError message={error} />
        <AuthSuccess message={success} />

        <SxyButton
          type="submit"
          variant="gold"
          size="lg"
          disabled={submitting}
          className="w-full"
        >
          {submitting ? "Creating your account…" : "Create My Account"}
        </SxyButton>

        <p className="text-center text-xs text-text-dim">
          By creating an account, you agree to the SXY's Corporate Club terms
          and acknowledge our privacy policy.
        </p>
      </form>
    </AuthShell>
  );
}
