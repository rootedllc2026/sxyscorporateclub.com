import * as React from "react";
import {
  createFileRoute,
  Link,
  useNavigate,
  notFound,
} from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { TierGate } from "@/components/sxy/TierGate";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { cn } from "@/lib/utils";
import {
  BID_CURRENCY,
  categoryEmoji,
  categoryLabel,
  formatBudget,
  statusLabel,
  statusTagVariant,
} from "@/lib/bidding/shared";

export const Route = createFileRoute("/bidding/$id/propose")({
  head: () => ({ meta: [{ title: "Submit Proposal — SXY's Corporate Club" }] }),
  component: ProposePage,
  errorComponent: ({ error }) => (
    <AppLayout title="Submit proposal">
      <SxyCard accent>
        <p className="text-sm text-text-muted">{error.message}</p>
      </SxyCard>
    </AppLayout>
  ),
});

type ProposalState = {
  proposed_price: string;
  timeline: string;
  cover_letter: string;
  years_experience: string;
  available_from: string;
  portfolio_url: string;
  proposalFiles: File[];
  certificationFiles: File[];
};

const STEPS = [
  { id: 1, label: "Project" },
  { id: 2, label: "Bid Info" },
  { id: 3, label: "Documents" },
  { id: 4, label: "Review" },
] as const;

const proposalSchema = z.object({
  proposed_price: z
    .number({ invalid_type_error: "Enter your proposed price" })
    .positive("Price must be greater than 0")
    .max(10_000_000),
  timeline: z.string().trim().min(2, "Add a timeline").max(120),
  cover_letter: z.string().trim().min(40, "Cover letter must be at least 40 characters").max(4000),
  years_experience: z.string().trim().min(1, "Pick your experience"),
  available_from: z.string().min(1, "Pick an availability date"),
  portfolio_url: z
    .string()
    .trim()
    .max(255)
    .optional()
    .or(z.literal(""))
    .refine(
      (v) => !v || /^https?:\/\//i.test(v),
      "Must start with http:// or https://",
    ),
});

function ProposePage() {
  const { id } = Route.useParams();
  return (
    <AppLayout title="Submit Proposal">
      <TierGate feature="Club Market">
        <ProposeContent projectId={id} />
      </TierGate>
    </AppLayout>
  );
}

function ProposeContent({ projectId }: { projectId: string }) {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [step, setStep] = React.useState(1);
  const [submitting, setSubmitting] = React.useState(false);
  const [state, setState] = React.useState<ProposalState>({
    proposed_price: "",
    timeline: "",
    cover_letter: "",
    years_experience: "",
    available_from: "",
    portfolio_url: "",
    proposalFiles: [],
    certificationFiles: [],
  });

  const { data: project, isLoading } = useQuery({
    queryKey: ["bidding", "project", projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select("*")
        .eq("id", projectId)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw notFound();
      return data;
    },
  });

  // Block double-submission if a bid already exists for this user/project.
  const { data: existingBid } = useQuery({
    queryKey: ["bidding", "existing-bid", projectId, currentUser?.id],
    enabled: !!currentUser,
    queryFn: async () => {
      const { data } = await supabase
        .from("bids")
        .select("id")
        .eq("project_id", projectId)
        .eq("bidder_id", currentUser!.id)
        .maybeSingle();
      return data;
    },
  });

  const update = <K extends keyof ProposalState>(
    key: K,
    value: ProposalState[K],
  ) => setState((prev) => ({ ...prev, [key]: value }));

  function validateStep2(): string | null {
    const parsed = proposalSchema.safeParse({
      proposed_price: Number(state.proposed_price),
      timeline: state.timeline,
      cover_letter: state.cover_letter,
      years_experience: state.years_experience,
      available_from: state.available_from,
      portfolio_url: state.portfolio_url,
    });
    if (!parsed.success) return parsed.error.errors[0]?.message ?? "Invalid input";
    return null;
  }

  async function handleSubmit() {
    if (!currentUser) {
      toast.error("Please sign in first");
      return;
    }
    const err = validateStep2();
    if (err) {
      toast.error(err);
      setStep(2);
      return;
    }
    setSubmitting(true);
    try {
      // 1. Upload any documents to Storage under {project_id}/{user_id}/.
      const uploadedPaths: string[] = [];
      const allFiles = [
        ...state.proposalFiles.map((f) => ({ kind: "proposal", file: f })),
        ...state.certificationFiles.map((f) => ({ kind: "cert", file: f })),
      ];
      for (const { kind, file } of allFiles) {
        const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        const path = `${projectId}/${currentUser.id}/${kind}-${Date.now()}-${safeName}`;
        const { error: upErr } = await supabase.storage
          .from("bid-documents")
          .upload(path, file, { upsert: false });
        if (upErr) throw upErr;
        uploadedPaths.push(path);
      }

      // 2. Insert the bid row.
      const proposedPrice = Number(state.proposed_price);
      const { error: insErr } = await supabase.from("bids").insert({
        project_id: projectId,
        bidder_id: currentUser.id,
        amount: proposedPrice,
        proposed_price: proposedPrice,
        timeline: state.timeline.trim(),
        cover_letter: state.cover_letter.trim(),
        years_experience: state.years_experience,
        available_from: state.available_from || null,
        portfolio_url: state.portfolio_url.trim() || null,
        documents: uploadedPaths,
        proposal: state.cover_letter.trim(),
        status: "submitted",
      });
      if (insErr) {
        if (insErr.code === "23505") {
          toast.error("You've already submitted a bid on this project.");
          await navigate({ to: "/bidding/my-bids" });
          return;
        }
        throw insErr;
      }

      toast.success("Proposal submitted! We'll let you know when there's an update.");
      await navigate({ to: "/bidding/my-bids" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't submit proposal");
    } finally {
      setSubmitting(false);
    }
  }

  if (isLoading || !project) {
    return (
      <SxyCard>
        <p className="text-sm text-text-muted">Loading project…</p>
      </SxyCard>
    );
  }

  if (existingBid) {
    return (
      <SxyCard accent>
        <h2 className="font-display text-xl text-teal-light">
          You've already bid
        </h2>
        <p className="mt-2 text-sm text-text-muted">
          You can review your submission from My Bids.
        </p>
        <div className="mt-5">
          <SxyButton variant="primary" size="sm" asChild>
            <Link to="/bidding/my-bids">View my bids</Link>
          </SxyButton>
        </div>
      </SxyCard>
    );
  }

  return (
    <div className="space-y-6">
      {/* Step indicator */}
      <ol className="flex flex-wrap items-center gap-2">
        {STEPS.map((s, idx) => (
          <li key={s.id} className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setStep(s.id)}
              className={cn(
                "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition",
                step === s.id
                  ? "border-gold bg-[color:var(--gold-glow)] text-gold-light"
                  : step > s.id
                  ? "border-border-teal bg-[color:var(--teal-glow)] text-teal-light"
                  : "border-border-base/60 bg-charcoal-card text-text-muted",
              )}
            >
              <span className="grid h-5 w-5 place-items-center rounded-full bg-charcoal text-[10px]">
                {step > s.id ? "✓" : s.id}
              </span>
              {s.label}
            </button>
            {idx < STEPS.length - 1 ? (
              <span aria-hidden className="text-text-dim">
                ─
              </span>
            ) : null}
          </li>
        ))}
      </ol>

      {step === 1 ? (
        <Step1Project project={project} />
      ) : step === 2 ? (
        <Step2BidInfo state={state} update={update} />
      ) : step === 3 ? (
        <Step3Documents state={state} update={update} />
      ) : (
        <Step4Review project={project} state={state} />
      )}

      {/* Footer */}
      <div className="flex items-center justify-between gap-3">
        <SxyButton
          variant="ghost"
          size="default"
          disabled={step === 1}
          onClick={() => setStep((s) => Math.max(1, s - 1))}
        >
          ← Back
        </SxyButton>
        {step < 4 ? (
          <SxyButton
            variant="primary"
            size="default"
            onClick={() => {
              if (step === 2) {
                const err = validateStep2();
                if (err) {
                  toast.error(err);
                  return;
                }
              }
              setStep((s) => Math.min(4, s + 1));
            }}
          >
            Continue →
          </SxyButton>
        ) : (
          <SxyButton
            variant="gold"
            size="default"
            disabled={submitting}
            onClick={handleSubmit}
          >
            {submitting ? "Submitting…" : "Submit Proposal"}
          </SxyButton>
        )}
      </div>
    </div>
  );
}

// ────────────────────────────── Step 1 ────────────────────────────────────
function Step1Project({ project }: { project: any }) {
  return (
    <SxyCard accent>
      <p className="sxy-section-label">Step 1 · Confirm project</p>
      <div className="mt-3 flex items-start gap-4">
        <span aria-hidden className="text-3xl">
          {categoryEmoji(project.category)}
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="font-display text-2xl text-text-primary">
            {project.title}
          </h2>
          <div className="mt-2 flex flex-wrap gap-2">
            <Tag variant={statusTagVariant(project.status)}>
              {statusLabel(project.status)}
            </Tag>
            <Tag variant="gray">{categoryLabel(project.category)}</Tag>
          </div>
          {project.summary || project.description ? (
            <p className="mt-3 text-sm text-text-muted">
              {project.summary ?? project.description}
            </p>
          ) : null}
        </div>
        <div className="text-right">
          <p className="text-[10px] uppercase tracking-[0.18em] text-text-dim">
            Budget
          </p>
          <p className="font-editorial text-2xl text-gold">
            {formatBudget(project.budget, project.budget_min, project.budget_max)}
          </p>
        </div>
      </div>
    </SxyCard>
  );
}

// ────────────────────────────── Step 2 ────────────────────────────────────
function Step2BidInfo({
  state,
  update,
}: {
  state: ProposalState;
  update: <K extends keyof ProposalState>(k: K, v: ProposalState[K]) => void;
}) {
  return (
    <SxyCard accent>
      <p className="sxy-section-label">Step 2 · Bid details</p>
      <div className="mt-4 grid gap-5 md:grid-cols-2">
        <FormField label="Proposed price (USD)">
          <input
            type="number"
            inputMode="decimal"
            min="0"
            step="100"
            value={state.proposed_price}
            onChange={(e) => update("proposed_price", e.target.value)}
            placeholder="5000"
            className={inputCls}
          />
        </FormField>
        <FormField label="Timeline">
          <input
            type="text"
            value={state.timeline}
            onChange={(e) => update("timeline", e.target.value)}
            placeholder="e.g. 4 weeks"
            className={inputCls}
            maxLength={120}
          />
        </FormField>
        <FormField label="Years of experience">
          <select
            value={state.years_experience}
            onChange={(e) => update("years_experience", e.target.value)}
            className={inputCls}
          >
            <option value="">Select…</option>
            <option value="0-2">0–2 years</option>
            <option value="3-5">3–5 years</option>
            <option value="6-10">6–10 years</option>
            <option value="10+">10+ years</option>
          </select>
        </FormField>
        <FormField label="Available from">
          <input
            type="date"
            value={state.available_from}
            onChange={(e) => update("available_from", e.target.value)}
            className={inputCls}
          />
        </FormField>
        <FormField label="Portfolio URL (optional)" className="md:col-span-2">
          <input
            type="url"
            value={state.portfolio_url}
            onChange={(e) => update("portfolio_url", e.target.value)}
            placeholder="https://your-portfolio.com"
            className={inputCls}
            maxLength={255}
          />
        </FormField>
        <FormField label="Cover letter" className="md:col-span-2">
          <textarea
            value={state.cover_letter}
            onChange={(e) => update("cover_letter", e.target.value)}
            placeholder="Why are you the right fit? What's your approach?"
            rows={6}
            maxLength={4000}
            className={cn(inputCls, "resize-y leading-relaxed")}
          />
          <p className="mt-1 text-right text-[10px] text-text-dim">
            {state.cover_letter.length}/4000
          </p>
        </FormField>
      </div>
    </SxyCard>
  );
}

// ────────────────────────────── Step 3 ────────────────────────────────────
function Step3Documents({
  state,
  update,
}: {
  state: ProposalState;
  update: <K extends keyof ProposalState>(k: K, v: ProposalState[K]) => void;
}) {
  return (
    <SxyCard accent>
      <p className="sxy-section-label">Step 3 · Documents (optional)</p>
      <div className="mt-4 grid gap-5 md:grid-cols-2">
        <FileDrop
          label="Proposal PDF"
          accept="application/pdf"
          files={state.proposalFiles}
          onChange={(files) => update("proposalFiles", files)}
          hint="Detailed proposal, scope, or pricing breakdown"
        />
        <FileDrop
          label="Certifications"
          accept="application/pdf,image/*"
          files={state.certificationFiles}
          onChange={(files) => update("certificationFiles", files)}
          hint="Licenses, insurance, or relevant credentials"
        />
      </div>
      <p className="mt-4 text-xs text-text-dim">
        Files upload securely on submit. Only you and project admins can read them.
      </p>
    </SxyCard>
  );
}

function FileDrop({
  label,
  accept,
  files,
  onChange,
  hint,
}: {
  label: string;
  accept: string;
  files: File[];
  onChange: (files: File[]) => void;
  hint: string;
}) {
  const inputRef = React.useRef<HTMLInputElement>(null);
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
        {label}
      </p>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="mt-2 flex w-full flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-border-teal/60 bg-charcoal-card px-4 py-6 text-center text-sm text-text-muted transition hover:border-teal-mid hover:text-text-primary"
      >
        <span aria-hidden className="text-2xl">📎</span>
        <span>Click to upload</span>
        <span className="text-[10px] text-text-dim">{hint}</span>
      </button>
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple
        className="hidden"
        onChange={(e) => {
          const list = e.target.files;
          if (!list) return;
          onChange([...files, ...Array.from(list)]);
          e.target.value = "";
        }}
      />
      {files.length > 0 ? (
        <ul className="mt-3 space-y-1.5 text-xs">
          {files.map((f, i) => (
            <li
              key={`${f.name}-${i}`}
              className="flex items-center justify-between rounded-md border border-border-base/60 bg-charcoal-card-2 px-3 py-1.5"
            >
              <span className="truncate text-text-primary">{f.name}</span>
              <button
                type="button"
                onClick={() => onChange(files.filter((_, idx) => idx !== i))}
                className="ml-2 text-text-dim hover:text-danger"
                aria-label={`Remove ${f.name}`}
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

// ────────────────────────────── Step 4 ────────────────────────────────────
function Step4Review({
  project,
  state,
}: {
  project: any;
  state: ProposalState;
}) {
  const priceNum = Number(state.proposed_price);
  return (
    <div className="space-y-5">
      <SxyCard accent>
        <p className="sxy-section-label">Step 4 · Review &amp; confirm</p>
        <h2 className="mt-2 font-display text-xl text-text-primary">
          {project.title}
        </h2>
        <dl className="mt-5 grid gap-4 md:grid-cols-2">
          <ReviewRow label="Proposed price">
            {priceNum > 0 ? BID_CURRENCY.format(priceNum) : "—"}
          </ReviewRow>
          <ReviewRow label="Timeline">{state.timeline || "—"}</ReviewRow>
          <ReviewRow label="Years of experience">
            {state.years_experience || "—"}
          </ReviewRow>
          <ReviewRow label="Available from">
            {state.available_from || "—"}
          </ReviewRow>
          <ReviewRow label="Portfolio" className="md:col-span-2">
            {state.portfolio_url ? (
              <a
                href={state.portfolio_url}
                target="_blank"
                rel="noreferrer noopener"
                className="text-teal-light underline"
              >
                {state.portfolio_url}
              </a>
            ) : (
              "—"
            )}
          </ReviewRow>
          <ReviewRow label="Cover letter" className="md:col-span-2">
            <p className="whitespace-pre-line text-sm text-text-primary">
              {state.cover_letter || "—"}
            </p>
          </ReviewRow>
          <ReviewRow label="Attachments" className="md:col-span-2">
            {state.proposalFiles.length + state.certificationFiles.length === 0
              ? "None"
              : [...state.proposalFiles, ...state.certificationFiles]
                  .map((f) => f.name)
                  .join(", ")}
          </ReviewRow>
        </dl>
      </SxyCard>
      <SxyCard className="border-border-gold/50">
        <p className="text-xs leading-relaxed text-text-muted">
          <strong className="text-gold-light">Binding submission:</strong>{" "}
          By clicking Submit, you certify the information above is accurate,
          your proposal is valid for 30 days, and you can deliver as outlined.
          The project owner may shortlist or award this bid at their discretion.
        </p>
      </SxyCard>
    </div>
  );
}

function ReviewRow({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <dt className="text-[10px] uppercase tracking-[0.18em] text-text-dim">
        {label}
      </dt>
      <dd className="mt-1 text-sm text-text-primary">{children}</dd>
    </div>
  );
}

// ─────────────────────── Shared form primitives ──────────────────────────
const inputCls =
  "w-full rounded-lg border border-border-base/60 bg-charcoal-card px-3 py-2 text-sm text-text-primary placeholder:text-text-dim focus:border-border-teal focus:outline-none";

function FormField({
  label,
  className,
  children,
}: {
  label: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <label className={cn("flex flex-col gap-1.5", className)}>
      <span className="text-xs font-semibold uppercase tracking-wider text-text-muted">
        {label}
      </span>
      {children}
    </label>
  );
}
