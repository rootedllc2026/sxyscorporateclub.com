/**
 * /economy-bites/$id/edit — admin form to edit an existing video.
 *
 * Loads the row via Supabase and reuses VideoForm in edit mode.
 */
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { EconomyBitesNav } from "@/components/videos/EconomyBitesNav";
import { VideoForm } from "@/components/videos/VideoForm";
import { supabase } from "@/integrations/supabase/client";
import type { VideoRow } from "@/lib/videos/shared";

export const Route = createFileRoute("/economy-bites/$id/edit")({
  head: () => ({ meta: [{ title: "Edit Video — SXY's Corporate Club" }] }),
  component: () => (
    <AdminRoute>
      <AppLayout title="Edit Content">
        <EditPage />
      </AppLayout>
    </AdminRoute>
  ),
});

function EditPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { data: video, isLoading } = useQuery({
    queryKey: ["video", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as VideoRow | null;
    },
  });

  async function onDelete() {
    if (!video) return;
    const ok = window.confirm(
      `Delete "${video.title}"? This permanently removes the video, saves, and progress for all members.`,
    );
    if (!ok) return;
    const { error } = await supabase.from("videos").delete().eq("id", video.id);
    if (error) {
      window.alert(`Delete failed: ${error.message}`);
      return;
    }
    navigate({ to: "/economy-bites" });
  }

  return (
    <div className="space-y-6">
      <EconomyBitesNav />

      {isLoading ? (
        <p className="text-sm text-text-muted">Loading video…</p>
      ) : !video ? (
        <SxyCard className="text-center text-sm text-text-muted">
          Video not found.{" "}
          <Link to="/economy-bites" className="text-teal-light underline">
            Back to library
          </Link>
        </SxyCard>
      ) : (
        <>
          <SxyCard accent>
            <VideoForm initial={video} />
          </SxyCard>

          <SxyCard className="space-y-3 border-[oklch(0.72_0.18_25/0.35)]">
            <div>
              <h2 className="font-display text-base text-danger">Danger zone</h2>
              <p className="text-xs text-text-dim">
                Permanently delete this video and all related saves and progress.
              </p>
            </div>
            <div>
              <SxyButton
                type="button"
                variant="outline"
                size="sm"
                onClick={onDelete}
              >
                Delete video
              </SxyButton>
            </div>
          </SxyCard>
        </>
      )}
    </div>
  );
}
