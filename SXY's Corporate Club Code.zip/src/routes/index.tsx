import { createFileRoute } from "@tanstack/react-router";
import { Tag, SxyButton } from "@/components/sxy";
import logo from "@/assets/logo.png";
import sashaAvatar from "@/assets/sasha-avatar.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SXY's Corporate Club" },
      {
        name: "description",
        content:
          "Foundational design tokens and components for SXY's Corporate Club member portal.",
      },
    ],
  }),
  component: DesignSystemPage,
});

function DesignSystemPage() {
  return (
    <main className="min-h-screen bg-charcoal text-text-primary">
      {/* Top brand bar */}
      <header className="sticky top-0 z-50 border-b border-border bg-charcoal-soft/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-7 py-3">
          <div className="flex items-center gap-3">
            <img src={logo} alt="SXY's Corporate Club" className="h-9 w-9 rounded-md object-cover" />
            <div className="leading-tight">
              <p className="font-display text-[20px] text-gold">
                SXY's Corporate Club
              </p>
              <p className="text-[9px] uppercase tracking-[0.2em] text-teal-mid">
                Design System · v1
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Tag variant="gold">Foundation Ready</Tag>
            <a
              href="/kiddos/hub"
              className="hidden sm:inline-flex items-center gap-1 rounded-full border border-teal-mid/50 bg-[color:var(--teal-glow)] px-3 py-1.5 text-xs font-semibold text-teal-light hover:bg-teal-mid/20"
            >
              🧒 Kiddos App
            </a>
            <a href="/login" className="text-xs font-semibold text-text-muted hover:text-teal-light">
              Sign in
            </a>
            <a
              href="/signup"
              className="rounded-full border border-gold/40 bg-gold/10 px-3 py-1.5 text-xs font-semibold text-gold-light hover:bg-gold/20"
            >
              Join the Club
            </a>
          </div>
        </div>
      </header>


      {/* Hero / brand intro */}
      <section className="sxy-hero-bg relative overflow-hidden border-b border-border">
        <div className="pointer-events-none absolute -right-24 -top-24 h-[600px] w-[600px] rounded-full border border-[color:var(--border-gold)]" />
        <div className="pointer-events-none absolute -bottom-20 left-1/3 h-[400px] w-[400px] rounded-full border border-[color:var(--border-teal)]" />

        <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-7 py-20 md:grid-cols-[1fr_360px]">
          <div>
            <span className="sxy-eyebrow">The Premier Business Club</span>
            <h1 className="sxy-display mt-5 text-[clamp(2.6rem,5vw,4rem)]">
              Your Business,
              <br />
              <em>Guided</em> &amp; Protected.
            </h1>
            <p className="sxy-sub mt-5 max-w-xl">
              A virtual business marketplace and resource hub for entrepreneurs
              and professionals.
            </p>

            <div className="mt-7 flex flex-wrap gap-2">
              {[
                "Entity Formation",
                "AI Integration",
                "Content Management",
                "Market Analysis",
                "Marketing Services",
                "General Strategy",
                "Restructuring",
                "Wealth Management",
              ].map((p) => (
                <span key={p} className="sxy-pill">
                  {p}
                </span>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <SxyButton variant="primary">Book Free Call — It&apos;s Free</SxyButton>
              <SxyButton variant="gold">Marketing Services</SxyButton>
              <a href="/referrals">
                <SxyButton variant="outline">
                  Book a Strategy Session
                </SxyButton>
              </a>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[340px]">
            <div className="absolute inset-0 -z-10 rounded-[40%_40%_50%_50%/20%_20%_70%_70%] bg-gradient-to-b from-[color:var(--teal-glow)] to-[color:var(--teal-pale)] blur-md" />
            <div className="overflow-hidden rounded-[24px] border-2 border-[color:var(--border-gold)] shadow-[0_24px_60px_oklch(0.55_0.085_210/0.3)]">
              <img src={sashaAvatar} alt="Sasha — Your guide" className="block w-full" />
            </div>
            <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-[image:var(--gradient-gold)] px-5 py-1.5 font-display text-sm font-bold text-text-primary shadow-[var(--shadow-gold)]">
              ✦ Sasha — Your Guide
            </div>
          </div>
        </div>
      </section>

      <footer className="mx-auto max-w-6xl border-t border-border px-7 pt-8 pb-6 text-center">
        <p className="font-display text-lg text-gold">SXY's Corporate Club</p>
        <p className="mt-1 text-[10px] uppercase tracking-[0.25em] text-text-dim">
          SXY's Economic Roots LLC
        </p>
      </footer>
    </main>
  );
}

function Section({
  eyebrow,
  title,
  children,
}: {
  eyebrow: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <p className="sxy-section-label">{eyebrow}</p>
      <h2 className="sxy-section-title mt-1 text-3xl">{title}</h2>
      <div className="mt-6">{children}</div>
    </section>
  );
}
