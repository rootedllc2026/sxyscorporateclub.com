/**
 * Cron-callable route that drains due `scheduled_emails` rows.
 *
 * Endpoint:  /api/public/process-scheduled-emails
 * Trigger:   pg_cron (every 1 min) sends a POST with the shared CRON_SECRET.
 *
 * Why a public route?
 *   `/api/public/*` bypasses Lovable's published-site auth wall so external
 *   schedulers can call it. We re-add our own bearer-token check inside.
 *
 * Setup (one-time, in Supabase SQL editor):
 *   1. Add a runtime secret called CRON_SECRET (any long random string).
 *   2. Schedule the cron job:
 *
 *      select cron.schedule(
 *        'process-scheduled-emails',
 *        '* * * * *',
 *        $$
 *        select net.http_post(
 *          url:='https://www.sxyscorporateclub.com/api/public/process-scheduled-emails',
 *          headers:='{"Authorization":"Bearer YOUR_CRON_SECRET","Content-Type":"application/json"}'::jsonb,
 *          body:='{}'::jsonb
 *        );
 *        $$
 *      );
 *
 * Behavior per invocation:
 *   - Picks up to 50 due rows (status='pending', send_at <= now()).
 *   - For each: re-fetches the booking, builds the template, sends via Resend.
 *   - Marks the row 'sent' (or 'failed' with last_error after 3 attempts).
 *   - Skips if booking is cancelled or refunded → marks row 'cancelled'.
 */
import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { sendResendEmail } from "@/server/email/resend";
import { buildBookingReminder } from "@/server/email/templates";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
} as const;

const MAX_BATCH = 50;
const MAX_ATTEMPTS = 3;

interface BookingReminderPayload {
  service_name: string;
  booked_date: string;
  booked_time?: string | null;
  client_name?: string | null;
}

async function processBookingReminder(row: {
  id: string;
  reference_id: string | null;
  recipient: string;
  payload: BookingReminderPayload;
}): Promise<{ ok: boolean; error?: string; cancelled?: boolean }> {
  // Re-check the booking status — don't remind for cancelled/refunded ones.
  if (row.reference_id) {
    const { data: booking } = await supabaseAdmin
      .from("bookings")
      .select("status")
      .eq("id", row.reference_id)
      .maybeSingle();
    if (!booking) return { ok: false, cancelled: true, error: "booking gone" };
    if (["cancelled", "refunded"].includes(booking.status)) {
      return { ok: false, cancelled: true };
    }
  }

  const { subject, html } = buildBookingReminder({
    clientFullName: row.payload.client_name,
    serviceName: row.payload.service_name,
    bookedDate: row.payload.booked_date,
    bookedTime: row.payload.booked_time,
  });

  try {
    await sendResendEmail({
      to: row.recipient,
      subject,
      html,
      tag: "booking-reminder",
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

export const Route = createFileRoute("/api/public/process-scheduled-emails")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: corsHeaders }),

      GET: async () =>
        new Response(
          JSON.stringify({
            ok: true,
            message:
              "Scheduled email worker. POST with Bearer CRON_SECRET to drain.",
          }),
          {
            status: 200,
            headers: { "Content-Type": "application/json", ...corsHeaders },
          },
        ),

      POST: async ({ request }) => {
        const expected = process.env.CRON_SECRET;
        if (!expected) {
          console.error("[scheduled-emails] CRON_SECRET not configured");
          return new Response("Misconfigured", { status: 500, headers: corsHeaders });
        }
        const auth = request.headers.get("authorization");
        if (auth !== `Bearer ${expected}`) {
          return new Response("Unauthorized", { status: 401, headers: corsHeaders });
        }

        const { data: due, error: fetchErr } = await supabaseAdmin
          .from("scheduled_emails")
          .select("id, kind, reference_id, recipient, payload, attempts")
          .eq("status", "pending")
          .lte("send_at", new Date().toISOString())
          .order("send_at", { ascending: true })
          .limit(MAX_BATCH);

        if (fetchErr) {
          console.error("[scheduled-emails] fetch failed", fetchErr);
          return new Response(
            JSON.stringify({ ok: false, error: fetchErr.message }),
            { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } },
          );
        }

        const rows = due ?? [];
        let sent = 0;
        let failed = 0;
        let cancelled = 0;

        for (const row of rows) {
          let result: { ok: boolean; error?: string; cancelled?: boolean };
          if (row.kind === "booking-reminder-24h") {
            result = await processBookingReminder({
              id: row.id,
              reference_id: row.reference_id,
              recipient: row.recipient,
              payload: row.payload as unknown as BookingReminderPayload,
            });
          } else {
            result = { ok: false, error: `unknown kind: ${row.kind}` };
          }

          if (result.cancelled) {
            cancelled += 1;
            await supabaseAdmin
              .from("scheduled_emails")
              .update({
                status: "cancelled",
                attempts: row.attempts + 1,
                last_error: result.error ?? null,
              })
              .eq("id", row.id);
          } else if (result.ok) {
            sent += 1;
            await supabaseAdmin
              .from("scheduled_emails")
              .update({
                status: "sent",
                sent_at: new Date().toISOString(),
                attempts: row.attempts + 1,
              })
              .eq("id", row.id);
          } else {
            failed += 1;
            const nextAttempts = row.attempts + 1;
            await supabaseAdmin
              .from("scheduled_emails")
              .update({
                status: nextAttempts >= MAX_ATTEMPTS ? "failed" : "pending",
                attempts: nextAttempts,
                last_error: result.error ?? "unknown",
              })
              .eq("id", row.id);
          }
        }

        return new Response(
          JSON.stringify({ ok: true, processed: rows.length, sent, failed, cancelled }),
          { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } },
        );
      },
    },
  },
});
