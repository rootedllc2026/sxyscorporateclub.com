import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import {
  MutationCache,
  QueryCache,
  QueryClient,
  QueryClientProvider,
} from "@tanstack/react-query";

import appCss from "../styles.css?url";
import { AuthProvider } from "@/integrations/supabase/AuthContext";
import { Toaster } from "@/components/ui/sonner";
import { handleSupabaseError } from "@/integrations/supabase/errors";
import { BackendHealthBanner } from "@/components/system/BackendHealthBanner";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60_000,
      gcTime: 10 * 60_000,
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
  queryCache: new QueryCache({
    onError: (error) => handleSupabaseError(error, "Failed to load data"),
  }),
  mutationCache: new MutationCache({
    onError: (error) => handleSupabaseError(error, "Action failed"),
  }),
});

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "SXY's Corporate Club" },
      {
        name: "description",
        content:
          "The premier business club for entrepreneurs and professionals — entity formation, AI integration, project management and more. Powered by SXY's Corporate Club.",
      },
      { name: "author", content: "SXY's Economic Roots LLC" },
      { name: "theme-color", content: "#0a5c6b" },
      { property: "og:title", content: "SXY's Corporate Club" },
      {
        property: "og:description",
        content:
          "Your business, guided & protected. Online platform for entrepreneurs and professionals who've decided to build something.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "SXY's Corporate Club" },
      { name: "description", content: "A virtual business marketplace and resource hub for business owners and professionals. Join for free and upgrade for additional resources. Welcome to the club." },
      { property: "og:description", content: "A virtual business marketplace and resource hub for business owners and professionals. Join for free and upgrade for additional resources. Welcome to the club." },
      { name: "twitter:description", content: "A virtual business marketplace and resource hub for business owners and professionals. Join for free and upgrade for additional resources. Welcome to the club." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/4JqlZ3MXOYhZmvxcf9B6b9E9R3O2/social-images/social-1777245800368-SXY_Social_Image.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/4JqlZ3MXOYhZmvxcf9B6b9E9R3O2/social-images/social-1777245800368-SXY_Social_Image.webp" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,600&family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap",
      },
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <BackendHealthBanner />
        <Outlet />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}
