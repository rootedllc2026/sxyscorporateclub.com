import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";

export const Route = createFileRoute("/exchange")({
  head: () => ({ meta: [{ title: "Exchange — SXY's Corporate Club" }] }),
  component: () => (
    <AppLayout title="Exchange">
      <SxyCard accent>
        <h2 className="font-display text-xl text-teal-light">Member chat</h2>
        <p className="mt-2 text-sm text-text-muted">
          The community Exchange is next on the roadmap. Messages already power
          the Community Posts stat on your dashboard.
        </p>
      </SxyCard>
    </AppLayout>
  ),
});
