import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type {
  ApprenticeshipProgram,
  StructuredAnswer,
} from "@/lib/apprenticeship/shared";

export const Route = createFileRoute("/apprenticeship/$id/apply")({
  head: () => ({ meta: [{ title: "Apply — SXY's Corporate Club" }] }),
  component: ApplyPage,
});

function ApplyPage() {
  const { id } = Route.useParams();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const { data: program, isLoading } = useQuery({
    queryKey: ["apprenticeship", "program", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("apprenticeship_programs")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as ApprenticeshipProgram | null;
    },
  });

  const [coverNote, setCoverNote] = React.useState("");
  const [resumeFile, setResumeFile] = React.useState<File | null>(null);
  const [videoFile, setVideoFile] = React.useState<File | null>(null);
  const [portfolioLinks, setPortfolioLinks] = React.useState("");
  const [answers, setAnswers] = React.useState<Record<string, string>>({});
  const [submitting, setSubmitting] = React.useState(false);

  if (isLoading) return <AppLayout title="Apply"><p>Loading…</p></AppLayout>;
  if (!program) return <AppLayout title="Apply"><p>Program not found.</p></AppLayout>;

  const uploadFile = async (file: File, kind: "resume" | "video") => {
    const ext = file.name.split(".").pop() ?? "bin";
    const path = `${currentUser!.id}/${program.id}/${kind}-${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from("apprentice-uploads")
      .upload(path, file, { upsert: true });
    if (error) throw new Error(error.message);
    return path;
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (program.require_cover_note && coverNote.trim().length < 10) {
      toast.error("Cover note required (10+ characters)");
      return;
    }
    if (program.require_resume && !resumeFile) {
      toast.error("Resume file required");
      return;
    }
    if (program.require_video && !videoFile) {
      toast.error("Video intro required");
      return;
    }
    if (program.require_portfolio && portfolioLinks.trim().length === 0) {
      toast.error("Portfolio links required");
      return;
    }
    for (const q of program.structured_questions) {
      if (!answers[q.id]?.trim()) {
        toast.error(`Please answer: ${q.prompt}`);
        return;
      }
    }

    setSubmitting(true);
    try {
      let resumePath: string | null = null;
      let videoPath: string | null = null;
      if (resumeFile) resumePath = await uploadFile(resumeFile, "resume");
      if (videoFile) videoPath = await uploadFile(videoFile, "video");

      const links = portfolioLinks
        .split(/\s+/)
        .map((s) => s.trim())
        .filter(Boolean);

      const structured: StructuredAnswer[] = program.structured_questions.map(
        (q) => ({ id: q.id, answer: answers[q.id] ?? "" }),
      );

      const { error } = await supabase
        .from("apprenticeship_applications")
        .insert({
          program_id: program.id,
          applicant_id: currentUser.id,
          cover_note: coverNote || null,
          resume_path: resumePath,
          video_path: videoPath,
          portfolio_links: links,
          structured_answers: structured,
        });
      if (error) throw new Error(error.message);
      toast.success("Application submitted");
      navigate({ to: "/apprenticeship/$id", params: { id: program.id } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to submit");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AppLayout title={`Apply: ${program.title}`}>
      <form onSubmit={onSubmit} className="mx-auto max-w-2xl space-y-5">
        {program.require_cover_note && (
          <SxyCard>
            <Label>Cover note</Label>
            <Textarea
              rows={6}
              value={coverNote}
              onChange={(e) => setCoverNote(e.target.value)}
              placeholder="Why you, why now."
              maxLength={2000}
            />
          </SxyCard>
        )}
        {program.require_resume && (
          <SxyCard>
            <Label>Resume / CV</Label>
            <Input
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={(e) => setResumeFile(e.target.files?.[0] ?? null)}
            />
          </SxyCard>
        )}
        {program.require_video && (
          <SxyCard>
            <Label>Video intro (60–90s, mp4/mov)</Label>
            <Input
              type="file"
              accept="video/*"
              onChange={(e) => setVideoFile(e.target.files?.[0] ?? null)}
            />
          </SxyCard>
        )}
        {program.require_portfolio && (
          <SxyCard>
            <Label>Portfolio links (one per line)</Label>
            <Textarea
              rows={3}
              value={portfolioLinks}
              onChange={(e) => setPortfolioLinks(e.target.value)}
              placeholder={"https://linkedin.com/in/you\nhttps://yourportfolio.com"}
            />
          </SxyCard>
        )}
        {program.structured_questions.length > 0 && (
          <SxyCard>
            <p className="sxy-section-label">Questions from the program owner</p>
            <div className="mt-3 space-y-4">
              {program.structured_questions.map((q, i) => (
                <div key={q.id}>
                  <Label>
                    Q{i + 1}. {q.prompt}
                  </Label>
                  <Textarea
                    rows={3}
                    value={answers[q.id] ?? ""}
                    onChange={(e) =>
                      setAnswers((a) => ({ ...a, [q.id]: e.target.value }))
                    }
                    maxLength={1500}
                  />
                </div>
              ))}
            </div>
          </SxyCard>
        )}

        <div className="flex justify-end gap-2">
          <SxyButton type="button" variant="ghost" size="sm" asChild>
            <Link to="/apprenticeship/$id" params={{ id: program.id }}>
              Cancel
            </Link>
          </SxyButton>
          <SxyButton type="submit" variant="gold" size="sm" disabled={submitting}>
            {submitting ? "Submitting…" : "Submit application"}
          </SxyButton>
        </div>
      </form>
    </AppLayout>
  );
}
