import * as React from "react";
import {
  createFileRoute,
  Link,
  notFound,
} from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { TierGate } from "@/components/sxy/TierGate";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { AvatarBadge } from "@/components/layout/Avatar";
import {
  BID_CURRENCY,
  bidStatusVariant,
  categoryEmoji,
  categoryLabel,
  formatBudget,
  statusLabel,
  statusTagVariant,
  timeUntil,
} from "@/lib/bidding/shared";

export const Route = createFileRoute("/bidding/$id")({
  head: () => ({ meta: [{ title: "Project — SXY's Corporate Club" }] }),
  component: ProjectDetailPage,
  errorComponent: ({ error }) => (
    <AppLayout title="Project">
      <SxyCard accent>
        <h2 className="font-display text-xl text-teal-light">
          Couldn't load project
        </h2>
        <p className="mt-2 text-sm text-text-muted">{error.message}</p>
      </SxyCard>
    </AppLayout>
  ),
  notFoundComponent: () => (
    <AppLayout title="Project not found">
      <SxyCard accent>
        <h2 className="font-display text-xl text-teal-light">
          Project not found
        </h2>
        <p className="mt-2 text-sm text-text-muted">
          The project may have been removed.
        </p>
        <div className="mt-4">
          <SxyButton variant="primary" size="sm" asChild>
            <Link to="/bidding">Back to projects</Link>
          </SxyButton>
        </div>
      </SxyCard>
    </AppLayout>
  ),
});

function ProjectDetailPage() {
  const { id } = Route.useParams();
  return (
    <AppLayout title="Project Details">
      <TierGate feature="Club Market">
        <DetailContent projectId={id} />
      </TierGate>
    </AppLayout>
  );
}

function DetailContent({ projectId }: { projectId: string }) {
  const { currentUser } = useAuth();

  const { data: project, isLoading } = useQuery({
    queryKey: ["bidding", "project", projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select("*")
        .eq("id", projectId)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw notFound();
      return data;
    },
  });

  const { data: bids } = useQuery({
    queryKey: ["bidding", "project-bids", projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bids")
        .select(
          "id, bidder_id, amount, proposed_price, status, created_at, profiles!bids_bidder_id_fkey(full_name, avatar_color)",
        )
        .eq("project_id", projectId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const userHasBid = React.useMemo(
    () =>
      !!bids?.some((b: any) => b.bidder_id === currentUser?.id),
    [bids, currentUser?.id],
  );

  if (isLoading || !project) {
    return (
      <SxyCard>
        <p className="text-sm text-text-muted">Loading project…</p>
      </SxyCard>
    );
  }

  const isOpen = project.status === "open";
  const requirements: string[] = Array.isArray(project.requirements)
    ? project.requirements
    : [];

  return (
    <div className="space-y-8">
      {/* Hero banner */}
      <section
        className="overflow-hidden rounded-2xl border border-border-teal/60 p-8"
        style={{
          backgroundImage:
            "linear-gradient(135deg, var(--teal-deep), var(--charcoal-soft) 75%)",
        }}
      >
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-3">
              <span aria-hidden className="text-3xl">
                {categoryEmoji(project.category)}
              </span>
              <Tag variant={statusTagVariant(project.status)}>
                {statusLabel(project.status)}
              </Tag>
              <Tag variant="gray">{categoryLabel(project.category)}</Tag>
            </div>
            <h1 className="mt-3 font-display text-3xl text-text-primary">
              {project.title}
            </h1>
            <p className="mt-3 text-xs uppercase tracking-wider text-text-dim">
              Posted{" "}
              {new Date(project.created_at).toLocaleDateString(undefined, {
                month: "short",
                day: "numeric",
                year: "numeric",
              })}
            </p>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-[0.18em] text-text-dim">
              Budget
            </p>
            <p className="font-editorial text-3xl text-gold">
              {formatBudget(
                project.budget,
                project.budget_min,
                project.budget_max,
              )}
            </p>
            <p className="mt-3 text-[10px] uppercase tracking-[0.18em] text-text-dim">
              Deadline
            </p>
            <p className="text-sm text-text-primary">
              {timeUntil(project.deadline ?? project.closes_at)}
            </p>
          </div>
        </div>
      </section>

      {/* Two-column body */}
      <section className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Project description
            </h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-text-primary">
              {project.description ??
                project.summary ??
                "No description provided."}
            </p>
          </SxyCard>

          {requirements.length > 0 ? (
            <SxyCard accent>
              <h2 className="font-display text-lg text-teal-light">
                Requirements
              </h2>
              <ul className="mt-3 space-y-2">
                {requirements.map((req) => (
                  <li
                    key={req}
                    className="flex items-start gap-2 text-sm text-text-primary"
                  >
                    <span className="mt-0.5 text-gold">◆</span>
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </SxyCard>
          ) : null}

          {project.rfp_url ? (
            <SxyCard>
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="font-editorial text-base text-text-primary">
                    RFP document
                  </p>
                  <p className="text-xs text-text-dim">
                    Detailed brief attached by the project owner.
                  </p>
                </div>
                <SxyButton variant="outline" size="sm" asChild>
                  <a
                    href={project.rfp_url}
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    Download RFP
                  </a>
                </SxyButton>
              </div>
            </SxyCard>
          ) : null}
        </div>

        {/* Sidebar */}
        <aside className="space-y-6">
          <SxyCard accent>
            <div className="flex items-center justify-between">
              <p className="sxy-section-label">Bid activity</p>
              <BidRing count={bids?.length ?? 0} />
            </div>
            <p className="mt-4 text-xs uppercase tracking-[0.18em] text-text-dim">
              Budget
            </p>
            <p className="font-editorial text-2xl text-gold">
              {formatBudget(
                project.budget,
                project.budget_min,
                project.budget_max,
              )}
            </p>
          </SxyCard>

          <SxyCard accent>
            <h3 className="font-display text-base text-teal-light">
              Current bidders
            </h3>
            <ul className="mt-4 space-y-3">
              {bids && bids.length > 0 ? (
                bids.map((b: any) => (
                  <li
                    key={b.id}
                    className="flex items-center justify-between gap-3"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <AvatarBadge
                        name={b.profiles?.full_name ?? "Member"}
                        colorKey={b.profiles?.avatar_color ?? "teal"}
                        size={32}
                      />
                      <div className="min-w-0">
                        <p className="truncate text-sm text-text-primary">
                          {b.profiles?.full_name ?? "Member"}
                        </p>
                        <Tag
                          variant={bidStatusVariant(b.status)}
                          className="mt-0.5 px-1.5 py-0 text-[9px]"
                        >
                          {b.status}
                        </Tag>
                      </div>
                    </div>
                    <p className="font-mono text-xs text-text-muted">
                      {BID_CURRENCY.format(
                        Number(b.proposed_price ?? b.amount ?? 0),
                      )}
                    </p>
                  </li>
                ))
              ) : (
                <li className="rounded-lg border border-dashed border-border-base/60 p-4 text-center text-xs text-text-dim">
                  No bids yet — be the first.
                </li>
              )}
            </ul>
          </SxyCard>

          <div className="space-y-3">
            {isOpen && !userHasBid ? (
              <SxyButton
                variant="gold"
                size="lg"
                className="w-full"
                asChild
              >
                <Link
                  to="/bidding/$id/propose"
                  params={{ id: projectId }}
                >
                  Submit Your Proposal
                </Link>
              </SxyButton>
            ) : userHasBid ? (
              <SxyButton variant="outline" size="lg" className="w-full" disabled>
                You've already bid
              </SxyButton>
            ) : (
              <SxyButton variant="outline" size="lg" className="w-full" disabled>
                Bidding Closed
              </SxyButton>
            )}
            <SxyButton variant="ghost" size="sm" className="w-full" asChild>
              <Link to="/bidding">← Back to all projects</Link>
            </SxyButton>
          </div>
        </aside>
      </section>
    </div>
  );
}

function BidRing({ count }: { count: number }) {
  // Simple visual ring — strokeDasharray maxes out at 20+ bids.
  const pct = Math.min(count / 20, 1);
  const r = 22;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative h-14 w-14">
      <svg viewBox="0 0 56 56" className="h-full w-full -rotate-90">
        <circle
          cx="28"
          cy="28"
          r={r}
          fill="none"
          stroke="oklch(1 0 0 / 0.08)"
          strokeWidth="4"
        />
        <circle
          cx="28"
          cy="28"
          r={r}
          fill="none"
          stroke="var(--teal-mid)"
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={`${c * pct} ${c}`}
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center font-display text-base text-text-primary">
        {count}
      </span>
    </div>
  );
}

