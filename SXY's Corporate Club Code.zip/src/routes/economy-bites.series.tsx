/**
 * /economy-bites/series — the three-card series overview.
 *
 * Each subcategory card pulls counts from `videos` for the corresponding
 * series and shows a progress bar (user's completed / total).  VIP cards
 * render a locked teaser strip with a gradient fade if the member doesn't
 * have VIP access.
 */
import * as React from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Lock } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { UpgradeModal } from "@/components/sxy/UpgradeModal";
import { EconomyBitesNav } from "@/components/videos/EconomyBitesNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  SERIES_META,
  canAccessVideo,
  type VideoRow,
  type VideoSeries,
} from "@/lib/videos/shared";

export const Route = createFileRoute("/economy-bites/series")({
  head: () => ({
    meta: [
      { title: "Economy Bites Series — SXY's Corporate Club" },
      {
        name: "description",
        content:
          "Browse the three Economy Bites series: Business Bites (free), Market Bites and Bankruptcy Bites (VIP educational content).",
      },
    ],
  }),
  component: () => (
    <AppLayout title="Economy Bites — Series">
      <SeriesPage />
    </AppLayout>
  ),
});

const SERIES_ORDER: VideoSeries[] = [
  "business-bites",
  "market-bites",
  "bankruptcy-bites",
];

const SERIES_DESCRIPTION: Record<VideoSeries, string> = {
  "business-bites":
    "Practical business lessons covering pricing strategy, branding, AI tooling and entity structure — designed for operators of any size.",
  "market-bites":
    "Educational breakdowns of markets, interest rates, and economic cycles. Built for general learning — not investment guidance.",
  "bankruptcy-bites":
    "Educational explanations of Chapters 7, 11 and 13, the automatic stay, and creditor claims. General education only — not legal advice.",
};

function SeriesPage() {
  const { userTier, isAdmin, currentUser } = useAuth();
  const navigate = useNavigate();
  const [upgradeOpen, setUpgradeOpen] = React.useState(false);

  const { data: videos = [] } = useQuery({
    queryKey: ["videos", "for-series"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("videos")
        .select("id, title, series, access_level, is_published")
        .eq("is_published", true)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Pick<VideoRow, "id" | "title" | "series" | "access_level" | "is_published">[];
    },
  });

  const { data: completedIds = new Set<string>() } = useQuery({
    queryKey: ["videos", "completedSet", currentUser?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("video_progress")
        .select("video_id, completed")
        .eq("user_id", currentUser!.id)
        .eq("completed", true);
      return new Set((data ?? []).map((r) => r.video_id as string));
    },
    enabled: !!currentUser,
  });

  return (
    <div className="space-y-8">
      <EconomyBitesNav />

      <header className="space-y-3 text-center">
        <h2
          className="font-editorial italic text-gold"
          style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: 32 }}
        >
          Economy Bites
        </h2>
        <p className="mx-auto max-w-2xl text-sm text-text-muted">
          Bite-sized economic education for SXY's Corporate Club members. All
          content is for educational purposes — not financial, investment or
          legal advice.
        </p>
      </header>

      <div className="space-y-5">
        {SERIES_ORDER.map((s) => {
          const meta = SERIES_META[s];
          const seriesVideos = videos.filter((v) => v.series === s);
          const total = seriesVideos.length;
          const done = seriesVideos.filter((v) => completedIds.has(v.id)).length;
          const pct = total ? Math.round((done / total) * 100) : 0;
          const accessible = canAccessVideo(meta.access, userTier, isAdmin);

          return (
            <SxyCard
              key={s}
              accent
              className="overflow-hidden p-0"
              style={{ borderColor: "var(--border-base)" }}
            >
              <div className="grid gap-0 lg:grid-cols-[1fr_280px]">
                {/* Banner + body */}
                <div className="relative p-6 lg:p-8" style={{ background: meta.gradient }}>
                  <div className="flex items-center gap-3">
                    <span aria-hidden className="text-3xl">
                      {meta.emoji}
                    </span>
                    <div>
                      <h3 className="font-display text-xl text-text-primary lg:text-2xl">
                        {meta.title}
                      </h3>
                      <p className="text-[11px] uppercase tracking-wider text-text-muted">
                        {meta.tag}
                      </p>
                    </div>
                  </div>
                  <p className="mt-4 max-w-xl text-sm text-text-primary/90">
                    {SERIES_DESCRIPTION[s]}
                  </p>

                  {/* Teaser strip */}
                  <div className="relative mt-6">
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {seriesVideos.slice(0, 4).map((v) => (
                        <button
                          key={v.id}
                          type="button"
                          disabled={!accessible}
                          onClick={() =>
                            accessible
                              ? navigate({ to: "/economy-bites/$id", params: { id: v.id } })
                              : setUpgradeOpen(true)
                          }
                          className="shrink-0 rounded-full border border-white/15 bg-black/40 px-3 py-1 text-xs text-text-primary backdrop-blur transition-colors enabled:hover:border-white/30 disabled:cursor-not-allowed"
                        >
                          {v.title}
                        </button>
                      ))}
                      {seriesVideos.length === 0 ? (
                        <span className="text-xs text-text-muted">
                          Videos coming soon.
                        </span>
                      ) : null}
                    </div>
                    {!accessible && seriesVideos.length > 0 ? (
                      <span
                        aria-hidden
                        className="pointer-events-none absolute inset-y-0 right-0 w-24"
                        style={{
                          background:
                            "linear-gradient(90deg, transparent, var(--charcoal))",
                        }}
                      />
                    ) : null}
                  </div>
                </div>

                {/* Right stats panel */}
                <div className="flex flex-col justify-between gap-4 border-t border-border-base/60 bg-charcoal-card p-6 lg:border-l lg:border-t-0">
                  <div className="space-y-3">
                    <div className="flex items-baseline justify-between">
                      <span className="font-display text-3xl text-teal-light">
                        {total}
                      </span>
                      <span className="text-[11px] uppercase tracking-wider text-text-dim">
                        videos
                      </span>
                    </div>

                    <Tag variant={meta.access === "free" ? "teal" : "gold"}>
                      {meta.access === "free" ? "Free" : "VIP Only"}
                    </Tag>

                    <div>
                      <div className="flex items-center justify-between text-[11px] text-text-muted">
                        <span>Progress</span>
                        <span>
                          {done} / {total}
                        </span>
                      </div>
                      <div className="mt-1 h-2 overflow-hidden rounded-full bg-charcoal-card-2">
                        <div
                          className="h-full rounded-full bg-teal-mid"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {accessible ? (
                    <SxyButton
                      size="sm"
                      onClick={() =>
                        navigate({
                          to: "/economy-bites",
                          search: { series: s } as never,
                        })
                      }
                    >
                      Browse videos
                    </SxyButton>
                  ) : (
                    <SxyButton
                      variant="gold"
                      size="sm"
                      onClick={() => setUpgradeOpen(true)}
                    >
                      <Lock className="h-3.5 w-3.5" /> Unlock with VIP
                    </SxyButton>
                  )}
                </div>
              </div>
            </SxyCard>
          );
        })}
      </div>

      <p className="rounded-xl border border-border-base/60 bg-charcoal-card p-4 text-center text-xs text-text-dim">
        All Economy Bites content is educational only. Market Bites and
        Bankruptcy Bites are not investment, financial, or legal advice.
      </p>

      <UpgradeModal open={upgradeOpen} onOpenChange={setUpgradeOpen} />
    </div>
  );
}
