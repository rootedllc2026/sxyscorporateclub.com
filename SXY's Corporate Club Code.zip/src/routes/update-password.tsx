import * as React from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell, AuthError } from "@/components/auth/AuthShell";
import { AuthInput, Field } from "@/components/auth/AuthInput";
import { SxyButton } from "@/components/sxy/SxyButton";

export const Route = createFileRoute("/update-password")({
  head: () => ({
    meta: [
      { title: "Set New Password — SXY's Corporate Club" },
    ],
  }),
  component: UpdatePasswordPage,
});

const schema = z
  .object({
    password: z.string().min(8, "Password must be at least 8 characters").max(128),
    confirm: z.string(),
  })
  .refine((d) => d.password === d.confirm, {
    message: "Passwords do not match",
    path: ["confirm"],
  });

function UpdatePasswordPage() {
  const navigate = useNavigate();
  const [ready, setReady] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // Supabase places the recovery token in the URL hash; getSession() picks it up.
  React.useEffect(() => {
    let mounted = true;
    void supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      if (!data.session) {
        setError(
          "This reset link is invalid or has expired. Request a new one.",
        );
      }
      setReady(true);
    });
    return () => {
      mounted = false;
    };
  }, []);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const fd = new FormData(e.currentTarget);
    const parsed = schema.safeParse({
      password: fd.get("password"),
      confirm: fd.get("confirm"),
    });
    if (!parsed.success) {
      setError(parsed.error.errors[0]?.message ?? "Invalid input");
      return;
    }
    setSubmitting(true);
    try {
      const { error: upErr } = await supabase.auth.updateUser({
        password: parsed.data.password,
      });
      if (upErr) {
        setError(upErr.message);
        return;
      }
      toast.success("Password updated. Please sign in with your new password.");
      // Sign out so they explicitly re-authenticate.
      await supabase.auth.signOut();
      await navigate({ to: "/login" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthShell
      title="Set a New Password"
      subtitle="Enter your new password to finish resetting your account."
    >
      <form onSubmit={onSubmit} className="space-y-5" noValidate>
        <Field label="New password" htmlFor="password" hint="Minimum 8 characters">
          <AuthInput
            id="password"
            name="password"
            type="password"
            autoComplete="new-password"
            minLength={8}
            required
            disabled={!ready}
            placeholder="••••••••"
          />
        </Field>
        <Field label="Confirm password" htmlFor="confirm">
          <AuthInput
            id="confirm"
            name="confirm"
            type="password"
            autoComplete="new-password"
            minLength={8}
            required
            disabled={!ready}
            placeholder="••••••••"
          />
        </Field>

        <AuthError message={error} />

        <SxyButton
          type="submit"
          variant="primary"
          size="lg"
          disabled={submitting || !ready}
          className="w-full"
        >
          {submitting ? "Updating…" : "Update Password"}
        </SxyButton>
      </form>
    </AuthShell>
  );
}
