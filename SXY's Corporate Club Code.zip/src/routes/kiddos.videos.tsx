import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { KidShell } from "@/components/kiddos/KidShell";
import { CreditBadge } from "@/components/kiddos/CreditBadge";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  submitKiddoVideo,
  recordVideoView,
  signKiddoVideoUrl,
} from "@/lib/kiddos/kiddos.functions";
import { toEmbedUrl, isUploadedVideo } from "@/lib/kiddos/youtube";

export const Route = createFileRoute("/kiddos/videos")({
  head: () => ({ meta: [{ title: "Learn — Kiddos" }] }),
  component: () => (
    <KidShell title="Learn 🎬">
      <VideosContent />
    </KidShell>
  ),
});

type VideoRow = {
  id: string;
  title: string;
  description: string | null;
  topic: string | null;
  video_url: string | null;
  storage_path: string | null;
  thumbnail_url: string | null;
  duration_seconds: number;
  kind: "official" | "kid_submission";
  status: string;
  creator_user_id: string | null;
  view_count: number;
  credits_per_view: number;
};

function VideosContent() {
  const { currentUser } = useAuth();
  const userId = currentUser?.id;
  const qc = useQueryClient();
  const submitFn = useServerFn(submitKiddoVideo);

  const { data: videos } = useQuery({
    queryKey: ["kiddo-videos-approved"],
    queryFn: async (): Promise<VideoRow[]> => {
      const { data, error } = await supabase
        .from("kiddo_videos")
        .select(
          "id, title, description, topic, video_url, storage_path, thumbnail_url, duration_seconds, kind, status, creator_user_id, view_count, credits_per_view",
        )
        .eq("status", "approved")
        .eq("is_published", true)
        .order("created_at", { ascending: false })
        .limit(40);
      if (error) throw error;
      return (data ?? []) as VideoRow[];
    },
  });

  const { data: mine } = useQuery({
    queryKey: ["kiddo-videos-mine", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("kiddo_videos")
        .select("id, title, status, rejection_reason, created_at")
        .eq("creator_user_id", userId)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const submitMut = useMutation({
    mutationFn: (v: {
      title: string;
      description?: string;
      topic?: string;
      videoUrl?: string;
      storagePath?: string;
      durationSeconds: number;
    }) => submitFn({ data: { ...v, kind: "kid_submission" } }),
    onSuccess: () => {
      toast.success("Submitted! Your parent will review it.");
      qc.invalidateQueries({ queryKey: ["kiddo-videos-mine", userId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!currentUser) {
    return (
      <div className="kid-card text-center">
        <p className="mb-4">Sign in to watch and submit videos.</p>
        <Link to="/login" className="kid-btn kid-btn-primary">Sign in</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-5">
      <section className="kid-card">
        <h2 className="text-xl mb-2">Submit a video (under 5 minutes)</h2>
        <p className="text-sm text-[var(--kid-ink-muted)] mb-3">
          Paste a YouTube/Vimeo link or upload an MP4. Your parent reviews it, then an admin publishes it.
          You earn <strong>credits each time a peer watches it</strong>.
        </p>
        <SubmitForm
          userId={userId!}
          onSubmit={(v) => submitMut.mutate(v)}
          pending={submitMut.isPending}
        />
      </section>

      {mine && mine.length > 0 && (
        <section className="kid-card">
          <h2 className="text-xl mb-3">Your submissions</h2>
          <ul className="space-y-2 text-sm">
            {mine.map((m) => (
              <li key={m.id} className="flex items-center justify-between gap-3">
                <span className="truncate">{m.title}</span>
                <StatusPill status={m.status} />
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="grid sm:grid-cols-2 gap-4">
        {(videos ?? []).map((v) => (
          <VideoCard key={v.id} video={v} viewerId={userId!} />
        ))}
        {(!videos || videos.length === 0) && (
          <div className="kid-card sm:col-span-2 text-center text-[var(--kid-ink-muted)]">
            No videos yet. Be the first to submit one!
          </div>
        )}
      </section>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending_parent: "Waiting on parent",
    pending_admin: "Waiting on admin",
    approved: "Live ✓",
    rejected: "Rejected",
    draft: "Draft",
  };
  return (
    <span
      className="text-xs px-2 py-1 rounded-full"
      style={{ background: "rgba(10,92,107,0.08)", color: "var(--kid-teal)" }}
    >
      {map[status] ?? status}
    </span>
  );
}

function VideoCard({ video, viewerId }: { video: VideoRow; viewerId: string }) {
  const [open, setOpen] = React.useState(false);
  const [src, setSrc] = React.useState<string | null>(null);
  const signFn = useServerFn(signKiddoVideoUrl);
  const recordFn = useServerFn(recordVideoView);

  async function play() {
    try {
      if (video.storage_path) {
        const { url } = await signFn({ data: { path: video.storage_path } });
        setSrc(url);
      } else if (video.video_url) {
        setSrc(toEmbedUrl(video.video_url) ?? video.video_url);
      }
      setOpen(true);
      // Award credits on first watch (server enforces uniqueness).
      if (video.creator_user_id && video.creator_user_id !== viewerId) {
        recordFn({ data: { videoId: video.id } }).catch(() => {});
      }
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  const isMp4 = !!video.storage_path || (video.video_url && isUploadedVideo(video.video_url));

  return (
    <div className="kid-card">
      <button
        type="button"
        className="text-left w-full"
        onClick={play}
        style={{ minHeight: 48 }}
      >
        <div
          className="rounded-xl mb-3 flex items-center justify-center text-5xl"
          style={{
            aspectRatio: "16/9",
            background: video.thumbnail_url
              ? `center/cover no-repeat url(${video.thumbnail_url})`
              : "linear-gradient(135deg, rgba(10,92,107,0.15), rgba(240,180,41,0.2))",
          }}
        >
          {!video.thumbnail_url && "▶︎"}
        </div>
        <div className="flex items-center justify-between gap-2 mb-1">
          <span
            className="text-xs px-2 py-0.5 rounded-full"
            style={{
              background: video.kind === "official" ? "rgba(240,180,41,0.2)" : "rgba(10,92,107,0.1)",
              color: video.kind === "official" ? "var(--kid-gold-dark, #8a6500)" : "var(--kid-teal)",
            }}
          >
            {video.kind === "official" ? "Official" : "Kid creator"}
          </span>
          <span className="text-xs text-[var(--kid-ink-muted)]">{video.view_count} views</span>
        </div>
        <div className="font-semibold">{video.title}</div>
        {video.description && (
          <p className="text-sm text-[var(--kid-ink-muted)] line-clamp-2 mt-1">{video.description}</p>
        )}
        <div className="mt-2 flex items-center gap-2 text-xs text-[var(--kid-ink-muted)]">
          {video.topic && <span>#{video.topic}</span>}
          {video.credits_per_view > 0 && video.kind === "kid_submission" && (
            <CreditBadge amount={`+${video.credits_per_view}/view`} />
          )}
        </div>
      </button>

      {open && src && (
        <div
          className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="bg-black rounded-2xl overflow-hidden w-full max-w-3xl"
            onClick={(e) => e.stopPropagation()}
            style={{ aspectRatio: "16/9" }}
          >
            {isMp4 ? (
              <video src={src} controls autoPlay className="w-full h-full" />
            ) : (
              <iframe
                src={src}
                title={video.title}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function SubmitForm({
  userId,
  onSubmit,
  pending,
}: {
  userId: string;
  onSubmit: (v: {
    title: string;
    description?: string;
    topic?: string;
    videoUrl?: string;
    storagePath?: string;
    durationSeconds: number;
  }) => void;
  pending: boolean;
}) {
  const [title, setTitle] = React.useState("");
  const [desc, setDesc] = React.useState("");
  const [topic, setTopic] = React.useState("");
  const [url, setUrl] = React.useState("");
  const [duration, setDuration] = React.useState("");
  const [storagePath, setStoragePath] = React.useState<string | null>(null);
  const [uploading, setUploading] = React.useState(false);

  async function handleFile(file: File) {
    if (file.size > 200 * 1024 * 1024) {
      toast.error("File too large (max 200MB).");
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop() ?? "mp4";
    const path = `${userId}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("kiddo-videos").upload(path, file, {
      upsert: false,
      contentType: file.type,
    });
    setUploading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setStoragePath(path);
    toast.success("Uploaded. Add title & duration, then submit.");
  }

  return (
    <form
      className="grid gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const d = Number(duration);
        if (!title.trim() || !Number.isFinite(d) || d <= 0) {
          toast.error("Title and duration required.");
          return;
        }
        if (d > 300) {
          toast.error("Max 5 minutes (300 seconds).");
          return;
        }
        if (!url.trim() && !storagePath) {
          toast.error("Provide a link or upload a file.");
          return;
        }
        onSubmit({
          title: title.trim(),
          description: desc.trim() || undefined,
          topic: topic.trim() || undefined,
          videoUrl: url.trim() || undefined,
          storagePath: storagePath ?? undefined,
          durationSeconds: Math.floor(d),
        });
        setTitle(""); setDesc(""); setTopic(""); setUrl(""); setDuration(""); setStoragePath(null);
      }}
    >
      <input className="kid-input" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
      <div className="flex gap-2 flex-wrap">
        <input className="kid-input flex-1 min-w-[180px]" placeholder="Topic (e.g. saving, investing)" value={topic} onChange={(e) => setTopic(e.target.value)} maxLength={60} />
        <input className="kid-input" style={{ width: 160 }} placeholder="Duration (sec)" inputMode="numeric" value={duration} onChange={(e) => setDuration(e.target.value)} />
      </div>
      <textarea className="kid-input" placeholder="What's it about? (no emails or phone numbers)" value={desc} onChange={(e) => setDesc(e.target.value)} rows={2} maxLength={1000} />
      <input className="kid-input" placeholder="YouTube / Vimeo URL (or upload below)" value={url} onChange={(e) => setUrl(e.target.value)} />
      <label className="kid-btn kid-btn-ghost self-start cursor-pointer" style={{ minHeight: 48 }}>
        {uploading ? "Uploading…" : storagePath ? "✓ File uploaded — replace" : "Upload MP4"}
        <input
          type="file"
          accept="video/mp4,video/webm,video/quicktime"
          className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
        />
      </label>
      <button type="submit" className="kid-btn kid-btn-primary self-start" disabled={pending || uploading}>
        Submit for parent review
      </button>
    </form>
  );
}
