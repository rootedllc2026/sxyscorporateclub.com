/**
 * /economy-bites/saved — the user's saved video bookmarks.
 */
import * as React from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { EconomyBitesNav } from "@/components/videos/EconomyBitesNav";
import { VideoCard } from "@/components/videos/VideoCard";
import { UpgradeModal } from "@/components/sxy/UpgradeModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { canAccessVideo, type VideoRow } from "@/lib/videos/shared";

export const Route = createFileRoute("/economy-bites/saved")({
  head: () => ({
    meta: [{ title: "Saved Videos — SXY's Corporate Club" }],
  }),
  component: () => (
    <AppLayout title="Saved Videos">
      <SavedPage />
    </AppLayout>
  ),
});

interface SaveJoinRow {
  video_id: string;
  videos: VideoRow | null;
}

function SavedPage() {
  const { currentUser, userTier, isAdmin } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [upgradeOpen, setUpgradeOpen] = React.useState(false);

  const { data: saves = [], isLoading } = useQuery({
    queryKey: ["videos", "savedList", currentUser?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("video_saves")
        .select("video_id, videos(*)")
        .eq("user_id", currentUser!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as SaveJoinRow[];
    },
    enabled: !!currentUser,
  });

  async function remove(videoId: string) {
    await supabase
      .from("video_saves")
      .delete()
      .eq("user_id", currentUser!.id)
      .eq("video_id", videoId);
    qc.invalidateQueries({ queryKey: ["videos", "savedList"] });
    qc.invalidateQueries({ queryKey: ["videos", "savedCount"] });
  }

  const items = saves.map((s) => s.videos).filter(Boolean) as VideoRow[];

  return (
    <div className="space-y-6">
      <EconomyBitesNav />

      {isLoading ? (
        <p className="text-sm text-text-muted">Loading…</p>
      ) : items.length === 0 ? (
        <SxyCard className="text-center text-sm text-text-muted">
          You haven't saved any videos yet. Tap the bookmark icon on a video to
          save it for later.
        </SxyCard>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((v) => {
            const locked = !canAccessVideo(v.access_level, userTier, isAdmin);
            return (
              <VideoCard
                key={v.id}
                video={v}
                locked={locked}
                saved
                showRemove
                onClick={() =>
                  locked
                    ? setUpgradeOpen(true)
                    : navigate({ to: "/economy-bites/$id", params: { id: v.id } })
                }
                onToggleSave={() => remove(v.id)}
              />
            );
          })}
        </div>
      )}

      <UpgradeModal open={upgradeOpen} onOpenChange={setUpgradeOpen} />
    </div>
  );
}
