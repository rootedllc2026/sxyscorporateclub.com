import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  sendResendEmail,
  ADMIN_NOTIFICATION_RECIPIENTS,
} from "@/server/email/resend";
import {
  buildBookingConfirmed,
  buildBookingAdminNotification,
  buildMembershipUpgrade,
} from "@/server/email/templates";

/**
 * Stripe webhook handler.
 *
 * Endpoint:    /api/public/stripe-webhook
 * Stripe URL:  https://<your-domain>/api/public/stripe-webhook
 *
 * Handles:
 *   • payment_intent.succeeded         → confirm booking + record payout owed
 *   • payment_intent.payment_failed    → mark booking failed
 *   • customer.subscription.created    → set profile tier
 *   • customer.subscription.updated    → sync profile tier + status
 *   • customer.subscription.deleted    → downgrade profile to free
 *   • invoice.payment_succeeded        → keep subscription_status fresh
 *
 * Signature verification uses Web Crypto (HMAC-SHA256) so the route runs
 * cleanly in the Cloudflare Worker SSR runtime — no Node-only `stripe` SDK
 * is required.
 *
 * Required env vars (already configured as project secrets):
 *   - STRIPE_WEBHOOK_SECRET
 *   - SXY_SUPABASE_URL
 *   - SXY_SUPABASE_SERVICE_ROLE_KEY
 */

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Stripe-Signature, stripe-signature",
} as const;

type StripeEvent = {
  id: string;
  type: string;
  data: { object: Record<string, unknown> };
};

/**
 * Verify a Stripe webhook signature.
 * Stripe-Signature header looks like: `t=1492774577,v1=5257a...`
 */
async function verifyStripeSignature(
  payload: string,
  header: string | null,
  secret: string,
  toleranceSeconds = 300,
): Promise<boolean> {
  if (!header) return false;

  const parts = header.split(",").reduce<Record<string, string[]>>(
    (acc, part) => {
      const [k, v] = part.split("=");
      if (!k || !v) return acc;
      (acc[k] ??= []).push(v);
      return acc;
    },
    {},
  );

  const timestamp = parts["t"]?.[0];
  const signatures = parts["v1"] ?? [];
  if (!timestamp || signatures.length === 0) return false;

  // Reject events older than the tolerance window.
  const ts = Number(timestamp);
  if (!Number.isFinite(ts)) return false;
  const ageSeconds = Math.floor(Date.now() / 1000) - ts;
  if (Math.abs(ageSeconds) > toleranceSeconds) return false;

  const signedPayload = `${timestamp}.${payload}`;
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sigBuf = await crypto.subtle.sign("HMAC", key, enc.encode(signedPayload));
  const expected = Array.from(new Uint8Array(sigBuf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  // Constant-time-ish comparison.
  return signatures.some((sig) => {
    if (sig.length !== expected.length) return false;
    let mismatch = 0;
    for (let i = 0; i < sig.length; i++) {
      mismatch |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
    }
    return mismatch === 0;
  });
}

/* ─── Tier mapping ─────────────────────────────────────────────────────── */

/**
 * Resolve the membership tier for a Stripe subscription event. Lookup order:
 *
 *   1. Match the subscription's first price.id against the env-configured
 *      price IDs (STRIPE_PRICE_PAID / STRIPE_PRICE_INVESTING → "paid",
 *      STRIPE_PRICE_ANNUAL → "annual", STRIPE_PRICE_VIP → "vip").
 *   2. Fall back to subscription.metadata.tier if the customer was created
 *      via our checkout flow with explicit metadata.
 *   3. Fall back to a fuzzy match on price.lookup_key / price.nickname.
 *
 * Returns null when nothing matched so the caller can default to "paid".
 */
function tierFromSubscription(
  sub: Record<string, unknown>,
): "free" | "paid" | "annual" | "vip" | null {
  const items = (sub.items as { data?: Array<Record<string, unknown>> })?.data;
  const price = items?.[0]?.price as
    | {
        id?: string | null;
        lookup_key?: string | null;
        nickname?: string | null;
      }
    | undefined;

  // 1. env-configured price IDs (primary).
  const priceId = price?.id ?? "";
  if (priceId) {
    const paidId =
      process.env.STRIPE_PRICE_PAID ?? process.env.STRIPE_PRICE_INVESTING;
    const annualId = process.env.STRIPE_PRICE_ANNUAL;
    const vipId = process.env.STRIPE_PRICE_VIP;
    if (paidId && priceId === paidId) return "paid";
    if (annualId && priceId === annualId) return "annual";
    if (vipId && priceId === vipId) return "vip";
  }

  // 2. explicit metadata.tier.
  const meta = (sub.metadata ?? {}) as Record<string, string>;
  const metaTier = meta.tier as
    | "free"
    | "paid"
    | "annual"
    | "vip"
    | undefined;
  if (metaTier && ["free", "paid", "annual", "vip"].includes(metaTier)) {
    return metaTier;
  }

  // 3. lookup_key / nickname fallback.
  const lookup = price?.lookup_key ?? price?.nickname ?? "";
  if (lookup.includes("annual")) return "annual";
  if (lookup.includes("vip")) return "vip";
  if (lookup.includes("paid") || lookup.includes("monthly") || lookup.includes("invest"))
    return "paid";

  return null;
}

/**
 * Fetch a Stripe customer's email when we only have the customer id.
 * Used as a fallback for subscription events when the profile hasn't yet
 * been linked via stripe_customer_id (e.g. self-serve checkout flows where
 * the customer was created in Stripe before we wrote the link in our DB).
 */
async function fetchStripeCustomerEmail(
  customerId: string,
): Promise<string | null> {
  const stripeKey = process.env.STRIPE_SECRET_KEY;
  if (!stripeKey) return null;

  try {
    const res = await fetch(
      `https://api.stripe.com/v1/customers/${customerId}`,
      {
        headers: {
          Authorization: `Bearer ${stripeKey}`,
        },
      },
    );
    if (!res.ok) {
      console.warn(
        "[stripe-webhook] customer fetch failed",
        res.status,
        await res.text(),
      );
      return null;
    }
    const customer = (await res.json()) as { email?: string | null };
    return customer.email ?? null;
  } catch (err) {
    console.error("[stripe-webhook] customer fetch threw", err);
    return null;
  }
}

/* ─── Event handlers ───────────────────────────────────────────────────── */

async function handlePaymentIntentSucceeded(
  pi: Record<string, unknown>,
): Promise<void> {
  const paymentIntentId = pi.id as string;
  const metadata = (pi.metadata ?? {}) as Record<string, string>;
  const bookingId = metadata.booking_id;

  // Look up the booking either by metadata.booking_id (preferred) or by
  // payment_intent_id we already wrote when creating the PI.
  let query = supabaseAdmin
    .from("bookings")
    .select(
      "id, business_page_id, provider_id, buyer_id, service_id, net_to_provider, total_amount, booked_date, booked_time",
    )
    .limit(1);
  query = bookingId
    ? query.eq("id", bookingId)
    : query.eq("payment_intent_id", paymentIntentId);

  const { data: booking, error: fetchErr } = await query.maybeSingle();
  if (fetchErr) {
    console.error("[stripe-webhook] booking lookup failed", fetchErr);
    return;
  }
  if (!booking) {
    console.warn(
      "[stripe-webhook] payment_intent.succeeded — no matching booking",
      paymentIntentId,
    );
    return;
  }

  const { error: updateErr } = await supabaseAdmin
    .from("bookings")
    .update({
      status: "confirmed",
      payment_intent_id: paymentIntentId,
      paid_at: new Date().toISOString(),
    })
    .eq("id", booking.id);

  if (updateErr) {
    console.error("[stripe-webhook] booking update failed", updateErr);
    return;
  }

  // Bump aggregates on the business_page.
  const { data: page } = await supabaseAdmin
    .from("business_pages")
    .select("total_bookings, total_revenue, business_name")
    .eq("id", booking.business_page_id)
    .single();

  if (page) {
    await supabaseAdmin
      .from("business_pages")
      .update({
        total_bookings: (page.total_bookings ?? 0) + 1,
        total_revenue:
          Number(page.total_revenue ?? 0) + Number(booking.net_to_provider ?? 0),
      })
      .eq("id", booking.business_page_id);
  }

  // ── Side effects: emails + reminder scheduling ─────────────────────────
  // Best-effort: never throw here, otherwise Stripe will keep retrying the
  // webhook for transient email failures even though the booking is fine.
  try {
    // Resolve buyer + provider profile + service for the email payload.
    const [{ data: buyer }, { data: provider }, serviceRes] = await Promise.all([
      supabaseAdmin
        .from("profiles")
        .select("email, full_name, phone")
        .eq("id", booking.buyer_id)
        .maybeSingle(),
      supabaseAdmin
        .from("profiles")
        .select("full_name")
        .eq("id", booking.provider_id)
        .maybeSingle(),
      booking.service_id
        ? supabaseAdmin
            .from("referral_services")
            .select("name")
            .eq("id", booking.service_id)
            .maybeSingle()
        : Promise.resolve({ data: null as { name?: string } | null }),
    ]);

    const serviceName =
      serviceRes?.data?.name ||
      page?.business_name ||
      "your booking";
    const providerName = provider?.full_name ?? "your provider";
    const buyerEmail = buyer?.email ?? null;

    // 1. Confirmation to client.
    if (buyerEmail) {
      const { subject, html } = buildBookingConfirmed({
        clientFullName: buyer?.full_name,
        serviceName,
        providerName,
        bookedDate: booking.booked_date,
        bookedTime: booking.booked_time,
      });
      try {
        await sendResendEmail({
          to: buyerEmail,
          subject,
          html,
          tag: "booking-confirmation",
        });
      } catch (e) {
        console.warn("[stripe-webhook] booking-confirmation email failed", e);
      }
    }

    // 2. Admin notification.
    try {
      const { subject, html } = buildBookingAdminNotification({
        clientFullName: buyer?.full_name ?? buyerEmail ?? "A client",
        clientEmail: buyerEmail ?? "(unknown)",
        clientPhone: buyer?.phone ?? null,
        serviceName,
        bookedDate: booking.booked_date,
        bookedTime: booking.booked_time,
        totalAmount: Number(booking.total_amount ?? 0),
        netAmount: Number(booking.net_to_provider ?? 0),
      });
      await sendResendEmail({
        to: ADMIN_NOTIFICATION_RECIPIENTS,
        subject,
        html,
        replyTo: buyerEmail ?? undefined,
        tag: "booking-admin-notification",
      });
    } catch (e) {
      console.warn("[stripe-webhook] booking-admin-notify failed", e);
    }

    // 3. Schedule 24-hour reminder (one-shot via scheduled_emails table).
    if (buyerEmail && booking.booked_date) {
      const sendAt = new Date(
        `${booking.booked_date}T${booking.booked_time ?? "09:00"}:00Z`,
      );
      sendAt.setUTCHours(sendAt.getUTCHours() - 24);
      // Only schedule if the reminder time is still in the future.
      if (sendAt.getTime() > Date.now()) {
        const { error: schedErr } = await supabaseAdmin
          .from("scheduled_emails")
          .insert({
            kind: "booking-reminder-24h",
            reference_id: booking.id,
            recipient: buyerEmail,
            send_at: sendAt.toISOString(),
            payload: {
              service_name: serviceName,
              booked_date: booking.booked_date,
              booked_time: booking.booked_time,
              client_name: buyer?.full_name ?? null,
            },
          });
        if (schedErr) {
          console.warn("[stripe-webhook] reminder schedule failed", schedErr);
        }
      }
    }
  } catch (sideErr) {
    console.warn("[stripe-webhook] booking side effects failed", sideErr);
  }
}

async function handlePaymentIntentFailed(
  pi: Record<string, unknown>,
): Promise<void> {
  const paymentIntentId = pi.id as string;
  const metadata = (pi.metadata ?? {}) as Record<string, string>;
  const bookingId = metadata.booking_id;

  const query = supabaseAdmin
    .from("bookings")
    .update({ status: "cancelled" });

  const { error } = bookingId
    ? await query.eq("id", bookingId)
    : await query.eq("payment_intent_id", paymentIntentId);

  if (error) {
    console.error("[stripe-webhook] booking failure update failed", error);
  }
}

async function handleSubscriptionChange(
  sub: Record<string, unknown>,
  options: { cancelToFree?: boolean } = {},
): Promise<void> {
  const customerId = sub.customer as string | undefined;
  const subscriptionId = sub.id as string | undefined;
  if (!customerId || !subscriptionId) return;

  const status = sub.status as string | undefined;
  const currentPeriodEnd = sub.current_period_end as number | undefined;
  const nextBillingDate =
    typeof currentPeriodEnd === "number"
      ? new Date(currentPeriodEnd * 1000).toISOString()
      : null;

  const tier = options.cancelToFree
    ? "free"
    : tierFromSubscription(sub) ?? "paid";

  // 1. Try to find the profile by stripe_customer_id (set during checkout).
  let profileId: string | null = null;
  let previousTier: string | null = null;
  let profileEmail: string | null = null;
  let profileFullName: string | null = null;
  {
    const { data: profile, error: lookupErr } = await supabaseAdmin
      .from("profiles")
      .select("id, tier, email, full_name")
      .eq("stripe_customer_id", customerId)
      .maybeSingle();

    if (lookupErr) {
      console.error("[stripe-webhook] profile lookup by customer failed", lookupErr);
      return;
    }
    if (profile) {
      profileId = profile.id;
      previousTier = profile.tier ?? null;
      profileEmail = profile.email ?? null;
      profileFullName = profile.full_name ?? null;
    }
  }

  // 2. Fall back to email lookup via Stripe API. Self-serve checkout flows
  //    may create the Stripe customer before we've persisted the link.
  if (!profileId && !options.cancelToFree) {
    const email = await fetchStripeCustomerEmail(customerId);
    if (email) {
      const { data: profileByEmail, error: emailErr } = await supabaseAdmin
        .from("profiles")
        .select("id, tier, email, full_name")
        .eq("email", email)
        .maybeSingle();

      if (emailErr) {
        console.error("[stripe-webhook] profile lookup by email failed", emailErr);
      } else if (profileByEmail) {
        profileId = profileByEmail.id;
        previousTier = profileByEmail.tier ?? null;
        profileEmail = profileByEmail.email ?? null;
        profileFullName = profileByEmail.full_name ?? null;
      }
    }
  }

  if (!profileId) {
    console.warn(
      "[stripe-webhook] subscription event — no profile for customer",
      customerId,
    );
    return;
  }

  const updatePayload: Record<string, unknown> = {
    tier,
    stripe_customer_id: customerId,
    stripe_subscription_id: options.cancelToFree ? null : subscriptionId,
    subscription_status: options.cancelToFree ? "inactive" : status ?? "active",
  };
  if (!options.cancelToFree && nextBillingDate) {
    updatePayload.next_billing_date = nextBillingDate;
  }

  const { error: updateErr } = await supabaseAdmin
    .from("profiles")
    .update(updatePayload as never)
    .eq("id", profileId);

  if (updateErr) {
    console.error("[stripe-webhook] profile tier update failed", updateErr);
    return;
  }

  // Send membership-upgrade email when tier actually changes (and we're not
  // downgrading to free via cancellation). Best-effort.
  if (
    !options.cancelToFree &&
    profileEmail &&
    tier !== "free" &&
    previousTier !== tier
  ) {
    try {
      const { subject, html } = buildMembershipUpgrade({
        fullName: profileFullName,
        tier: tier as "paid" | "annual" | "vip",
      });
      await sendResendEmail({
        to: profileEmail,
        subject,
        html,
        tag: "membership-upgrade",
      });
    } catch (e) {
      console.warn("[stripe-webhook] membership-upgrade email failed", e);
    }
  }
}

async function handleInvoicePaymentSucceeded(
  invoice: Record<string, unknown>,
): Promise<void> {
  const customerId = invoice.customer as string | undefined;
  if (!customerId) return;

  const { error } = await supabaseAdmin
    .from("profiles")
    .update({ subscription_status: "active" })
    .eq("stripe_customer_id", customerId);

  if (error) {
    console.error("[stripe-webhook] invoice update failed", error);
  }
}

/* ─── Route ────────────────────────────────────────────────────────────── */

export const Route = createFileRoute("/api/public/stripe-webhook")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: corsHeaders }),

      GET: async () =>
        new Response(
          JSON.stringify({
            ok: true,
            message:
              "Stripe webhook endpoint. POST events from Stripe to this URL.",
          }),
          {
            status: 200,
            headers: { "Content-Type": "application/json", ...corsHeaders },
          },
        ),

      POST: async ({ request }) => {
        const secret = process.env.STRIPE_WEBHOOK_SECRET;
        if (!secret) {
          console.error("[stripe-webhook] STRIPE_WEBHOOK_SECRET not set");
          return new Response("Server misconfigured", {
            status: 500,
            headers: corsHeaders,
          });
        }

        const signature =
          request.headers.get("stripe-signature") ??
          request.headers.get("Stripe-Signature");
        const payload = await request.text();

        const valid = await verifyStripeSignature(payload, signature, secret);
        if (!valid) {
          console.warn("[stripe-webhook] invalid signature");
          return new Response("Invalid signature", {
            status: 401,
            headers: corsHeaders,
          });
        }

        let event: StripeEvent;
        try {
          event = JSON.parse(payload) as StripeEvent;
        } catch {
          return new Response("Invalid JSON", {
            status: 400,
            headers: corsHeaders,
          });
        }

        try {
          switch (event.type) {
            case "payment_intent.succeeded":
              await handlePaymentIntentSucceeded(event.data.object);
              break;
            case "payment_intent.payment_failed":
              await handlePaymentIntentFailed(event.data.object);
              break;
            case "customer.subscription.created":
            case "customer.subscription.updated":
              await handleSubscriptionChange(event.data.object);
              break;
            case "customer.subscription.deleted":
              await handleSubscriptionChange(event.data.object, {
                cancelToFree: true,
              });
              break;
            case "invoice.payment_succeeded":
              await handleInvoicePaymentSucceeded(event.data.object);
              break;
            default:
              // Acknowledge unhandled events so Stripe stops retrying.
              console.log("[stripe-webhook] unhandled event", event.type);
          }
        } catch (err) {
          console.error(
            "[stripe-webhook] handler crashed",
            event.type,
            err,
          );
          // Return 500 so Stripe retries.
          return new Response(
            JSON.stringify({ received: false, error: String(err) }),
            {
              status: 500,
              headers: { "Content-Type": "application/json", ...corsHeaders },
            },
          );
        }

        return new Response(JSON.stringify({ received: true }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      },
    },
  },
});
