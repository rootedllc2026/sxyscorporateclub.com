/**
 * /events/recordings — list of past completed events with archived recordings.
 *
 * Access: each event has its own `recording_access` (defaults to access_level
 * if null). VIP-locked recordings show a lock overlay and don't open.
 */
import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Lock, Play, Video } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { UpgradeModal } from "@/components/sxy/UpgradeModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { canAccessEvent, type EventRow } from "@/lib/events/shared";

export const Route = createFileRoute("/events/recordings")({
  head: () => ({ meta: [{ title: "Past Recordings — SXY's Corporate Club" }] }),
  component: () => (
    <AppLayout title="Past Recordings">
      <RecordingsPage />
    </AppLayout>
  ),
});

function RecordingsPage() {
  const { userTier, isAdmin } = useAuth();
  const [upgradeOpen, setUpgradeOpen] = React.useState(false);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["events", "recordings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("events")
        .select("*")
        .eq("status", "completed")
        .not("recording_url", "is", null)
        .order("starts_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as EventRow[];
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Link
          to="/events"
          className="inline-flex items-center gap-2 rounded-full border border-border-base/60 bg-charcoal-card px-4 py-1.5 text-xs text-text-muted hover:border-border-teal hover:text-text-primary"
        >
          ← Upcoming events
        </Link>
      </div>

      {isLoading ? (
        <p className="text-sm text-text-muted">Loading recordings…</p>
      ) : rows.length === 0 ? (
        <SxyCard className="text-center text-sm text-text-muted">
          No archived recordings yet.
        </SxyCard>
      ) : (
        <ul className="space-y-3">
          {rows.map((ev) => {
            const reqAccess = ev.recording_access ?? ev.access_level;
            const accessible = canAccessEvent(reqAccess, userTier, isAdmin);
            return (
              <li key={ev.id}>
                <SxyCard className="flex items-center gap-4 p-3">
                  <div
                    className="grid h-16 w-28 shrink-0 place-items-center rounded-lg"
                    style={{
                      background:
                        reqAccess === "vip"
                          ? "linear-gradient(135deg, oklch(0.42 0.09 85 / 0.85), oklch(0.18 0.025 85 / 0.95))"
                          : "linear-gradient(135deg, oklch(0.55 0.085 210 / 0.55), oklch(0.22 0.035 215 / 0.95))",
                    }}
                  >
                    {accessible ? (
                      <Play
                        className="h-6 w-6 text-text-primary"
                        fill="currentColor"
                      />
                    ) : (
                      <Lock className="h-5 w-5 text-gold" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <Tag variant={reqAccess === "vip" ? "gold" : "teal"}>
                        {reqAccess === "vip" ? "VIP" : "All members"}
                      </Tag>
                      <span className="text-[11px] text-text-dim">
                        {new Date(ev.starts_at).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="mt-1 truncate font-display text-base text-text-primary">
                      {ev.title}
                    </h3>
                    <p className="text-xs text-text-muted">
                      {ev.host_name ? `Hosted by ${ev.host_name} · ` : ""}
                      {ev.duration_min ? `${ev.duration_min} min · ` : ""}
                      {ev.registrant_count.toLocaleString()} attended
                    </p>
                  </div>

                  {accessible ? (
                    <SxyButton size="sm" variant="outline" asChild>
                      <a
                        href={ev.recording_url ?? "#"}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <Video className="h-3.5 w-3.5" /> Watch
                      </a>
                    </SxyButton>
                  ) : (
                    <SxyButton
                      size="sm"
                      variant="gold"
                      onClick={() => setUpgradeOpen(true)}
                    >
                      <Lock className="h-3.5 w-3.5" /> Unlock
                    </SxyButton>
                  )}
                </SxyCard>
              </li>
            );
          })}
        </ul>
      )}

      <UpgradeModal open={upgradeOpen} onOpenChange={setUpgradeOpen} />
    </div>
  );
}
