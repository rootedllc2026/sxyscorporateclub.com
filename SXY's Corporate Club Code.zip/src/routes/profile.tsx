import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { AvatarBadge, AVATAR_COLORS } from "@/components/layout/Avatar";
import { AuthInput, Field } from "@/components/auth/AuthInput";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "My Profile — SXY's Corporate Club" }] }),
  component: ProfileRoute,
});

function ProfileRoute() {
  return (
    <AppLayout title="My Profile">
      <ProfileContent />
    </AppLayout>
  );
}

const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA",
  "KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT",
  "VA","WA","WV","WI","WY","DC",
];

const TIER_LABEL: Record<string, string> = {
  free: "Free Member",
  paid: "Investing Member",
  annual: "Annual Member",
  vip: "VIP",
};

function ProfileContent() {
  const { userProfile, currentUser, isAdmin, refreshProfile } = useAuth();

  const [form, setForm] = React.useState(() => ({
    full_name: userProfile?.full_name ?? "",
    bio: userProfile?.bio ?? "",
    business_name: userProfile?.business_name ?? "",
    city: userProfile?.city ?? "",
    state: userProfile?.state ?? "",
    industry: userProfile?.industry ?? "",
    website_url: userProfile?.website_url ?? "",
    avatar_color: userProfile?.avatar_color ?? "teal",
  }));

  // Re-seed the form when the profile finishes loading from Supabase.
  React.useEffect(() => {
    if (!userProfile) return;
    setForm({
      full_name: userProfile.full_name ?? "",
      bio: userProfile.bio ?? "",
      business_name: userProfile.business_name ?? "",
      city: userProfile.city ?? "",
      state: userProfile.state ?? "",
      industry: userProfile.industry ?? "",
      website_url: userProfile.website_url ?? "",
      avatar_color: userProfile.avatar_color ?? "teal",
    });
  }, [userProfile]);

  const [saving, setSaving] = React.useState(false);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!currentUser) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: form.full_name.trim() || null,
        bio: form.bio.trim() || null,
        business_name: form.business_name.trim() || null,
        city: form.city.trim() || null,
        state: form.state || null,
        industry: form.industry.trim() || null,
        website_url: form.website_url.trim() || null,
        avatar_color: form.avatar_color,
      })
      .eq("id", currentUser.id);
    setSaving(false);
    if (error) {
      toast.error("Couldn't save profile", { description: error.message });
      return;
    }
    toast.success("Profile updated");
    await refreshProfile();
  }

  const memberSince = userProfile?.created_at
    ? new Date(userProfile.created_at).toLocaleDateString(undefined, {
        month: "long",
        year: "numeric",
      })
    : "—";

  return (
    <form onSubmit={handleSave} className="space-y-8">
      {/* Identity card */}
      <SxyCard accent className="flex flex-col gap-6 sm:flex-row sm:items-center">
        <AvatarBadge
          name={form.full_name || userProfile?.full_name}
          email={currentUser?.email}
          colorKey={form.avatar_color}
          size={96}
        />
        <div className="min-w-0 flex-1">
          <p className="font-display text-2xl text-text-primary">
            {form.full_name || currentUser?.email}
          </p>
          <p className="mt-1 text-sm text-text-muted">{currentUser?.email}</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Tag variant="gold">{TIER_LABEL[userProfile?.tier ?? "free"]}</Tag>
            {isAdmin ? <Tag variant="teal">Admin</Tag> : null}
            <Tag variant="gray">Member since {memberSince}</Tag>
          </div>
        </div>
        <div className="flex flex-col items-start gap-2">
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim">
            Avatar color
          </p>
          <div className="flex gap-2">
            {AVATAR_COLORS.map((color) => (
              <button
                key={color}
                type="button"
                aria-label={`Use ${color} avatar`}
                onClick={() => update("avatar_color", color)}
                className={`h-7 w-7 rounded-full ring-offset-2 ring-offset-charcoal-card transition ${
                  form.avatar_color === color
                    ? "ring-2 ring-teal-mid"
                    : "ring-1 ring-border-base hover:ring-border-teal"
                }`}
              >
                <AvatarBadge
                  colorKey={color}
                  name=" "
                  size={28}
                  className="!shadow-none !ring-0"
                />
              </button>
            ))}
          </div>
        </div>
      </SxyCard>

      {/* Editable details */}
      <SxyCard>
        <h2 className="font-display text-lg text-teal-light">Profile details</h2>
        <p className="mt-1 text-xs text-text-dim">
          Public to other members in the Exchange and on your business page.
        </p>

        <div className="mt-6 grid gap-5 sm:grid-cols-2">
          <Field label="Full name" htmlFor="full_name">
            <AuthInput
              id="full_name"
              value={form.full_name}
              onChange={(e) => update("full_name", e.target.value)}
              placeholder="Jane Doe"
            />
          </Field>
          <Field label="Business name" htmlFor="business_name">
            <AuthInput
              id="business_name"
              value={form.business_name}
              onChange={(e) => update("business_name", e.target.value)}
              placeholder="Acme LLC"
            />
          </Field>
          <Field label="City" htmlFor="city">
            <AuthInput
              id="city"
              value={form.city}
              onChange={(e) => update("city", e.target.value)}
              placeholder="Atlanta"
            />
          </Field>
          <Field label="State" htmlFor="state">
            <select
              id="state"
              value={form.state}
              onChange={(e) => update("state", e.target.value)}
              className="block h-11 w-full rounded-xl border border-border-base bg-charcoal px-4 text-sm text-text-primary transition focus:border-teal-mid focus:outline-none focus:ring-2 focus:ring-teal-mid/30"
            >
              <option value="">Select state…</option>
              {US_STATES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Industry" htmlFor="industry">
            <AuthInput
              id="industry"
              value={form.industry}
              onChange={(e) => update("industry", e.target.value)}
              placeholder="Construction, real estate…"
            />
          </Field>
          <Field label="Website" htmlFor="website_url">
            <AuthInput
              id="website_url"
              value={form.website_url}
              onChange={(e) => update("website_url", e.target.value)}
              placeholder="https://…"
              type="url"
            />
          </Field>
          <div className="sm:col-span-2">
            <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.16em] text-text-dim">
              Bio
            </label>
            <textarea
              value={form.bio}
              onChange={(e) => update("bio", e.target.value)}
              rows={4}
              maxLength={400}
              placeholder="Tell other members what you do."
              className="w-full rounded-xl border border-border-base bg-charcoal-card p-3 text-sm text-text-primary outline-none transition focus:border-border-teal"
            />
            <p className="mt-1 text-right text-[10px] text-text-dim">
              {form.bio.length}/400
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <SxyButton type="submit" variant="primary" disabled={saving}>
            {saving ? "Saving…" : "Save Changes"}
          </SxyButton>
        </div>
      </SxyCard>

      {/* Membership */}
      <SxyCard accent>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="font-display text-lg text-teal-light">Membership</h2>
            <p className="mt-1 text-sm text-text-muted">
              Current plan:{" "}
              <span className="font-semibold text-gold-light">
                {TIER_LABEL[userProfile?.tier ?? "free"]}
              </span>
            </p>
          </div>
          <SxyButton variant="gold" size="sm" asChild>
            <Link to="/membership">Upgrade plan</Link>
          </SxyButton>
        </div>
      </SxyCard>
    </form>
  );
}
