import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell, AuthError, AuthSuccess } from "@/components/auth/AuthShell";
import { AuthInput, Field } from "@/components/auth/AuthInput";
import { SxyButton } from "@/components/sxy/SxyButton";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset Password — SXY's Corporate Club" },
      {
        name: "description",
        content: "Request a password reset link for your SXY's Corporate Club account.",
      },
    ],
  }),
  component: ResetPasswordPage,
});

const emailSchema = z.string().trim().email("Enter a valid email").max(255);

function ResetPasswordPage() {
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [success, setSuccess] = React.useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const fd = new FormData(e.currentTarget);
    const parsed = emailSchema.safeParse(fd.get("email"));
    if (!parsed.success) {
      setError(parsed.error.errors[0]?.message ?? "Invalid email");
      return;
    }

    setSubmitting(true);
    try {
      const redirectTo =
        typeof window !== "undefined"
          ? `${window.location.origin}/update-password`
          : undefined;
      const { error: rpfeError } = await supabase.auth.resetPasswordForEmail(
        parsed.data,
        { redirectTo },
      );
      if (rpfeError) {
        setError(rpfeError.message);
        return;
      }
      setSuccess(
        "Check your email for a reset link. It may take a minute to arrive.",
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthShell
      title="Reset Password"
      subtitle="We'll email you a secure link to set a new password."
      footer={
        <>
          Remembered it?{" "}
          <Link to="/login" className="text-gold hover:text-gold-light">
            Back to sign in
          </Link>
        </>
      }
    >
      <form onSubmit={onSubmit} className="space-y-5" noValidate>
        <Field label="Email address" htmlFor="email">
          <AuthInput
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            placeholder="you@business.com"
          />
        </Field>

        <AuthError message={error} />
        <AuthSuccess message={success} />

        <SxyButton
          type="submit"
          variant="primary"
          size="lg"
          disabled={submitting}
          className="w-full"
        >
          {submitting ? "Sending…" : "Send Reset Link"}
        </SxyButton>
      </form>
    </AuthShell>
  );
}
