/**
 * /events/create — admin form for new events.
 *
 * Inserts a row into public.events. If `post_to_general` is on we ALSO insert
 * an announcement message into the #general channel via the messages table.
 */
import * as React from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import type { EventAccess } from "@/lib/events/shared";

export const Route = createFileRoute("/events/create")({
  head: () => ({ meta: [{ title: "Create Event — SXY's Corporate Club" }] }),
  component: () => (
    <AdminRoute>
      <AppLayout title="Create Event">
        <CreatePage />
      </AppLayout>
    </AdminRoute>
  ),
});

function CreatePage() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [pending, setPending] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setPending(true);
    try {
      const f = new FormData(e.currentTarget);
      const date = String(f.get("starts_date") ?? "");
      const time = String(f.get("starts_time") ?? "");
      const startsAt = new Date(`${date}T${time}`).toISOString();

      const { data, error: err } = await supabase
        .from("events")
        .insert({
          title: String(f.get("title") ?? "").trim(),
          description: String(f.get("description") ?? ""),
          icon_emoji: String(f.get("icon_emoji") ?? "📅"),
          host_name: String(f.get("host_name") ?? "") || null,
          starts_at: startsAt,
          duration_min: Number(f.get("duration_min") ?? 60),
          platform: String(f.get("platform") ?? "Zoom"),
          join_url: String(f.get("join_url") ?? "") || null,
          access_level: String(f.get("access_level") ?? "free") as EventAccess,
          archive_recording: f.get("archive_recording") === "on",
          notify_members: f.get("notify_members") === "on",
          post_to_general: f.get("post_to_general") === "on",
          created_by: currentUser?.id ?? null,
        })
        .select("id, title, starts_at, post_to_general, icon_emoji")
        .maybeSingle();
      if (err) throw err;

      // Optionally drop an announcement into #general so members see it.
      if (data && data.post_to_general && currentUser) {
        const { data: ch } = await supabase
          .from("channels")
          .select("id")
          .eq("name", "general")
          .maybeSingle();
        if (ch?.id) {
          await supabase.from("messages").insert({
            channel_id: ch.id,
            sender_id: currentUser.id,
            content: `📣 New event: ${data.icon_emoji ?? "📅"} ${data.title} — ${new Date(
              data.starts_at as string,
            ).toLocaleString()}. Register from the Events page.`,
            is_announcement: true,
          });
        }
      }

      navigate({ to: "/events" });
    } catch (e) {
      setError((e as Error).message ?? "Failed to create event.");
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="space-y-6">
      <SxyCard accent>
        <form onSubmit={onSubmit} className="space-y-5">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Title">
              <Input name="title" required placeholder="Q3 Pricing Power Workshop" />
            </Field>
            <Field label="Icon emoji">
              <Input name="icon_emoji" defaultValue="📅" maxLength={4} />
            </Field>
          </div>

          <Field label="Description">
            <Textarea
              name="description"
              rows={4}
              placeholder="What attendees will learn / take away…"
            />
          </Field>

          <div className="grid gap-4 md:grid-cols-3">
            <Field label="Host name">
              <Input name="host_name" placeholder="Tia Edwards" />
            </Field>
            <Field label="Date">
              <Input type="date" name="starts_date" required />
            </Field>
            <Field label="Start time">
              <Input type="time" name="starts_time" required />
            </Field>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <Field label="Duration (min)">
              <Input type="number" name="duration_min" min={5} defaultValue={60} />
            </Field>
            <Field label="Platform">
              <Select name="platform" defaultValue="Zoom">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Zoom">Zoom</SelectItem>
                  <SelectItem value="Google Meet">Google Meet</SelectItem>
                  <SelectItem value="Microsoft Teams">Microsoft Teams</SelectItem>
                  <SelectItem value="In Person">In Person</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Access">
              <Select name="access_level" defaultValue="free">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="annual">Annual</SelectItem>
                  <SelectItem value="vip">VIP</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>

          <Field label="Join URL">
            <Input name="join_url" placeholder="https://zoom.us/j/…" />
          </Field>

          <div className="grid gap-4 md:grid-cols-3">
            <Toggle name="archive_recording" label="Archive recording" defaultChecked />
            <Toggle name="notify_members" label="Notify members" defaultChecked />
            <Toggle name="post_to_general" label="Post to #general" defaultChecked />
          </div>

          {error ? (
            <p className="rounded-md border border-[oklch(0.72_0.18_25/0.4)] bg-[oklch(0.72_0.18_25/0.1)] p-3 text-xs text-danger">
              {error}
            </p>
          ) : null}

          <div className="flex justify-end gap-2">
            <SxyButton
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => navigate({ to: "/events" })}
            >
              Cancel
            </SxyButton>
            <SxyButton type="submit" disabled={pending}>
              {pending ? "Saving…" : "Create event"}
            </SxyButton>
          </div>
        </form>
      </SxyCard>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-text-muted">
        {label}
      </Label>
      {children}
    </label>
  );
}

function Toggle({
  name,
  label,
  defaultChecked,
}: {
  name: string;
  label: string;
  defaultChecked?: boolean;
}) {
  const [on, setOn] = React.useState(!!defaultChecked);
  return (
    <label className="flex items-center justify-between gap-3 rounded-xl border border-border-base/60 bg-charcoal-card-2 px-4 py-3 text-sm text-text-primary">
      <span>{label}</span>
      <input type="hidden" name={name} value={on ? "on" : ""} />
      <Switch checked={on} onCheckedChange={setOn} />
    </label>
  );
}
