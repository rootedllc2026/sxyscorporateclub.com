/**
 * /financials/admin/payouts — Payout queue.
 * Admin can Approve, Mark sent, or Reject pending requests. Status flows:
 *   requested → approved → paid (terminal)
 *   requested → rejected (terminal)
 * Supports row-level actions, bulk approval, an audit log drawer per row,
 * and stamps processed_by + bulk_action_id whenever an admin acts.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { History } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Checkbox } from "@/components/ui/checkbox";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { StatTile } from "@/components/sxy/StatTile";
import { Tag } from "@/components/sxy/Tag";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { notifyByEmail } from "@/lib/financials/notify";
import { sendEmail } from "@/lib/email/send";
import {
  formatDate,
  formatMoney,
  statusTone,
  type PayoutAuditEntry,
  type PayoutRow,
  type PayoutStatus,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/admin/payouts")({
  head: () => ({ meta: [{ title: "Payout Queue — SXY's Corporate Club" }] }),
  component: PayoutQueueRoute,
});

const FILTERS: { key: "open" | "all" | PayoutStatus; label: string }[] = [
  { key: "open", label: "Open" },
  { key: "requested", label: "Requested" },
  { key: "approved", label: "Approved" },
  { key: "processing", label: "Processing" },
  { key: "paid", label: "Paid" },
  { key: "rejected", label: "Rejected" },
  { key: "all", label: "All" },
];

function PayoutQueueRoute() {
  return (
    <AdminRoute>
      <AppLayout title="Payout Queue">
        <PayoutQueueInner />
      </AppLayout>
    </AdminRoute>
  );
}

interface PayoutWithMember extends PayoutRow {
  member_name?: string | null;
  member_email?: string | null;
  processor_name?: string | null;
}

function PayoutQueueInner() {
  const qc = useQueryClient();
  const { currentUser } = useAuth();
  const [filter, setFilter] = React.useState<(typeof FILTERS)[number]["key"]>(
    "open",
  );
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [auditFor, setAuditFor] = React.useState<PayoutWithMember | null>(null);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["financials", "admin", "payouts"],
    queryFn: async () => {
      const { data } = await supabase
        .from("payouts")
        .select(
          "*, profile:profiles!payouts_user_id_fkey(full_name,email), processor:profiles!payouts_processed_by_fkey(full_name)",
        )
        .order("requested_at", { ascending: false })
        .limit(500);
      return (data ?? []).map((r) => {
        const profile = (r as unknown as {
          profile?: { full_name?: string | null; email?: string | null };
        }).profile;
        const processor = (r as unknown as {
          processor?: { full_name?: string | null };
        }).processor;
        return {
          ...(r as PayoutRow),
          member_name: profile?.full_name ?? null,
          member_email: profile?.email ?? null,
          processor_name: processor?.full_name ?? null,
        } as PayoutWithMember;
      });
    },
  });

  const filtered = React.useMemo(() => {
    if (filter === "all") return rows;
    if (filter === "open") {
      return rows.filter((r) =>
        ["requested", "approved", "processing"].includes(r.status),
      );
    }
    return rows.filter((r) => r.status === filter);
  }, [rows, filter]);

  // Drop selections that are no longer visible.
  React.useEffect(() => {
    setSelected((prev) => {
      const visibleIds = new Set(filtered.map((r) => r.id));
      const next = new Set<string>();
      for (const id of prev) if (visibleIds.has(id)) next.add(id);
      return next;
    });
  }, [filtered]);

  const totals = React.useMemo(() => {
    let pending = 0;
    let paidMtd = 0;
    let openCount = 0;
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    for (const r of rows) {
      if (["requested", "approved", "processing"].includes(r.status)) {
        pending += Number(r.amount);
        openCount += 1;
      }
      if (r.status === "paid") {
        const t = new Date(r.processed_at ?? r.requested_at);
        if (t >= monthStart) paidMtd += Number(r.amount);
      }
    }
    return { pending, paidMtd, openCount };
  }, [rows]);

  /**
   * Best-effort email notification to a member when their payout transitions
   * to a state worth telling them about (approved / paid / sent / rejected).
   * Reads `notify_on_approval` from platform_settings — silently skips if off.
   * Failures never block the mutation success.
   */
  async function notifyMemberStatusChange(
    rowsToNotify: PayoutWithMember[],
    status: PayoutStatus,
  ) {
    if (!["approved", "paid", "sent", "rejected"].includes(status)) return;
    const { data: settings } = await supabase
      .from("platform_settings")
      .select("notify_on_approval")
      .eq("id", 1)
      .maybeSingle();
    if (!settings?.notify_on_approval) return;
    const verb =
      status === "approved"
        ? "approved"
        : status === "paid"
          ? "paid out"
          : status === "sent"
            ? "sent"
            : "rejected";
    await Promise.all(
      rowsToNotify
        .filter((r) => !!r.member_email)
        .map((r) => {
          // Approved → send the branded Resend "payout-approved" template.
          // Other statuses keep the existing Gmail-connector notification.
          if (status === "approved") {
            return sendEmail({
              kind: "payout-approved",
              to: r.member_email!,
              fullName: r.member_name ?? null,
              amount: Number(r.amount ?? 0),
              method: r.method ?? null,
            });
          }
          return notifyByEmail({
            to: r.member_email!,
            subject: `Your payout has been ${verb}`,
            body: [
              `Hi${r.member_name ? ` ${r.member_name.split(" ")[0]}` : ""},`,
              ``,
              `Your payout request for ${formatMoney(Number(r.amount))} has been ${verb}.`,
              r.method ? `Method: ${r.method}` : null,
              r.destination ? `Destination: ${r.destination}` : null,
              ``,
              `View details in your Financials → Overview.`,
              `— SXY`,
            ]
              .filter(Boolean)
              .join("\n"),
            toastOnError: false,
          });
        }),
    );
  }

  const updateStatus = useMutation({
    mutationFn: async (input: { id: string; status: PayoutStatus }) => {
      const patch: Partial<PayoutRow> = {
        status: input.status,
        processed_by: currentUser?.id ?? null,
      };
      if (["paid", "rejected", "sent"].includes(input.status)) {
        patch.processed_at = new Date().toISOString();
      }
      const { error } = await supabase
        .from("payouts")
        .update(patch)
        .eq("id", input.id);
      if (error) throw error;
      const row = rows.find((r) => r.id === input.id);
      return row ? [row] : [];
    },
    onSuccess: (touched, vars) => {
      toast.success(`Payout marked ${vars.status}.`);
      qc.invalidateQueries({ queryKey: ["financials"] });
      void notifyMemberStatusChange(touched, vars.status);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const bulkAction = useMutation({
    mutationFn: async (input: { ids: string[]; status: PayoutStatus }) => {
      if (input.ids.length === 0) throw new Error("Nothing selected");
      const bulkId = crypto.randomUUID();
      const patch: Partial<PayoutRow> = {
        status: input.status,
        processed_by: currentUser?.id ?? null,
        bulk_action_id: bulkId,
      };
      if (["paid", "rejected", "sent"].includes(input.status)) {
        patch.processed_at = new Date().toISOString();
      }
      const { error } = await supabase
        .from("payouts")
        .update(patch)
        .in("id", input.ids);
      if (error) throw error;
      const idSet = new Set(input.ids);
      return rows.filter((r) => idSet.has(r.id));
    },
    onSuccess: (touched, vars) => {
      const count = touched.length;
      toast.success(`${count} payout${count === 1 ? "" : "s"} marked ${vars.status}.`);
      setSelected(new Set());
      qc.invalidateQueries({ queryKey: ["financials"] });
      void notifyMemberStatusChange(touched, vars.status);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const selectableRows = filtered.filter((r) =>
    ["requested", "approved"].includes(r.status),
  );
  const allSelected =
    selectableRows.length > 0 &&
    selectableRows.every((r) => selected.has(r.id));

  function toggleAll() {
    if (allSelected) setSelected(new Set());
    else setSelected(new Set(selectableRows.map((r) => r.id)));
  }

  function toggleOne(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  return (
    <div className="space-y-8">
      <FinancialsNav />

      <section className="grid gap-4 sm:grid-cols-3">
        <StatTile
          label="Open Requests"
          value={String(totals.openCount)}
          delta={formatMoney(totals.pending)}
          deltaTone="neutral"
        />
        <StatTile label="Paid MTD" value={formatMoney(totals.paidMtd)} />
        <StatTile label="Total Records" value={String(rows.length)} />
      </section>

      <SxyCard accent>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-lg text-teal-light">
            Requests ({filtered.length})
          </h2>
          <div className="flex flex-wrap items-center gap-1">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`rounded-full border px-3 py-1 text-[10px] font-semibold uppercase tracking-wider transition-colors ${
                  filter === f.key
                    ? "border-border-teal bg-[color:var(--teal-glow)] text-teal-light"
                    : "border-transparent text-text-muted hover:text-teal-light"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {selected.size > 0 ? (
          <div className="mt-3 flex flex-wrap items-center gap-2 rounded-lg border border-border-teal/40 bg-[color:var(--teal-glow)] px-3 py-2">
            <p className="text-xs font-semibold text-teal-light">
              {selected.size} selected
            </p>
            <SxyButton
              variant="outline"
              size="sm"
              onClick={() =>
                bulkAction.mutate({
                  ids: Array.from(selected),
                  status: "approved",
                })
              }
              disabled={bulkAction.isPending}
            >
              Approve all
            </SxyButton>
            <SxyButton
              variant="gold"
              size="sm"
              onClick={() =>
                bulkAction.mutate({
                  ids: Array.from(selected),
                  status: "paid",
                })
              }
              disabled={bulkAction.isPending}
            >
              Mark all paid
            </SxyButton>
            <SxyButton
              variant="ghost"
              size="sm"
              onClick={() => setSelected(new Set())}
              disabled={bulkAction.isPending}
            >
              Clear
            </SxyButton>
          </div>
        ) : null}

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-[10px] uppercase tracking-wider text-text-dim">
              <tr className="border-b border-border-base/40">
                <th className="py-2 w-8">
                  <Checkbox
                    checked={allSelected}
                    onCheckedChange={toggleAll}
                    disabled={selectableRows.length === 0}
                    aria-label="Select all"
                  />
                </th>
                <th className="py-2 text-left font-semibold">Requested</th>
                <th className="py-2 text-left font-semibold">Member</th>
                <th className="py-2 text-left font-semibold">Method</th>
                <th className="py-2 text-right font-semibold">Amount</th>
                <th className="py-2 text-left font-semibold">Status</th>
                <th className="py-2 text-left font-semibold">Processed by</th>
                <th className="py-2 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-text-dim">
                    Loading…
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-text-dim">
                    Nothing here.
                  </td>
                </tr>
              ) : (
                filtered.map((p) => {
                  const isOpen = ["requested", "approved", "processing"].includes(
                    p.status,
                  );
                  const isSelectable = ["requested", "approved"].includes(p.status);
                  return (
                    <tr
                      key={p.id}
                      className="border-b border-border-base/30 last:border-0 align-top"
                    >
                      <td className="py-3">
                        <Checkbox
                          checked={selected.has(p.id)}
                          onCheckedChange={() => toggleOne(p.id)}
                          disabled={!isSelectable}
                          aria-label="Select row"
                        />
                      </td>
                      <td className="py-3 text-text-muted">
                        {formatDate(p.requested_at)}
                      </td>
                      <td className="py-3 text-text-primary">
                        <div className="font-medium">
                          {p.member_name ?? "—"}
                        </div>
                        <div className="text-[11px] text-text-dim">
                          {p.member_email ?? ""}
                        </div>
                        {p.notes ? (
                          <div className="mt-1 text-[11px] text-text-dim italic">
                            “{p.notes}”
                          </div>
                        ) : null}
                      </td>
                      <td className="py-3 text-text-muted">
                        <div>{p.method ?? "—"}</div>
                        {p.destination ? (
                          <div className="text-[11px] text-text-dim">
                            {p.destination}
                          </div>
                        ) : null}
                      </td>
                      <td className="py-3 text-right font-semibold text-gold">
                        {formatMoney(p.amount)}
                      </td>
                      <td className="py-3">
                        <Tag variant={statusTone(p.status)}>{p.status}</Tag>
                      </td>
                      <td className="py-3 text-text-muted text-[11px]">
                        {p.processor_name ?? "—"}
                        {p.processed_at ? (
                          <div className="text-text-dim">
                            {formatDate(p.processed_at)}
                          </div>
                        ) : null}
                      </td>
                      <td className="py-3">
                        <div className="flex flex-wrap items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setAuditFor(p)}
                            className="rounded-md p-1.5 text-text-dim hover:text-teal-light"
                            title="View audit log"
                          >
                            <History className="h-4 w-4" />
                          </button>
                          {isOpen ? (
                            <>
                              {p.status === "requested" ? (
                                <SxyButton
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    updateStatus.mutate({
                                      id: p.id,
                                      status: "approved",
                                    })
                                  }
                                >
                                  Approve
                                </SxyButton>
                              ) : null}
                              <SxyButton
                                variant="gold"
                                size="sm"
                                onClick={() =>
                                  updateStatus.mutate({
                                    id: p.id,
                                    status: "paid",
                                  })
                                }
                              >
                                Mark Paid
                              </SxyButton>
                              <SxyButton
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  updateStatus.mutate({
                                    id: p.id,
                                    status: "rejected",
                                  })
                                }
                              >
                                Reject
                              </SxyButton>
                            </>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </SxyCard>

      <PayoutAuditDrawer
        payout={auditFor}
        onClose={() => setAuditFor(null)}
      />
    </div>
  );
}

function PayoutAuditDrawer({
  payout,
  onClose,
}: {
  payout: PayoutWithMember | null;
  onClose: () => void;
}) {
  const { data: entries = [], isLoading } = useQuery({
    queryKey: ["financials", "admin", "payoutAudit", payout?.id],
    enabled: !!payout,
    queryFn: async () => {
      const { data } = await supabase
        .from("payout_audit_log")
        .select(
          "*, actor:profiles!payout_audit_log_actor_id_fkey(full_name,email)",
        )
        .eq("payout_id", payout!.id)
        .order("created_at", { ascending: false });
      return (data ?? []).map((r) => {
        const actor = (r as unknown as {
          actor?: { full_name?: string | null; email?: string | null };
        }).actor;
        return {
          ...(r as PayoutAuditEntry),
          actor_name: actor?.full_name ?? null,
          actor_email: actor?.email ?? null,
        } as PayoutAuditEntry;
      });
    },
  });

  return (
    <Sheet open={!!payout} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="border-border-teal/40 bg-charcoal-card text-text-primary sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-display text-xl text-teal-light">
            Payout audit log
          </SheetTitle>
        </SheetHeader>

        {payout ? (
          <div className="mt-4 space-y-4">
            <div className="rounded-lg border border-border-base/40 bg-charcoal-soft/40 p-3 text-sm">
              <p className="text-xs uppercase tracking-wider text-text-dim">
                {payout.member_name ?? payout.member_email ?? "Member"}
              </p>
              <p className="mt-1 font-semibold text-gold">
                {formatMoney(payout.amount)}
              </p>
              <p className="text-[11px] text-text-dim">
                Requested {formatDate(payout.requested_at)} · {payout.method}
              </p>
            </div>

            {isLoading ? (
              <p className="text-center text-sm text-text-dim">Loading…</p>
            ) : entries.length === 0 ? (
              <p className="text-center text-sm text-text-dim">
                No history yet.
              </p>
            ) : (
              <ol className="space-y-3">
                {entries.map((e) => (
                  <li
                    key={e.id}
                    className="rounded-lg border border-border-base/40 bg-charcoal-soft/40 p-3"
                  >
                    <div className="flex items-center gap-2 text-xs">
                      {e.from_status ? (
                        <>
                          <Tag variant={statusTone(e.from_status)}>
                            {e.from_status}
                          </Tag>
                          <span className="text-text-dim">→</span>
                        </>
                      ) : (
                        <span className="text-text-dim">created as</span>
                      )}
                      <Tag variant={statusTone(e.to_status)}>
                        {e.to_status}
                      </Tag>
                    </div>
                    <p className="mt-2 text-xs text-text-muted">
                      {e.actor_name ?? e.actor_email ?? "System"} ·{" "}
                      <span className="text-text-dim">
                        {formatDate(e.created_at)}
                      </span>
                    </p>
                    {e.note ? (
                      <p className="mt-1 text-xs italic text-text-dim">
                        “{e.note}”
                      </p>
                    ) : null}
                  </li>
                ))}
              </ol>
            )}
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}
