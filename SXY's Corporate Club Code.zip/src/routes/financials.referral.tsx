/**
 * /financials/referral — Referral earnings detail (member view).
 */
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { StatTile } from "@/components/sxy/StatTile";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  formatDate,
  formatMoney,
  type PayoutRow,
  type TransactionRow,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/referral")({
  head: () => ({ meta: [{ title: "Referral Earnings — SXY's Corporate Club" }] }),
  component: ReferralRoute,
});

function ReferralRoute() {
  const { currentUser } = useAuth();
  const userId = currentUser?.id;

  const { data: bookings = [] } = useQuery({
    queryKey: ["financials", "bookings", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data } = await supabase
        .from("bookings")
        .select("id, service_amount, platform_fee, net_to_provider, business_pages(business_name)")
        .eq("provider_id", userId!)
        .in("status", ["confirmed", "completed"]);
      return (data ?? []) as unknown as Array<{
        id: string;
        service_amount: number;
        platform_fee: number;
        net_to_provider: number;
        business_pages: { business_name: string } | { business_name: string }[] | null;
      }>;
    },
  });

  const { data: payouts = [] } = useQuery({
    queryKey: ["financials", "referralPayouts", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data } = await supabase
        .from("payouts")
        .select("*")
        .eq("user_id", userId!)
        .order("requested_at", { ascending: false })
        .limit(8);
      return (data ?? []) as PayoutRow[];
    },
  });

  const { data: txns = [] } = useQuery({
    queryKey: ["financials", "referralTxns", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", userId!)
        .eq("txn_type", "referral");
      return (data ?? []) as TransactionRow[];
    },
  });

  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const total = txns.reduce(
    (s, t) => s + Number(t.gross_amount ?? t.amount ?? 0),
    0,
  );
  const monthTotal = txns
    .filter((t) => new Date(t.created_at) >= monthStart)
    .reduce((s, t) => s + Number(t.gross_amount ?? t.amount ?? 0), 0);
  const avg = bookings.length ? total / bookings.length : 0;

  // Group bookings by source page
  const sourceMap = new Map<
    string,
    { name: string; count: number; gross: number; fee: number; net: number }
  >();
  for (const b of bookings) {
    const bp = Array.isArray(b.business_pages)
      ? b.business_pages[0]
      : b.business_pages;
    const name = bp?.business_name ?? "Unattributed";
    const cur =
      sourceMap.get(name) ?? { name, count: 0, gross: 0, fee: 0, net: 0 };
    cur.count += 1;
    cur.gross += Number(b.service_amount ?? 0);
    cur.fee += Number(b.platform_fee ?? 0);
    cur.net += Number(b.net_to_provider ?? 0);
    sourceMap.set(name, cur);
  }
  const sources = Array.from(sourceMap.values());

  return (
    <AppLayout title="Referral Earnings">
      <div className="space-y-6">
        <FinancialsNav />

        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatTile label="Total Referral Earnings" value={formatMoney(total)} />
          <StatTile label="This Month" value={formatMoney(monthTotal)} />
          <StatTile label="Total Bookings" value={String(bookings.length)} />
          <StatTile label="Avg per Booking" value={formatMoney(avg)} />
        </section>

        <div className="grid gap-6 lg:grid-cols-2">
          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Bookings by source
            </h2>
            <table className="mt-4 w-full text-sm">
              <thead className="text-[10px] uppercase tracking-wider text-text-dim">
                <tr className="border-b border-border-base/40">
                  <th className="py-2 text-left">Page</th>
                  <th className="py-2 text-right">Bookings</th>
                  <th className="py-2 text-right">Gross</th>
                  <th className="py-2 text-right">Fee</th>
                  <th className="py-2 text-right">Net</th>
                </tr>
              </thead>
              <tbody>
                {sources.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-text-dim">
                      No bookings yet.
                    </td>
                  </tr>
                ) : (
                  sources.map((s) => (
                    <tr key={s.name} className="border-b border-border-base/30">
                      <td className="py-2 text-text-primary">{s.name}</td>
                      <td className="py-2 text-right">{s.count}</td>
                      <td className="py-2 text-right">{formatMoney(s.gross)}</td>
                      <td className="py-2 text-right text-danger">
                        − {formatMoney(s.fee)}
                      </td>
                      <td className="py-2 text-right font-semibold text-gold">
                        {formatMoney(s.net)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </SxyCard>

          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Recent referral payouts
            </h2>
            <ul className="mt-4 divide-y divide-border-base/30">
              {payouts.length === 0 ? (
                <li className="py-6 text-center text-sm text-text-dim">
                  No payouts yet.
                </li>
              ) : (
                payouts.map((p) => (
                  <li key={p.id} className="flex items-center justify-between py-3">
                    <div>
                      <p className="text-sm text-text-primary">
                        {formatMoney(p.amount)}
                      </p>
                      <p className="text-xs text-text-dim">
                        {formatDate(p.requested_at)} · {p.method ?? "—"} ·{" "}
                        {p.status}
                      </p>
                    </div>
                  </li>
                ))
              )}
            </ul>
          </SxyCard>
        </div>
      </div>
    </AppLayout>
  );
}
