import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { KidShell } from "@/components/kiddos/KidShell";
import { CreditBadge, CREDIT_IMAGE_URL } from "@/components/kiddos/CreditBadge";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/kiddos/hub")({
  head: () => ({
    meta: [
      { title: "Kiddos Hub — SXY's Corporate Kiddos" },
      { name: "description", content: "Your money, goals, and trades in one kid-friendly dashboard." },
    ],
  }),
  component: KiddosHubRoute,
});

function KiddosHubRoute() {
  return (
    <KidShell title="Hi there 👋">
      <HubContent />
    </KidShell>
  );
}

function HubContent() {
  const { currentUser } = useAuth();
  const [privacyMode, setPrivacyMode] = React.useState(true);
  const userId = currentUser?.id;

  const { data: wallet, isLoading: walletLoading } = useQuery({
    queryKey: ["kiddo-wallet", userId],
    queryFn: async () => {
      if (!userId) return null;
      const { data, error } = await supabase
        .from("kiddo_wallets")
        .select("balance_credits, lifetime_earned, lifetime_spent")
        .eq("user_id", userId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!userId,
  });

  const { data: goals } = useQuery({
    queryKey: ["kiddo-goals", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("savings_goals")
        .select("id, title, target_credits, saved_credits")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(3);
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const { data: chores } = useQuery({
    queryKey: ["kiddo-chores-open", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("chores")
        .select("id, title, reward_credits, status")
        .eq("child_user_id", userId)
        .in("status", ["open", "submitted"])
        .order("created_at", { ascending: false })
        .limit(5);
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  if (!currentUser) {
    return (
      <div className="kid-card text-center">
        <p className="mb-4">Sign in to see your Kiddos hub.</p>
        <Link to="/login" className="kid-btn kid-btn-primary">Sign in</Link>
      </div>
    );
  }

  const balance = wallet?.balance_credits ?? 0;
  const earned = wallet?.lifetime_earned ?? 0;

  return (
    <div className="grid gap-5">
      <section
        className="kid-card relative overflow-hidden"
        style={{ background: "var(--kid-teal)", color: "#fff" }}
      >
        <img
          src={CREDIT_IMAGE_URL}
          alt=""
          aria-hidden
          className="absolute -right-10 -bottom-10 opacity-25 pointer-events-none"
          style={{ width: 260, height: 260, objectFit: "cover" }}
        />
        <div className="relative">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm uppercase tracking-wider opacity-80">Your credits</span>
            <button
              type="button"
              onClick={() => setPrivacyMode((v) => !v)}
              className="kid-btn"
              style={{
                minHeight: 40,
                padding: "0.4rem 0.9rem",
                background: "rgba(255,255,255,0.15)",
                color: "#fff",
                fontSize: "0.8rem",
              }}
              aria-pressed={privacyMode}
            >
              {privacyMode ? "👁️ Show" : "🙈 Hide"}
            </button>
          </div>
          <div className="flex items-center gap-3">
            <img
              src={CREDIT_IMAGE_URL}
              alt="Coins 4 Kiddos"
              width={64}
              height={64}
              style={{ width: 64, height: 64, borderRadius: "50%", objectFit: "cover", boxShadow: "0 4px 18px rgba(0,0,0,0.2)" }}
            />
            <div
              className={privacyMode ? "kid-money-blur" : ""}
              style={{ fontFamily: "var(--font-kid-money)", fontSize: "3rem", fontWeight: 700, lineHeight: 1 }}
            >
              {walletLoading ? "…" : balance.toLocaleString()}
            </div>
          </div>
          <div className="mt-2 text-sm opacity-80">
            Lifetime earned: <span className={privacyMode ? "kid-money-blur" : ""}>{earned.toLocaleString()}</span>
          </div>
          <div className="mt-4 flex gap-2 flex-wrap">
            <Link to="/kiddos/directory" className="kid-btn kid-btn-gold">Spend in Trade</Link>
            <Link to="/kiddos/money" className="kid-btn" style={{ background: "rgba(255,255,255,0.18)", color: "#fff" }}>
              Ledger →
            </Link>
          </div>
        </div>
      </section>

      <section className="grid sm:grid-cols-2 gap-5">
        <div className="kid-card">
          <h2 className="text-xl mb-3">Open chores</h2>
          {!chores || chores.length === 0 ? (
            <p className="text-[var(--kid-ink-muted)] text-sm">
              No chores right now. Ask your parent to add some in the Parent Center.
            </p>
          ) : (
            <ul className="space-y-2">
              {chores.map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-3">
                  <span>{c.title}</span>
                  <CreditBadge amount={`+${c.reward_credits}`} />
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="kid-card">
          <h2 className="text-xl mb-3">Savings goals</h2>
          {!goals || goals.length === 0 ? (
            <Link to="/kiddos/money" className="kid-btn kid-btn-ghost">+ Start a goal</Link>
          ) : (
            <ul className="space-y-3">
              {goals.map((g) => {
                const pct = Math.min(100, Math.round((g.saved_credits / Math.max(1, g.target_credits)) * 100));
                return (
                  <li key={g.id}>
                    <div className="flex justify-between text-sm mb-1">
                      <span>{g.title}</span>
                      <span className="kid-money">{pct}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-[var(--kid-teal-soft)] overflow-hidden">
                      <div className="h-full bg-[var(--kid-gold)]" style={{ width: `${pct}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>

      <p className="text-xs text-[var(--kid-ink-muted)] text-center mt-4">
        1 credit = 1 C4K coin. Use them to redeem things from friends in the Trade tab.
      </p>
    </div>
  );
}
