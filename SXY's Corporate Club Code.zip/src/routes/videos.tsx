import { createFileRoute, Navigate } from "@tanstack/react-router";

/**
 * Legacy /videos route — superseded by /economy-bites. We keep the route
 * registered so old bookmarks redirect cleanly.
 */
export const Route = createFileRoute("/videos")({
  head: () => ({ meta: [{ title: "Economy Bites — SXY's Corporate Club" }] }),
  component: () => <Navigate to="/economy-bites" replace />,
});
