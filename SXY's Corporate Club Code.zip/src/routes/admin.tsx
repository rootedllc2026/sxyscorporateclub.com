import { createFileRoute, Link } from "@tanstack/react-router";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";

type Tool = {
  to: string;
  glyph: string;
  title: string;
  desc: string;
};

const tools: Tool[] = [
  {
    to: "/economy-bites/upload",
    glyph: "↑",
    title: "Upload Content",
    desc: "Publish a new Economy Bites video, set its series, access tier and notify members.",
  },
  {
    to: "/events/create",
    glyph: "✦",
    title: "Create Event",
    desc: "Schedule a webinar or workshop, set access level, and announce it in #general.",
  },
  {
    to: "/bidding/admin",
    glyph: "⚡",
    title: "Bid Review",
    desc: "Post new projects, review incoming bids and award contracts to members.",
  },
  {
    to: "/economy-bites",
    glyph: "▣",
    title: "Economy Bites Library",
    desc: "Browse the full catalog of published videos and manage featured picks.",
  },
  {
    to: "/events",
    glyph: "📅",
    title: "Events Schedule",
    desc: "See upcoming and past events. Recordings live under Events → Recordings.",
  },
  {
    to: "/admin/set-password",
    glyph: "🔑",
    title: "Set User Password",
    desc: "Securely set a password for a user who can't receive reset emails. Audit-logged.",
  },
  {
    to: "/kiddos/hub",
    glyph: "🧒",
    title: "Kiddos App",
    desc: "Open the kids' financial literacy hub — videos, directory, money games, and the parent dashboard.",
  },
  {
    to: "/kiddos/parent",
    glyph: "👪",
    title: "Kiddos Parent / Approvals",
    desc: "Review kid-submitted videos (parent approval step before admin sign-off) and manage kid accounts.",
  },
  {
    to: "/kiddos/videos",
    glyph: "▶",
    title: "Kiddos Video Approvals",
    desc: "Admin queue for approving kid-submitted financial literacy videos after parent sign-off.",
  },
];

function AdminConsolePage() {
  return (
    <AdminRoute>
      <AppLayout title="Admin Console">
        <div className="space-y-6">
          <SxyCard accent>
            <h2 className="font-display text-xl text-teal-light">
              Operator tools
            </h2>
            <p className="mt-2 text-sm text-text-muted">
              Project posting, bid review, event publishing and content
              management. Only members with the admin role can see this page.
            </p>
          </SxyCard>

          <div className="grid gap-4 sm:grid-cols-2">
            {tools.map((tool) => (
              <Link
                key={tool.to}
                to={tool.to}
                className="group rounded-xl border border-border-base/60 bg-charcoal-card p-5 transition-colors hover:border-border-teal hover:bg-[color:var(--teal-glow)]"
              >
                <div className="flex items-start gap-3">
                  <span
                    aria-hidden
                    className="flex h-10 w-10 items-center justify-center rounded-lg border border-border-base/60 bg-charcoal-soft text-lg text-teal-light"
                  >
                    {tool.glyph}
                  </span>
                  <div className="flex-1">
                    <h3 className="font-display text-base text-text-primary group-hover:text-teal-light">
                      {tool.title}
                    </h3>
                    <p className="mt-1 text-xs text-text-muted">{tool.desc}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </AppLayout>
    </AdminRoute>
  );
}

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin Console — SXY's Corporate Club" }] }),
  component: AdminConsolePage,
});
