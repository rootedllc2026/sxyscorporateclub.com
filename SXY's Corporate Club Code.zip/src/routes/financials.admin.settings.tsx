/**
 * /financials/admin/settings — single-row platform_settings editor.
 * Edits fee tiers, payout window/threshold/method, notification preferences.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { supabase } from "@/integrations/supabase/client";
import { type PlatformSettingsRow } from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/admin/settings")({
  head: () => ({ meta: [{ title: "Fee Settings — SXY's Corporate Club" }] }),
  component: SettingsRoute,
});

function SettingsRoute() {
  return (
    <AdminRoute>
      <AppLayout title="Fee & Payout Settings">
        <SettingsInner />
      </AppLayout>
    </AdminRoute>
  );
}

type FormState = Omit<PlatformSettingsRow, "id" | "updated_at">;

const DEFAULTS: FormState = {
  fee_pct_basic: 8,
  fee_pct_standard: 10,
  fee_pct_featured: 12,
  payout_window_days: 7,
  payout_min_threshold: 50,
  payout_default_method: "stripe",
  notify_on_approval: true,
  notify_on_new_request: true,
  weekly_digest: false,
  admin_notification_emails: [],
};

function SettingsInner() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["financials", "admin", "settings"],
    queryFn: async () => {
      const { data } = await supabase
        .from("platform_settings")
        .select("*")
        .eq("id", 1)
        .maybeSingle();
      return (data ?? null) as PlatformSettingsRow | null;
    },
  });

  const [form, setForm] = React.useState<FormState>(DEFAULTS);
  React.useEffect(() => {
    if (data) {
      setForm({
        fee_pct_basic: Number(data.fee_pct_basic),
        fee_pct_standard: Number(data.fee_pct_standard),
        fee_pct_featured: Number(data.fee_pct_featured),
        payout_window_days: Number(data.payout_window_days),
        payout_min_threshold: Number(data.payout_min_threshold),
        payout_default_method: data.payout_default_method,
        notify_on_approval: data.notify_on_approval,
        notify_on_new_request: data.notify_on_new_request,
        weekly_digest: data.weekly_digest,
        admin_notification_emails: data.admin_notification_emails ?? [],
      });
    }
  }, [data]);

  const save = useMutation({
    mutationFn: async (next: FormState) => {
      const { error } = await supabase
        .from("platform_settings")
        .update({ ...next, updated_at: new Date().toISOString() })
        .eq("id", 1);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Settings saved.");
      qc.invalidateQueries({ queryKey: ["financials", "admin", "settings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  return (
    <div className="space-y-8">
      <FinancialsNav />

      {isLoading ? (
        <SxyCard accent>
          <p className="py-8 text-center text-sm text-text-dim">Loading…</p>
        </SxyCard>
      ) : (
        <>
          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Referral fee tiers
            </h2>
            <p className="mt-1 text-xs text-text-muted">
              Percentage withheld on referral &amp; consulting bookings by
              listing tier.
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <PctField
                id="fee-basic"
                label="Basic listings"
                value={form.fee_pct_basic}
                onChange={(v) => update("fee_pct_basic", v)}
              />
              <PctField
                id="fee-standard"
                label="Standard listings"
                value={form.fee_pct_standard}
                onChange={(v) => update("fee_pct_standard", v)}
              />
              <PctField
                id="fee-featured"
                label="Featured listings"
                value={form.fee_pct_featured}
                onChange={(v) => update("fee_pct_featured", v)}
              />
            </div>
          </SxyCard>

          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Payout policy
            </h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="window">Window (days)</Label>
                <Input
                  id="window"
                  type="number"
                  min={0}
                  step={1}
                  value={form.payout_window_days}
                  onChange={(e) =>
                    update("payout_window_days", Number(e.target.value || 0))
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="threshold">Min threshold ($)</Label>
                <Input
                  id="threshold"
                  type="number"
                  min={0}
                  step={1}
                  value={form.payout_min_threshold}
                  onChange={(e) =>
                    update(
                      "payout_min_threshold",
                      Number(e.target.value || 0),
                    )
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label>Default method</Label>
                <Select
                  value={form.payout_default_method}
                  onValueChange={(v) => update("payout_default_method", v)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="stripe">Stripe</SelectItem>
                    <SelectItem value="bank">Bank (ACH)</SelectItem>
                    <SelectItem value="paypal">PayPal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </SxyCard>

          <SxyCard accent>
            <h2 className="font-display text-lg text-teal-light">
              Notifications
            </h2>
            <div className="mt-4 space-y-4">
              <div className="space-y-1.5 rounded-xl border border-border-base/40 bg-charcoal-soft/40 p-4">
                <Label htmlFor="admin-emails">
                  Admin notification recipients
                </Label>
                <p className="text-xs text-text-muted">
                  Comma-separated emails. New payout requests and weekly digests
                  are sent here from your connected Gmail account.
                </p>
                <Input
                  id="admin-emails"
                  placeholder="ops@yourcompany.com, finance@yourcompany.com"
                  value={form.admin_notification_emails.join(", ")}
                  onChange={(e) =>
                    update(
                      "admin_notification_emails",
                      e.target.value
                        .split(",")
                        .map((s) => s.trim())
                        .filter(Boolean),
                    )
                  }
                />
              </div>
              <ToggleRow
                label="Notify member when payout is approved"
                description="Sends an email when an admin approves or marks their payout paid."
                checked={form.notify_on_approval}
                onChange={(v) => update("notify_on_approval", v)}
              />
              <ToggleRow
                label="Notify admins on new payout request"
                description="Emails every recipient above when a member submits a payout."
                checked={form.notify_on_new_request}
                onChange={(v) => update("notify_on_new_request", v)}
              />
              <ToggleRow
                label="Send weekly financial digest"
                description="Monday 9 AM digest summarising platform revenue and pending payouts."
                checked={form.weekly_digest}
                onChange={(v) => update("weekly_digest", v)}
              />
            </div>
          </SxyCard>

          <div className="flex justify-end">
            <SxyButton
              variant="gold"
              size="default"
              onClick={() => save.mutate(form)}
              disabled={save.isPending}
            >
              {save.isPending ? "Saving…" : "Save settings"}
            </SxyButton>
          </div>
        </>
      )}
    </div>
  );
}

function PctField({
  id,
  label,
  value,
  onChange,
}: {
  id: string;
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          id={id}
          type="number"
          min={0}
          max={100}
          step={0.5}
          value={value}
          onChange={(e) => onChange(Number(e.target.value || 0))}
          className="pr-8"
        />
        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-text-dim">
          %
        </span>
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-xl border border-border-base/40 bg-charcoal-soft/40 p-4">
      <div>
        <p className="text-sm font-medium text-text-primary">{label}</p>
        <p className="mt-0.5 text-xs text-text-muted">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
