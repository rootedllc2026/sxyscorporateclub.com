/**
 * /financials/transactions — Full transaction history with filters + CSV export.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { TransactionDetailModal } from "@/components/financials/TransactionDetailModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { downloadCsv, rowsToCsv } from "@/lib/financials/csv";
import {
  dateRangeStart,
  formatDate,
  formatMoney,
  statusTone,
  txnTypeLabel,
  txnTypeTone,
  type DateRangeKey,
  type TransactionRow,
  type TxnType,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/transactions")({
  head: () => ({ meta: [{ title: "Transactions — SXY's Corporate Club" }] }),
  component: TxnsRoute,
});

function TxnsRoute() {
  const { currentUser } = useAuth();
  const [type, setType] = React.useState<TxnType | "all">("all");
  const [range, setRange] = React.useState<DateRangeKey>("all");
  const [pageSize, setPageSize] = React.useState(20);
  const [detail, setDetail] = React.useState<TransactionRow | null>(null);

  const { data: rows = [] } = useQuery({
    queryKey: ["financials", "txns", currentUser?.id, type, range],
    enabled: !!currentUser,
    queryFn: async () => {
      let q = supabase
        .from("transactions")
        .select("*")
        .eq("user_id", currentUser!.id)
        .order("created_at", { ascending: false });
      if (type !== "all") q = q.eq("txn_type", type);
      const since = dateRangeStart(range);
      if (since) q = q.gte("created_at", since);
      const { data } = await q;
      return (data ?? []) as TransactionRow[];
    },
  });

  const visible = rows.slice(0, pageSize);

  function exportCsv() {
    const csv = rowsToCsv(rows as unknown as Record<string, unknown>[], [
      { key: "created_at", label: "Date" },
      { key: "description", label: "Description" },
      { key: "txn_type", label: "Type" },
      { key: "gross_amount", label: "Gross" },
      { key: "fee_amount", label: "Fee" },
      { key: "net_amount", label: "Net" },
      { key: "status", label: "Status" },
      { key: "source", label: "Source" },
    ]);
    downloadCsv(`transactions-${new Date().toISOString().slice(0, 10)}.csv`, csv);
  }

  return (
    <AppLayout
      title="Transactions"
      actions={
        <SxyButton variant="gold" size="sm" onClick={exportCsv}>
          Export CSV
        </SxyButton>
      }
    >
      <div className="space-y-6">
        <FinancialsNav />
        <SxyCard accent>
          <div className="flex flex-wrap items-center gap-3">
            <Select value={type} onValueChange={(v) => setType(v as TxnType | "all")}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="referral">Referral</SelectItem>
                <SelectItem value="consulting">Consulting</SelectItem>
                <SelectItem value="fee">Platform Fee</SelectItem>
                <SelectItem value="membership">Membership</SelectItem>
                <SelectItem value="payout">Payout</SelectItem>
              </SelectContent>
            </Select>
            <Select value={range} onValueChange={(v) => setRange(v as DateRangeKey)}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Date range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All time</SelectItem>
                <SelectItem value="month">This month</SelectItem>
                <SelectItem value="3months">Last 3 months</SelectItem>
                <SelectItem value="year">This year</SelectItem>
              </SelectContent>
            </Select>
            <span className="ml-auto text-xs text-text-dim">
              {rows.length} result{rows.length === 1 ? "" : "s"}
            </span>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[10px] uppercase tracking-wider text-text-dim">
                <tr className="border-b border-border-base/40">
                  <th className="py-2 text-left">Date</th>
                  <th className="py-2 text-left">Description</th>
                  <th className="py-2 text-left">Type</th>
                  <th className="py-2 text-right">Amount</th>
                  <th className="py-2 text-left">Source</th>
                  <th className="py-2 text-left">Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {visible.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-text-dim">
                      No transactions match these filters.
                    </td>
                  </tr>
                ) : (
                  visible.map((t) => {
                    const net = Number(
                      t.net_amount ??
                        Number(t.gross_amount ?? t.amount ?? 0) -
                          Number(t.fee_amount ?? 0),
                    );
                    const isNeg =
                      t.txn_type === "fee" || t.txn_type === "membership" || net < 0;
                    return (
                      <tr key={t.id} className="border-b border-border-base/30">
                        <td className="py-3 text-text-muted">
                          {formatDate(t.created_at)}
                        </td>
                        <td className="py-3 text-text-primary">
                          {t.description ?? "—"}
                        </td>
                        <td className="py-3">
                          <Tag variant={txnTypeTone(t.txn_type)}>
                            {txnTypeLabel(t.txn_type)}
                          </Tag>
                        </td>
                        <td
                          className={`py-3 text-right font-semibold ${
                            isNeg ? "text-danger" : "text-success"
                          }`}
                        >
                          {isNeg ? "−" : "+"}
                          {formatMoney(Math.abs(net))}
                        </td>
                        <td className="py-3 text-text-muted">
                          {t.source ?? "—"}
                        </td>
                        <td className="py-3">
                          <Tag variant={statusTone(t.status)}>{t.status}</Tag>
                        </td>
                        <td className="py-3 text-right">
                          <SxyButton
                            variant="ghost"
                            size="sm"
                            onClick={() => setDetail(t)}
                          >
                            View
                          </SxyButton>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {visible.length < rows.length ? (
            <div className="mt-4 flex justify-center">
              <SxyButton
                variant="outline"
                size="sm"
                onClick={() => setPageSize((p) => p + 20)}
              >
                Load more
              </SxyButton>
            </div>
          ) : null}
        </SxyCard>
      </div>

      <TransactionDetailModal txn={detail} onClose={() => setDetail(null)} />
    </AppLayout>
  );
}
