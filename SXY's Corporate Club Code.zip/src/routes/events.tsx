/**
 * /events — upcoming events landing page.
 *
 * - Hero card for the next upcoming event (live countdown).
 * - 14-day calendar strip, days with events show tier-colored dots.
 * - 3-column grid of upcoming event cards (filterable by selected day).
 * - Free events open a registration modal; VIP events show the upgrade modal.
 */
import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Calendar, Users, Video } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { UpgradeModal } from "@/components/sxy/UpgradeModal";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  canAccessEvent,
  computeCountdown,
  formatCountdown,
  formatEventDateTime,
  isWithin24h,
  type EventRow,
} from "@/lib/events/shared";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title: "Events & Webinars — SXY's Corporate Club" },
      {
        name: "description",
        content:
          "Upcoming SXY's Corporate Club webinars, live discussions, and member events.",
      },
    ],
  }),
  component: () => (
    <AppLayout title="Events & Webinars">
      <EventsPage />
    </AppLayout>
  ),
});

function EventsPage() {
  const { isAdmin, userTier, currentUser } = useAuth();
  const qc = useQueryClient();
  const [selectedDay, setSelectedDay] = React.useState<string | null>(null);
  const [upgradeOpen, setUpgradeOpen] = React.useState(false);
  const [registerEvent, setRegisterEvent] = React.useState<EventRow | null>(null);

  const { data: events = [] } = useQuery({
    queryKey: ["events", "upcoming"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("events")
        .select("*")
        .gt("starts_at", new Date().toISOString())
        .neq("status", "canceled")
        .order("starts_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as EventRow[];
    },
  });

  const { data: registeredIds = new Set<string>() } = useQuery({
    queryKey: ["events", "myRegs", currentUser?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("event_registrations")
        .select("event_id")
        .eq("user_id", currentUser!.id);
      return new Set((data ?? []).map((r) => r.event_id as string));
    },
    enabled: !!currentUser,
  });

  const next = events[0];

  // 14-day calendar strip
  const days = React.useMemo(() => {
    const arr: { iso: string; label: string; weekday: string; events: EventRow[] }[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    for (let i = 0; i < 14; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const iso = d.toISOString().slice(0, 10);
      const dayEvents = events.filter(
        (e) => new Date(e.starts_at).toISOString().slice(0, 10) === iso,
      );
      arr.push({
        iso,
        label: d.getDate().toString(),
        weekday: d.toLocaleDateString(undefined, { weekday: "short" }),
        events: dayEvents,
      });
    }
    return arr;
  }, [events]);

  const visibleEvents = selectedDay
    ? events.filter((e) => e.starts_at.slice(0, 10) === selectedDay)
    : events;

  async function register(ev: EventRow) {
    if (!currentUser) return;
    await supabase
      .from("event_registrations")
      .upsert(
        { event_id: ev.id, user_id: currentUser.id },
        { onConflict: "event_id,user_id" },
      );
    qc.invalidateQueries({ queryKey: ["events", "upcoming"] });
    qc.invalidateQueries({ queryKey: ["events", "myRegs"] });
    setRegisterEvent(null);
  }

  function onRegisterClick(ev: EventRow) {
    if (!canAccessEvent(ev.access_level, userTier, isAdmin)) {
      setUpgradeOpen(true);
      return;
    }
    setRegisterEvent(ev);
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center gap-3">
        <Link
          to="/events/recordings"
          className="inline-flex items-center gap-2 rounded-full border border-border-base/60 bg-charcoal-card px-4 py-1.5 text-xs text-text-muted hover:border-border-teal hover:text-text-primary"
        >
          <Video className="h-3.5 w-3.5" /> Past recordings
        </Link>
        {isAdmin ? (
          <Link
            to="/events/create"
            className="inline-flex items-center gap-2 rounded-full border border-border-gold bg-[color:var(--gold-glow)] px-4 py-1.5 text-xs text-gold-light hover:text-gold"
          >
            ✦ Create event
          </Link>
        ) : null}
      </div>

      {/* Hero — next event */}
      {next ? <NextEventHero event={next} onRegister={() => onRegisterClick(next)} /> : (
        <SxyCard className="text-center text-sm text-text-muted">
          No upcoming events scheduled. Check back soon!
        </SxyCard>
      )}

      {/* Calendar strip */}
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs text-text-dim">
          <Calendar className="h-3.5 w-3.5" /> Next 14 days
          {selectedDay ? (
            <button
              type="button"
              className="ml-2 text-teal-light underline"
              onClick={() => setSelectedDay(null)}
            >
              Clear
            </button>
          ) : null}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {days.map((d) => {
            const has = d.events.length > 0;
            const tone =
              d.events.find((e) => e.access_level === "vip")
                ? "bg-gold"
                : has
                  ? "bg-teal-mid"
                  : "bg-transparent";
            const active = selectedDay === d.iso;
            return (
              <button
                key={d.iso}
                type="button"
                onClick={() => setSelectedDay(active ? null : d.iso)}
                className={cn(
                  "grid h-16 w-14 shrink-0 place-items-center rounded-xl border text-center transition-colors",
                  active
                    ? "border-teal-mid bg-[color:var(--teal-glow)] text-teal-light"
                    : "border-border-base/60 bg-charcoal-card text-text-muted hover:border-border-teal",
                )}
              >
                <span className="block text-[10px] uppercase tracking-wider">
                  {d.weekday}
                </span>
                <span className="block font-display text-lg">{d.label}</span>
                <span className={cn("mt-0.5 h-1.5 w-1.5 rounded-full", tone)} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Event grid */}
      {visibleEvents.length === 0 ? (
        <SxyCard className="text-center text-sm text-text-muted">
          No events on this day.
        </SxyCard>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visibleEvents.map((ev) => (
            <EventCard
              key={ev.id}
              event={ev}
              registered={registeredIds.has(ev.id)}
              accessible={canAccessEvent(ev.access_level, userTier, isAdmin)}
              onRegister={() => onRegisterClick(ev)}
            />
          ))}
        </div>
      )}

      <UpgradeModal open={upgradeOpen} onOpenChange={setUpgradeOpen} />

      {registerEvent ? (
        <Dialog open onOpenChange={() => setRegisterEvent(null)}>
          <DialogContent className="border-border-teal bg-charcoal-card">
            <DialogHeader>
              <DialogTitle className="font-display text-xl text-teal-light">
                Confirm registration
              </DialogTitle>
              <DialogDescription className="text-text-muted">
                {registerEvent.title} · {formatEventDateTime(registerEvent.starts_at)}
                {registerEvent.host_name ? ` · ${registerEvent.host_name}` : ""}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <SxyButton
                variant="ghost"
                size="sm"
                onClick={() => setRegisterEvent(null)}
              >
                Cancel
              </SxyButton>
              <SxyButton size="sm" onClick={() => register(registerEvent)}>
                Confirm
              </SxyButton>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      ) : null}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────

function NextEventHero({
  event,
  onRegister,
}: {
  event: EventRow;
  onRegister: () => void;
}) {
  const [c, setC] = React.useState(() => computeCountdown(event.starts_at));
  React.useEffect(() => {
    const t = setInterval(() => setC(computeCountdown(event.starts_at)), 1000);
    return () => clearInterval(t);
  }, [event.starts_at]);

  return (
    <SxyCard accent className="overflow-hidden p-0">
      <div
        className="grid gap-0 lg:grid-cols-[1fr_280px]"
        style={{
          background:
            event.access_level === "vip"
              ? "linear-gradient(135deg, oklch(0.32 0.07 85 / 0.85), oklch(0.12 0.02 85 / 0.95))"
              : "linear-gradient(135deg, oklch(0.55 0.085 210 / 0.55), oklch(0.18 0.03 215 / 0.95))",
        }}
      >
        <div className="space-y-4 p-6 lg:p-8">
          <div className="flex flex-wrap items-center gap-2">
            <Tag variant="gold">Up next</Tag>
            {event.access_level === "vip" ? <Tag variant="gold">VIP</Tag> : null}
            {isWithin24h(event.starts_at) ? (
              <Tag variant="green">LIVE SOON</Tag>
            ) : null}
          </div>
          <h2 className="font-display text-2xl text-text-primary lg:text-3xl">
            <span aria-hidden className="mr-2">
              {event.icon_emoji}
            </span>
            {event.title}
          </h2>
          {event.host_name ? (
            <p className="text-sm text-text-muted">Hosted by {event.host_name}</p>
          ) : null}
          {event.description ? (
            <p className="line-clamp-3 text-sm text-text-muted">{event.description}</p>
          ) : null}
          <div className="text-xs text-text-dim">
            {formatEventDateTime(event.starts_at)}
            {event.duration_min ? ` · ${event.duration_min} min` : ""}
            {event.platform ? ` · ${event.platform}` : ""}
          </div>
          <div className="pt-2">
            <SxyButton size="sm" onClick={onRegister}>
              Register
            </SxyButton>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center gap-2 border-t border-border-base/60 bg-black/40 p-6 lg:border-l lg:border-t-0">
          <span className="text-[11px] uppercase tracking-wider text-text-dim">
            Starts in
          </span>
          <CountdownDisplay c={c} />
        </div>
      </div>
    </SxyCard>
  );
}

function CountdownDisplay({ c }: { c: ReturnType<typeof computeCountdown> }) {
  return (
    <div className="font-mono text-2xl text-teal-light lg:text-3xl">
      {formatCountdown(c)}
    </div>
  );
}

function EventCard({
  event,
  registered,
  accessible,
  onRegister,
}: {
  event: EventRow;
  registered: boolean;
  accessible: boolean;
  onRegister: () => void;
}) {
  return (
    <article className="overflow-hidden rounded-2xl border border-border-base/60 bg-charcoal-card transition-colors hover:border-border-teal">
      <div
        className="grid h-28 place-items-center"
        style={{
          background:
            event.access_level === "vip"
              ? "linear-gradient(135deg, oklch(0.42 0.09 85 / 0.85), oklch(0.18 0.025 85 / 0.95))"
              : "linear-gradient(135deg, oklch(0.55 0.085 210 / 0.55), oklch(0.22 0.035 215 / 0.95))",
        }}
      >
        <span aria-hidden className="text-4xl">
          {event.icon_emoji}
        </span>
      </div>
      <div className="space-y-3 p-4">
        <div className="flex items-center gap-2">
          {isWithin24h(event.starts_at) ? (
            <Tag variant="green">LIVE SOON</Tag>
          ) : null}
          {event.access_level === "vip" ? <Tag variant="gold">VIP</Tag> : null}
        </div>
        <h3 className="line-clamp-2 font-display text-base text-text-primary">
          {event.title}
        </h3>
        <p className="text-xs text-text-muted">
          {event.host_name ? `${event.host_name} · ` : ""}
          {formatEventDateTime(event.starts_at)}
        </p>
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-1 text-[11px] text-text-dim">
            <Users className="h-3 w-3" />
            {event.registrant_count.toLocaleString()} registered
          </span>
          {registered ? (
            <span className="text-[11px] text-success">✓ Registered</span>
          ) : (
            <SxyButton
              size="sm"
              variant={accessible ? "primary" : "outline"}
              onClick={onRegister}
            >
              {accessible ? "Register" : "VIP only"}
            </SxyButton>
          )}
        </div>
      </div>
    </article>
  );
}
