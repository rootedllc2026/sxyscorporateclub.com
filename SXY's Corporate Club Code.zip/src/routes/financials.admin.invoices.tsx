/**
 * /financials/admin/invoices — Admin view of every invoice in the system.
 * Search by client/number/member, filter by status, mark paid/cancelled,
 * and download the PDF for any row.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { StatTile } from "@/components/sxy/StatTile";
import { Tag } from "@/components/sxy/Tag";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { supabase } from "@/integrations/supabase/client";
import { downloadInvoicePdf } from "@/lib/financials/invoice-pdf";
import {
  formatDate,
  formatMoney,
  statusTone,
  type InvoiceRow,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/admin/invoices")({
  head: () => ({ meta: [{ title: "All Invoices — SXY's Corporate Club" }] }),
  component: AdminInvoicesRoute,
});

interface InvoiceWithMember extends InvoiceRow {
  member_name: string | null;
  member_email: string | null;
}

const STATUSES = ["all", "draft", "sent", "paid", "overdue", "cancelled"] as const;
type StatusFilter = (typeof STATUSES)[number];

function AdminInvoicesRoute() {
  return (
    <AdminRoute>
      <AppLayout title="All Invoices">
        <AdminInvoicesInner />
      </AppLayout>
    </AdminRoute>
  );
}

function AdminInvoicesInner() {
  const qc = useQueryClient();
  const [status, setStatus] = React.useState<StatusFilter>("all");
  const [search, setSearch] = React.useState("");

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["financials", "admin", "invoices"],
    queryFn: async () => {
      const { data } = await supabase
        .from("invoices")
        .select("*, profile:profiles!invoices_user_id_fkey(full_name,email)")
        .order("issued_at", { ascending: false })
        .limit(500);
      return (data ?? []).map((r) => {
        const profile = (r as unknown as {
          profile?: { full_name?: string | null; email?: string | null };
        }).profile;
        return {
          ...(r as InvoiceRow),
          member_name: profile?.full_name ?? null,
          member_email: profile?.email ?? null,
        } as InvoiceWithMember;
      });
    },
  });

  const filtered = React.useMemo(() => {
    let r = rows;
    if (status !== "all") r = r.filter((x) => x.status === status);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      r = r.filter(
        (x) =>
          x.invoice_number.toLowerCase().includes(q) ||
          x.client_name.toLowerCase().includes(q) ||
          (x.member_name ?? "").toLowerCase().includes(q) ||
          (x.member_email ?? "").toLowerCase().includes(q),
      );
    }
    return r;
  }, [rows, status, search]);

  const totals = React.useMemo(() => {
    let outstanding = 0;
    let paid = 0;
    let overdue = 0;
    for (const r of rows) {
      const amt = Number(r.amount);
      if (r.status === "paid") paid += amt;
      else if (r.status === "overdue") overdue += amt;
      else if (r.status === "sent" || r.status === "draft") outstanding += amt;
    }
    return { outstanding, paid, overdue };
  }, [rows]);

  const updateStatus = useMutation({
    mutationFn: async (input: { id: string; status: InvoiceRow["status"] }) => {
      const patch: Partial<InvoiceRow> = { status: input.status };
      if (input.status === "paid") patch.paid_at = new Date().toISOString();
      const { error } = await supabase
        .from("invoices")
        .update(patch)
        .eq("id", input.id);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      toast.success(`Invoice marked ${vars.status}.`);
      qc.invalidateQueries({ queryKey: ["financials"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-8">
      <FinancialsNav />

      <section className="grid gap-4 sm:grid-cols-3">
        <StatTile label="Outstanding" value={formatMoney(totals.outstanding)} />
        <StatTile label="Paid (all-time)" value={formatMoney(totals.paid)} />
        <StatTile
          label="Overdue"
          value={formatMoney(totals.overdue)}
          deltaTone={totals.overdue > 0 ? "down" : "neutral"}
        />
      </section>

      <SxyCard accent>
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="font-display text-lg text-teal-light">
            Invoices ({filtered.length})
          </h2>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Input
              placeholder="Search number, client, or member…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-72"
            />
            <Select
              value={status}
              onValueChange={(v) => setStatus(v as StatusFilter)}
            >
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s === "all" ? "All statuses" : s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-[10px] uppercase tracking-wider text-text-dim">
              <tr className="border-b border-border-base/40">
                <th className="py-2 text-left font-semibold">Number</th>
                <th className="py-2 text-left font-semibold">Member</th>
                <th className="py-2 text-left font-semibold">Client</th>
                <th className="py-2 text-left font-semibold">Issued</th>
                <th className="py-2 text-right font-semibold">Amount</th>
                <th className="py-2 text-left font-semibold">Status</th>
                <th className="py-2 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-text-dim">
                    Loading…
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-text-dim">
                    No invoices match these filters.
                  </td>
                </tr>
              ) : (
                filtered.map((inv) => (
                  <tr
                    key={inv.id}
                    className="border-b border-border-base/30 last:border-0 align-top"
                  >
                    <td className="py-3 font-mono text-teal-light">
                      {inv.invoice_number}
                    </td>
                    <td className="py-3 text-text-primary">
                      <div className="font-medium">
                        {inv.member_name ?? "—"}
                      </div>
                      <div className="text-[11px] text-text-dim">
                        {inv.member_email ?? ""}
                      </div>
                    </td>
                    <td className="py-3 text-text-muted">
                      {inv.client_name}
                    </td>
                    <td className="py-3 text-text-muted">
                      {formatDate(inv.issued_at)}
                    </td>
                    <td className="py-3 text-right font-semibold text-text-primary">
                      {formatMoney(inv.amount)}
                    </td>
                    <td className="py-3">
                      <Tag variant={statusTone(inv.status)}>{inv.status}</Tag>
                    </td>
                    <td className="py-3">
                      <div className="flex flex-wrap justify-end gap-1.5">
                        {inv.status !== "paid" &&
                        inv.status !== "cancelled" ? (
                          <>
                            <SxyButton
                              variant="gold"
                              size="sm"
                              onClick={() =>
                                updateStatus.mutate({
                                  id: inv.id,
                                  status: "paid",
                                })
                              }
                            >
                              Mark Paid
                            </SxyButton>
                            <SxyButton
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                updateStatus.mutate({
                                  id: inv.id,
                                  status: "cancelled",
                                })
                              }
                            >
                              Cancel
                            </SxyButton>
                          </>
                        ) : null}
                        <SxyButton
                          variant="outline"
                          size="sm"
                          onClick={() =>
                            downloadInvoicePdf(inv, inv.member_name ?? undefined)
                          }
                        >
                          PDF
                        </SxyButton>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </SxyCard>
    </div>
  );
}
