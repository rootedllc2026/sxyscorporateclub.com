import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/kiddos/")({
  beforeLoad: () => {
    throw redirect({ to: "/kiddos/hub" });
  },
});
