import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { TierGate } from "@/components/sxy/TierGate";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { StatTile } from "@/components/sxy/StatTile";
import { Tag } from "@/components/sxy/Tag";
import {
  BID_CURRENCY,
  bidStatusVariant,
} from "@/lib/bidding/shared";

export const Route = createFileRoute("/bidding/my-bids")({
  head: () => ({ meta: [{ title: "My Bids — SXY's Corporate Club" }] }),
  component: MyBidsPage,
});

function MyBidsPage() {
  return (
    <AppLayout
      title="My Bids"
      actions={
        <SxyButton variant="primary" size="sm" asChild>
          <Link to="/bidding">Browse projects</Link>
        </SxyButton>
      }
    >
      <TierGate feature="Club Market">
        <MyBidsContent />
      </TierGate>
    </AppLayout>
  );
}

function MyBidsContent() {
  const { currentUser } = useAuth();
  const userId = currentUser?.id;

  const { data, isLoading } = useQuery({
    queryKey: ["bidding", "my-bids", userId],
    enabled: !!userId,
    queryFn: async () => {
      const [bidsRes, earningsRes, competitorRes] = await Promise.all([
        supabase
          .from("bids")
          .select(
            "id, status, amount, proposed_price, created_at, project_id, projects(title, budget, budget_min, budget_max, status)",
          )
          .eq("bidder_id", userId!)
          .order("created_at", { ascending: false }),
        supabase
          .from("transactions")
          .select("amount")
          .eq("user_id", userId!)
          .in("txn_type", ["bid_award", "payout"]),
        supabase.from("bids").select("project_id"),
      ]);

      const bids = bidsRes.data ?? [];
      const competitorMap = new Map<string, number>();
      for (const row of competitorRes.data ?? []) {
        competitorMap.set(
          (row as any).project_id,
          (competitorMap.get((row as any).project_id) ?? 0) + 1,
        );
      }
      const totalEarned = (earningsRes.data ?? []).reduce(
        (s: number, r: { amount: number | string }) => s + Number(r.amount ?? 0),
        0,
      );

      return {
        bids,
        competitorMap,
        stats: {
          submitted: bids.length,
          shortlisted: bids.filter((b: any) => b.status === "shortlisted").length,
          won: bids.filter((b: any) => b.status === "awarded").length,
          totalEarned,
        },
      };
    },
  });

  return (
    <div className="space-y-8">
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile
          label="Total Submitted"
          value={String(data?.stats.submitted ?? 0)}
        />
        <StatTile
          label="Shortlisted"
          value={String(data?.stats.shortlisted ?? 0)}
        />
        <StatTile label="Won" value={String(data?.stats.won ?? 0)} />
        <StatTile
          label="Total Earned"
          value={BID_CURRENCY.format(data?.stats.totalEarned ?? 0)}
        />
      </section>

      <SxyCard accent>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg text-teal-light">
            Your bid history
          </h2>
          <Tag variant="gray">{data?.bids.length ?? 0}</Tag>
        </div>

        {isLoading ? (
          <p className="mt-4 text-sm text-text-muted">Loading…</p>
        ) : !data || data.bids.length === 0 ? (
          <div className="mt-6 rounded-xl border border-dashed border-border-base/60 p-8 text-center">
            <p className="font-editorial text-base text-text-muted">
              You haven't placed any bids yet.
            </p>
            <SxyButton variant="primary" size="sm" className="mt-4" asChild>
              <Link to="/bidding">Find a project</Link>
            </SxyButton>
          </div>
        ) : (
          <ul className="mt-4 divide-y divide-border-base/40">
            {data.bids.map((b: any) => {
              const projectTitle = b.projects?.title ?? "Project";
              const competitors = Math.max(
                0,
                (data.competitorMap.get(b.project_id) ?? 1) - 1,
              );
              const amount = Number(b.proposed_price ?? b.amount ?? 0);
              return (
                <li key={b.id} className="py-4">
                  <Link
                    to="/bidding/$id"
                    params={{ id: b.project_id }}
                    className="flex flex-wrap items-center justify-between gap-3"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-editorial text-base text-text-primary">
                        {projectTitle}
                      </p>
                      <p className="mt-1 text-xs text-text-dim">
                        Submitted{" "}
                        {new Date(b.created_at).toLocaleDateString(undefined, {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                        })}
                        {" · "}
                        {competitors} competitor
                        {competitors === 1 ? "" : "s"}
                      </p>
                    </div>
                    <p className="font-mono text-sm text-text-primary">
                      {BID_CURRENCY.format(amount)}
                    </p>
                    <Tag variant={bidStatusVariant(b.status)}>{b.status}</Tag>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </SxyCard>
    </div>
  );
}
