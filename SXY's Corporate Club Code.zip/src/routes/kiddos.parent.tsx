import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { KidShell } from "@/components/kiddos/KidShell";
import { CreditBadge } from "@/components/kiddos/CreditBadge";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  createChildAccount,
  loadCredits,
  createChore,
  approveChore,
  parentApproveVideo,
  rejectKiddoVideo,
  parentApproveBusiness,
  rejectKidBusinessPage,
  adminApproveVideo,
  adminApproveBusiness,
  submitKiddoVideo,
} from "@/lib/kiddos/kiddos.functions";

export const Route = createFileRoute("/kiddos/parent")({
  head: () => ({ meta: [{ title: "Parent Command Center — Kiddos" }] }),
  component: () => (
    <KidShell title="Parent Command Center 👤">
      <ParentContent />
    </KidShell>
  ),
});

type ChildRow = {
  id: string;
  display_name: string;
  avatar_emoji: string | null;
  balance: number;
};

function ParentContent() {
  const { currentUser } = useAuth();
  const parentId = currentUser?.id;
  const qc = useQueryClient();

  const createChildFn = useServerFn(createChildAccount);
  const loadFn = useServerFn(loadCredits);
  const choreFn = useServerFn(createChore);
  const approveFn = useServerFn(approveChore);
  const approveVideoFn = useServerFn(parentApproveVideo);
  const rejectVideoFn = useServerFn(rejectKiddoVideo);
  const approveBizFn = useServerFn(parentApproveBusiness);
  const rejectBizFn = useServerFn(rejectKidBusinessPage);
  const adminVideoFn = useServerFn(adminApproveVideo);
  const adminBizFn = useServerFn(adminApproveBusiness);
  const officialVideoFn = useServerFn(submitKiddoVideo);

  const { data: roles } = useQuery({
    queryKey: ["my-roles", parentId],
    queryFn: async () => {
      if (!parentId) return [];
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", parentId);
      return (data ?? []).map((r) => r.role);
    },
    enabled: !!parentId,
  });
  const isAdmin = (roles ?? []).includes("admin");

  const { data: children } = useQuery({
    queryKey: ["parent-children", parentId],
    queryFn: async (): Promise<ChildRow[]> => {
      if (!parentId) return [];
      const { data: links, error } = await supabase
        .from("parent_child_links")
        .select("child_user_id")
        .eq("parent_user_id", parentId)
        .eq("status", "active");
      if (error) throw error;
      const ids = (links ?? []).map((l) => l.child_user_id);
      if (ids.length === 0) return [];
      const [{ data: kids }, { data: wallets }] = await Promise.all([
        supabase.from("kiddo_profiles").select("id, display_name, avatar_emoji").in("id", ids),
        supabase.from("kiddo_wallets").select("user_id, balance_credits").in("user_id", ids),
      ]);
      const walletMap = new Map((wallets ?? []).map((w) => [w.user_id, w.balance_credits]));
      return (kids ?? []).map((k) => ({
        id: k.id,
        display_name: k.display_name,
        avatar_emoji: k.avatar_emoji,
        balance: walletMap.get(k.id) ?? 0,
      }));
    },
    enabled: !!parentId,
  });

  const { data: pendingChores } = useQuery({
    queryKey: ["parent-chores-pending", parentId],
    queryFn: async () => {
      if (!parentId) return [];
      const { data, error } = await supabase
        .from("chores")
        .select("id, title, reward_credits, status, child_user_id")
        .eq("parent_user_id", parentId)
        .in("status", ["submitted", "open"])
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!parentId,
  });

  const { data: pendingVideos } = useQuery({
    queryKey: ["parent-pending-videos", parentId],
    queryFn: async () => {
      if (!parentId) return [];
      // children of this parent
      const { data: links } = await supabase
        .from("parent_child_links")
        .select("child_user_id")
        .eq("parent_user_id", parentId)
        .eq("status", "active");
      const ids = (links ?? []).map((l) => l.child_user_id);
      if (!ids.length) return [];
      const { data, error } = await supabase
        .from("kiddo_videos")
        .select("id, title, status, creator_user_id, video_url, storage_path, duration_seconds, description")
        .in("creator_user_id", ids)
        .eq("status", "pending_parent")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!parentId,
  });

  const { data: pendingBusinesses } = useQuery({
    queryKey: ["parent-pending-biz", parentId],
    queryFn: async () => {
      if (!parentId) return [];
      const { data: links } = await supabase
        .from("parent_child_links")
        .select("child_user_id")
        .eq("parent_user_id", parentId)
        .eq("status", "active");
      const ids = (links ?? []).map((l) => l.child_user_id);
      if (!ids.length) return [];
      const { data, error } = await supabase
        .from("kid_business_pages")
        .select("id, name, tagline, youtube_url, owner_user_id, status")
        .in("owner_user_id", ids)
        .eq("status", "pending_parent")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!parentId,
  });

  const { data: adminPendingVideos } = useQuery({
    queryKey: ["admin-pending-videos"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kiddo_videos")
        .select("id, title, video_url, storage_path, duration_seconds, creator_user_id, description")
        .eq("status", "pending_admin")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: isAdmin,
  });

  const { data: adminPendingBiz } = useQuery({
    queryKey: ["admin-pending-biz"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kid_business_pages")
        .select("id, name, tagline, youtube_url, owner_user_id")
        .eq("status", "pending_admin")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: isAdmin,
  });

  const invalidateAll = () => {
    qc.invalidateQueries({ queryKey: ["parent-children", parentId] });
    qc.invalidateQueries({ queryKey: ["parent-chores-pending", parentId] });
    qc.invalidateQueries({ queryKey: ["parent-pending-videos", parentId] });
    qc.invalidateQueries({ queryKey: ["parent-pending-biz", parentId] });
    qc.invalidateQueries({ queryKey: ["admin-pending-videos"] });
    qc.invalidateQueries({ queryKey: ["admin-pending-biz"] });
  };

  const createChildMut = useMutation({
    mutationFn: (input: { displayName: string; dateOfBirth: string; loginEmail: string; tempPassword: string; avatarEmoji?: string }) =>
      createChildFn({ data: input }),
    onSuccess: () => { toast.success("Child account created."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });

  const loadMut = useMutation({
    mutationFn: (v: { childId: string; amount: number }) => loadFn({ data: v }),
    onSuccess: () => { toast.success("Credits loaded."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });

  const choreMut = useMutation({
    mutationFn: (v: { childId: string; title: string; rewardCredits: number }) => choreFn({ data: v }),
    onSuccess: () => { toast.success("Chore added."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });

  const approveMut = useMutation({
    mutationFn: (choreId: string) => approveFn({ data: { choreId } }),
    onSuccess: () => { toast.success("Approved & credited."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });

  const approveVideoMut = useMutation({
    mutationFn: (videoId: string) => approveVideoFn({ data: { videoId } }),
    onSuccess: () => { toast.success("Sent to admin for final approval."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const rejectVideoMut = useMutation({
    mutationFn: (videoId: string) => rejectVideoFn({ data: { videoId, reason: "Parent rejected" } }),
    onSuccess: () => { toast.success("Rejected."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const approveBizMut = useMutation({
    mutationFn: (pageId: string) => approveBizFn({ data: { pageId } }),
    onSuccess: () => { toast.success("Sent to admin."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const rejectBizMut = useMutation({
    mutationFn: (pageId: string) => rejectBizFn({ data: { pageId, reason: "Parent rejected" } }),
    onSuccess: () => { toast.success("Rejected."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const adminVideoMut = useMutation({
    mutationFn: (videoId: string) => adminVideoFn({ data: { videoId } }),
    onSuccess: () => { toast.success("Published."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const adminBizMut = useMutation({
    mutationFn: (pageId: string) => adminBizFn({ data: { pageId } }),
    onSuccess: () => { toast.success("Published."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const officialVideoMut = useMutation({
    mutationFn: (v: { title: string; description?: string; topic?: string; videoUrl: string; durationSeconds: number }) =>
      officialVideoFn({ data: { ...v, kind: "official" } }),
    onSuccess: () => { toast.success("Official video published."); invalidateAll(); },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!currentUser) {
    return (
      <div className="kid-card text-center">
        <p className="mb-4">Sign in to manage your children.</p>
        <Link to="/login" className="kid-btn kid-btn-primary">Sign in</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-5">
      <section className="kid-card">
        <h2 className="text-xl mb-3">Add a child</h2>
        <CreateChildForm onCreate={(v) => createChildMut.mutate(v)} pending={createChildMut.isPending} />
        <p className="text-xs text-[var(--kid-ink-muted)] mt-2">
          You provide consent on their behalf. For under-13s we follow COPPA — no marketing, no PII in listings.
        </p>
      </section>

      <section className="kid-card">
        <h2 className="text-xl mb-3">Your children</h2>
        {!children || children.length === 0 ? (
          <p className="text-sm text-[var(--kid-ink-muted)]">No children linked yet.</p>
        ) : (
          <ul className="space-y-4">
            {children.map((c) => (
              <li key={c.id} className="border-t pt-4 first:border-0 first:pt-0 border-[rgba(10,92,107,0.08)]">
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl" aria-hidden>{c.avatar_emoji ?? "🧒"}</span>
                    <div>
                      <div className="font-semibold">{c.display_name}</div>
                      <CreditBadge amount={c.balance} />
                    </div>
                  </div>
                </div>
                <LoadCreditsForm onLoad={(amount) => loadMut.mutate({ childId: c.id, amount })} pending={loadMut.isPending} />
                <AddChoreForm onAdd={(title, reward) => choreMut.mutate({ childId: c.id, title, rewardCredits: reward })} pending={choreMut.isPending} />
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="kid-card">
        <h2 className="text-xl mb-3">Chores waiting on you</h2>
        {!pendingChores || pendingChores.length === 0 ? (
          <p className="text-sm text-[var(--kid-ink-muted)]">Nothing pending.</p>
        ) : (
          <ul className="space-y-2">
            {pendingChores.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-3">
                <div>
                  <div className="font-medium">{c.title}</div>
                  <div className="text-xs text-[var(--kid-ink-muted)] capitalize">{c.status}</div>
                </div>
                <div className="flex items-center gap-3">
                  <CreditBadge amount={`+${c.reward_credits}`} />
                  {c.status === "submitted" && (
                    <button
                      type="button"
                      className="kid-btn kid-btn-primary"
                      onClick={() => approveMut.mutate(c.id)}
                      disabled={approveMut.isPending}
                    >
                      Approve
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="kid-card">
        <h2 className="text-xl mb-3">Videos awaiting your approval</h2>
        {!pendingVideos || pendingVideos.length === 0 ? (
          <p className="text-sm text-[var(--kid-ink-muted)]">Nothing pending.</p>
        ) : (
          <ul className="space-y-3">
            {pendingVideos.map((v) => (
              <li key={v.id} className="border-t pt-3 first:border-0 first:pt-0 border-[rgba(10,92,107,0.08)]">
                <div className="font-medium">{v.title}</div>
                {v.description && <p className="text-sm text-[var(--kid-ink-muted)] line-clamp-2">{v.description}</p>}
                <div className="text-xs text-[var(--kid-ink-muted)] mt-1">
                  {v.duration_seconds}s · {v.video_url ? "External link" : "Uploaded file"}
                </div>
                {v.video_url && (
                  <a href={v.video_url} target="_blank" rel="noreferrer" className="text-xs underline text-[var(--kid-teal)]">
                    Preview link
                  </a>
                )}
                <div className="mt-2 flex gap-2">
                  <button type="button" className="kid-btn kid-btn-primary" onClick={() => approveVideoMut.mutate(v.id)} disabled={approveVideoMut.isPending}>
                    Approve → Admin
                  </button>
                  <button type="button" className="kid-btn kid-btn-ghost" onClick={() => rejectVideoMut.mutate(v.id)} disabled={rejectVideoMut.isPending}>
                    Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="kid-card">
        <h2 className="text-xl mb-3">Business pages awaiting your approval</h2>
        {!pendingBusinesses || pendingBusinesses.length === 0 ? (
          <p className="text-sm text-[var(--kid-ink-muted)]">Nothing pending.</p>
        ) : (
          <ul className="space-y-3">
            {pendingBusinesses.map((b) => (
              <li key={b.id} className="border-t pt-3 first:border-0 first:pt-0 border-[rgba(10,92,107,0.08)]">
                <div className="font-medium">{b.name}</div>
                {b.tagline && <p className="text-sm text-[var(--kid-ink-muted)]">{b.tagline}</p>}
                {b.youtube_url && (
                  <a href={b.youtube_url} target="_blank" rel="noreferrer" className="text-xs underline text-[var(--kid-teal)]">
                    YouTube: {b.youtube_url}
                  </a>
                )}
                <div className="mt-2 flex gap-2">
                  <button type="button" className="kid-btn kid-btn-primary" onClick={() => approveBizMut.mutate(b.id)} disabled={approveBizMut.isPending}>
                    Approve → Admin
                  </button>
                  <button type="button" className="kid-btn kid-btn-ghost" onClick={() => rejectBizMut.mutate(b.id)} disabled={rejectBizMut.isPending}>
                    Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {isAdmin && (
        <>
          <section className="kid-card" style={{ borderColor: "var(--kid-gold)" }}>
            <h2 className="text-xl mb-3">🛡️ Admin: Upload official video</h2>
            <OfficialVideoForm onSubmit={(v) => officialVideoMut.mutate(v)} pending={officialVideoMut.isPending} />
          </section>

          <section className="kid-card" style={{ borderColor: "var(--kid-gold)" }}>
            <h2 className="text-xl mb-3">🛡️ Admin: Videos to publish</h2>
            {!adminPendingVideos || adminPendingVideos.length === 0 ? (
              <p className="text-sm text-[var(--kid-ink-muted)]">Nothing waiting.</p>
            ) : (
              <ul className="space-y-3">
                {adminPendingVideos.map((v) => (
                  <li key={v.id} className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-medium">{v.title}</div>
                      {v.video_url && (
                        <a href={v.video_url} target="_blank" rel="noreferrer" className="text-xs underline text-[var(--kid-teal)]">
                          Preview
                        </a>
                      )}
                    </div>
                    <button type="button" className="kid-btn kid-btn-gold" onClick={() => adminVideoMut.mutate(v.id)} disabled={adminVideoMut.isPending}>
                      Publish
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="kid-card" style={{ borderColor: "var(--kid-gold)" }}>
            <h2 className="text-xl mb-3">🛡️ Admin: Business pages to publish</h2>
            {!adminPendingBiz || adminPendingBiz.length === 0 ? (
              <p className="text-sm text-[var(--kid-ink-muted)]">Nothing waiting.</p>
            ) : (
              <ul className="space-y-3">
                {adminPendingBiz.map((b) => (
                  <li key={b.id} className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-medium">{b.name}</div>
                      {b.tagline && <p className="text-xs text-[var(--kid-ink-muted)]">{b.tagline}</p>}
                    </div>
                    <button type="button" className="kid-btn kid-btn-gold" onClick={() => adminBizMut.mutate(b.id)} disabled={adminBizMut.isPending}>
                      Publish
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  );
}

function OfficialVideoForm({
  onSubmit,
  pending,
}: {
  onSubmit: (v: { title: string; description?: string; topic?: string; videoUrl: string; durationSeconds: number }) => void;
  pending: boolean;
}) {
  const [title, setTitle] = React.useState("");
  const [url, setUrl] = React.useState("");
  const [topic, setTopic] = React.useState("");
  const [dur, setDur] = React.useState("");
  const [desc, setDesc] = React.useState("");
  return (
    <form
      className="grid gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const d = Number(dur);
        if (!title.trim() || !url.trim() || !Number.isFinite(d) || d <= 0) {
          toast.error("Title, URL, and duration required.");
          return;
        }
        onSubmit({
          title: title.trim(),
          videoUrl: url.trim(),
          topic: topic.trim() || undefined,
          description: desc.trim() || undefined,
          durationSeconds: Math.floor(d),
        });
        setTitle(""); setUrl(""); setTopic(""); setDur(""); setDesc("");
      }}
    >
      <input className="kid-input" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
      <input className="kid-input" placeholder="YouTube / Vimeo URL" value={url} onChange={(e) => setUrl(e.target.value)} />
      <div className="flex gap-2 flex-wrap">
        <input className="kid-input flex-1 min-w-[160px]" placeholder="Topic" value={topic} onChange={(e) => setTopic(e.target.value)} />
        <input className="kid-input" style={{ width: 160 }} placeholder="Duration (sec)" inputMode="numeric" value={dur} onChange={(e) => setDur(e.target.value)} />
      </div>
      <textarea className="kid-input" placeholder="Description" rows={2} value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={1000} />
      <button type="submit" className="kid-btn kid-btn-gold self-start" disabled={pending}>Publish official</button>
    </form>
  );
}

function CreateChildForm({
  onCreate,
  pending,
}: {
  onCreate: (v: { displayName: string; dateOfBirth: string; loginEmail: string; tempPassword: string; avatarEmoji?: string }) => void;
  pending: boolean;
}) {
  const [name, setName] = React.useState("");
  const [dob, setDob] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [pw, setPw] = React.useState("");
  const [emoji, setEmoji] = React.useState("🧒");
  return (
    <form
      className="grid gap-2 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim() || !dob || !email.trim() || pw.length < 8) {
          toast.error("Fill all fields. Password ≥ 8 chars.");
          return;
        }
        onCreate({ displayName: name.trim(), dateOfBirth: dob, loginEmail: email.trim(), tempPassword: pw, avatarEmoji: emoji });
        setName(""); setDob(""); setEmail(""); setPw("");
      }}
    >
      <input className="kid-input" placeholder="Display name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} />
      <input className="kid-input" type="date" value={dob} onChange={(e) => setDob(e.target.value)} aria-label="Date of birth" />
      <input className="kid-input" type="email" placeholder="Login email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input className="kid-input" type="password" placeholder="Temp password (min 8)" value={pw} onChange={(e) => setPw(e.target.value)} />
      <input className="kid-input" style={{ width: 80 }} value={emoji} onChange={(e) => setEmoji(e.target.value.slice(0, 4))} aria-label="Avatar emoji" />
      <button type="submit" className="kid-btn kid-btn-primary" disabled={pending}>Create child</button>
    </form>
  );
}

function LoadCreditsForm({ onLoad, pending }: { onLoad: (n: number) => void; pending: boolean }) {
  const [amt, setAmt] = React.useState("");
  return (
    <form
      className="flex gap-2 mt-2"
      onSubmit={(e) => {
        e.preventDefault();
        const n = Number(amt);
        if (!Number.isFinite(n) || n <= 0) return;
        onLoad(Math.floor(n));
        setAmt("");
      }}
    >
      <input className="kid-input" placeholder="Load credits" inputMode="numeric" value={amt} onChange={(e) => setAmt(e.target.value)} style={{ maxWidth: 160 }} />
      <button type="submit" className="kid-btn kid-btn-gold" disabled={pending}>Load</button>
    </form>
  );
}

function AddChoreForm({ onAdd, pending }: { onAdd: (title: string, reward: number) => void; pending: boolean }) {
  const [title, setTitle] = React.useState("");
  const [reward, setReward] = React.useState("");
  return (
    <form
      className="flex flex-wrap gap-2 mt-2"
      onSubmit={(e) => {
        e.preventDefault();
        const n = Number(reward);
        if (!title.trim() || !Number.isFinite(n) || n <= 0) return;
        onAdd(title.trim(), Math.floor(n));
        setTitle(""); setReward("");
      }}
    >
      <input className="kid-input flex-1 min-w-[160px]" placeholder="New chore (e.g. Take out trash)" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
      <input className="kid-input" placeholder="Credits" inputMode="numeric" value={reward} onChange={(e) => setReward(e.target.value)} style={{ width: 110 }} />
      <button type="submit" className="kid-btn kid-btn-ghost" disabled={pending}>Add chore</button>
    </form>
  );
}
