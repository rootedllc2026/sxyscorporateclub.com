import { createFileRoute, Navigate } from "@tanstack/react-router";

// Legacy `/projects` route — the bidding portal now lives at `/bidding`.
// Redirect to keep any old links/bookmarks working.
export const Route = createFileRoute("/projects")({
  component: () => <Navigate to="/bidding" replace />,
});
