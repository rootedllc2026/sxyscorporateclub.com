/**
 * /community — three-column real-time chat experience.
 *
 *   ChannelSidebar (220) │ MessageFeed + Compose │ RightPanel (260)
 *
 * Subscribes to public.messages + public.reactions via Supabase Realtime
 * scoped to the active channel so new messages appear without refresh.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { ChannelSidebar, type DmThread } from "@/components/community/ChannelSidebar";
import { MessageRow } from "@/components/community/MessageRow";
import { ComposeBar } from "@/components/community/ComposeBar";
import { RightPanel } from "@/components/community/RightPanel";
import { PostModal } from "@/components/community/PostModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  formatDayDivider,
  isNewDay,
  shouldGroupWithPrev,
} from "@/lib/community/format";
import type {
  CommunityChannel,
  CommunityMessage,
  CommunityProfileLite,
  CommunityReaction,
  MessageWithSender,
} from "@/lib/community/types";
import { Lock, Plus } from "lucide-react";

export const Route = createFileRoute("/community")({
  head: () => ({
    meta: [{ title: "Community Exchange — SXY's Corporate Club" }],
  }),
  component: () => (
    <AppLayout title="Community Exchange" actions={<TopbarActions />}>
      <CommunityPage />
    </AppLayout>
  ),
});

// `actions` slot lives outside CommunityPage so the modal trigger can talk
// to the page through a tiny shared event.
function TopbarActions() {
  return (
    <SxyButton
      size="sm"
      onClick={() =>
        window.dispatchEvent(new CustomEvent("community:open-post"))
      }
    >
      <Plus className="h-3.5 w-3.5" /> Post
    </SxyButton>
  );
}

// ─────────────────────────────────────────────────────────────────────────────

function CommunityPage() {
  const { currentUser, userProfile, userTier, isAdmin } = useAuth();
  const queryClient = useQueryClient();

  const [activeChannelId, setActiveChannelId] = React.useState<string | null>(
    null,
  );
  const [activeDmUserId, setActiveDmUserId] = React.useState<string | null>(
    null,
  );
  const [postOpen, setPostOpen] = React.useState(false);
  const [postType, setPostType] = React.useState<
    "message" | "announcement"
  >("message");
  const [gateChannel, setGateChannel] =
    React.useState<CommunityChannel | null>(null);

  const canAccessVip = userTier === "vip";

  // Open Post modal from topbar
  React.useEffect(() => {
    function handler() {
      setPostType("message");
      setPostOpen(true);
    }
    window.addEventListener("community:open-post", handler);
    return () =>
      window.removeEventListener("community:open-post", handler);
  }, []);

  // Heartbeat to update last_seen_at
  React.useEffect(() => {
    if (!currentUser) return;
    let cancelled = false;
    const ping = async () => {
      if (cancelled) return;
      await supabase
        .from("profiles")
        .update({ last_seen_at: new Date().toISOString() })
        .eq("id", currentUser.id);
    };
    void ping();
    const id = window.setInterval(ping, 60_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [currentUser]);

  // Channels
  const channelsQuery = useQuery({
    queryKey: ["community", "channels"],
    queryFn: async (): Promise<CommunityChannel[]> => {
      const { data, error } = await supabase
        .from("channels")
        .select(
          "id, slug, name, description, channel_type, icon, state_code, display_order",
        )
        .order("display_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as CommunityChannel[];
    },
    staleTime: 5 * 60_000,
  });

  // Pick a default channel once channels load
  React.useEffect(() => {
    if (!activeChannelId && !activeDmUserId && channelsQuery.data) {
      const general =
        channelsQuery.data.find((c) => c.slug === "general") ??
        channelsQuery.data[0];
      if (general) setActiveChannelId(general.id);
    }
  }, [channelsQuery.data, activeChannelId, activeDmUserId]);

  // Members
  const membersQuery = useQuery({
    queryKey: ["community", "members"],
    queryFn: async (): Promise<CommunityProfileLite[]> => {
      const { data: profiles, error } = await supabase
        .from("profiles")
        .select(
          "id, full_name, email, avatar_color, state, tier, last_seen_at, is_active",
        )
        .eq("is_active", true);
      if (error) throw error;
      const { data: admins } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "admin");
      const adminSet = new Set((admins ?? []).map((r) => r.user_id));
      return (profiles ?? []).map((p) => ({
        ...(p as CommunityProfileLite),
        is_admin: adminSet.has(p.id),
      }));
    },
    staleTime: 60_000,
  });

  // Visits
  const visitsQuery = useQuery({
    queryKey: ["community", "visits", currentUser?.id],
    enabled: !!currentUser,
    queryFn: async (): Promise<Record<string, string>> => {
      const { data, error } = await supabase
        .from("channel_visits")
        .select("channel_id, last_visited")
        .eq("user_id", currentUser!.id);
      if (error) throw error;
      const map: Record<string, string> = {};
      for (const v of data ?? []) map[v.channel_id] = v.last_visited;
      return map;
    },
    staleTime: 10_000,
  });

  // Unread counts per channel: messages.created_at > last_visited
  const unreadQuery = useQuery({
    queryKey: [
      "community",
      "unread",
      currentUser?.id,
      channelsQuery.data?.length,
    ],
    enabled: !!currentUser && !!channelsQuery.data,
    queryFn: async (): Promise<Record<string, number>> => {
      if (!channelsQuery.data) return {};
      const visits = visitsQuery.data ?? {};
      const epoch = "1970-01-01T00:00:00Z";
      const out: Record<string, number> = {};
      // Cheap parallel HEAD count per channel
      await Promise.all(
        channelsQuery.data.map(async (c) => {
          const since = visits[c.id] ?? epoch;
          const { count } = await supabase
            .from("messages")
            .select("id", { count: "exact", head: true })
            .eq("channel_id", c.id)
            .gt("created_at", since);
          out[c.id] = count ?? 0;
        }),
      );
      return out;
    },
    staleTime: 30_000,
  });

  // Messages for active channel
  const activeChannel = React.useMemo(
    () =>
      channelsQuery.data?.find((c) => c.id === activeChannelId) ?? null,
    [channelsQuery.data, activeChannelId],
  );

  // VIP gate
  React.useEffect(() => {
    if (!activeChannel) return;
    if (
      activeChannel.channel_type === "vip" &&
      !canAccessVip &&
      !isAdmin
    ) {
      setGateChannel(activeChannel);
    } else {
      setGateChannel(null);
    }
  }, [activeChannel, canAccessVip, isAdmin]);

  const messagesQuery = useQuery({
    queryKey: ["community", "messages", activeChannelId],
    enabled: !!activeChannelId && !gateChannel,
    queryFn: async (): Promise<MessageWithSender[]> => {
      if (!activeChannelId) return [];
      const { data: msgs, error } = await supabase
        .from("messages")
        .select(
          "id, channel_id, sender_id, content, body, embed_title, embed_desc, embed_link, is_pinned, is_announcement, pinned_by, pinned_at, dm_recipient_id, post_type, resource_category, resource_visibility, poll_options, poll_closes_at, created_at",
        )
        .eq("channel_id", activeChannelId)
        .order("created_at", { ascending: true })
        .limit(50);
      if (error) throw error;
      const typed = (msgs ?? []) as CommunityMessage[];

      const senderIds = Array.from(new Set(typed.map((m) => m.sender_id)));
      const messageIds = typed.map((m) => m.id);

      const [{ data: senders }, { data: reactions }, { data: admins }] =
        await Promise.all([
          senderIds.length
            ? supabase
                .from("profiles")
                .select(
                  "id, full_name, email, avatar_color, state, tier, last_seen_at, is_active",
                )
                .in("id", senderIds)
            : Promise.resolve({ data: [] as CommunityProfileLite[] }),
          messageIds.length
            ? supabase
                .from("reactions")
                .select("id, message_id, user_id, emoji")
                .in("message_id", messageIds)
            : Promise.resolve({ data: [] as CommunityReaction[] }),
          senderIds.length
            ? supabase
                .from("user_roles")
                .select("user_id")
                .eq("role", "admin")
                .in("user_id", senderIds)
            : Promise.resolve({ data: [] as { user_id: string }[] }),
        ]);

      const adminSet = new Set((admins ?? []).map((r) => r.user_id));
      const senderMap = new Map<string, CommunityProfileLite>();
      for (const s of (senders ?? []) as CommunityProfileLite[]) {
        senderMap.set(s.id, { ...s, is_admin: adminSet.has(s.id) });
      }
      const reactionsByMsg = new Map<string, CommunityReaction[]>();
      for (const r of (reactions ?? []) as CommunityReaction[]) {
        const arr = reactionsByMsg.get(r.message_id) ?? [];
        arr.push(r);
        reactionsByMsg.set(r.message_id, arr);
      }

      return typed.map<MessageWithSender>((m) => ({
        ...m,
        sender: senderMap.get(m.sender_id) ?? null,
        reactions: reactionsByMsg.get(m.id) ?? [],
      }));
    },
  });

  // Pinned + announcements
  const pinnedQuery = useQuery({
    queryKey: ["community", "pinned", activeChannelId],
    enabled: !!activeChannelId,
    queryFn: async (): Promise<MessageWithSender[]> => {
      if (!activeChannelId) return [];
      const { data, error } = await supabase
        .from("messages")
        .select(
          "id, channel_id, sender_id, content, body, embed_title, embed_desc, embed_link, is_pinned, is_announcement, pinned_by, pinned_at, dm_recipient_id, post_type, resource_category, resource_visibility, poll_options, poll_closes_at, created_at",
        )
        .eq("channel_id", activeChannelId)
        .eq("is_pinned", true)
        .order("pinned_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      const typed = (data ?? []) as CommunityMessage[];
      const senderIds = Array.from(new Set(typed.map((m) => m.sender_id)));
      const { data: senders } = senderIds.length
        ? await supabase
            .from("profiles")
            .select("id, full_name, email, avatar_color, state, tier, last_seen_at, is_active")
            .in("id", senderIds)
        : { data: [] as CommunityProfileLite[] };
      const map = new Map<string, CommunityProfileLite>();
      for (const s of (senders ?? []) as CommunityProfileLite[]) {
        map.set(s.id, s);
      }
      return typed.map((m) => ({
        ...m,
        sender: map.get(m.sender_id) ?? null,
        reactions: [],
      }));
    },
  });

  const announcementsQuery = useQuery({
    queryKey: ["community", "announcements"],
    queryFn: async (): Promise<MessageWithSender[]> => {
      const { data, error } = await supabase
        .from("messages")
        .select(
          "id, channel_id, sender_id, content, body, embed_title, embed_desc, embed_link, is_pinned, is_announcement, pinned_by, pinned_at, dm_recipient_id, post_type, resource_category, resource_visibility, poll_options, poll_closes_at, created_at",
        )
        .eq("is_announcement", true)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      const typed = (data ?? []) as CommunityMessage[];
      const senderIds = Array.from(new Set(typed.map((m) => m.sender_id)));
      const { data: senders } = senderIds.length
        ? await supabase
            .from("profiles")
            .select("id, full_name, email, avatar_color, state, tier, last_seen_at, is_active")
            .in("id", senderIds)
        : { data: [] as CommunityProfileLite[] };
      const map = new Map<string, CommunityProfileLite>();
      for (const s of (senders ?? []) as CommunityProfileLite[]) {
        map.set(s.id, s);
      }
      return typed.map((m) => ({
        ...m,
        sender: map.get(m.sender_id) ?? null,
        reactions: [],
      }));
    },
    staleTime: 60_000,
  });

  // DM threads — distinct other participants
  const dmThreadsQuery = useQuery<DmThread[]>({
    queryKey: ["community", "dms", currentUser?.id],
    enabled: !!currentUser,
    queryFn: async (): Promise<DmThread[]> => {
      if (!currentUser) return [];
      const { data, error } = await supabase
        .from("messages")
        .select("sender_id, dm_recipient_id, created_at")
        .or(
          `sender_id.eq.${currentUser.id},dm_recipient_id.eq.${currentUser.id}`,
        )
        .not("dm_recipient_id", "is", null)
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      const lastByOther = new Map<string, string>();
      for (const row of (data ?? []) as Array<{
        sender_id: string;
        dm_recipient_id: string;
        created_at: string;
      }>) {
        const other =
          row.sender_id === currentUser.id
            ? row.dm_recipient_id
            : row.sender_id;
        if (!lastByOther.has(other)) lastByOther.set(other, row.created_at);
      }
      const otherIds = Array.from(lastByOther.keys());
      if (otherIds.length === 0) return [];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, email, avatar_color, state, tier, last_seen_at, is_active")
        .in("id", otherIds);
      const profMap = new Map<string, CommunityProfileLite>();
      for (const p of (profiles ?? []) as CommunityProfileLite[]) {
        profMap.set(p.id, p);
      }
      return otherIds
        .map((id) => {
          const p = profMap.get(id);
          if (!p) return null;
          return {
            otherUser: p,
            lastMessageAt: lastByOther.get(id)!,
          } satisfies DmThread;
        })
        .filter((x): x is DmThread => x !== null);
    },
    staleTime: 30_000,
  });

  // Realtime subscription per active channel
  React.useEffect(() => {
    if (!activeChannelId || gateChannel) return;
    const channel: RealtimeChannel = supabase
      .channel(`community:${activeChannelId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "messages",
          filter: `channel_id=eq.${activeChannelId}`,
        },
        () => {
          queryClient.invalidateQueries({
            queryKey: ["community", "messages", activeChannelId],
          });
          queryClient.invalidateQueries({
            queryKey: ["community", "pinned", activeChannelId],
          });
        },
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "reactions" },
        () => {
          queryClient.invalidateQueries({
            queryKey: ["community", "messages", activeChannelId],
          });
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [activeChannelId, gateChannel, queryClient]);

  // Mark channel as visited
  React.useEffect(() => {
    if (!activeChannelId || !currentUser || gateChannel) return;
    const id = window.setTimeout(() => {
      void supabase
        .from("channel_visits")
        .upsert(
          {
            user_id: currentUser.id,
            channel_id: activeChannelId,
            last_visited: new Date().toISOString(),
          },
          { onConflict: "user_id,channel_id" },
        )
        .then(() => {
          queryClient.invalidateQueries({
            queryKey: ["community", "unread"],
          });
          queryClient.invalidateQueries({
            queryKey: ["community", "visits"],
          });
        });
    }, 800);
    return () => window.clearTimeout(id);
  }, [activeChannelId, currentUser, gateChannel, queryClient, messagesQuery.data?.length]);

  // Auto-scroll to bottom on new messages
  const feedRef = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    const el = feedRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messagesQuery.data, activeChannelId]);

  // ─── Actions ──────────────────────────────────────────────────────────────

  async function handleSend(text: string) {
    if (!currentUser || !activeChannelId) return;
    const { error } = await supabase.from("messages").insert({
      sender_id: currentUser.id,
      channel_id: activeChannelId,
      content: text,
      body: text, // legacy NOT NULL column
      post_type: "message",
    });
    if (error) {
      console.error("[community] send failed", error);
    }
  }

  async function handleToggleReaction(messageId: string, emoji: string) {
    if (!currentUser) return;
    const msg = messagesQuery.data?.find((m) => m.id === messageId);
    const mine = msg?.reactions.find(
      (r) => r.user_id === currentUser.id && r.emoji === emoji,
    );
    if (mine) {
      await supabase.from("reactions").delete().eq("id", mine.id);
    } else {
      await supabase.from("reactions").insert({
        message_id: messageId,
        user_id: currentUser.id,
        emoji,
      });
    }
    queryClient.invalidateQueries({
      queryKey: ["community", "messages", activeChannelId],
    });
  }

  async function handleTogglePin(message: MessageWithSender) {
    if (!isAdmin) return;
    const next = !message.is_pinned;
    await supabase
      .from("messages")
      .update({
        is_pinned: next,
        pinned_by: next ? currentUser?.id ?? null : null,
        pinned_at: next ? new Date().toISOString() : null,
      })
      .eq("id", message.id);
    queryClient.invalidateQueries({
      queryKey: ["community", "messages", activeChannelId],
    });
    queryClient.invalidateQueries({
      queryKey: ["community", "pinned", activeChannelId],
    });
  }

  // ─── Render ───────────────────────────────────────────────────────────────

  const messages = messagesQuery.data ?? [];
  const topPinned = pinnedQuery.data?.[0] ?? null;

  // The main element of AppLayout has padding (px-4 pb-24 pt-6 on mobile,
  // sm:px-6 sm:py-8, lg:px-10 lg:py-10). We negate it so the chat fills the
  // viewport edge-to-edge. Mobile keeps space for the bottom nav (pb-24 stays).
  return (
    <div
      className="-mx-4 -mt-6 flex h-[calc(100vh-4rem-5rem)] sm:-mx-6 sm:-my-8 md:h-[calc(100vh-4rem)] lg:-mx-10 lg:-my-10"
    >
      <ChannelSidebar
        channels={channelsQuery.data ?? []}
        unreadByChannel={unreadQuery.data ?? {}}
        activeChannelId={activeChannelId}
        activeDmUserId={activeDmUserId}
        dmThreads={dmThreadsQuery.data ?? []}
        canAccessVip={canAccessVip}
        isAdmin={isAdmin}
        onSelectChannel={(c) => {
          setActiveDmUserId(null);
          setActiveChannelId(c.id);
        }}
        onSelectDm={(u) => {
          setActiveChannelId(null);
          setActiveDmUserId(u.id);
        }}
      />

      {/* Center: feed + compose */}
      <section className="flex min-w-0 flex-1 flex-col bg-charcoal">
        {/* Channel header */}
        <div className="flex h-12 shrink-0 items-center gap-2 border-b border-border-base/60 bg-charcoal-soft px-6">
          {activeChannel ? (
            <>
              <span aria-hidden className="text-base text-text-muted">
                {activeChannel.channel_type === "public"
                  ? "#"
                  : (activeChannel.icon ?? "#")}
              </span>
              <h2 className="font-display text-sm text-text-primary">
                {activeChannel.name}
              </h2>
              {activeChannel.description ? (
                <span className="hidden text-xs text-text-dim md:inline">
                  · {activeChannel.description}
                </span>
              ) : null}
            </>
          ) : (
            <h2 className="font-display text-sm text-text-muted">
              Select a channel
            </h2>
          )}
        </div>

        {gateChannel ? (
          <UpgradeGate channelName={gateChannel.name} />
        ) : (
          <>
            {topPinned ? (
              <div className="flex items-center gap-2 border-b border-[color:var(--border-gold)] bg-[color:var(--gold-glow)] px-6 py-2 text-xs">
                <span className="text-gold-light">📌 Pinned</span>
                <span className="truncate text-text-muted">
                  {topPinned.content ?? topPinned.body}
                </span>
                <span className="ml-auto text-[10px] text-text-dim">
                  {topPinned.sender?.full_name ?? "Member"}
                </span>
              </div>
            ) : null}

            <div
              ref={feedRef}
              className="flex-1 overflow-y-auto py-2"
            >
              {messagesQuery.isLoading ? (
                <p className="px-6 py-6 text-sm text-text-dim">
                  Loading messages…
                </p>
              ) : messages.length === 0 ? (
                <p className="px-6 py-10 text-center text-sm text-text-dim">
                  No messages yet. Be the first to say something.
                </p>
              ) : (
                messages.map((m, i) => {
                  const prev = messages[i - 1];
                  const continued = shouldGroupWithPrev(m, prev);
                  const showDay = isNewDay(m, prev);
                  return (
                    <React.Fragment key={m.id}>
                      {showDay ? (
                        <div className="my-3 flex items-center gap-3 px-6">
                          <span className="h-px flex-1 bg-border-base" />
                          <span className="text-[10px] uppercase tracking-wider text-text-dim">
                            {formatDayDivider(m.created_at)}
                          </span>
                          <span className="h-px flex-1 bg-border-base" />
                        </div>
                      ) : null}
                      <MessageRow
                        message={m}
                        continued={continued && !showDay}
                        currentUserId={currentUser?.id ?? ""}
                        isAdmin={isAdmin}
                        onToggleReaction={handleToggleReaction}
                        onTogglePin={handleTogglePin}
                      />
                    </React.Fragment>
                  );
                })
              )}
            </div>

            <ComposeBar
              placeholder={
                activeChannel
                  ? `Message #${activeChannel.name}…`
                  : "Select a channel…"
              }
              disabled={!activeChannel}
              onSend={handleSend}
            />
          </>
        )}
      </section>

      <RightPanel
        members={membersQuery.data ?? []}
        pinned={pinnedQuery.data ?? []}
        announcements={announcementsQuery.data ?? []}
        isAdmin={isAdmin}
        onNewAnnouncement={() => {
          setPostType("announcement");
          setPostOpen(true);
        }}
      />

      {currentUser && channelsQuery.data ? (
        <PostModal
          open={postOpen}
          onOpenChange={setPostOpen}
          channels={channelsQuery.data.filter(
            (c) => c.channel_type !== "vip" || canAccessVip || isAdmin,
          )}
          defaultChannelId={activeChannelId}
          defaultType={postType}
          currentUserId={currentUser.id}
          isAdmin={isAdmin}
          onPosted={() => {
            queryClient.invalidateQueries({
              queryKey: ["community", "messages"],
            });
            queryClient.invalidateQueries({
              queryKey: ["community", "announcements"],
            });
          }}
        />
      ) : null}
      {/* Reference userProfile to satisfy unused-var rule even when not displayed */}
      <span className="sr-only">{userProfile?.full_name ?? ""}</span>
    </div>
  );
}

function UpgradeGate({ channelName }: { channelName: string }) {
  return (
    <div className="flex flex-1 items-center justify-center px-6 py-10">
      <div className="max-w-md rounded-xl border border-[color:var(--border-gold)] bg-[color:var(--gold-glow)] p-8 text-center">
        <Lock className="mx-auto h-8 w-8 text-gold-light" />
        <h3 className="mt-3 font-display text-xl text-gold-light">
          #{channelName} is VIP-only
        </h3>
        <p className="mt-2 text-sm text-text-muted">
          Upgrade your membership to unlock the inner-circle channels, deal
          flow, and the VIP lounge.
        </p>
        <SxyButton variant="gold" size="sm" className="mt-4" asChild>
          <a href="/membership">Upgrade to VIP</a>
        </SxyButton>
      </div>
    </div>
  );
}
