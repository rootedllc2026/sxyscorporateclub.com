import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { StatTile } from "@/components/sxy/StatTile";
import { Tag } from "@/components/sxy/Tag";
import { cn } from "@/lib/utils";
import {
  USD,
  USD_2,
  bookingStatusLabel,
  bookingStatusVariant,
  categoryBannerGradient,
  formatPrice,
  pageStatusVariant,
  refCategoryEmoji,
  refCategoryLabel,
} from "@/lib/referrals/shared";

export const Route = createFileRoute("/referrals/my-page")({
  head: () => ({ meta: [{ title: "My Page — SXY's Corporate Club" }] }),
  component: MyPage,
});

function MyPage() {
  return (
    <AppLayout
      title="My Page & Bookings"
      actions={
        <SxyButton variant="outline" size="sm" asChild>
          <Link to="/referrals">← Directory</Link>
        </SxyButton>
      }
    >
      <MyPageContent />
    </AppLayout>
  );
}

function MyPageContent() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [payoutOpen, setPayoutOpen] = React.useState(false);

  const { data: page, isLoading } = useQuery({
    queryKey: ["referrals", "my-page", currentUser?.id],
    enabled: !!currentUser,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("business_pages")
        .select("*")
        .eq("owner_id", currentUser!.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: bookingsData } = useQuery({
    queryKey: ["referrals", "my-bookings", currentUser?.id],
    enabled: !!currentUser,
    queryFn: async () => {
      const today = new Date().toISOString().slice(0, 10);
      const [upcoming, completed, asBuyer] = await Promise.all([
        supabase
          .from("bookings")
          .select("*, business_pages(business_name, icon_emoji, category)")
          .eq("provider_id", currentUser!.id)
          .gte("booked_date", today)
          .neq("status", "cancelled")
          .order("booked_date", { ascending: true })
          .limit(20),
        supabase
          .from("bookings")
          .select("*, business_pages(business_name, icon_emoji, category)")
          .eq("provider_id", currentUser!.id)
          .eq("status", "completed")
          .order("booked_date", { ascending: false })
          .limit(10),
        supabase
          .from("bookings")
          .select("*, business_pages(id, business_name, icon_emoji, category)")
          .eq("buyer_id", currentUser!.id)
          .order("booked_date", { ascending: false })
          .limit(20),
      ]);
      return {
        upcoming: upcoming.data ?? [],
        completed: completed.data ?? [],
        asBuyer: asBuyer.data ?? [],
      };
    },
  });

  React.useEffect(() => {
    if (!isLoading && currentUser && page === null) {
    }
  }, [isLoading, page, currentUser]);

  if (isLoading) {
    return (
      <SxyCard><p className="text-sm text-text-muted">Loading your page…</p></SxyCard>
    );
  }

  if (!page) {
    return (
      <div className="space-y-6">
        <SxyCard accent>
          <h2 className="font-display text-xl text-teal-light">
            You don't have a business page yet
          </h2>
          <p className="mt-2 text-sm text-text-muted">
            List your services in the Club directory and start receiving
            bookings from other members.
          </p>
          <div className="mt-4">
            <SxyButton variant="gold" asChild>
              <Link to="/referrals/request">+ Request My Page</Link>
            </SxyButton>
          </div>
        </SxyCard>

        <BuyerBookings bookings={bookingsData?.asBuyer ?? []} />
      </div>
    );
  }

  if (page.status === "pending") {
    return (
      <div className="space-y-6">
        <SxyCard accent>
          <Tag variant="amber">Pending review</Tag>
          <h2 className="mt-3 font-display text-xl text-teal-light">
            Your page is under review
          </h2>
          <p className="mt-2 text-sm text-text-muted">
            An admin is finalizing your listing. You'll see your live page and
            booking calendar here as soon as it's published.
          </p>
        </SxyCard>

        <SubmittedPagePreview page={page} />
        <BuyerBookings bookings={bookingsData?.asBuyer ?? []} />
      </div>
    );
  }

  const upcoming = bookingsData?.upcoming ?? [];
  const completed = bookingsData?.completed ?? [];
  const fees = Number(page.total_revenue ?? 0) * Number(page.platform_fee_pct ?? 0) / 100;
  const net = Math.max(0, Number(page.total_revenue ?? 0) - fees);

  return (
    <div className="space-y-8">
      <section
        className="overflow-hidden rounded-2xl border border-border-teal/60"
      >
        <div
          className="flex h-32 items-center justify-center"
          style={{ backgroundImage: categoryBannerGradient(page.category) }}
        >
          <span aria-hidden className="text-6xl drop-shadow-2xl">
            {page.icon_emoji ?? refCategoryEmoji(page.category)}
          </span>
        </div>
        <div className="space-y-4 bg-charcoal-card p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="font-display text-2xl text-text-primary">
                {page.business_name}
              </h1>
              <div className="mt-2 flex flex-wrap gap-2">
                <Tag variant={pageStatusVariant(page.status)}>
                  {page.status.toUpperCase()}
                </Tag>
                <Tag variant="teal">{refCategoryLabel(page.category)}</Tag>
              </div>
            </div>
            <div className="flex gap-2">
              <SxyButton variant="outline" size="sm" asChild>
                <Link to="/referrals/$id" params={{ id: page.id }}>
                  View public page
                </Link>
              </SxyButton>
              <SxyButton
                variant="gold"
                size="sm"
                onClick={() => setPayoutOpen(true)}
              >
                Request Payout
              </SxyButton>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatTile label="Total Bookings" value={String(page.total_bookings ?? 0)} />
            <StatTile
              label="Total Revenue"
              value={USD.format(Number(page.total_revenue ?? 0))}
            />
            <StatTile label="Platform Fees" value={USD.format(fees)} />
            <StatTile label="Net to You" value={USD.format(net)} />
          </div>
        </div>
      </section>

      <section>
        <h2 className="font-display text-lg text-teal-light">Upcoming bookings</h2>
        <div className="mt-3 space-y-3">
          {upcoming.length === 0 ? (
            <SxyCard>
              <p className="text-sm text-text-muted">
                No upcoming bookings — keep your page sharp and members will
                reach out.
              </p>
            </SxyCard>
          ) : (
            upcoming.map((b: any) => <BookingRow key={b.id} booking={b} />)
          )}
        </div>
      </section>

      {completed.length > 0 ? (
        <section>
          <h2 className="font-display text-lg text-teal-light">Recently completed</h2>
          <div className="mt-3 space-y-3">
            {completed.map((b: any) => <BookingRow key={b.id} booking={b} />)}
          </div>
        </section>
      ) : null}

      <BuyerBookings bookings={bookingsData?.asBuyer ?? []} />

      {payoutOpen ? (
        <PayoutModal
          maxAmount={net}
          onClose={() => setPayoutOpen(false)}
          onSubmitted={() => {
            void queryClient.invalidateQueries({ queryKey: ["referrals"] });
            setPayoutOpen(false);
          }}
        />
      ) : null}
    </div>
  );
}

function SubmittedPagePreview({ page }: { page: any }) {
  return (
    <SxyCard>
      <p className="sxy-section-label">Your submission</p>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        <Detail label="Business" value={page.business_name} />
        <Detail label="Category" value={refCategoryLabel(page.category)} />
        <Detail label="Service area" value={page.service_area ?? "—"} />
        <Detail label="Fee" value={`${Number(page.platform_fee_pct)}%`} />
      </div>
      {page.description ? (
        <p className="mt-4 whitespace-pre-line rounded-lg border border-border-base/40 bg-charcoal-soft p-3 text-sm text-text-primary">
          {page.description}
        </p>
      ) : null}
    </SxyCard>
  );
}

function BookingRow({ booking }: { booking: any }) {
  const bp = booking.business_pages ?? {};
  return (
    <SxyCard className="flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <span aria-hidden className="text-2xl">
          {bp.icon_emoji ?? refCategoryEmoji(bp.category)}
        </span>
        <div>
          <p className="font-medium text-text-primary">
            {bp.business_name ?? "Booking"}
          </p>
          <p className="text-xs text-text-dim">
            {new Date(booking.booked_date).toLocaleDateString(undefined, {
              weekday: "short", month: "short", day: "numeric",
            })}
            {booking.booked_time ? ` · ${booking.booked_time}` : ""}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Tag variant={bookingStatusVariant(booking.status)}>
          {bookingStatusLabel(booking.status)}
        </Tag>
        {booking.payment_method === "trade" ? (
          <Tag variant="teal">🤝 Trade</Tag>
        ) : (
          <p className="font-mono text-sm text-gold">
            {USD_2.format(Number(booking.total_amount ?? 0))}
          </p>
        )}
        <SxyButton variant="ghost" size="sm" asChild>
          <Link to="/bookings/$id" params={{ id: booking.id }}>View</Link>
        </SxyButton>
      </div>
    </SxyCard>
  );
}

function BuyerBookings({ bookings }: { bookings: any[] }) {
  if (bookings.length === 0) return null;
  return (
    <section>
      <h2 className="font-display text-lg text-teal-light">Bookings I've made</h2>
      <div className="mt-3 space-y-3">
        {bookings.map((b) => (
          <SxyCard key={b.id} className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span aria-hidden className="text-2xl">
                {b.business_pages?.icon_emoji ?? refCategoryEmoji(b.business_pages?.category)}
              </span>
              <div>
                <p className="font-medium text-text-primary">
                  {b.business_pages?.business_name ?? "Booking"}
                </p>
                <p className="text-xs text-text-dim">
                  {new Date(b.booked_date).toLocaleDateString(undefined, {
                    weekday: "short", month: "short", day: "numeric",
                  })}
                  {b.booked_time ? ` · ${b.booked_time}` : ""}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Tag variant={bookingStatusVariant(b.status)}>
                {bookingStatusLabel(b.status)}
              </Tag>
              {b.payment_method === "trade" ? (
                <Tag variant="teal">🤝 Trade</Tag>
              ) : (
                <p className="font-mono text-sm text-gold">
                  {USD_2.format(Number(b.total_amount ?? 0))}
                </p>
              )}
              <SxyButton variant="ghost" size="sm" asChild>
                <Link to="/bookings/$id" params={{ id: b.id }}>View</Link>
              </SxyButton>
            </div>
          </SxyCard>
        ))}
      </div>
    </section>
  );
}

function PayoutModal({
  maxAmount,
  onClose,
  onSubmitted,
}: {
  maxAmount: number;
  onClose: () => void;
  onSubmitted: () => void;
}) {
  const { currentUser } = useAuth();
  const [amount, setAmount] = React.useState<string>(maxAmount.toFixed(2));
  const [method, setMethod] = React.useState("stripe");
  const [destination, setDestination] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  async function submit() {
    if (!currentUser) return;
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.from("payouts").insert({
        user_id: currentUser.id,
        amount: amt,
        method,
        destination: destination.trim() || null,
        notes: notes.trim() || null,
        status: "requested",
      });
      if (error) throw error;
      toast.success("Payout requested. We'll review it shortly.");
      onSubmitted();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't request payout");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-border-teal/60 bg-charcoal-card p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <p className="sxy-section-label">Request payout</p>
        <p className="mt-2 text-xs text-text-dim">
          Available balance (estimated): {USD_2.format(Math.max(0, maxAmount))}
        </p>

        <div className="mt-4 space-y-3">
          <Field label="Amount (USD)">
            <input
              type="number"
              min="0"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className={inputCls}
            />
          </Field>
          <Field label="Payout method">
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className={inputCls}
            >
              <option value="stripe">Stripe Connect</option>
              <option value="bank">Bank transfer (ACH)</option>
              <option value="paypal">PayPal</option>
            </select>
          </Field>
          <Field label="Destination (account / email)">
            <input
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              maxLength={120}
              className={inputCls}
              placeholder="e.g. ****1234 or you@example.com"
            />
          </Field>
          <Field label="Notes (optional)">
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              maxLength={300}
              className={cn(inputCls, "resize-y")}
            />
          </Field>
        </div>

        <div className="mt-5 flex items-center justify-between gap-3">
          <SxyButton variant="ghost" onClick={onClose}>Cancel</SxyButton>
          <SxyButton variant="gold" disabled={submitting} onClick={submit}>
            {submitting ? "Submitting…" : "Request payout"}
          </SxyButton>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
        {label}
      </p>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.18em] text-text-dim">
        {label}
      </p>
      <p className="mt-1 text-sm text-text-primary">{value}</p>
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-border-base/60 bg-charcoal-soft px-3 py-2 text-sm text-text-primary placeholder:text-text-dim focus:border-border-teal focus:outline-none";
