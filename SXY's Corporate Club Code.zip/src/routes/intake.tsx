/**
 * Public intake form — /intake
 *
 * No auth required. Posts to /api/public/intake which inserts the row,
 * sends the client confirmation, and notifies admin@ + strategy@.
 *
 * Designed to be the new home for sxysinvestors.com's sasha-intake.html
 * — the legacy form should set its action to
 *   https://www.sxyscorporateclub.com/api/public/intake
 * and submissions will land in the same pipeline as in-app intake.
 */
import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { SxyButton } from "@/components/sxy/SxyButton";

export const Route = createFileRoute("/intake")({
  head: () => ({
    meta: [
      { title: "Get in touch — SXY's Corporate Club" },
      {
        name: "description",
        content:
          "Tell us what you need. Our strategists respond within 1 business day. Or book a free Club Chat directly via Calendly.",
      },
      { property: "og:title", content: "Get in touch — SXY's Corporate Club" },
      {
        property: "og:description",
        content:
          "Strategy, entity formation, AI integration and more. We respond within 1 business day.",
      },
    ],
  }),
  component: IntakePage,
});

const SERVICE_INTERESTS = [
  "Strategy Session",
  "Entity Formation",
  "AI Integration",
  "Financial Literacy Workshop",
  "General Inquiry",
] as const;

const CALENDLY_LINK = "https://calendly.com/rootedllc2026/30min";

type FormState = {
  full_name: string;
  email: string;
  phone: string;
  business_name: string;
  service_interest: (typeof SERVICE_INTERESTS)[number];
  message: string;
  preferred_contact: "email" | "phone";
};

const INITIAL: FormState = {
  full_name: "",
  email: "",
  phone: "",
  business_name: "",
  service_interest: "Strategy Session",
  message: "",
  preferred_contact: "email",
};

function IntakePage() {
  const [form, setForm] = React.useState<FormState>(INITIAL);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [success, setSuccess] = React.useState(false);

  const update =
    <K extends keyof FormState>(key: K) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value as FormState[K] }));

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    // Light client-side validation; server re-validates with zod.
    if (!form.full_name.trim() || !form.email.trim()) {
      setError("Please share your name and email so we can reach you.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/public/intake", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body?.error ?? "Something went wrong.");
      }
      setSuccess(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-charcoal-base text-text-primary">
      {/* Brand header */}
      <header className="border-b border-border-base/40 bg-charcoal-soft/60 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4 sm:px-6">
          <Link to="/" className="font-editorial text-lg text-gold-light">
            SXY's Corporate Club
          </Link>
          <Link
            to="/login"
            className="text-xs font-semibold uppercase tracking-[0.18em] text-text-dim hover:text-text-primary"
          >
            Member sign in
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 py-10 sm:px-6 sm:py-16">
        {success ? <SuccessPanel /> : (
          <>
            <div className="mb-8">
              <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-gold-light">
                Get in touch
              </p>
              <h1 className="mt-2 font-editorial text-3xl text-text-primary sm:text-4xl">
                Tell us what you're working on
              </h1>
              <p className="mt-3 text-sm leading-relaxed text-text-muted">
                Share a few details and one of our strategists will be in touch
                within 1 business day. Prefer to skip the form?{" "}
                <a
                  href={CALENDLY_LINK}
                  target="_blank"
                  rel="noreferrer"
                  className="text-gold underline-offset-2 hover:underline"
                >
                  Book a free Club Chat directly →
                </a>
              </p>
            </div>

            <form
              onSubmit={handleSubmit}
              className="space-y-5 rounded-2xl border border-border-base/60 bg-charcoal-card p-6 sm:p-8"
            >
              <Field label="Full name" required>
                <input
                  required
                  type="text"
                  autoComplete="name"
                  value={form.full_name}
                  onChange={update("full_name")}
                  className={inputClass}
                />
              </Field>

              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Email address" required>
                  <input
                    required
                    type="email"
                    autoComplete="email"
                    value={form.email}
                    onChange={update("email")}
                    className={inputClass}
                  />
                </Field>
                <Field label="Phone number">
                  <input
                    type="tel"
                    autoComplete="tel"
                    value={form.phone}
                    onChange={update("phone")}
                    className={inputClass}
                  />
                </Field>
              </div>

              <Field label="Business name">
                <input
                  type="text"
                  autoComplete="organization"
                  value={form.business_name}
                  onChange={update("business_name")}
                  className={inputClass}
                />
              </Field>

              <Field label="Service interest" required>
                <select
                  required
                  value={form.service_interest}
                  onChange={update("service_interest")}
                  className={inputClass}
                >
                  {SERVICE_INTERESTS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </Field>

              <Field label="Message / details">
                <textarea
                  rows={5}
                  value={form.message}
                  onChange={update("message")}
                  placeholder="What can we help you with?"
                  className={`${inputClass} resize-y leading-relaxed`}
                />
              </Field>

              <Field label="Preferred contact method" required>
                <div className="flex gap-3">
                  {(["email", "phone"] as const).map((opt) => (
                    <label
                      key={opt}
                      className={`flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-lg border px-4 py-2.5 text-sm capitalize transition-colors ${
                        form.preferred_contact === opt
                          ? "border-gold/70 bg-gold/10 text-gold-light"
                          : "border-border-base/60 text-text-muted hover:border-border-teal"
                      }`}
                    >
                      <input
                        type="radio"
                        name="preferred_contact"
                        value={opt}
                        checked={form.preferred_contact === opt}
                        onChange={() =>
                          setForm((f) => ({ ...f, preferred_contact: opt }))
                        }
                        className="sr-only"
                      />
                      {opt}
                    </label>
                  ))}
                </div>
              </Field>

              {error && (
                <p
                  role="alert"
                  className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive-foreground"
                >
                  {error}
                </p>
              )}

              <div className="flex flex-col-reverse gap-3 pt-2 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-xs text-text-dim">
                  We respond within 1 business day.
                </p>
                <SxyButton
                  type="submit"
                  variant="gold"
                  disabled={submitting}
                  className="w-full sm:w-auto"
                >
                  {submitting ? "Sending…" : "Submit inquiry →"}
                </SxyButton>
              </div>
            </form>
          </>
        )}
      </main>
    </div>
  );
}

const inputClass =
  "w-full rounded-lg border border-border-base/60 bg-charcoal-base px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-dim transition-colors focus:border-gold/60 focus:outline-none focus:ring-2 focus:ring-gold/20";

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">
        {label}
        {required && <span className="ml-1 text-gold">*</span>}
      </span>
      {children}
    </label>
  );
}

function SuccessPanel() {
  return (
    <div className="rounded-2xl border border-gold/40 bg-charcoal-card p-8 text-center sm:p-12">
      <div
        aria-hidden
        className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-gold/15 text-2xl text-gold"
      >
        ✓
      </div>
      <h1 className="font-editorial text-3xl text-text-primary">
        Thank you!
      </h1>
      <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-text-muted">
        We'll be in touch within 1 business day. In the meantime, you can book
        your free Club Chat directly via Calendly.
      </p>
      <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <a href={CALENDLY_LINK} target="_blank" rel="noreferrer">
          <SxyButton variant="gold">Book a Club Chat →</SxyButton>
        </a>
        <Link to="/">
          <SxyButton variant="outline">Back to home</SxyButton>
        </Link>
      </div>
    </div>
  );
}
