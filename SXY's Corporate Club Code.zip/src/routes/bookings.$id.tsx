/**
 * /bookings/$id — booking detail with trade-agreement workflow and document
 * uploads (service agreements, invoices, purchase orders). Visible to the
 * booking's buyer, provider, and admins.
 */
import * as React from "react";
import {
  createFileRoute,
  Link,
  notFound,
  useRouter,
} from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  USD_2,
  bookingStatusLabel,
  bookingStatusVariant,
} from "@/lib/referrals/shared";
import { cn } from "@/lib/utils";

const BUCKET = "booking-documents";

export const Route = createFileRoute("/bookings/$id")({
  head: () => ({ meta: [{ title: "Booking — SXY's Corporate Club" }] }),
  component: BookingDetailPage,
  errorComponent: ({ error, reset }) => {
    const router = useRouter();
    return (
      <AppLayout title="Booking">
        <SxyCard accent>
          <p className="text-sm text-text-muted">{error.message}</p>
          <div className="mt-3">
            <SxyButton
              variant="outline"
              size="sm"
              onClick={() => {
                reset();
                void router.invalidate();
              }}
            >
              Retry
            </SxyButton>
          </div>
        </SxyCard>
      </AppLayout>
    );
  },
  notFoundComponent: () => (
    <AppLayout title="Not found">
      <SxyCard accent>
        <h2 className="font-display text-xl text-teal-light">Booking not found</h2>
        <div className="mt-4">
          <SxyButton variant="primary" size="sm" asChild>
            <Link to="/referrals/my-page">Back to My Page</Link>
          </SxyButton>
        </div>
      </SxyCard>
    </AppLayout>
  ),
});

function BookingDetailPage() {
  const { id } = Route.useParams();
  return (
    <AppLayout title="Booking Details">
      <DetailContent bookingId={id} />
    </AppLayout>
  );
}

function DetailContent({ bookingId }: { bookingId: string }) {
  const { currentUser } = useAuth();
  const queryClient = useQueryClient();

  const { data: booking, isLoading } = useQuery({
    queryKey: ["booking", bookingId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*, business_pages(business_name, icon_emoji, category)")
        .eq("id", bookingId)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw notFound();
      return data as any;
    },
  });

  const { data: agreement } = useQuery({
    queryKey: ["trade-agreement", bookingId],
    enabled: !!booking && booking.payment_method === "trade",
    queryFn: async () => {
      const { data, error } = await supabase
        .from("trade_agreements")
        .select("*")
        .eq("booking_id", bookingId)
        .maybeSingle();
      if (error) throw error;
      return data as any;
    },
  });

  if (isLoading || !booking) {
    return (
      <SxyCard>
        <p className="text-sm text-text-muted">Loading booking…</p>
      </SxyCard>
    );
  }

  const isBuyer = currentUser?.id === booking.buyer_id;
  const isProvider = currentUser?.id === booking.provider_id;
  const bp = booking.business_pages ?? {};

  return (
    <div className="space-y-6">
      <SxyCard accent className="space-y-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-3xl" aria-hidden>{bp.icon_emoji ?? "📅"}</span>
            <div>
              <h1 className="font-display text-2xl text-text-primary">
                {bp.business_name ?? "Booking"}
              </h1>
              <p className="text-xs text-text-dim">
                {new Date(booking.booked_date).toLocaleDateString(undefined, {
                  weekday: "short", month: "short", day: "numeric", year: "numeric",
                })}
                {booking.booked_time ? ` · ${booking.booked_time}` : ""}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Tag variant={bookingStatusVariant(booking.status)}>
              {bookingStatusLabel(booking.status)}
            </Tag>
            <Tag variant={booking.payment_method === "trade" ? "teal" : "gold"}>
              {booking.payment_method === "trade" ? "🤝 Trade" : "💳 Card"}
            </Tag>
          </div>
        </div>
        {booking.notes ? (
          <p className="rounded-lg border border-border-base/40 bg-charcoal-soft p-3 text-sm text-text-muted">
            {booking.notes}
          </p>
        ) : null}
        {booking.payment_method === "card" ? (
          <div className="flex items-baseline justify-between border-t border-border-base/30 pt-3">
            <p className="text-xs uppercase tracking-wider text-text-dim">Total</p>
            <p className="font-display text-2xl text-gold">
              {USD_2.format(Number(booking.total_amount ?? 0))}
            </p>
          </div>
        ) : null}
      </SxyCard>

      {booking.payment_method === "trade" ? (
        <TradeAgreementPanel
          booking={booking}
          agreement={agreement}
          isBuyer={isBuyer}
          isProvider={isProvider}
          onChanged={() => {
            void queryClient.invalidateQueries({ queryKey: ["booking", bookingId] });
            void queryClient.invalidateQueries({ queryKey: ["trade-agreement", bookingId] });
          }}
        />
      ) : null}

      <DocumentsPanel
        bookingId={bookingId}
        canUpload={isBuyer || isProvider}
      />
    </div>
  );
}

// ─────────────────────── Trade agreement ───────────────────────

function TradeAgreementPanel({
  booking,
  agreement,
  isBuyer,
  isProvider,
  onChanged,
}: {
  booking: any;
  agreement: any | null | undefined;
  isBuyer: boolean;
  isProvider: boolean;
  onChanged: () => void;
}) {
  const [submitting, setSubmitting] = React.useState(false);
  const [declineReason, setDeclineReason] = React.useState("");
  const [showDecline, setShowDecline] = React.useState(false);

  if (!agreement) {
    return (
      <SxyCard accent>
        <h2 className="font-display text-lg text-teal-light">Trade agreement</h2>
        <p className="mt-2 text-sm text-text-muted">No agreement on file yet.</p>
      </SxyCard>
    );
  }

  const buyerAccepted = !!agreement.buyer_accepted_at;
  const providerAccepted = !!agreement.provider_accepted_at;
  const declined = !!agreement.declined_at;
  const bothAccepted = buyerAccepted && providerAccepted;

  async function accept() {
    setSubmitting(true);
    const patch: Record<string, any> = {};
    if (isBuyer && !buyerAccepted) patch.buyer_accepted_at = new Date().toISOString();
    if (isProvider && !providerAccepted) patch.provider_accepted_at = new Date().toISOString();
    const willBeFullyAccepted =
      (buyerAccepted || !!patch.buyer_accepted_at) &&
      (providerAccepted || !!patch.provider_accepted_at);

    const { error } = await supabase
      .from("trade_agreements")
      .update(patch as never)
      .eq("id", agreement.id);
    if (error) {
      toast.error(error.message);
      setSubmitting(false);
      return;
    }

    if (willBeFullyAccepted) {
      const { error: bErr } = await supabase
        .from("bookings")
        .update({ status: "confirmed" })
        .eq("id", booking.id);
      if (bErr) toast.error(bErr.message);
    }

    toast.success(willBeFullyAccepted ? "Trade confirmed!" : "Acceptance recorded.");
    setSubmitting(false);
    onChanged();
  }

  async function decline() {
    setSubmitting(true);
    const { error } = await supabase
      .from("trade_agreements")
      .update({
        declined_at: new Date().toISOString(),
        declined_by_user_id: (isBuyer ? booking.buyer_id : booking.provider_id),
        decline_reason: declineReason.trim() || null,
      })
      .eq("id", agreement.id);
    if (error) {
      toast.error(error.message);
      setSubmitting(false);
      return;
    }
    await supabase
      .from("bookings")
      .update({ status: "agreement_declined" })
      .eq("id", booking.id);
    toast.success("Trade declined.");
    setSubmitting(false);
    setShowDecline(false);
    onChanged();
  }

  async function markCompleted() {
    setSubmitting(true);
    const { error } = await supabase
      .from("trade_agreements")
      .update({ completed_at: new Date().toISOString() })
      .eq("id", agreement.id);
    if (!error) {
      await supabase
        .from("bookings")
        .update({ status: "completed" })
        .eq("id", booking.id);
      toast.success("Marked completed.");
      onChanged();
    } else {
      toast.error(error.message);
    }
    setSubmitting(false);
  }

  return (
    <SxyCard accent className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <h2 className="font-display text-lg text-teal-light">Trade agreement</h2>
        {declined ? (
          <Tag variant="red">Declined</Tag>
        ) : bothAccepted ? (
          <Tag variant="green">Both accepted</Tag>
        ) : (
          <Tag variant="amber">Pending</Tag>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Buyer offers">
          <p className="whitespace-pre-line text-sm text-text-primary">
            {agreement.offered_description}
          </p>
        </Field>
        <Field label="In exchange for">
          <p className="whitespace-pre-line text-sm text-text-primary">
            {agreement.requested_description}
          </p>
        </Field>
      </div>

      {agreement.estimated_value_usd ? (
        <div className="rounded-lg border border-border-base/40 bg-charcoal-soft p-3">
          <p className="text-[10px] uppercase tracking-wider text-text-dim">
            Estimated value
          </p>
          <p className="font-display text-xl text-gold">
            {USD_2.format(Number(agreement.estimated_value_usd))}
          </p>
        </div>
      ) : null}

      <div className="grid gap-2 sm:grid-cols-2">
        <AcceptStatus label="Buyer" acceptedAt={agreement.buyer_accepted_at} />
        <AcceptStatus label="Provider" acceptedAt={agreement.provider_accepted_at} />
      </div>

      {declined ? (
        <p className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">
          Declined{agreement.decline_reason ? ` — ${agreement.decline_reason}` : ""}.
        </p>
      ) : null}

      {!declined && !bothAccepted && (isBuyer || isProvider) ? (
        <div className="flex flex-wrap gap-2 pt-2">
          {((isBuyer && !buyerAccepted) || (isProvider && !providerAccepted)) ? (
            <SxyButton
              variant="primary"
              size="sm"
              disabled={submitting}
              onClick={accept}
            >
              Accept agreement
            </SxyButton>
          ) : null}
          <SxyButton
            variant="outline"
            size="sm"
            disabled={submitting}
            onClick={() => setShowDecline((v) => !v)}
          >
            Decline
          </SxyButton>
        </div>
      ) : null}

      {showDecline ? (
        <div className="space-y-2 rounded-lg border border-border-base/40 bg-charcoal-soft p-3">
          <p className="text-xs text-text-muted">Reason (optional)</p>
          <textarea
            rows={2}
            maxLength={300}
            value={declineReason}
            onChange={(e) => setDeclineReason(e.target.value)}
            className="w-full rounded-md border border-border-base/60 bg-charcoal-card px-3 py-2 text-sm text-text-primary focus:border-border-teal focus:outline-none"
          />
          <div className="flex justify-end gap-2">
            <SxyButton variant="ghost" size="sm" onClick={() => setShowDecline(false)}>
              Cancel
            </SxyButton>
            <SxyButton variant="primary" size="sm" disabled={submitting} onClick={decline}>
              Confirm decline
            </SxyButton>
          </div>
        </div>
      ) : null}

      {bothAccepted && !agreement.completed_at && (isBuyer || isProvider) ? (
        <SxyButton variant="gold" size="sm" disabled={submitting} onClick={markCompleted}>
          Mark trade completed
        </SxyButton>
      ) : null}
    </SxyCard>
  );
}

function AcceptStatus({ label, acceptedAt }: { label: string; acceptedAt: string | null }) {
  return (
    <div className="rounded-lg border border-border-base/40 bg-charcoal-soft p-3">
      <p className="text-[10px] uppercase tracking-wider text-text-dim">{label}</p>
      <p className={cn("mt-1 text-sm font-medium", acceptedAt ? "text-green-400" : "text-text-muted")}>
        {acceptedAt
          ? `✓ Accepted ${new Date(acceptedAt).toLocaleDateString()}`
          : "Awaiting acceptance"}
      </p>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border-base/40 bg-charcoal-soft p-3">
      <p className="text-[10px] uppercase tracking-wider text-text-dim">{label}</p>
      <div className="mt-1.5">{children}</div>
    </div>
  );
}

// ─────────────────────── Documents ───────────────────────

const DOC_TYPES = [
  { value: "agreement",      label: "Service agreement" },
  { value: "invoice",        label: "Invoice" },
  { value: "purchase_order", label: "Purchase order" },
  { value: "other",          label: "Other" },
] as const;

function DocumentsPanel({ bookingId, canUpload }: { bookingId: string; canUpload: boolean }) {
  const { currentUser } = useAuth();
  const queryClient = useQueryClient();
  const [docType, setDocType] = React.useState<string>("agreement");
  const [note, setNote] = React.useState("");
  const [uploading, setUploading] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const { data: docs = [] } = useQuery({
    queryKey: ["booking-documents", bookingId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("booking_documents")
        .select("*")
        .eq("booking_id", bookingId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as any[];
    },
  });

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;
    if (file.size > 25 * 1024 * 1024) {
      toast.error("File must be 25 MB or smaller.");
      return;
    }
    setUploading(true);
    try {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const storagePath = `${bookingId}/${Date.now()}-${safeName}`;
      const { error: upErr } = await supabase.storage
        .from(BUCKET)
        .upload(storagePath, file, {
          contentType: file.type || "application/octet-stream",
          upsert: false,
        });
      if (upErr) throw upErr;

      const { error: insErr } = await supabase.from("booking_documents").insert({
        booking_id: bookingId,
        uploaded_by: currentUser.id,
        storage_path: storagePath,
        file_name: file.name,
        mime_type: file.type || null,
        size_bytes: file.size,
        doc_type: docType,
        note: note.trim() || null,
      });
      if (insErr) throw insErr;

      toast.success("Document uploaded.");
      setNote("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      void queryClient.invalidateQueries({ queryKey: ["booking-documents", bookingId] });
    } catch (err: any) {
      toast.error(err?.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  async function download(doc: any) {
    const { data, error } = await supabase.storage
      .from(BUCKET)
      .createSignedUrl(doc.storage_path, 60);
    if (error || !data?.signedUrl) {
      toast.error(error?.message ?? "Couldn't get download link");
      return;
    }
    window.open(data.signedUrl, "_blank", "noopener,noreferrer");
  }

  async function remove(doc: any) {
    if (!confirm(`Delete "${doc.file_name}"?`)) return;
    const { error: sErr } = await supabase.storage.from(BUCKET).remove([doc.storage_path]);
    if (sErr) {
      toast.error(sErr.message);
      return;
    }
    const { error: dErr } = await supabase.from("booking_documents").delete().eq("id", doc.id);
    if (dErr) {
      toast.error(dErr.message);
      return;
    }
    toast.success("Document removed.");
    void queryClient.invalidateQueries({ queryKey: ["booking-documents", bookingId] });
  }

  return (
    <SxyCard accent className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg text-teal-light">Documents</h2>
        <span className="text-[10px] uppercase tracking-wider text-text-dim">
          Agreements · Invoices · POs
        </span>
      </div>

      {canUpload ? (
        <div className="space-y-3 rounded-lg border border-border-base/40 bg-charcoal-soft p-3">
          <div className="grid gap-3 sm:grid-cols-[1fr_2fr]">
            <label className="block">
              <p className="text-[10px] uppercase tracking-wider text-text-dim">Type</p>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                className="mt-1 w-full rounded-md border border-border-base/60 bg-charcoal-card px-3 py-2 text-sm text-text-primary focus:border-border-teal focus:outline-none"
              >
                {DOC_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <p className="text-[10px] uppercase tracking-wider text-text-dim">Note (optional)</p>
              <input
                value={note}
                onChange={(e) => setNote(e.target.value)}
                maxLength={200}
                className="mt-1 w-full rounded-md border border-border-base/60 bg-charcoal-card px-3 py-2 text-sm text-text-primary focus:border-border-teal focus:outline-none"
                placeholder="e.g. Signed copy from buyer"
              />
            </label>
          </div>
          <div className="flex items-center gap-3">
            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFile}
              disabled={uploading}
              accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.csv,.xlsx,.txt"
              className="block w-full text-xs text-text-muted file:mr-3 file:rounded-md file:border-0 file:bg-[color:var(--teal-glow)] file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-teal-light hover:file:bg-[color:var(--teal-glow)]/80"
            />
            {uploading ? <span className="text-xs text-text-dim">Uploading…</span> : null}
          </div>
          <p className="text-[10px] text-text-dim">Max 25 MB per file.</p>
        </div>
      ) : null}

      {docs.length === 0 ? (
        <p className="rounded-lg border border-dashed border-border-base/60 p-4 text-center text-xs text-text-dim">
          No documents uploaded yet.
        </p>
      ) : (
        <ul className="divide-y divide-border-base/40">
          {docs.map((doc) => (
            <li key={doc.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-text-primary">
                  {doc.file_name}
                </p>
                <p className="mt-0.5 text-[11px] text-text-dim">
                  <Tag variant="gray">{DOC_TYPES.find((t) => t.value === doc.doc_type)?.label ?? doc.doc_type}</Tag>
                  <span className="ml-2">
                    {doc.uploaded_by === currentUser?.id ? "You" : "Member"} · {new Date(doc.created_at).toLocaleDateString()}
                  </span>
                </p>
                {doc.note ? <p className="mt-1 text-xs text-text-muted">{doc.note}</p> : null}
              </div>
              <div className="flex items-center gap-2">
                <SxyButton variant="outline" size="sm" onClick={() => download(doc)}>
                  Download
                </SxyButton>
                {doc.uploaded_by === currentUser?.id ? (
                  <SxyButton variant="ghost" size="sm" onClick={() => remove(doc)}>
                    Delete
                  </SxyButton>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      )}
    </SxyCard>
  );
}
