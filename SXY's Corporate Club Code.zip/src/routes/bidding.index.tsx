import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { AppLayout } from "@/components/layout/AppLayout";
import { TierGate } from "@/components/sxy/TierGate";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { StatTile } from "@/components/sxy/StatTile";
import { FilterChip } from "@/components/sxy/FilterChip";
import { Tag } from "@/components/sxy/Tag";
import {
  CATEGORIES,
  type CategoryId,
  BID_CURRENCY,
  budgetNumber,
  categoryEmoji,
  categoryLabel,
  formatBudget,
  statusLabel,
  statusTagVariant,
  timeUntil,
} from "@/lib/bidding/shared";

const browseSearchSchema = z.object({
  category: z
    .enum([
      "all",
      "strategy",
      "contractor",
      "cleaning",
      "marketing",
      "legal",
      "trades",
      "tech_ai",
    ])
    .optional()
    .default("all"),
  q: z.string().optional().default(""),
});

export const Route = createFileRoute("/bidding/")({
  head: () => ({ meta: [{ title: "Browse Projects — SXY's Corporate Club" }] }),
  validateSearch: browseSearchSchema,
  component: BrowseProjectsPage,
});

function BrowseProjectsPage() {
  const { isAdmin } = useAuth();
  return (
    <AppLayout
      title="Browse Projects"
      actions={
        <div className="flex items-center gap-3">
          <SxyButton variant="outline" size="sm" asChild>
            <Link to="/bidding/my-bids">My Bids</Link>
          </SxyButton>
          {isAdmin ? (
            <SxyButton variant="gold" size="sm">
              + Post Project
            </SxyButton>
          ) : null}
        </div>
      }
    >
      <TierGate feature="Club Market">
        <BrowseContent />
      </TierGate>
    </AppLayout>
  );
}

function BrowseContent() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const { currentUser } = useAuth();

  const setCategory = (id: CategoryId) =>
    navigate({ search: (prev: typeof search) => ({ ...prev, category: id }) });
  const setQuery = (q: string) =>
    navigate({ search: (prev: typeof search) => ({ ...prev, q }) });

  // Stats row — four counts in parallel.
  const { data: stats } = useQuery({
    queryKey: ["bidding", "stats", currentUser?.id ?? "anon"],
    queryFn: async () => {
      const [openRes, totalBidsRes, myActiveRes, openBudgetRes] =
        await Promise.all([
          supabase
            .from("projects")
            .select("id", { count: "exact", head: true })
            .eq("status", "open"),
          supabase.from("bids").select("id", { count: "exact", head: true }),
          currentUser
            ? supabase
                .from("bids")
                .select("id", { count: "exact", head: true })
                .eq("bidder_id", currentUser.id)
                .in("status", ["submitted", "shortlisted"])
            : Promise.resolve({ count: 0 } as { count: number | null }),
          supabase
            .from("projects")
            .select("budget, budget_min, budget_max")
            .eq("status", "open"),
        ]);

      const budgets = ((openBudgetRes as any).data ?? [])
        .map((row: any) => budgetNumber(row))
        .filter((n: number | null): n is number => n != null && n > 0);
      const avg =
        budgets.length > 0
          ? budgets.reduce((s: number, n: number) => s + n, 0) / budgets.length
          : 0;

      return {
        open: openRes.count ?? 0,
        totalBids: totalBidsRes.count ?? 0,
        myActive: (myActiveRes as { count: number | null }).count ?? 0,
        avgBudget: avg,
      };
    },
  });

  // Project list — driven by category + search.
  const { data: projects, isLoading } = useQuery({
    queryKey: ["bidding", "list", search.category, search.q],
    queryFn: async () => {
      let query = supabase
        .from("open_projects_with_bids")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(60);
      if (search.category !== "all") {
        query = query.eq("category", search.category);
      }
      if (search.q && search.q.trim().length > 0) {
        query = query.ilike("title", `%${search.q.trim()}%`);
      }
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <div className="space-y-8">
      {/* Stats row */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile label="Open Projects" value={String(stats?.open ?? 0)} />
        <StatTile
          label="Total Bids Placed"
          value={String(stats?.totalBids ?? 0)}
        />
        <StatTile
          label="Your Active Bids"
          value={String(stats?.myActive ?? 0)}
        />
        <StatTile
          label="Avg Budget"
          value={
            stats?.avgBudget
              ? BID_CURRENCY.format(stats.avgBudget)
              : "—"
          }
        />
      </section>

      {/* Filter bar */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          {CATEGORIES.map((cat) => (
            <FilterChip
              key={cat.id}
              active={search.category === cat.id}
              onClick={() => setCategory(cat.id)}
            >
              <span aria-hidden>{cat.emoji}</span>
              {cat.label}
            </FilterChip>
          ))}
        </div>
        <div className="relative max-w-md">
          <input
            type="search"
            value={search.q}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search projects by title…"
            className="w-full rounded-full border border-border-base/60 bg-charcoal-card px-4 py-2.5 pl-10 text-sm text-text-primary placeholder:text-text-dim focus:border-border-teal focus:outline-none"
          />
          <span
            aria-hidden
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-text-dim"
          >
            🔍
          </span>
        </div>
      </section>

      {/* Project cards */}
      <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {isLoading ? (
          <SxyCard>
            <p className="text-sm text-text-muted">Loading projects…</p>
          </SxyCard>
        ) : projects && projects.length > 0 ? (
          projects.map((p: any) => <ProjectCard key={p.id} project={p} />)
        ) : (
          <SxyCard accent className="md:col-span-2 xl:col-span-3">
            <p className="font-display text-lg text-teal-light">
              No projects match your filters
            </p>
            <p className="mt-2 text-sm text-text-muted">
              Try clearing the search or picking a different category.
            </p>
          </SxyCard>
        )}
      </section>
    </div>
  );
}

function ProjectCard({ project }: { project: any }) {
  return (
    <SxyCard hoverable accent className="flex flex-col">
      <div className="flex items-start justify-between gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-border-teal/40 bg-[color:var(--teal-glow)] text-2xl">
          {categoryEmoji(project.category)}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <Tag variant={statusTagVariant(project.status)}>
            {statusLabel(project.status)}
          </Tag>
          <Tag variant="gray">{categoryLabel(project.category)}</Tag>
        </div>
      </div>

      <h3 className="mt-4 font-display text-lg leading-snug text-text-primary">
        {project.title}
      </h3>
      {project.summary || project.description ? (
        <p className="mt-2 line-clamp-3 text-sm text-text-muted">
          {project.summary ?? project.description}
        </p>
      ) : null}

      <div className="mt-5 flex items-baseline justify-between">
        <p
          className="font-editorial text-2xl text-gold"
          title="Budget"
        >
          {formatBudget(project.budget, project.budget_min, project.budget_max)}
        </p>
        <p className="text-xs text-text-dim">
          {timeUntil(project.deadline ?? project.closes_at)}
        </p>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-border-base/50 pt-4">
        <p className="text-xs text-text-muted">
          <span className="font-semibold text-text-primary">
            {project.bid_count}
          </span>{" "}
          bid{project.bid_count === 1 ? "" : "s"}
        </p>
        <SxyButton variant="primary" size="sm" asChild>
          <Link to="/bidding/$id" params={{ id: project.id }}>
            View &amp; Bid
          </Link>
        </SxyButton>
      </div>
    </SxyCard>
  );
}
