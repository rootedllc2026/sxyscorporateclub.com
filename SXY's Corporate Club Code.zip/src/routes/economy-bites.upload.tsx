/**
 * /economy-bites/upload — admin form to publish new videos.
 *
 * Inserts a row into public.videos. RLS only allows admins to insert/update
 * but we also gate the route with AdminRoute so non-admins see the dashboard.
 */
import { createFileRoute } from "@tanstack/react-router";
import { AdminRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { EconomyBitesNav } from "@/components/videos/EconomyBitesNav";
import { VideoForm } from "@/components/videos/VideoForm";

export const Route = createFileRoute("/economy-bites/upload")({
  head: () => ({ meta: [{ title: "Upload Video — SXY's Corporate Club" }] }),
  component: () => (
    <AdminRoute>
      <AppLayout title="Upload Content">
        <div className="space-y-6">
          <EconomyBitesNav />
          <SxyCard accent>
            <VideoForm />
          </SxyCard>
        </div>
      </AppLayout>
    </AdminRoute>
  ),
});
