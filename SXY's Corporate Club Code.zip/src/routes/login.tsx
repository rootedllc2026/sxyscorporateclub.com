import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { AuthShell, AuthError } from "@/components/auth/AuthShell";
import { AuthInput, Field } from "@/components/auth/AuthInput";
import { SxyButton } from "@/components/sxy/SxyButton";

const loginSearchSchema = z.object({
  redirect: z.string().optional(),
});

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign In — SXY's Corporate Club" },
      {
        name: "description",
        content: "Sign in to SXY's Corporate Club to access your member portal.",
      },
    ],
  }),
  validateSearch: loginSearchSchema,
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const { isAuthenticated } = useAuth();
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // Already logged in? Bounce to the requested page or /dashboard.
  React.useEffect(() => {
    if (isAuthenticated) {
      void navigate({ to: search.redirect ?? "/dashboard" });
    }
  }, [isAuthenticated, navigate, search.redirect]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const fd = new FormData(e.currentTarget);
    const email = String(fd.get("email") ?? "").trim();
    const password = String(fd.get("password") ?? "");

    if (!email || !password) {
      setError("Enter your email and password");
      return;
    }

    setSubmitting(true);
    try {
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (signInError) {
        setError(
          signInError.message.toLowerCase().includes("invalid")
            ? "Wrong email or password"
            : signInError.message,
        );
        return;
      }
      toast.success("Welcome back");
      await navigate({ to: search.redirect ?? "/dashboard" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthShell
      title="Welcome Back"
      subtitle="Sign in to your member portal"
      footer={
        <>
          Not a member yet?{" "}
          <Link to="/signup" className="text-gold hover:text-gold-light">
            Join the club
          </Link>
        </>
      }
    >
      <form onSubmit={onSubmit} className="space-y-5" noValidate>
        <Field label="Email address" htmlFor="email">
          <AuthInput
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            placeholder="you@business.com"
          />
        </Field>
        <Field label="Password" htmlFor="password">
          <AuthInput
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            placeholder="••••••••"
          />
        </Field>

        <AuthError message={error} />

        <SxyButton
          type="submit"
          variant="primary"
          size="lg"
          disabled={submitting}
          className="w-full"
        >
          {submitting ? "Signing in…" : "Sign In"}
        </SxyButton>

        <div className="flex items-center justify-between text-xs">
          <Link
            to="/reset-password"
            className="text-text-muted hover:text-teal-light"
          >
            Forgot password?
          </Link>
          <Link to="/signup" className="text-text-muted hover:text-gold-light">
            Create an account
          </Link>
        </div>
      </form>
    </AuthShell>
  );
}
