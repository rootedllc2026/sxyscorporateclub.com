import { createFileRoute, Link } from "@tanstack/react-router";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { useAuth } from "@/integrations/supabase/AuthContext";

export const Route = createFileRoute("/membership")({
  head: () => ({ meta: [{ title: "Membership — SXY's Corporate Club" }] }),
  component: MembershipPage,
});

const TIERS = [
  {
    id: "free" as const,
    name: "Free Member",
    price: "$0",
    cadence: "forever",
    perks: ["Browse the Exchange", "Read Economy Bites previews"],
  },
  {
    id: "paid" as const,
    name: "Investing Member",
    price: "$9",
    cadence: "per month",
    perks: [
      "Submit bids on projects",
      "Referral portal access",
      "Member events",
    ],
  },
  {
    id: "annual" as const,
    name: "Annual Member",
    price: "$89",
    cadence: "per year",
    perks: ["Everything in Investing Member", "2 months free"],
  },
  {
    id: "vip" as const,
    name: "VIP",
    price: "$49",
    cadence: "per month",
    perks: ["Priority bid review", "1:1 strategy sessions", "VIP-only events"],
  },
];

function MembershipPage() {
  const { userProfile } = useAuth();
  return (
    <AppLayout title="Membership">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {TIERS.map((tier) => {
          const isCurrent = userProfile?.tier === tier.id;
          return (
            <SxyCard key={tier.id} accent hoverable>
              <p className="sxy-section-label">{tier.name}</p>
              <p className="mt-2 font-display text-3xl text-teal-light">
                {tier.price}
                <span className="ml-1 text-xs text-text-dim">
                  {tier.cadence}
                </span>
              </p>
              <ul className="mt-4 space-y-1.5 text-xs text-text-muted">
                {tier.perks.map((p) => (
                  <li key={p}>· {p}</li>
                ))}
              </ul>
              <div className="mt-5">
                {isCurrent ? (
                  <SxyButton variant="ghost" size="sm" disabled>
                    Current plan
                  </SxyButton>
                ) : tier.id === "free" ? (
                  <SxyButton variant="outline" size="sm" disabled>
                    Default tier
                  </SxyButton>
                ) : (
                  <SxyButton variant="gold" size="sm" asChild>
                    <Link to="/checkout" search={{ tier: tier.id }}>
                      Upgrade
                    </Link>
                  </SxyButton>
                )}
              </div>
            </SxyCard>
          );
        })}
      </div>
    </AppLayout>
  );
}
