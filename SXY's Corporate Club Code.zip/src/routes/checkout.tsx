import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { AuthShell } from "@/components/auth/AuthShell";
import { SxyButton } from "@/components/sxy/SxyButton";
import { downgradeToFree } from "@/server/membership/downgradeToFree";
import { toast } from "sonner";

const checkoutSearchSchema = z.object({
  tier: z.enum(["paid", "annual", "vip"]).optional(),
});

const TIER_DETAILS: Record<
  "paid" | "annual" | "vip",
  { name: string; price: string; cadence: string; perks: string[] }
> = {
  paid: {
    name: "Investing Member",
    price: "$9",
    cadence: "per month",
    perks: [
      "Everything in Free Member",
      "Submit bids on projects",
      "Referral portal access",
      "Member events",
    ],
  },
  annual: {
    name: "Annual Member",
    price: "$89",
    cadence: "per year",
    perks: [
      "Everything in Investing Member",
      "2 months free vs monthly",
      "Priority support",
    ],
  },
  vip: {
    name: "VIP",
    price: "$49",
    cadence: "per month",
    perks: [
      "All Investing Member features",
      "Economy Bites VIP",
      "Deal flow access",
      "Inner-circle community",
    ],
  },
};

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [{ title: "Checkout — SXY's Corporate Club" }],
  }),
  validateSearch: checkoutSearchSchema,
  component: CheckoutPage,
});

/**
 * Placeholder checkout. Stripe integration goes here next turn — for now this
 * page lets the user either proceed (downgrades to free) or skip and explore.
 *
 * When Stripe is wired in, replace `handleContinueAsFree` with a call to a
 * Supabase Edge Function that creates a Stripe Checkout Session and redirects.
 */
function CheckoutPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { isAuthenticated, isLoading, currentUser, refreshProfile } = useAuth();
  const [downgrading, setDowngrading] = React.useState(false);

  React.useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      void navigate({
        to: "/login",
        search: { redirect: `/checkout?tier=${search.tier ?? ""}` },
      });
    }
  }, [isAuthenticated, isLoading, navigate, search.tier]);

  if (!search.tier) {
    return (
      <AuthShell title="No plan selected" subtitle="Pick a membership to continue.">
        <div className="space-y-4">
          <SxyButton
            variant="gold"
            size="lg"
            className="w-full"
            onClick={() => navigate({ to: "/signup" })}
          >
            Choose a plan
          </SxyButton>
        </div>
      </AuthShell>
    );
  }

  const tier: "paid" | "annual" | "vip" = search.tier;
  const details = TIER_DETAILS[tier];

  async function handleContinueAsFree() {
    if (!currentUser) return;
    setDowngrading(true);
    try {
      // Tier writes go through a server function (service_role) because the
      // profiles table blocks tier changes from the anon client. The function
      // can only set tier='free' — it cannot grant a paid tier.
      await downgradeToFree();
      await refreshProfile();
      toast.success("You're in as a Free Newbie. Upgrade anytime.");
      await navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't update plan");
    } finally {
      setDowngrading(false);
    }
  }

  return (
    <AuthShell
      title="Complete Your Membership"
      subtitle="Secure checkout via Stripe is coming online shortly."
      footer={
        <Link to="/dashboard" className="text-text-muted hover:text-teal-light">
          Skip for now
        </Link>
      }
    >
      <div className="space-y-6">
        <div className="rounded-2xl border border-border-gold/40 bg-gold/5 p-5">
          <div className="flex items-baseline justify-between">
            <h2 className="font-editorial text-xl text-gold-light">
              {details.name}
            </h2>
            <div className="text-right">
              <div className="text-2xl font-bold text-gold">{details.price}</div>
              <div className="text-xs text-text-muted">{details.cadence}</div>
            </div>
          </div>
          <ul className="mt-4 space-y-2">
            {details.perks.map((p) => (
              <li
                key={p}
                className="flex items-start gap-2 text-sm text-text-primary"
              >
                <span className="mt-0.5 text-gold">◆</span>
                <span>{p}</span>
              </li>
            ))}
          </ul>
        </div>

        <div
          className="rounded-xl border border-border-teal/40 bg-teal-mist/40 px-4 py-3 text-sm text-teal-light"
          role="status"
        >
          <strong className="font-semibold">Payments coming next.</strong>{" "}
          Stripe checkout is being wired up. In the meantime you can continue
          with the Free Newbie tier and upgrade later from your dashboard.
        </div>

        <SxyButton
          variant="primary"
          size="lg"
          className="w-full"
          disabled
          title="Stripe integration coming next"
        >
          Continue to Stripe (coming soon)
        </SxyButton>

        <SxyButton
          variant="outline"
          size="lg"
          className="w-full"
          disabled={downgrading}
          onClick={handleContinueAsFree}
        >
          {downgrading ? "Updating…" : "Continue as Free Newbie for now"}
        </SxyButton>
      </div>
    </AuthShell>
  );
}
