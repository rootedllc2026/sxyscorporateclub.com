import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/layout/AppLayout";

export const Route = createFileRoute("/club-boutique")({
  head: () => ({
    meta: [{ title: "Club Boutique — SXY's Corporate Club" }],
  }),
  component: ClubBoutiquePage,
});

function ClubBoutiquePage() {
  return (
    <AppLayout title="Club Boutique">
      <div className="overflow-hidden rounded-lg border border-border-base/60 bg-black">
        <iframe
          src="/club-boutique.html"
          title="Club Boutique"
          className="h-[calc(100vh-9rem)] w-full"
        />
      </div>
    </AppLayout>
  );
}
