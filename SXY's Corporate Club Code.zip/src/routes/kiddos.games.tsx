import { createFileRoute } from "@tanstack/react-router";
import { KidShell } from "@/components/kiddos/KidShell";

export const Route = createFileRoute("/kiddos/games")({
  head: () => ({ meta: [{ title: "Games — Kiddos" }] }),
  component: () => (
    <KidShell title="Games 🎮">
      <div className="kid-card">
        <p>Money quizzes and simulators — coming next.</p>
      </div>
    </KidShell>
  ),
});
