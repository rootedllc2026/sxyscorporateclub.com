import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Tag } from "@/components/sxy/Tag";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { isPaidTier, type ApprenticeshipProgram } from "@/lib/apprenticeship/shared";

export const Route = createFileRoute("/apprenticeship/")({
  head: () => ({
    meta: [{ title: "Apprenticeship Program — SXY's Corporate Club" }],
  }),
  component: ApprenticeshipIndex,
});

function ApprenticeshipIndex() {
  const { userTier, isAdmin } = useAuth();
  const canCreate = isAdmin || isPaidTier(userTier);

  const { data: programs, isLoading } = useQuery({
    queryKey: ["apprenticeship", "programs", "open"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("apprenticeship_programs")
        .select("*")
        .eq("status", "open")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data as ApprenticeshipProgram[]) ?? [];
    },
  });

  return (
    <AppLayout
      title="Apprenticeship Program"
      actions={
        <div className="flex gap-2">
          <SxyButton variant="outline" size="sm" asChild>
            <Link to="/apprenticeship/manage">Manage mine</Link>
          </SxyButton>
          {canCreate ? (
            <SxyButton variant="gold" size="sm" asChild>
              <Link to="/apprenticeship/create">+ Post Program</Link>
            </SxyButton>
          ) : null}
        </div>
      }
    >
      <div className="mb-6">
        <p className="sxy-section-label text-gold">Mentorship marketplace</p>
        <h2 className="mt-2 font-display text-3xl text-text-primary">
          Find a hands-on apprenticeship
        </h2>
        <p className="mt-2 max-w-2xl text-sm text-text-muted">
          Member-led programs designed to grow operators, tradespeople, and
          founders. Browse open positions, apply, and (if accepted) get a
          private portal to track milestones and message your mentor.
        </p>
      </div>

      {isLoading ? (
        <p className="text-sm text-text-muted">Loading programs…</p>
      ) : programs && programs.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {programs.map((p) => (
            <SxyCard key={p.id} hoverable>
              <div className="flex items-center justify-between gap-2">
                <Tag variant="teal">{p.industry ?? "General"}</Tag>
                {p.duration_weeks ? (
                  <span className="text-xs text-text-dim">
                    {p.duration_weeks} weeks
                  </span>
                ) : null}
              </div>
              <h3 className="mt-3 font-display text-xl text-text-primary">
                {p.title}
              </h3>
              <p className="mt-2 line-clamp-3 text-sm text-text-muted">
                {p.summary}
              </p>
              <div className="mt-4 flex items-center justify-between">
                <span className="text-xs text-text-dim">
                  {p.location ?? "Remote"}
                </span>
                <SxyButton variant="outline" size="sm" asChild>
                  <Link to="/apprenticeship/$id" params={{ id: p.id }}>
                    View
                  </Link>
                </SxyButton>
              </div>
            </SxyCard>
          ))}
        </div>
      ) : (
        <SxyCard>
          <p className="text-sm text-text-muted">
            No open programs yet. Check back soon, or post one yourself if
            you're a paid member.
          </p>
        </SxyCard>
      )}
    </AppLayout>
  );
}
