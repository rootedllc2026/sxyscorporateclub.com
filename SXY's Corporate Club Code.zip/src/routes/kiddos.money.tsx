import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { KidShell } from "@/components/kiddos/KidShell";
import { CreditBadge } from "@/components/kiddos/CreditBadge";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  createSavingsGoal,
  submitChore,
} from "@/lib/kiddos/kiddos.functions";

export const Route = createFileRoute("/kiddos/money")({
  head: () => ({ meta: [{ title: "Money — Kiddos" }] }),
  component: () => (
    <KidShell title="Money 💰">
      <MoneyContent />
    </KidShell>
  ),
});

function MoneyContent() {
  const { currentUser } = useAuth();
  const userId = currentUser?.id;
  const qc = useQueryClient();
  const submitFn = useServerFn(submitChore);
  const goalFn = useServerFn(createSavingsGoal);

  const { data: ledger } = useQuery({
    queryKey: ["kiddo-ledger", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("credit_ledger")
        .select("id, delta_credits, reason, note, created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const { data: chores } = useQuery({
    queryKey: ["kiddo-chores-all", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("chores")
        .select("id, title, status, reward_credits")
        .eq("child_user_id", userId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const { data: goals } = useQuery({
    queryKey: ["kiddo-goals-all", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("savings_goals")
        .select("id, title, target_credits, saved_credits, target_date")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const submitMut = useMutation({
    mutationFn: (choreId: string) => submitFn({ data: { choreId } }),
    onSuccess: () => {
      toast.success("Submitted! Your parent will review it.");
      qc.invalidateQueries({ queryKey: ["kiddo-chores-all", userId] });
      qc.invalidateQueries({ queryKey: ["kiddo-chores-open", userId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const goalMut = useMutation({
    mutationFn: async (input: { title: string; targetCredits: number }) =>
      goalFn({ data: input }),
    onSuccess: () => {
      toast.success("Goal added.");
      qc.invalidateQueries({ queryKey: ["kiddo-goals-all", userId] });
      qc.invalidateQueries({ queryKey: ["kiddo-goals", userId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!currentUser) {
    return (
      <div className="kid-card text-center">
        <p className="mb-4">Sign in to see your money.</p>
        <Link to="/login" className="kid-btn kid-btn-primary">Sign in</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-5">
      <section className="kid-card">
        <h2 className="text-xl mb-3">Chores</h2>
        {!chores || chores.length === 0 ? (
          <p className="text-sm text-[var(--kid-ink-muted)]">No chores yet.</p>
        ) : (
          <ul className="space-y-2">
            {chores.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-3 py-2 border-b last:border-0 border-[rgba(10,92,107,0.08)]">
                <div>
                  <div className="font-medium">{c.title}</div>
                  <div className="text-xs text-[var(--kid-ink-muted)] capitalize">{c.status}</div>
                </div>
                <div className="flex items-center gap-3">
                  <CreditBadge amount={`+${c.reward_credits}`} />
                  {c.status === "open" && (
                    <button
                      type="button"
                      className="kid-btn kid-btn-primary"
                      onClick={() => submitMut.mutate(c.id)}
                      disabled={submitMut.isPending}
                    >
                      Submit
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="kid-card">
        <h2 className="text-xl mb-3">Savings goals</h2>
        <NewGoalForm
          onCreate={(title, target) => goalMut.mutate({ title, targetCredits: target })}
          pending={goalMut.isPending}
        />
        <ul className="mt-4 space-y-3">
          {(goals ?? []).map((g) => {
            const pct = Math.min(100, Math.round((g.saved_credits / Math.max(1, g.target_credits)) * 100));
            return (
              <li key={g.id}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{g.title}</span>
                  <CreditBadge amount={`${g.saved_credits} / ${g.target_credits}`} />
                </div>
                <div className="h-2 rounded-full bg-[var(--kid-teal-soft)] overflow-hidden">
                  <div className="h-full bg-[var(--kid-gold)]" style={{ width: `${pct}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="kid-card">
        <h2 className="text-xl mb-3">Recent activity</h2>
        {!ledger || ledger.length === 0 ? (
          <p className="text-sm text-[var(--kid-ink-muted)]">Nothing yet.</p>
        ) : (
          <ul className="divide-y divide-[rgba(10,92,107,0.08)]">
            {ledger.map((row) => (
              <li key={row.id} className="py-2 flex items-center justify-between gap-3 text-sm">
                <div>
                  <div className="font-medium">{row.note ?? row.reason.replace(/_/g, " ")}</div>
                  <div className="text-xs text-[var(--kid-ink-muted)]">
                    {new Date(row.created_at).toLocaleString()}
                  </div>
                </div>
                <CreditBadge
                  amount={`${row.delta_credits > 0 ? "+" : ""}${row.delta_credits}`}
                  className={row.delta_credits >= 0 ? "text-[var(--kid-teal)]" : "text-[#b94a3a]"}
                />
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="text-xs text-[var(--kid-ink-muted)] text-center">
        Allowance is tracked in your "Look At Me!" app and synced here.
      </p>
    </div>
  );
}

function NewGoalForm({
  onCreate,
  pending,
}: {
  onCreate: (title: string, target: number) => void;
  pending: boolean;
}) {
  const [title, setTitle] = React.useState("");
  const [target, setTarget] = React.useState("");
  return (
    <form
      className="flex flex-wrap gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const n = Number(target);
        if (!title.trim() || !Number.isFinite(n) || n <= 0) return;
        onCreate(title.trim(), Math.floor(n));
        setTitle("");
        setTarget("");
      }}
    >
      <input
        className="kid-input flex-1 min-w-[160px]"
        placeholder="Goal name (e.g. New skateboard)"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        maxLength={80}
      />
      <input
        className="kid-input"
        placeholder="Credits"
        inputMode="numeric"
        value={target}
        onChange={(e) => setTarget(e.target.value)}
        style={{ width: 120 }}
      />
      <button type="submit" className="kid-btn kid-btn-primary" disabled={pending}>
        Add goal
      </button>
    </form>
  );
}
