/**
 * /economy-bites — the All Videos browse page.
 *
 * Layout:
 *   - EconomyBitesNav sub-rail (All Videos / Series / Saved / admin extras)
 *   - Featured hero (one row from videos where is_featured = true)
 *   - Filter bar (categories + Free Only + search)
 *   - 3-column responsive video grid
 *
 * Access control: RLS already filters to the user's tier, but we still pass
 * the client-side `canAccessVideo` flag down so we can render lock overlays
 * for VIP videos that an admin published as previews.
 */
import * as React from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search, Play, Bookmark } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { FilterChip } from "@/components/sxy/FilterChip";
import { UpgradeModal } from "@/components/sxy/UpgradeModal";
import { EconomyBitesNav } from "@/components/videos/EconomyBitesNav";
import { VideoCard } from "@/components/videos/VideoCard";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  CATEGORY_FILTERS,
  canAccessVideo,
  formatDuration,
  type VideoRow,
} from "@/lib/videos/shared";

export const Route = createFileRoute("/economy-bites/")({
  head: () => ({
    meta: [
      { title: "Economy Bites — SXY's Corporate Club" },
      {
        name: "description",
        content:
          "Bite-sized educational videos on business, markets and bankruptcy basics for SXY's Corporate Club members.",
      },
    ],
  }),
  component: () => (
    <AppLayout title="Economy Bites">
      <EconomyBitesPage />
    </AppLayout>
  ),
});

function EconomyBitesPage() {
  const { userTier, isAdmin, currentUser } = useAuth();
  const navigate = useNavigate();
  const [category, setCategory] = React.useState<string>("All");
  const [search, setSearch] = React.useState("");
  const [upgradeOpen, setUpgradeOpen] = React.useState(false);

  // All published videos (RLS ensures tier-appropriate rows).
  const { data: videos = [], isLoading } = useQuery({
    queryKey: ["videos", "list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("is_published", true)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as VideoRow[];
    },
  });

  const { data: featured } = useQuery({
    queryKey: ["videos", "featured"],
    queryFn: async () => {
      const { data } = await supabase
        .from("videos")
        .select("*")
        .eq("is_published", true)
        .eq("is_featured", true)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return (data ?? null) as VideoRow | null;
    },
  });

  // Per-user progress map for the cards' progress bars.
  const { data: progressMap = {} } = useQuery({
    queryKey: ["videos", "progress", currentUser?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("video_progress")
        .select("video_id, progress_pct")
        .eq("user_id", currentUser!.id);
      const map: Record<string, number> = {};
      for (const r of data ?? []) map[r.video_id as string] = Number(r.progress_pct ?? 0);
      return map;
    },
    enabled: !!currentUser,
  });

  const filtered = React.useMemo(() => {
    return videos.filter((v) => {
      if (category === "Free Only" && v.access_level !== "free") return false;
      if (category !== "All" && category !== "Free Only" && v.category !== category)
        return false;
      if (
        search.trim() &&
        !`${v.title} ${v.description ?? ""}`
          .toLowerCase()
          .includes(search.trim().toLowerCase())
      )
        return false;
      return true;
    });
  }, [videos, category, search]);

  function openVideo(v: VideoRow) {
    if (!canAccessVideo(v.access_level, userTier, isAdmin)) {
      setUpgradeOpen(true);
      return;
    }
    navigate({ to: "/economy-bites/$id", params: { id: v.id } });
  }

  return (
    <div className="space-y-8">
      <EconomyBitesNav />

      {/* Featured hero */}
      {featured ? (
        <SxyCard accent className="overflow-hidden p-0">
          <div className="grid gap-0 lg:grid-cols-[1fr_minmax(280px,400px)]">
            <div className="space-y-4 p-6 lg:p-8">
              <div className="flex items-center gap-2">
                <Tag variant="gold">Featured</Tag>
                {featured.access_level === "vip" ? (
                  <Tag variant="gold">VIP</Tag>
                ) : null}
                {featured.category ? (
                  <Tag variant="teal">{featured.category}</Tag>
                ) : null}
              </div>
              <h2 className="font-display text-2xl text-teal-light lg:text-3xl">
                {featured.title}
              </h2>
              {featured.description ? (
                <p className="line-clamp-3 text-sm text-text-muted">
                  {featured.description}
                </p>
              ) : null}
              <div className="flex flex-wrap gap-2 pt-2">
                <SxyButton size="sm" onClick={() => openVideo(featured)}>
                  <Play className="h-3.5 w-3.5" fill="currentColor" /> Watch now
                </SxyButton>
                <SxyButton variant="outline" size="sm">
                  <Bookmark className="h-3.5 w-3.5" /> Save
                </SxyButton>
              </div>
            </div>

            <button
              type="button"
              onClick={() => openVideo(featured)}
              className="group relative grid min-h-[200px] place-items-center overflow-hidden lg:min-h-full"
              style={{
                background: featured.thumbnail_url
                  ? `url(${featured.thumbnail_url}) center/cover`
                  : "linear-gradient(135deg, oklch(0.55 0.085 210 / 0.7), oklch(0.22 0.035 215 / 0.95))",
              }}
            >
              {!featured.thumbnail_url ? (
                <span aria-hidden className="text-7xl opacity-90">
                  {featured.icon_emoji}
                </span>
              ) : null}
              <span className="absolute inset-0 grid place-items-center bg-black/30 opacity-0 transition-opacity group-hover:opacity-100">
                <span className="grid h-16 w-16 place-items-center rounded-full bg-teal-mid/95 text-charcoal">
                  <Play className="h-6 w-6 translate-x-0.5" fill="currentColor" />
                </span>
              </span>
              <span className="absolute bottom-3 right-3 rounded bg-black/70 px-2 py-1 font-mono text-xs text-white">
                {formatDuration(featured.duration_seconds)}
              </span>
            </button>
          </div>
        </SxyCard>
      ) : null}

      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex flex-wrap gap-2">
          {CATEGORY_FILTERS.map((c) => (
            <FilterChip
              key={c}
              active={category === c}
              onClick={() => setCategory(c)}
            >
              {c}
            </FilterChip>
          ))}
        </div>
        <label className="ml-auto flex w-full items-center gap-2 rounded-full border border-border-base/60 bg-charcoal-card px-4 py-2 sm:w-72">
          <Search className="h-4 w-4 text-text-dim" />
          <input
            type="search"
            placeholder="Search videos…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-transparent text-sm text-text-primary placeholder:text-text-dim focus:outline-none"
          />
        </label>
      </div>

      {/* Grid */}
      {isLoading ? (
        <p className="text-sm text-text-muted">Loading videos…</p>
      ) : filtered.length === 0 ? (
        <SxyCard className="text-center text-sm text-text-muted">
          No videos match your filters yet.
        </SxyCard>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((v) => {
            const locked = !canAccessVideo(v.access_level, userTier, isAdmin);
            return (
              <VideoCard
                key={v.id}
                video={v}
                locked={locked}
                progressPct={progressMap[v.id] ?? 0}
                onClick={() => openVideo(v)}
              />
            );
          })}
        </div>
      )}

      <UpgradeModal open={upgradeOpen} onOpenChange={setUpgradeOpen} />
    </div>
  );
}
