/**
 * /economy-bites/$id — single-video player.
 *
 * Two-column layout:
 *   Left: embedded player (YouTube / Vimeo iframe, or <video> for storage URLs),
 *         description, action row (Save / Share / Transcript / Mark Complete).
 *   Right: notes textarea (saved into video_progress.notes), placeholder
 *          transcript, "Up Next" list of 4 videos from the same series.
 *
 * Access enforcement: if the current user can't access this video we redirect
 * to /economy-bites. RLS on the videos table also blocks the read so we'd 404
 * before this code even runs for non-admins.
 */
import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bookmark,
  BookmarkCheck,
  Check,
  FileText,
  Pencil,
  Play,
  Share2,
  Trash2,
} from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { Textarea } from "@/components/ui/textarea";
import { EconomyBitesNav } from "@/components/videos/EconomyBitesNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  canAccessVideo,
  formatDuration,
  isVideoFile,
  toEmbedUrl,
  type VideoProgressRow,
  type VideoRow,
} from "@/lib/videos/shared";

export const Route = createFileRoute("/economy-bites/$id")({
  head: () => ({ meta: [{ title: "Watching — SXY's Corporate Club" }] }),
  component: () => (
    <AppLayout title="Watching">
      <PlayerPage />
    </AppLayout>
  ),
});

function PlayerPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { currentUser, userTier, isAdmin } = useAuth();
  const [showTranscript, setShowTranscript] = React.useState(false);
  const [notesDraft, setNotesDraft] = React.useState("");
  const notesTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const { data: video, isLoading } = useQuery({
    queryKey: ["video", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("videos")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as VideoRow | null;
    },
  });

  const { data: progress } = useQuery({
    queryKey: ["video", "progress", id, currentUser?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("video_progress")
        .select("*")
        .eq("user_id", currentUser!.id)
        .eq("video_id", id)
        .maybeSingle();
      return (data ?? null) as VideoProgressRow | null;
    },
    enabled: !!currentUser,
  });

  const { data: saved = false } = useQuery({
    queryKey: ["video", "isSaved", id, currentUser?.id],
    queryFn: async () => {
      const { count } = await supabase
        .from("video_saves")
        .select("id", { count: "exact", head: true })
        .eq("user_id", currentUser!.id)
        .eq("video_id", id);
      return (count ?? 0) > 0;
    },
    enabled: !!currentUser,
  });

  const { data: upNext = [] } = useQuery({
    queryKey: ["video", "upNext", id, video?.series],
    queryFn: async () => {
      const { data } = await supabase
        .from("videos")
        .select("id, title, icon_emoji, duration_seconds, series, access_level")
        .eq("series", video!.series)
        .eq("is_published", true)
        .neq("id", id)
        .order("created_at", { ascending: false })
        .limit(4);
      return (data ?? []) as Pick<
        VideoRow,
        "id" | "title" | "icon_emoji" | "duration_seconds" | "series" | "access_level"
      >[];
    },
    enabled: !!video,
  });

  // Hydrate notes from existing progress row.
  React.useEffect(() => {
    setNotesDraft(progress?.notes ?? "");
  }, [progress?.id]);

  // Bump view_count + create progress row on first load.
  React.useEffect(() => {
    if (!video || !currentUser) return;
    // no-op
    void supabase
      .from("videos")
      .update({ view_count: (video.view_count ?? 0) + 1 })
      .eq("id", video.id);
    void supabase.from("video_progress").upsert(
      {
        user_id: currentUser.id,
        video_id: video.id,
        progress_pct: progress?.progress_pct ?? 0,
        progress_seconds: progress?.progress_seconds ?? 0,
        completed: progress?.completed ?? false,
      },
      { onConflict: "user_id,video_id" },
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [video?.id, currentUser?.id]);

  // Redirect on access denial.
  React.useEffect(() => {
    if (!isLoading && video && !canAccessVideo(video.access_level, userTier, isAdmin)) {
      navigate({ to: "/economy-bites" });
    }
  }, [isLoading, video, userTier, isAdmin, navigate]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <EconomyBitesNav />
        <p className="text-sm text-text-muted">Loading video…</p>
      </div>
    );
  }
  if (!video) {
    return (
      <div className="space-y-6">
        <EconomyBitesNav />
        <SxyCard className="text-center text-sm text-text-muted">
          Video not found.{" "}
          <Link to="/economy-bites" className="text-teal-light underline">
            Back to library
          </Link>
        </SxyCard>
      </div>
    );
  }

  async function toggleSave() {
    if (!currentUser) return;
    if (saved) {
      await supabase
        .from("video_saves")
        .delete()
        .eq("user_id", currentUser.id)
        .eq("video_id", video!.id);
    } else {
      await supabase
        .from("video_saves")
        .upsert(
          { user_id: currentUser.id, video_id: video!.id },
          { onConflict: "user_id,video_id" },
        );
    }
    qc.invalidateQueries({ queryKey: ["video", "isSaved", id] });
    qc.invalidateQueries({ queryKey: ["videos", "savedCount"] });
  }

  async function markComplete() {
    if (!currentUser) return;
    await supabase.from("video_progress").upsert(
      {
        user_id: currentUser.id,
        video_id: video!.id,
        progress_pct: 100,
        progress_seconds: video!.duration_seconds,
        completed: true,
      },
      { onConflict: "user_id,video_id" },
    );
    qc.invalidateQueries({ queryKey: ["video", "progress", id] });
    qc.invalidateQueries({ queryKey: ["videos", "completedSet"] });
  }

  function onNotesChange(v: string) {
    setNotesDraft(v);
    if (notesTimer.current) clearTimeout(notesTimer.current);
    notesTimer.current = setTimeout(() => {
      if (!currentUser) return;
      void supabase.from("video_progress").upsert(
        {
          user_id: currentUser.id,
          video_id: video!.id,
          progress_pct: progress?.progress_pct ?? 0,
          progress_seconds: progress?.progress_seconds ?? 0,
          completed: progress?.completed ?? false,
          notes: v,
        },
        { onConflict: "user_id,video_id" },
      );
    }, 600);
  }

  function shareLink() {
    const url = window.location.href;
    if (navigator.share) {
      void navigator.share({ title: video!.title, url });
    } else {
      void navigator.clipboard.writeText(url);
    }
  }

  const url = video.video_url ?? "";

  return (
    <div className="space-y-6">
      <EconomyBitesNav />

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        {/* Left column */}
        <div className="space-y-5">
          <div className="aspect-video overflow-hidden rounded-2xl border border-border-base/60 bg-black">
            {url ? (
              isVideoFile(url) ? (
                <video controls src={url} className="h-full w-full" />
              ) : (
                <iframe
                  src={toEmbedUrl(url)}
                  title={video.title}
                  className="h-full w-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              )
            ) : (
              <div className="grid h-full place-items-center text-text-dim">
                No video URL provided yet.
              </div>
            )}
          </div>

          {/* Progress bar */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-text-dim">
              <span>Progress</span>
              <span>{Math.round(Number(progress?.progress_pct ?? 0))}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-charcoal-card-2">
              <div
                className="h-full rounded-full bg-teal-mid"
                style={{ width: `${Math.min(100, Number(progress?.progress_pct ?? 0))}%` }}
              />
            </div>
          </div>

          {/* Title + tags */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Tag variant={video.access_level === "vip" ? "gold" : "teal"}>
                {video.series.replace("-", " ")}
              </Tag>
              {video.category ? <Tag variant="gray">{video.category}</Tag> : null}
              <span className="ml-auto text-xs text-text-dim">
                {formatDuration(video.duration_seconds)} ·{" "}
                {video.view_count.toLocaleString()} views
              </span>
            </div>
            <h1 className="font-display text-2xl text-text-primary">{video.title}</h1>
            {video.description ? (
              <p className="text-sm text-text-muted">{video.description}</p>
            ) : null}
          </div>

          {/* Action row */}
          <div className="flex flex-wrap gap-2">
            <SxyButton size="sm" variant={saved ? "outline" : "primary"} onClick={toggleSave}>
              {saved ? (
                <>
                  <BookmarkCheck className="h-3.5 w-3.5" /> Saved
                </>
              ) : (
                <>
                  <Bookmark className="h-3.5 w-3.5" /> Save
                </>
              )}
            </SxyButton>
            <SxyButton size="sm" variant="outline" onClick={shareLink}>
              <Share2 className="h-3.5 w-3.5" /> Share
            </SxyButton>
            <SxyButton
              size="sm"
              variant="outline"
              onClick={() => setShowTranscript((s) => !s)}
            >
              <FileText className="h-3.5 w-3.5" />{" "}
              {showTranscript ? "Hide" : "Show"} transcript
            </SxyButton>
            <SxyButton size="sm" variant="success" onClick={markComplete}>
              <Check className="h-3.5 w-3.5" /> Mark complete
            </SxyButton>
            {isAdmin ? (
              <>
                <SxyButton
                  size="sm"
                  variant="outline"
                  onClick={() =>
                    navigate({
                      to: "/economy-bites/$id/edit",
                      params: { id: video!.id },
                    })
                  }
                >
                  <Pencil className="h-3.5 w-3.5" /> Edit
                </SxyButton>
                <SxyButton
                  size="sm"
                  variant="outline"
                  onClick={async () => {
                    const ok = window.confirm(
                      `Delete "${video!.title}"? This permanently removes the video, saves, and progress for all members.`,
                    );
                    if (!ok) return;
                    const { error } = await supabase
                      .from("videos")
                      .delete()
                      .eq("id", video!.id);
                    if (error) {
                      window.alert(`Delete failed: ${error.message}`);
                      return;
                    }
                    navigate({ to: "/economy-bites" });
                  }}
                >
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </SxyButton>
              </>
            ) : null}
          </div>
        </div>

        {/* Right sidebar */}
        <aside className="space-y-5">
          <SxyCard className="space-y-2">
            <h2 className="font-display text-base text-teal-light">Notes</h2>
            <Textarea
              rows={6}
              placeholder="Capture takeaways and timestamps…"
              value={notesDraft}
              onChange={(e) => onNotesChange(e.target.value)}
              className="resize-none border-border-base/60 bg-charcoal-card-2"
            />
            <p className="text-[10px] text-text-dim">Auto-saves as you type.</p>
          </SxyCard>

          {showTranscript ? (
            <SxyCard className="space-y-2">
              <h2 className="font-display text-base text-teal-light">Transcript</h2>
              <ul className="space-y-1.5 text-sm text-text-muted">
                <li>
                  <button className="font-mono text-xs text-teal-light">00:00</button>{" "}
                  Intro and overview of today's bite.
                </li>
                <li>
                  <button className="font-mono text-xs text-teal-light">02:30</button>{" "}
                  Key concept #1.
                </li>
                <li>
                  <button className="font-mono text-xs text-teal-light">05:45</button>{" "}
                  Key concept #2.
                </li>
                <li>
                  <button className="font-mono text-xs text-teal-light">08:10</button>{" "}
                  Wrap-up & next steps.
                </li>
              </ul>
              <p className="text-[10px] text-text-dim">
                Transcripts will be generated automatically once we wire the
                upload pipeline.
              </p>
            </SxyCard>
          ) : null}

          <SxyCard className="space-y-3">
            <h2 className="font-display text-base text-teal-light">Up next</h2>
            {upNext.length === 0 ? (
              <p className="text-xs text-text-muted">
                No more videos in this series yet.
              </p>
            ) : (
              <ul className="space-y-2">
                {upNext.map((v) => (
                  <li key={v.id}>
                    <Link
                      to="/economy-bites/$id"
                      params={{ id: v.id }}
                      className="group flex items-center gap-3 rounded-lg border border-border-base/60 bg-charcoal-card-2 p-2 transition-colors hover:border-border-teal"
                    >
                      <span
                        aria-hidden
                        className="grid h-12 w-16 shrink-0 place-items-center rounded bg-teal-deep/30 text-xl"
                      >
                        {v.icon_emoji}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="line-clamp-2 block text-xs text-text-primary group-hover:text-teal-light">
                          {v.title}
                        </span>
                        <span className="mt-0.5 flex items-center gap-1 text-[10px] text-text-dim">
                          <Play className="h-2.5 w-2.5" fill="currentColor" />
                          {formatDuration(v.duration_seconds)}
                        </span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </SxyCard>
        </aside>
      </div>
    </div>
  );
}
