/**
 * /financials/invoices — list, create, and download invoices.
 */
import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FinancialsNav } from "@/components/financials/FinancialsNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { downloadInvoicePdf } from "@/lib/financials/invoice-pdf";
import {
  formatDate,
  formatMoney,
  statusTone,
  type InvoiceRow,
} from "@/lib/financials/shared";

export const Route = createFileRoute("/financials/invoices")({
  head: () => ({ meta: [{ title: "Invoices — SXY's Corporate Club" }] }),
  component: InvoicesRoute,
});

function InvoicesRoute() {
  const { currentUser, userProfile } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = React.useState(false);

  const { data: invoices = [] } = useQuery({
    queryKey: ["financials", "invoices", currentUser?.id],
    enabled: !!currentUser,
    queryFn: async () => {
      const { data } = await supabase
        .from("invoices")
        .select("*")
        .eq("user_id", currentUser!.id)
        .order("issued_at", { ascending: false });
      return (data ?? []) as InvoiceRow[];
    },
  });

  const mostRecent = invoices[0];

  return (
    <AppLayout
      title="Invoices"
      actions={
        <SxyButton variant="gold" size="sm" onClick={() => setOpen(true)}>
          Create Invoice
        </SxyButton>
      }
    >
      <div className="space-y-6">
        <FinancialsNav />

        {mostRecent ? (
          <SxyCard accent className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg text-teal-light">
                Most recent invoice
              </h2>
              <Tag variant={statusTone(mostRecent.status)}>{mostRecent.status}</Tag>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <p className="text-[10px] uppercase text-text-dim">Number</p>
                <p className="font-mono text-sm text-teal-light">
                  {mostRecent.invoice_number}
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase text-text-dim">Client</p>
                <p className="text-sm text-text-primary">
                  {mostRecent.client_name}
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase text-text-dim">Amount</p>
                <p className="font-editorial text-2xl text-gold">
                  {formatMoney(mostRecent.amount)}
                </p>
              </div>
            </div>
            <p className="text-sm text-text-muted">{mostRecent.description}</p>
            <SxyButton
              variant="outline"
              size="sm"
              onClick={() =>
                downloadInvoicePdf(mostRecent, userProfile?.full_name)
              }
            >
              Download PDF
            </SxyButton>
          </SxyCard>
        ) : null}

        <SxyCard accent>
          <h2 className="font-display text-lg text-teal-light">All invoices</h2>
          <table className="mt-4 w-full text-sm">
            <thead className="text-[10px] uppercase tracking-wider text-text-dim">
              <tr className="border-b border-border-base/40">
                <th className="py-2 text-left">Number</th>
                <th className="py-2 text-left">Description</th>
                <th className="py-2 text-left">Issued</th>
                <th className="py-2 text-right">Amount</th>
                <th className="py-2 text-left">Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {invoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-text-dim">
                    No invoices yet — create your first one.
                  </td>
                </tr>
              ) : (
                invoices.map((inv) => (
                  <tr key={inv.id} className="border-b border-border-base/30">
                    <td className="py-2 font-mono text-teal-light">
                      {inv.invoice_number}
                    </td>
                    <td className="py-2 text-text-primary">
                      {inv.description ?? "—"}
                    </td>
                    <td className="py-2 text-text-muted">
                      {formatDate(inv.issued_at)}
                    </td>
                    <td className="py-2 text-right font-semibold text-text-primary">
                      {formatMoney(inv.amount)}
                    </td>
                    <td className="py-2">
                      <Tag variant={statusTone(inv.status)}>{inv.status}</Tag>
                    </td>
                    <td className="py-2 text-right">
                      <SxyButton
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          downloadInvoicePdf(inv, userProfile?.full_name)
                        }
                      >
                        Download PDF
                      </SxyButton>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </SxyCard>
      </div>

      <CreateInvoiceModal
        open={open}
        onOpenChange={setOpen}
        onCreated={() => qc.invalidateQueries({ queryKey: ["financials", "invoices"] })}
      />
    </AppLayout>
  );
}

function CreateInvoiceModal({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: () => void;
}) {
  const { currentUser } = useAuth();
  const [client, setClient] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [amount, setAmount] = React.useState("");
  const [dueDate, setDueDate] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  React.useEffect(() => {
    if (!open) {
      setClient("");
      setDescription("");
      setAmount("");
      setDueDate("");
      setNotes("");
    }
  }, [open]);

  async function submit() {
    if (!currentUser) return;
    const n = Number(amount);
    if (!client.trim() || !n || n <= 0) {
      toast.error("Enter a client and a valid amount.");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("invoices").insert({
      user_id: currentUser.id,
      client_name: client.trim(),
      description: description || null,
      amount: n,
      due_date: dueDate || null,
      notes: notes || null,
      status: "sent",
    });
    setSubmitting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Invoice created.");
    onCreated();
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border-teal/40 bg-charcoal-card sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-teal-light">
            Create invoice
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="inv-client">Client name</Label>
            <Input
              id="inv-client"
              value={client}
              onChange={(e) => setClient(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="inv-desc">Service description</Label>
            <Textarea
              id="inv-desc"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="inv-amount">Amount (USD)</Label>
              <Input
                id="inv-amount"
                type="number"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="inv-due">Due date</Label>
              <Input
                id="inv-due"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="inv-notes">Notes</Label>
            <Textarea
              id="inv-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <SxyButton
            variant="outline"
            size="sm"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            Cancel
          </SxyButton>
          <SxyButton
            variant="gold"
            size="sm"
            onClick={submit}
            disabled={submitting}
          >
            {submitting ? "Creating…" : "Create invoice"}
          </SxyButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
