import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { KidShell } from "@/components/kiddos/KidShell";
import { CreditBadge } from "@/components/kiddos/CreditBadge";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { createRedeemable, redeemItem, fulfillRedemption, upsertKidBusinessPage } from "@/lib/kiddos/kiddos.functions";
import { toEmbedUrl } from "@/lib/kiddos/youtube";

export const Route = createFileRoute("/kiddos/directory")({
  head: () => ({ meta: [{ title: "Trade — Kiddos" }] }),
  component: () => (
    <KidShell title="Trade 🛍️">
      <TradeContent />
    </KidShell>
  ),
});

function TradeContent() {
  const { currentUser } = useAuth();
  const userId = currentUser?.id;
  const qc = useQueryClient();
  const createFn = useServerFn(createRedeemable);
  const buyFn = useServerFn(redeemItem);
  const fulfillFn = useServerFn(fulfillRedemption);
  const bizFn = useServerFn(upsertKidBusinessPage);

  const { data: businesses } = useQuery({
    queryKey: ["kid-businesses-approved"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kid_business_pages")
        .select("id, name, tagline, description, emoji, category, youtube_url, owner_user_id")
        .eq("status", "approved")
        .order("created_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return data ?? [];
    },
  });

  const bizMut = useMutation({
    mutationFn: (v: { name: string; tagline?: string; description?: string; emoji?: string; youtubeUrl?: string }) =>
      bizFn({ data: v }),
    onSuccess: () => {
      toast.success("Submitted! Parent will review.");
      qc.invalidateQueries({ queryKey: ["kid-businesses-approved"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: items } = useQuery({
    queryKey: ["redeemables-active"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("redeemables")
        .select("id, title, description, price_credits, quantity, category, image_emoji, owner_user_id, status")
        .eq("status", "active")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: mySales } = useQuery({
    queryKey: ["my-pending-sales", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("redemptions")
        .select("id, status, price_credits, buyer_user_id, redeemable_id")
        .eq("seller_user_id", userId)
        .eq("status", "pending")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const buyMut = useMutation({
    mutationFn: (id: string) => buyFn({ data: { redeemableId: id } }),
    onSuccess: () => {
      toast.success("Redeemed! The seller will deliver.");
      qc.invalidateQueries({ queryKey: ["redeemables-active"] });
      qc.invalidateQueries({ queryKey: ["kiddo-wallet", userId] });
      qc.invalidateQueries({ queryKey: ["kiddo-ledger", userId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const fulfillMut = useMutation({
    mutationFn: (id: string) => fulfillFn({ data: { redemptionId: id } }),
    onSuccess: () => {
      toast.success("Marked fulfilled.");
      qc.invalidateQueries({ queryKey: ["my-pending-sales", userId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const createMut = useMutation({
    mutationFn: (input: { title: string; priceCredits: number; description?: string; imageEmoji?: string }) =>
      createFn({ data: { ...input, quantity: 1 } }),
    onSuccess: () => {
      toast.success("Listed!");
      qc.invalidateQueries({ queryKey: ["redeemables-active"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!currentUser) {
    return (
      <div className="kid-card text-center">
        <p className="mb-4">Sign in to trade with friends.</p>
        <Link to="/login" className="kid-btn kid-btn-primary">Sign in</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-5">
      <section className="kid-card">
        <h2 className="text-xl mb-3">List something to trade</h2>
        <NewListingForm onCreate={(v) => createMut.mutate(v)} pending={createMut.isPending} />
        <p className="text-xs text-[var(--kid-ink-muted)] mt-2">
          No phone numbers or emails in titles or descriptions — those are blocked.
        </p>
      </section>

      <section className="kid-card">
        <h2 className="text-xl mb-2">Your business page</h2>
        <p className="text-sm text-[var(--kid-ink-muted)] mb-3">
          Promote your hustle. Parent + admin must approve before it goes live in the directory.
          You can link your YouTube channel (parent will check it).
        </p>
        <BusinessForm onCreate={(v) => bizMut.mutate(v)} pending={bizMut.isPending} />
      </section>

      {businesses && businesses.length > 0 && (
        <section>
          <h2 className="text-xl mb-3 px-1">Kid businesses</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {businesses.map((b) => (
              <div key={b.id} className="kid-card">
                <div className="flex items-start gap-3">
                  <div className="text-4xl" aria-hidden>{b.emoji ?? "🏪"}</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold">{b.name}</div>
                    {b.tagline && <p className="text-sm text-[var(--kid-ink-muted)]">{b.tagline}</p>}
                    {b.description && <p className="text-sm mt-2 line-clamp-3">{b.description}</p>}
                    {b.youtube_url && (
                      <div className="mt-3 rounded-xl overflow-hidden" style={{ aspectRatio: "16/9" }}>
                        <iframe
                          src={toEmbedUrl(b.youtube_url) ?? b.youtube_url}
                          title={b.name}
                          className="w-full h-full"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {mySales && mySales.length > 0 && (
        <section className="kid-card">
          <h2 className="text-xl mb-3">Deliveries to fulfill</h2>
          <ul className="space-y-2">
            {mySales.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-3 text-sm">
                <span>Order #{s.id.slice(0, 6)}</span>
                <div className="flex items-center gap-3">
                  <CreditBadge amount={`+${s.price_credits}`} />
                  <button
                    type="button"
                    className="kid-btn kid-btn-primary"
                    onClick={() => fulfillMut.mutate(s.id)}
                    disabled={fulfillMut.isPending}
                  >
                    Mark delivered
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="grid sm:grid-cols-2 gap-4">
        {(items ?? []).map((it) => {
          const mine = it.owner_user_id === userId;
          return (
            <div key={it.id} className="kid-card">
              <div className="flex items-start gap-3">
                <div className="text-4xl" aria-hidden>{it.image_emoji ?? "🎁"}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold">{it.title}</div>
                  {it.description && (
                    <p className="text-sm text-[var(--kid-ink-muted)] mt-1 line-clamp-3">{it.description}</p>
                  )}
                  <div className="mt-3 flex items-center justify-between">
                    <CreditBadge amount={it.price_credits} />
                    <button
                      type="button"
                      className="kid-btn kid-btn-gold"
                      disabled={mine || buyMut.isPending}
                      onClick={() => buyMut.mutate(it.id)}
                    >
                      {mine ? "Yours" : "Redeem"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        {(!items || items.length === 0) && (
          <div className="kid-card sm:col-span-2 text-center text-[var(--kid-ink-muted)]">
            No listings yet — be the first to trade.
          </div>
        )}
      </section>
    </div>
  );
}

function NewListingForm({
  onCreate,
  pending,
}: {
  onCreate: (v: { title: string; priceCredits: number; description?: string; imageEmoji?: string }) => void;
  pending: boolean;
}) {
  const [title, setTitle] = React.useState("");
  const [price, setPrice] = React.useState("");
  const [desc, setDesc] = React.useState("");
  const [emoji, setEmoji] = React.useState("🎁");
  return (
    <form
      className="grid gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const p = Number(price);
        if (!title.trim() || !Number.isFinite(p) || p <= 0) return;
        onCreate({ title: title.trim(), priceCredits: Math.floor(p), description: desc.trim() || undefined, imageEmoji: emoji });
        setTitle(""); setPrice(""); setDesc("");
      }}
    >
      <div className="flex gap-2">
        <input className="kid-input" style={{ width: 64, textAlign: "center" }} value={emoji} onChange={(e) => setEmoji(e.target.value.slice(0, 4))} aria-label="Emoji" />
        <input className="kid-input flex-1" placeholder="What are you offering?" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={80} />
        <input className="kid-input" style={{ width: 110 }} placeholder="Credits" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value)} />
      </div>
      <textarea className="kid-input" placeholder="Description (optional)" value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={300} rows={2} />
      <button type="submit" className="kid-btn kid-btn-primary self-start" disabled={pending}>List it</button>
    </form>
  );
}

function BusinessForm({
  onCreate,
  pending,
}: {
  onCreate: (v: { name: string; tagline?: string; description?: string; emoji?: string; youtubeUrl?: string }) => void;
  pending: boolean;
}) {
  const [name, setName] = React.useState("");
  const [tagline, setTagline] = React.useState("");
  const [desc, setDesc] = React.useState("");
  const [emoji, setEmoji] = React.useState("🏪");
  const [yt, setYt] = React.useState("");
  return (
    <form
      className="grid gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) {
          toast.error("Business name required.");
          return;
        }
        onCreate({
          name: name.trim(),
          tagline: tagline.trim() || undefined,
          description: desc.trim() || undefined,
          emoji,
          youtubeUrl: yt.trim() || undefined,
        });
        setName(""); setTagline(""); setDesc(""); setYt("");
      }}
    >
      <div className="flex gap-2">
        <input className="kid-input" style={{ width: 64, textAlign: "center" }} value={emoji} onChange={(e) => setEmoji(e.target.value.slice(0, 4))} aria-label="Emoji" />
        <input className="kid-input flex-1" placeholder="Business name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
      </div>
      <input className="kid-input" placeholder="Tagline (one line)" value={tagline} onChange={(e) => setTagline(e.target.value)} maxLength={160} />
      <textarea className="kid-input" placeholder="What do you do? (no emails or phone numbers)" value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} maxLength={1000} />
      <input className="kid-input" placeholder="YouTube channel URL (optional)" value={yt} onChange={(e) => setYt(e.target.value)} />
      <button type="submit" className="kid-btn kid-btn-primary self-start" disabled={pending}>Submit for review</button>
    </form>
  );
}
