import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { TierGate } from "@/components/sxy/TierGate";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import {
  BID_CURRENCY,
  categoryEmoji,
  categoryLabel,
} from "@/lib/bidding/shared";

export const Route = createFileRoute("/bidding/awarded")({
  head: () => ({ meta: [{ title: "Awarded Projects — SXY's Corporate Club" }] }),
  component: AwardedPage,
});

function AwardedPage() {
  return (
    <AppLayout
      title="Awarded Projects"
      actions={
        <SxyButton variant="outline" size="sm" asChild>
          <Link to="/bidding">Back to browse</Link>
        </SxyButton>
      }
    >
      <TierGate feature="Club Market">
        <AwardedContent />
      </TierGate>
    </AppLayout>
  );
}

function AwardedContent() {
  const { data, isLoading } = useQuery({
    queryKey: ["bidding", "awarded"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select(
          "id, title, category, contract_value, budget, budget_min, budget_max, updated_at, winner:winner_id(full_name, avatar_color)",
        )
        .eq("status", "awarded")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  if (isLoading) {
    return (
      <SxyCard>
        <p className="text-sm text-text-muted">Loading awarded projects…</p>
      </SxyCard>
    );
  }

  if (!data || data.length === 0) {
    return (
      <SxyCard accent>
        <h2 className="font-display text-lg text-teal-light">
          No awards yet
        </h2>
        <p className="mt-2 text-sm text-text-muted">
          Once admins announce winners they'll show up here.
        </p>
      </SxyCard>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-border-base/60">
      <table className="w-full text-sm">
        <thead className="bg-charcoal-soft text-left text-[10px] uppercase tracking-[0.18em] text-text-dim">
          <tr>
            <th className="px-4 py-3">Project</th>
            <th className="px-4 py-3">Winner</th>
            <th className="px-4 py-3 text-right">Amount</th>
            <th className="px-4 py-3 text-right">Awarded</th>
            <th className="px-4 py-3 text-right">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border-base/40 bg-charcoal-card">
          {data.map((p: any) => (
            <tr key={p.id}>
              <td className="px-4 py-3">
                <div className="flex items-center gap-2">
                  <span aria-hidden>{categoryEmoji(p.category)}</span>
                  <Link
                    to="/bidding/$id"
                    params={{ id: p.id }}
                    className="font-editorial text-base text-text-primary hover:text-teal-light"
                  >
                    {p.title}
                  </Link>
                </div>
                <p className="ml-6 text-[10px] uppercase tracking-wider text-text-dim">
                  {categoryLabel(p.category)}
                </p>
              </td>
              <td className="px-4 py-3 text-text-primary">
                {p.winner?.full_name ?? "—"}
              </td>
              <td className="px-4 py-3 text-right font-mono text-text-primary">
                {BID_CURRENCY.format(
                  Number(p.contract_value ?? p.budget ?? 0),
                )}
              </td>
              <td className="px-4 py-3 text-right text-xs text-text-dim">
                {new Date(p.updated_at).toLocaleDateString()}
              </td>
              <td className="px-4 py-3 text-right">
                <Tag variant="green">Awarded</Tag>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
