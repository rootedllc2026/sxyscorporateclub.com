import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";
import { FilterChip } from "@/components/sxy/FilterChip";
import { cn } from "@/lib/utils";
import {
  DAYS_OF_WEEK,
  type DayId,
  REFERRAL_BOOKABLE_CATEGORIES,
  categoryBannerGradient,
  formatPrice,
  refCategoryEmoji,
  refCategoryLabel,
} from "@/lib/referrals/shared";

export const Route = createFileRoute("/referrals/request")({
  head: () => ({ meta: [{ title: "Request My Page — SXY's Corporate Club" }] }),
  component: RequestPage,
});

type ServiceDraft = { id: string; name: string; price: string; description: string };

type State = {
  business_name: string;
  category: string;
  icon_emoji: string;
  description: string;
  service_area: string;
  website_url: string;
  logo_file: File | null;
  logo_preview_url: string | null;
  services: ServiceDraft[];
  platform_fee_pct: number;
  available_days: DayId[];
  start_time: string;
  end_time: string;
  session_length_min: number;
  booking_lead_hours: number;
  require_intake_form: boolean;
  allow_virtual: boolean;
  require_deposit: boolean;
};

const STEPS = [
  { id: 1, label: "Business" },
  { id: 2, label: "Services" },
  { id: 3, label: "Booking" },
  { id: 4, label: "Review" },
] as const;

function RequestPage() {
  return (
    <AppLayout title="Request My Page">
      <RequestContent />
    </AppLayout>
  );
}

function RequestContent() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [step, setStep] = React.useState(1);
  const [submitting, setSubmitting] = React.useState(false);
  const [state, setState] = React.useState<State>({
    business_name: "",
    category: "cleaning",
    icon_emoji: "🧼",
    description: "",
    service_area: "",
    website_url: "",
    logo_file: null,
    logo_preview_url: null,
    services: [{ id: crypto.randomUUID(), name: "", price: "", description: "" }],
    platform_fee_pct: 3,
    available_days: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    start_time: "09:00",
    end_time: "17:00",
    session_length_min: 60,
    booking_lead_hours: 24,
    require_intake_form: false,
    allow_virtual: true,
    require_deposit: false,
  });

  const update = <K extends keyof State>(key: K, value: State[K]) =>
    setState((prev) => ({ ...prev, [key]: value }));

  const startingPrice = React.useMemo(() => {
    const prices = state.services
      .map((s) => Number(s.price))
      .filter((n) => Number.isFinite(n) && n > 0);
    return prices.length > 0 ? Math.min(...prices) : 0;
  }, [state.services]);

  function validateStep(s: number): string | null {
    if (s === 1) {
      if (state.business_name.trim().length < 2)
        return "Add your business name";
      if (state.description.trim().length < 20)
        return "Describe your business in at least 20 characters";
    }
    if (s === 2) {
      const valid = state.services.filter(
        (svc) => svc.name.trim().length > 0 && Number(svc.price) > 0,
      );
      if (valid.length === 0)
        return "Add at least one service with a name and price";
    }
    if (s === 3) {
      if (state.available_days.length === 0)
        return "Pick at least one available day";
      if (!state.start_time || !state.end_time)
        return "Set your daily hours";
    }
    return null;
  }

  async function handleSubmit() {
    if (!currentUser) {
      toast.error("Please sign in first");
      return;
    }
    for (const s of [1, 2, 3]) {
      const err = validateStep(s);
      if (err) {
        toast.error(err);
        setStep(s);
        return;
      }
    }
    setSubmitting(true);
    try {
      // 1. Optional logo upload
      let logoUrl: string | null = null;
      if (state.logo_file) {
        const safeName = state.logo_file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        const path = `${currentUser.id}/logo-${Date.now()}-${safeName}`;
        const { error: upErr } = await supabase.storage
          .from("business-pages")
          .upload(path, state.logo_file, { upsert: false });
        if (upErr) throw upErr;
        const { data } = supabase.storage.from("business-pages").getPublicUrl(path);
        logoUrl = data.publicUrl;
      }

      // 2. Insert page
      const { data: pageRow, error: pageErr } = await supabase
        .from("business_pages")
        .insert({
          owner_id: currentUser.id,
          business_name: state.business_name.trim(),
          category: state.category as "cleaning" | "contractor" | "strategy" | "marketing" | "legal" | "tech_ai" | "other",
          icon_emoji: state.icon_emoji.trim() || null,
          description: state.description.trim(),
          service_area: state.service_area.trim() || null,
          website_url: state.website_url.trim() || null,
          logo_url: logoUrl,
          starting_price: startingPrice > 0 ? startingPrice : null,
          platform_fee_pct: state.platform_fee_pct,
          available_days: state.available_days,
          start_time: state.start_time,
          end_time: state.end_time,
          session_length_min: state.session_length_min,
          booking_lead_hours: state.booking_lead_hours,
          require_intake_form: state.require_intake_form,
          allow_virtual: state.allow_virtual,
          require_deposit: state.require_deposit,
          status: "pending",
        })
        .select("id")
        .single();
      if (pageErr) throw pageErr;

      // 3. Insert services
      const validServices = state.services.filter(
        (svc) => svc.name.trim().length > 0 && Number(svc.price) > 0,
      );
      if (validServices.length > 0) {
        const { error: svcErr } = await supabase
          .from("referral_services")
          .insert(
            validServices.map((svc, idx) => ({
              business_page_id: pageRow.id,
              name: svc.name.trim(),
              description: svc.description.trim() || null,
              price: Number(svc.price),
              sort_order: idx,
            })),
          );
        if (svcErr) throw svcErr;
      }

      toast.success("Page submitted! It'll go live after admin review.");
      await navigate({ to: "/referrals/my-page" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't submit page");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
      <div className="space-y-6">
        {/* Step indicator */}
        <ol className="flex flex-wrap items-center gap-2">
          {STEPS.map((s, idx) => (
            <li key={s.id} className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setStep(s.id)}
                className={cn(
                  "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition",
                  step === s.id
                    ? "border-gold bg-[color:var(--gold-glow)] text-gold-light"
                    : step > s.id
                    ? "border-border-teal bg-[color:var(--teal-glow)] text-teal-light"
                    : "border-border-base/60 bg-charcoal-card text-text-muted",
                )}
              >
                <span className="grid h-5 w-5 place-items-center rounded-full bg-charcoal text-[10px]">
                  {step > s.id ? "✓" : s.id}
                </span>
                {s.label}
              </button>
              {idx < STEPS.length - 1 ? (
                <span aria-hidden className="text-text-dim">─</span>
              ) : null}
            </li>
          ))}
        </ol>

        {step === 1 ? (
          <Step1 state={state} update={update} />
        ) : step === 2 ? (
          <Step2 state={state} update={update} />
        ) : step === 3 ? (
          <Step3 state={state} update={update} />
        ) : (
          <Step4 state={state} startingPrice={startingPrice} />
        )}

        {/* Footer */}
        <div className="flex items-center justify-between gap-3">
          <SxyButton
            variant="ghost"
            disabled={step === 1}
            onClick={() => setStep((s) => Math.max(1, s - 1))}
          >
            ← Back
          </SxyButton>
          {step < 4 ? (
            <SxyButton
              variant="primary"
              onClick={() => {
                const err = validateStep(step);
                if (err) {
                  toast.error(err);
                  return;
                }
                setStep((s) => Math.min(4, s + 1));
              }}
            >
              Continue →
            </SxyButton>
          ) : (
            <SxyButton variant="gold" disabled={submitting} onClick={handleSubmit}>
              {submitting ? "Submitting…" : "Submit for review"}
            </SxyButton>
          )}
        </div>
      </div>

      {/* Live preview */}
      <aside className="lg:sticky lg:top-6 lg:self-start">
        <p className="sxy-section-label">Live preview</p>
        <div className="mt-3">
          <PreviewCard state={state} startingPrice={startingPrice} />
        </div>
        <p className="mt-3 text-[10px] text-text-dim">
          This is how your card appears in the directory once approved.
        </p>
      </aside>
    </div>
  );
}

// ─── Steps ────────────────────────────────────────────────────────────────
function Step1({
  state,
  update,
}: {
  state: State;
  update: <K extends keyof State>(k: K, v: State[K]) => void;
}) {
  function onLogoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null;
    if (state.logo_preview_url) URL.revokeObjectURL(state.logo_preview_url);
    if (file) {
      update("logo_file", file);
      update("logo_preview_url", URL.createObjectURL(file));
    } else {
      update("logo_file", null);
      update("logo_preview_url", null);
    }
  }

  return (
    <SxyCard accent>
      <p className="sxy-section-label">Step 1 · Business info</p>
      <div className="mt-4 grid gap-5 md:grid-cols-2">
        <Field label="Business name">
          <input
            value={state.business_name}
            onChange={(e) => update("business_name", e.target.value)}
            maxLength={120}
            className={inputCls}
            placeholder="e.g. Pristine Cleaning Co."
          />
        </Field>
        <Field label="Category">
          <select
            value={state.category}
            onChange={(e) => update("category", e.target.value)}
            className={inputCls}
          >
            {REFERRAL_BOOKABLE_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>{c.emoji} {c.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Icon (emoji)">
          <input
            value={state.icon_emoji}
            onChange={(e) => update("icon_emoji", e.target.value)}
            maxLength={4}
            className={inputCls}
            placeholder="🧼"
          />
        </Field>
        <Field label="Service area">
          <input
            value={state.service_area}
            onChange={(e) => update("service_area", e.target.value)}
            maxLength={120}
            className={inputCls}
            placeholder="e.g. Atlanta metro"
          />
        </Field>
        <Field label="Website (optional)" className="md:col-span-2">
          <input
            type="url"
            value={state.website_url}
            onChange={(e) => update("website_url", e.target.value)}
            maxLength={255}
            className={inputCls}
            placeholder="https://example.com"
          />
        </Field>
        <Field label="Description" className="md:col-span-2">
          <textarea
            value={state.description}
            onChange={(e) => update("description", e.target.value)}
            rows={5}
            maxLength={1000}
            className={cn(inputCls, "resize-y leading-relaxed")}
            placeholder="What you do, who you serve, what makes you stand out…"
          />
          <p className="mt-1 text-right text-[10px] text-text-dim">
            {state.description.length}/1000
          </p>
        </Field>
        <Field label="Logo (optional, PNG/JPG)" className="md:col-span-2">
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={onLogoChange}
            className="block w-full text-xs text-text-muted file:mr-3 file:rounded-full file:border-0 file:bg-[color:var(--teal-glow)] file:px-4 file:py-1.5 file:text-xs file:font-semibold file:text-teal-light hover:file:bg-[color:var(--teal-glow)]/70"
          />
        </Field>
      </div>
    </SxyCard>
  );
}

function Step2({
  state,
  update,
}: {
  state: State;
  update: <K extends keyof State>(k: K, v: State[K]) => void;
}) {
  function setSvc(id: string, patch: Partial<ServiceDraft>) {
    update(
      "services",
      state.services.map((s) => (s.id === id ? { ...s, ...patch } : s)),
    );
  }
  function addSvc() {
    update("services", [
      ...state.services,
      { id: crypto.randomUUID(), name: "", price: "", description: "" },
    ]);
  }
  function removeSvc(id: string) {
    if (state.services.length <= 1) return;
    update("services", state.services.filter((s) => s.id !== id));
  }

  return (
    <SxyCard accent>
      <p className="sxy-section-label">Step 2 · Services & pricing</p>
      <div className="mt-4 space-y-3">
        {state.services.map((svc, idx) => (
          <div
            key={svc.id}
            className="rounded-lg border border-border-base/40 bg-charcoal-soft p-4"
          >
            <div className="grid gap-3 md:grid-cols-[2fr_1fr_auto]">
              <input
                value={svc.name}
                onChange={(e) => setSvc(svc.id, { name: e.target.value })}
                placeholder={`Service ${idx + 1} name`}
                maxLength={120}
                className={inputCls}
              />
              <input
                type="number"
                inputMode="decimal"
                min="0"
                step="10"
                value={svc.price}
                onChange={(e) => setSvc(svc.id, { price: e.target.value })}
                placeholder="Price (USD)"
                className={inputCls}
              />
              <SxyButton
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => removeSvc(svc.id)}
                disabled={state.services.length <= 1}
              >
                Remove
              </SxyButton>
            </div>
            <textarea
              value={svc.description}
              onChange={(e) => setSvc(svc.id, { description: e.target.value })}
              rows={2}
              maxLength={300}
              placeholder="Short description (optional)"
              className={cn(inputCls, "mt-2 resize-y text-xs")}
            />
          </div>
        ))}
        <SxyButton type="button" variant="outline" size="sm" onClick={addSvc}>
          + Add another service
        </SxyButton>
      </div>

      <div className="mt-6 rounded-lg border border-border-gold/40 bg-[color:var(--gold-glow)] p-3 text-[11px] text-gold-light">
        <strong className="font-semibold">Club platform fee:</strong> 3% is
        added to the buyer's total at checkout (2% if the buyer is a VIP
        member). You always receive 100% of your listed service price — the
        fee is on top, not deducted.
      </div>
    </SxyCard>
  );
}

function Step3({
  state,
  update,
}: {
  state: State;
  update: <K extends keyof State>(k: K, v: State[K]) => void;
}) {
  function toggleDay(d: DayId) {
    const has = state.available_days.includes(d);
    update(
      "available_days",
      has
        ? state.available_days.filter((x) => x !== d)
        : [...state.available_days, d],
    );
  }
  return (
    <SxyCard accent>
      <p className="sxy-section-label">Step 3 · Booking settings</p>

      <div className="mt-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
          Available days
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          {DAYS_OF_WEEK.map((d) => (
            <FilterChip
              key={d.id}
              active={state.available_days.includes(d.id)}
              onClick={() => toggleDay(d.id)}
            >
              {d.label}
            </FilterChip>
          ))}
        </div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-4">
        <Field label="Start time">
          <input
            type="time"
            value={state.start_time}
            onChange={(e) => update("start_time", e.target.value)}
            className={inputCls}
          />
        </Field>
        <Field label="End time">
          <input
            type="time"
            value={state.end_time}
            onChange={(e) => update("end_time", e.target.value)}
            className={inputCls}
          />
        </Field>
        <Field label="Session length (min)">
          <input
            type="number"
            min="15"
            step="15"
            value={state.session_length_min}
            onChange={(e) =>
              update("session_length_min", Number(e.target.value) || 60)
            }
            className={inputCls}
          />
        </Field>
        <Field label="Lead time (hrs)">
          <input
            type="number"
            min="0"
            step="1"
            value={state.booking_lead_hours}
            onChange={(e) =>
              update("booking_lead_hours", Number(e.target.value) || 0)
            }
            className={inputCls}
          />
        </Field>
      </div>

      <div className="mt-6 grid gap-3 md:grid-cols-3">
        <Toggle
          label="Require intake form"
          checked={state.require_intake_form}
          onChange={(v) => update("require_intake_form", v)}
        />
        <Toggle
          label="Allow virtual sessions"
          checked={state.allow_virtual}
          onChange={(v) => update("allow_virtual", v)}
        />
        <Toggle
          label="Require deposit"
          checked={state.require_deposit}
          onChange={(v) => update("require_deposit", v)}
        />
      </div>
    </SxyCard>
  );
}

function Step4({ state, startingPrice }: { state: State; startingPrice: number }) {
  const validServices = state.services.filter(
    (s) => s.name.trim() && Number(s.price) > 0,
  );
  return (
    <SxyCard accent>
      <p className="sxy-section-label">Step 4 · Review & submit</p>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <Detail label="Business" value={state.business_name || "—"} />
        <Detail label="Category" value={refCategoryLabel(state.category)} />
        <Detail label="Service area" value={state.service_area || "—"} />
        <Detail label="Platform fee" value="3% · 2% for VIPs" />
        <Detail
          label="Available days"
          value={state.available_days.join(", ") || "—"}
        />
        <Detail
          label="Hours"
          value={`${state.start_time} – ${state.end_time} · ${state.session_length_min}m`}
        />
        <Detail
          label="Starting price"
          value={startingPrice > 0 ? formatPrice(startingPrice) : "—"}
        />
        <Detail label="Services" value={`${validServices.length} listed`} />
      </div>

      <div className="mt-5">
        <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
          Description
        </p>
        <p className="mt-1 whitespace-pre-line rounded-lg border border-border-base/40 bg-charcoal-soft p-3 text-sm text-text-primary">
          {state.description || "—"}
        </p>
      </div>

      <p className="mt-5 text-xs text-text-dim">
        Once you submit, your page enters the admin review queue. You'll see a
        "Pending review" banner on My Page until it's published.
      </p>
    </SxyCard>
  );
}

// ─── Preview card ─────────────────────────────────────────────────────────
function PreviewCard({ state, startingPrice }: { state: State; startingPrice: number }) {
  return (
    <div className="sxy-card overflow-hidden p-0">
      <div
        className="flex h-28 items-center justify-center"
        style={{ backgroundImage: categoryBannerGradient(state.category) }}
      >
        <span aria-hidden className="text-5xl drop-shadow-lg">
          {state.icon_emoji || refCategoryEmoji(state.category)}
        </span>
      </div>
      <div className="p-4">
        <h3 className="font-display text-base text-text-primary">
          {state.business_name || "Your business name"}
        </h3>
        <p className="mt-1 text-xs text-text-dim">
          {state.service_area || "Service area"}
        </p>
        {state.description ? (
          <p className="mt-2 line-clamp-2 text-xs text-text-muted">
            {state.description}
          </p>
        ) : null}
        <div className="mt-3 flex flex-wrap gap-2">
          <Tag variant="teal">{refCategoryLabel(state.category)}</Tag>
        </div>
        <div className="mt-3 flex items-baseline justify-between">
          <p className="text-[9px] uppercase tracking-[0.18em] text-text-dim">
            Starting at
          </p>
          <p className="font-editorial text-xl text-gold">
            {startingPrice > 0 ? formatPrice(startingPrice) : "—"}
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Reusable bits ────────────────────────────────────────────────────────
function Field({
  label,
  className,
  children,
}: {
  label: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <label className={cn("block", className)}>
      <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">
        {label}
      </p>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.18em] text-text-dim">
        {label}
      </p>
      <p className="mt-1 text-sm text-text-primary">{value}</p>
    </div>
  );
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={cn(
        "flex items-center justify-between gap-3 rounded-lg border px-4 py-3 text-left text-sm transition",
        checked
          ? "border-border-teal bg-[color:var(--teal-glow)] text-teal-light"
          : "border-border-base/60 bg-charcoal-soft text-text-muted hover:border-border-teal",
      )}
    >
      <span>{label}</span>
      <span
        aria-hidden
        className={cn(
          "grid h-5 w-9 place-items-center rounded-full border transition",
          checked
            ? "border-teal-mid bg-teal-deep"
            : "border-border-base/60 bg-charcoal",
        )}
      >
        <span
          className={cn(
            "h-3.5 w-3.5 rounded-full bg-text-primary transition-transform",
            checked ? "translate-x-1.5" : "-translate-x-1.5",
          )}
        />
      </span>
    </button>
  );
}

const inputCls =
  "w-full rounded-lg border border-border-base/60 bg-charcoal-soft px-3 py-2 text-sm text-text-primary placeholder:text-text-dim focus:border-border-teal focus:outline-none";
