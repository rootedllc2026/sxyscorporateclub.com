/**
 * Jayla chatbot proxy — POST /api/public/jayla
 *
 * Proxies the Club Boutique chat widget (public/club-boutique.html) to the
 * Lovable AI Gateway. Keeps LOVABLE_API_KEY server-side. Accepts an
 * Anthropic-style payload ({ system, messages, max_tokens }) for compatibility
 * with the existing widget script and returns { content: [{ text }] }.
 */
import { createFileRoute } from "@tanstack/react-router";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

export const Route = createFileRoute("/api/public/jayla")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: CORS }),

      POST: async ({ request }) => {
        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) {
          return json({ error: "AI not configured" }, 500);
        }

        let body: {
          system?: string;
          messages?: Array<{ role: string; content: string }>;
          max_tokens?: number;
        };
        try {
          body = await request.json();
        } catch {
          return json({ error: "Invalid JSON" }, 400);
        }

        const messages = Array.isArray(body.messages) ? body.messages : [];
        if (messages.length === 0) {
          return json({ error: "No messages" }, 400);
        }

        // Truncate to last ~20 turns to stay within sensible context.
        const trimmed = messages.slice(-20).map((m) => ({
          role: m.role === "assistant" ? "assistant" : "user",
          content: String(m.content ?? "").slice(0, 4000),
        }));

        const payload = {
          model: "google/gemini-3-flash-preview",
          messages: [
            ...(body.system
              ? [{ role: "system", content: body.system }]
              : []),
            ...trimmed,
          ],
          max_tokens: Math.min(Math.max(body.max_tokens ?? 250, 50), 600),
        };

        try {
          const r = await fetch(
            "https://ai.gateway.lovable.dev/v1/chat/completions",
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${apiKey}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify(payload),
            },
          );

          if (!r.ok) {
            const t = await r.text();
            console.error("[jayla] gateway error", r.status, t);
            if (r.status === 429)
              return json({ error: "Busy — try again in a sec." }, 429);
            if (r.status === 402)
              return json({ error: "AI credits exhausted." }, 402);
            return json({ error: "AI gateway error" }, 502);
          }

          const data = (await r.json()) as {
            choices?: Array<{ message?: { content?: string } }>;
          };
          const text =
            data.choices?.[0]?.message?.content?.trim() ||
            "Try me again, babe!";

          // Return in the shape the existing widget expects.
          return json({ content: [{ text }] });
        } catch (err) {
          console.error("[jayla] fetch failed", err);
          return json({ error: "Network error" }, 500);
        }
      },
    },
  },
});
