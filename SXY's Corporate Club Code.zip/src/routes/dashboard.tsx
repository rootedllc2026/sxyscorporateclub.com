import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { SxyButton } from "@/components/sxy/SxyButton";
import { SxyCard } from "@/components/sxy/SxyCard";
import { Tag } from "@/components/sxy/Tag";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [{ title: "Dashboard — SXY's Corporate Club" }],
  }),
  component: DashboardRoute,
});

function DashboardRoute() {
  return (
    <AppLayout
      title="Dashboard"
      actions={
        <>
          <SxyButton variant="outline" size="sm" asChild>
            <Link to="/kiddos/hub">🧒 Kiddos App</Link>
          </SxyButton>
          <SxyButton variant="gold" size="sm">+ Post Project</SxyButton>
        </>
      }
    >
      <DashboardContent />
    </AppLayout>
  );
}

/** Format a date as "in 3 days" / "2 hours ago" — short, friendly. */
function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const abs = Math.abs(diff);
  const minute = 60_000;
  const hour = 60 * minute;
  const day = 24 * hour;
  const future = diff < 0;
  const value =
    abs < hour
      ? `${Math.max(1, Math.round(abs / minute))}m`
      : abs < day
        ? `${Math.round(abs / hour)}h`
        : `${Math.round(abs / day)}d`;
  return future ? `in ${value}` : `${value} ago`;
}

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

function DashboardContent() {
  const { currentUser, userProfile } = useAuth();
  const userId = currentUser?.id;

  const firstName = React.useMemo(() => {
    const full = userProfile?.full_name?.trim();
    if (full) return full.split(/\s+/)[0];
    return currentUser?.email?.split("@")[0] ?? "Member";
  }, [userProfile, currentUser]);

  // ---- Live counts (one round-trip each, head:true means no rows returned) ---
  const { data: stats } = useQuery({
    queryKey: ["dashboard", "stats", userId],
    enabled: !!userId,
    queryFn: async () => {
      const [activeBidsRes, earningsRes, postsRes, videosRes, eventsRes, pendingReferralRes] =
        await Promise.all([
          supabase
            .from("bids")
            .select("id", { count: "exact", head: true })
            .eq("bidder_id", userId!)
            .in("status", ["submitted", "shortlisted"]),
          supabase
            .from("transactions")
            .select("amount")
            .eq("user_id", userId!)
            .eq("txn_type", "referral"),
          supabase
            .from("messages")
            .select("id", { count: "exact", head: true })
            .eq("sender_id", userId!),
          supabase
            .from("video_progress")
            .select("id", { count: "exact", head: true })
            .eq("user_id", userId!)
            .eq("completed", true),
          supabase
            .from("events")
            .select("id", { count: "exact", head: true })
            .gt("starts_at", new Date().toISOString()),
          supabase
            .from("transactions")
            .select("id", { count: "exact", head: true })
            .eq("user_id", userId!)
            .eq("txn_type", "referral")
            .is("reference_id", null),
        ]);
      const referralEarnings = (earningsRes.data ?? []).reduce(
        (sum, row: { amount: number | string }) =>
          sum + Number(row.amount ?? 0),
        0,
      );
      return {
        activeBids: activeBidsRes.count ?? 0,
        referralEarnings,
        communityPosts: postsRes.count ?? 0,
        videosWatched: videosRes.count ?? 0,
        upcomingEvents: eventsRes.count ?? 0,
        pendingReferrals: pendingReferralRes.count ?? 0,
      };
    },
  });

  // ---- Recent activity: last 5 bids + last 5 transactions, merged ----------
  const { data: activity } = useQuery({
    queryKey: ["dashboard", "activity", userId],
    enabled: !!userId,
    queryFn: async () => {
      const [bidsRes, txnRes] = await Promise.all([
        supabase
          .from("bids")
          .select("id, status, created_at, project_id, projects(title)")
          .eq("bidder_id", userId!)
          .order("created_at", { ascending: false })
          .limit(5),
        supabase
          .from("transactions")
          .select("id, amount, txn_type, description, created_at")
          .eq("user_id", userId!)
          .order("created_at", { ascending: false })
          .limit(5),
      ]);

      type Item = {
        id: string;
        kind: "bid" | "earning";
        label: string;
        when: string;
      };
      const bids: Item[] = (bidsRes.data ?? []).map((b: any) => ({
        id: `bid-${b.id}`,
        kind: "bid",
        label: `Bid ${b.status} on ${b.projects?.title ?? "a project"}`,
        when: b.created_at,
      }));
      const txns: Item[] = (txnRes.data ?? []).map((t: any) => ({
        id: `txn-${t.id}`,
        kind: "earning",
        label:
          t.description ??
          `${currency.format(Number(t.amount ?? 0))} ${t.txn_type.replace("_", " ")}`,
        when: t.created_at,
      }));
      return [...bids, ...txns]
        .sort((a, b) => +new Date(b.when) - +new Date(a.when))
        .slice(0, 5);
    },
  });

  // ---- Upcoming events visible to the member ------------------------------
  const { data: upcoming } = useQuery({
    queryKey: ["dashboard", "events", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data } = await supabase
        .from("events")
        .select("id, title, starts_at, location, access_level")
        .gt("starts_at", new Date().toISOString())
        .order("starts_at", { ascending: true })
        .limit(3);
      return data ?? [];
    },
  });

  return (
    <div className="space-y-8">
      {/* Welcome banner */}
      <section
        className="overflow-hidden rounded-2xl border border-border-teal/60 p-8"
        style={{
          backgroundImage:
            "linear-gradient(135deg, var(--teal-deep), var(--charcoal-soft) 75%)",
        }}
      >
        <p className="font-editorial text-2xl text-text-primary">
          Welcome back, {firstName} 👋
        </p>
        <p className="mt-2 max-w-2xl text-sm text-text-muted">
          You have{" "}
          <span className="font-semibold text-teal-light">
            {stats?.activeBids ?? 0}
          </span>{" "}
          active bid{stats?.activeBids === 1 ? "" : "s"},{" "}
          <span className="font-semibold text-gold-light">
            {stats?.pendingReferrals ?? 0}
          </span>{" "}
          pending referral approval
          {stats?.pendingReferrals === 1 ? "" : "s"}, and{" "}
          <span className="font-semibold text-teal-light">
            {stats?.upcomingEvents ?? 0}
          </span>{" "}
          upcoming event{stats?.upcomingEvents === 1 ? "" : "s"}.
        </p>
        <div className="mt-5 flex flex-wrap gap-3">
          <Link to="/kiddos/hub">
            <SxyButton variant="outline" size="sm">
              🧒 Open Kiddos App
            </SxyButton>
          </Link>
          <Link to="/referrals">
            <SxyButton variant="gold" size="sm">
              Book a Strategy Session with Skyler →
            </SxyButton>
          </Link>
        </div>
      </section>

      {/* Book a Strategy Session — prominent CTA card visible to every member */}
      <section
        className="overflow-hidden rounded-2xl border border-gold/40 p-6 sm:p-8"
        style={{
          backgroundImage:
            "linear-gradient(135deg, color-mix(in oklab, var(--gold) 14%, var(--charcoal-soft)), var(--charcoal-soft) 70%)",
        }}
      >
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="max-w-2xl">
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-gold-light">
              Members benefit
            </p>
            <h2 className="mt-2 font-editorial text-2xl text-text-primary sm:text-3xl">
              Book a Strategy Session
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-text-muted">
              Work directly with one of our premier strategists on general
              business strategy, entity formation, AI integration, media and
              content management, competitive market analysis, or marketing
              strategy.
            </p>
          </div>
          <div className="shrink-0">
            <Link
              to="/referrals"
              search={{ category: "strategy", q: "" }}
              hash="skylers-business-consulting"
            >
              <SxyButton variant="gold">Book Now →</SxyButton>
            </Link>
          </div>
        </div>
      </section>

      {/* 4-column stat grid */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Active Bids"
          value={String(stats?.activeBids ?? 0)}
          tone="teal"
        />
        <StatCard
          label="Referral Earnings"
          value={currency.format(stats?.referralEarnings ?? 0)}
          tone="gold"
        />
        <StatCard
          label="Community Posts"
          value={String(stats?.communityPosts ?? 0)}
          tone="teal"
        />
        <StatCard
          label="Videos Watched"
          value={String(stats?.videosWatched ?? 0)}
          tone="teal"
        />
      </section>

      {/* Two-column row */}
      <section className="grid gap-6 lg:grid-cols-2">
        <SxyCard accent>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg text-teal-light">
              Recent activity
            </h2>
            <Tag variant="gray">Last 5</Tag>
          </div>
          <ul className="mt-4 divide-y divide-border-base/40">
            {activity && activity.length > 0 ? (
              activity.map((item) => (
                <li
                  key={item.id}
                  className="flex items-start gap-3 py-3 text-sm"
                >
                  <span
                    aria-hidden
                    className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${
                      item.kind === "bid" ? "bg-teal-mid" : "bg-gold"
                    }`}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-text-primary">{item.label}</p>
                    <p className="text-xs text-text-dim">
                      {timeAgo(item.when)}
                    </p>
                  </div>
                </li>
              ))
            ) : (
              <li className="py-8 text-center text-sm text-text-dim">
                No activity yet — submit your first bid to get started.
              </li>
            )}
          </ul>
        </SxyCard>

        <SxyCard accent>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg text-teal-light">
              Upcoming events
            </h2>
            <Link
              to="/events"
              className="text-xs font-semibold uppercase tracking-wider text-gold hover:text-gold-light"
            >
              View all →
            </Link>
          </div>
          <ul className="mt-4 space-y-4">
            {upcoming && upcoming.length > 0 ? (
              upcoming.map((event) => (
                <li
                  key={event.id}
                  className="flex items-center justify-between gap-4 rounded-xl border border-border-base/60 p-3"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-text-primary">
                      {event.title}
                    </p>
                    <p className="text-xs text-text-dim">
                      {new Date(event.starts_at).toLocaleString(undefined, {
                        weekday: "short",
                        month: "short",
                        day: "numeric",
                        hour: "numeric",
                        minute: "2-digit",
                      })}
                      {event.location ? ` · ${event.location}` : ""}
                    </p>
                  </div>
                  <SxyButton variant="outline" size="sm">
                    Register
                  </SxyButton>
                </li>
              ))
            ) : (
              <li className="rounded-xl border border-dashed border-border-base/60 p-6 text-center text-sm text-text-dim">
                No upcoming events scheduled.
              </li>
            )}
          </ul>
        </SxyCard>
      </section>
    </div>
  );
}

function StatCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "teal" | "gold";
}) {
  return (
    <div className="rounded-2xl border border-border-base/60 bg-charcoal-card p-5 transition-colors hover:border-border-teal">
      <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim">
        {label}
      </p>
      <p
        className={`mt-2 font-display text-3xl ${
          tone === "gold" ? "text-gold-light" : "text-teal-light"
        }`}
      >
        {value}
      </p>
    </div>
  );
}
