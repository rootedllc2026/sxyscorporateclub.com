import * as React from "react";
import { toast } from "sonner";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Tag } from "@/components/sxy/Tag";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  formatDate,
  formatMoney,
  statusTone,
  txnTypeLabel,
  txnTypeTone,
  type TransactionRow,
} from "@/lib/financials/shared";

/**
 * Shows the full breakdown of a single transaction. Admins see a "Refund"
 * button for completed referral / consulting / bid_award / membership txns.
 * Refunding inserts a paired refund txn referencing the original and stamps
 * the original with refunded_at + refunded_by + refund_txn_id.
 */
export function TransactionDetailModal({
  txn,
  onClose,
}: {
  txn: TransactionRow | null;
  onClose: () => void;
}) {
  const { isAdmin, currentUser } = useAuth();
  const qc = useQueryClient();
  const [refundOpen, setRefundOpen] = React.useState(false);
  const [reason, setReason] = React.useState("");

  React.useEffect(() => {
    if (!txn) {
      setRefundOpen(false);
      setReason("");
    }
  }, [txn]);

  const refund = useMutation({
    mutationFn: async () => {
      if (!txn || !currentUser) throw new Error("Missing context");
      const gross = Number(txn.gross_amount ?? txn.amount ?? 0);
      const fee = Number(txn.fee_amount ?? 0);
      const net = Number(txn.net_amount ?? gross - fee);

      // 1) Insert paired refund row.
      const { data: refundRow, error: insErr } = await supabase
        .from("transactions")
        .insert({
          user_id: txn.user_id,
          txn_type: "refund",
          amount: -Math.abs(net),
          gross_amount: -Math.abs(gross),
          fee_amount: -Math.abs(fee),
          net_amount: -Math.abs(net),
          description: `Refund of ${txn.description ?? txn.id.slice(0, 8)}`,
          source: txn.source,
          status: "completed",
          reference_id: txn.id,
          refund_reason: reason || null,
          refunded_by: currentUser.id,
          refunded_at: new Date().toISOString(),
        })
        .select("id")
        .single();
      if (insErr) throw insErr;

      // 2) Stamp original.
      const { error: updErr } = await supabase
        .from("transactions")
        .update({
          status: "refunded",
          refunded_at: new Date().toISOString(),
          refunded_by: currentUser.id,
          refund_reason: reason || null,
          refund_txn_id: refundRow.id,
        })
        .eq("id", txn.id);
      if (updErr) throw updErr;
    },
    onSuccess: () => {
      toast.success("Refund issued.");
      qc.invalidateQueries({ queryKey: ["financials"] });
      setRefundOpen(false);
      onClose();
    },
    onError: (e: Error) => toast.error(`Refund failed: ${e.message}`),
  });

  const canRefund =
    !!txn &&
    isAdmin &&
    !txn.refunded_at &&
    txn.status !== "refunded" &&
    txn.txn_type !== "refund" &&
    txn.txn_type !== "payout";

  return (
    <Dialog open={!!txn} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="border-border-teal/40 bg-charcoal-card text-text-primary sm:max-w-md">
        {txn ? (
          <>
            <DialogHeader>
              <DialogTitle className="font-display text-xl text-teal-light">
                Transaction details
              </DialogTitle>
            </DialogHeader>

            <dl className="space-y-3 text-sm">
              <Row label="Date" value={formatDate(txn.created_at)} />
              <Row
                label="Type"
                value={
                  <Tag variant={txnTypeTone(txn.txn_type)}>
                    {txnTypeLabel(txn.txn_type)}
                  </Tag>
                }
              />
              <Row
                label="Status"
                value={<Tag variant={statusTone(txn.status)}>{txn.status}</Tag>}
              />
              <Row label="Description" value={txn.description ?? "—"} />
              <Row label="Source" value={txn.source ?? "—"} />
              <hr className="border-border-base/40" />
              <Row
                label="Gross"
                value={formatMoney(txn.gross_amount ?? txn.amount)}
              />
              <Row
                label="Platform fee"
                value={`− ${formatMoney(txn.fee_amount ?? 0)}`}
              />
              <Row
                label="Net"
                valueClass="font-semibold text-gold"
                value={formatMoney(
                  txn.net_amount ??
                    Number(txn.gross_amount ?? txn.amount ?? 0) -
                      Number(txn.fee_amount ?? 0),
                )}
              />
              {txn.stripe_payment_intent_id ? (
                <Row
                  label="Stripe PI"
                  value={
                    <code className="break-all text-[11px] text-text-muted">
                      {txn.stripe_payment_intent_id}
                    </code>
                  }
                />
              ) : null}
              {txn.refunded_at ? (
                <>
                  <hr className="border-border-base/40" />
                  <Row
                    label="Refunded"
                    value={formatDate(txn.refunded_at)}
                  />
                  {txn.refund_reason ? (
                    <Row label="Reason" value={txn.refund_reason} />
                  ) : null}
                </>
              ) : null}
            </dl>

            {refundOpen ? (
              <div className="space-y-2 rounded-lg border border-danger/40 bg-danger/5 p-3">
                <Label htmlFor="refund-reason" className="text-danger">
                  Refund reason
                </Label>
                <Textarea
                  id="refund-reason"
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Briefly describe why this is being refunded…"
                />
                <div className="flex justify-end gap-2">
                  <SxyButton
                    variant="ghost"
                    size="sm"
                    onClick={() => setRefundOpen(false)}
                    disabled={refund.isPending}
                  >
                    Cancel
                  </SxyButton>
                  <SxyButton
                    variant="primary"
                    size="sm"
                    onClick={() => refund.mutate()}
                    disabled={refund.isPending}
                  >
                    {refund.isPending ? "Refunding…" : "Confirm refund"}
                  </SxyButton>
                </div>
              </div>
            ) : null}

            <DialogFooter className="gap-2 sm:justify-between">
              <div className="flex gap-2">
                {canRefund && !refundOpen ? (
                  <SxyButton
                    variant="ghost"
                    size="sm"
                    onClick={() => setRefundOpen(true)}
                  >
                    Issue refund
                  </SxyButton>
                ) : null}
              </div>
              <div className="flex gap-2">
                <SxyButton variant="outline" size="sm" onClick={onClose}>
                  Close
                </SxyButton>
                <SxyButton
                  variant="primary"
                  size="sm"
                  onClick={() => window.print()}
                >
                  Print receipt
                </SxyButton>
              </div>
            </DialogFooter>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function Row({
  label,
  value,
  valueClass,
}: {
  label: string;
  value: React.ReactNode;
  valueClass?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="text-xs uppercase tracking-wider text-text-dim">
        {label}
      </dt>
      <dd className={valueClass ?? "text-right text-text-primary"}>{value}</dd>
    </div>
  );
}
