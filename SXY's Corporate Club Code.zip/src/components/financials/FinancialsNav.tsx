import { Link, useLocation } from "@tanstack/react-router";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { cn } from "@/lib/utils";

/**
 * Sub-navigation for /financials/*. Member tabs always visible; Admin tabs
 * appended for users with the admin role.
 */
const memberTabs = [
  { to: "/financials", label: "My Overview" },
  { to: "/financials/transactions", label: "Transactions" },
  { to: "/financials/referral", label: "Referral Earnings" },
  { to: "/financials/membership", label: "Membership" },
  { to: "/financials/invoices", label: "Invoices" },
] as const;

const adminTabs = [
  { to: "/financials/admin/platform", label: "Platform Revenue" },
  { to: "/financials/admin/members", label: "Member Financials" },
  { to: "/financials/admin/payouts", label: "Payout Queue" },
  { to: "/financials/admin/invoices", label: "All Invoices" },
  { to: "/financials/admin/settings", label: "Fee Settings" },
] as const;

export function FinancialsNav() {
  const { isAdmin } = useAuth();
  const location = useLocation();
  const tabs = isAdmin ? [...memberTabs, ...adminTabs] : memberTabs;

  return (
    <nav className="-mx-2 flex flex-wrap gap-1 border-b border-border-base/40 px-2 pb-2">
      {tabs.map((t) => {
        const isActive =
          location.pathname === t.to ||
          (t.to !== "/financials" && location.pathname.startsWith(t.to));
        return (
          <Link
            key={t.to}
            to={t.to as string}
            className={cn(
              "rounded-full border border-transparent px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-text-muted transition-colors hover:text-teal-light",
              isActive &&
                "border-border-teal bg-[color:var(--teal-glow)] text-teal-light",
            )}
          >
            {t.label}
          </Link>
        );
      })}
    </nav>
  );
}
