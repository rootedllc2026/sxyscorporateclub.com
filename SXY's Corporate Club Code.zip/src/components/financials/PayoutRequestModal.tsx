import * as React from "react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SxyButton } from "@/components/sxy/SxyButton";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { formatMoney } from "@/lib/financials/shared";
import { notifyByEmail } from "@/lib/financials/notify";
import { useQueryClient } from "@tanstack/react-query";
import { usePayoutMethods } from "./SavedPayoutMethods";

/**
 * Shared payout request modal. Reads available_balance from the current user's
 * profile, lets them request a payout, inserts into public.payouts with
 * status='requested'. Pre-fills with the user's default saved method when one
 * exists. Admin approval flow lives in /financials/admin/payouts.
 */
export function PayoutRequestModal({
  open,
  onOpenChange,
  availableBalance,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  availableBalance: number;
}) {
  const { currentUser } = useAuth();
  const qc = useQueryClient();
  const { data: savedMethods = [] } = usePayoutMethods();
  const [savedId, setSavedId] = React.useState<string>("");
  const [amount, setAmount] = React.useState("");
  const [method, setMethod] = React.useState("stripe");
  const [destination, setDestination] = React.useState("");
  const [note, setNote] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  // Pre-fill from default saved method when modal opens.
  React.useEffect(() => {
    if (!open) {
      setAmount("");
      setMethod("stripe");
      setDestination("");
      setNote("");
      setSavedId("");
      return;
    }
    const def = savedMethods.find((m) => m.is_default) ?? savedMethods[0];
    if (def) {
      setSavedId(def.id);
      setMethod(def.method);
      setDestination(def.destination);
    }
  }, [open, savedMethods]);

  function pickSaved(id: string) {
    setSavedId(id);
    if (id === "_manual") {
      setDestination("");
      return;
    }
    const m = savedMethods.find((x) => x.id === id);
    if (m) {
      setMethod(m.method);
      setDestination(m.destination);
    }
  }

  async function submit() {
    if (!currentUser) return;
    const n = Number(amount);
    if (!n || n <= 0) {
      toast.error("Enter a payout amount greater than zero.");
      return;
    }
    if (n > availableBalance) {
      toast.error("Amount exceeds your available balance.");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("payouts").insert({
      user_id: currentUser.id,
      amount: n,
      method,
      destination: destination || null,
      notes: note || null,
      status: "requested",
    });
    setSubmitting(false);
    if (error) {
      toast.error(`Couldn't request payout: ${error.message}`);
      return;
    }
    toast.success("Payout request submitted for review.");
    qc.invalidateQueries({ queryKey: ["financials"] });
    onOpenChange(false);

    // Best-effort admin notification — never blocks success.
    void (async () => {
      const { data: settings } = await supabase
        .from("platform_settings")
        .select("notify_on_new_request, admin_notification_emails")
        .eq("id", 1)
        .maybeSingle();
      if (
        !settings?.notify_on_new_request ||
        !settings.admin_notification_emails?.length
      ) {
        return;
      }
      const memberLabel =
        currentUser.user_metadata?.full_name ||
        currentUser.email ||
        "A member";
      await notifyByEmail({
        to: settings.admin_notification_emails,
        subject: `New payout request — ${formatMoney(n)}`,
        body: [
          `${memberLabel} submitted a new payout request.`,
          ``,
          `Amount: ${formatMoney(n)}`,
          `Method: ${method}`,
          destination ? `Destination: ${destination}` : null,
          note ? `Note: ${note}` : null,
          ``,
          `Review it in Admin → Payout Queue.`,
        ]
          .filter(Boolean)
          .join("\n"),
        toastOnError: false,
      });
    })();
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border-teal/40 bg-charcoal-card text-text-primary sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-teal-light">
            Request a payout
          </DialogTitle>
          <DialogDescription>
            Available balance:{" "}
            <span className="font-semibold text-gold">
              {formatMoney(availableBalance)}
            </span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="payout-amount">Amount</Label>
            <Input
              id="payout-amount"
              type="number"
              step="0.01"
              min="0"
              max={availableBalance}
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>

          {savedMethods.length > 0 ? (
            <div className="space-y-1.5">
              <Label>Saved method</Label>
              <Select value={savedId} onValueChange={pickSaved}>
                <SelectTrigger>
                  <SelectValue placeholder="Pick a saved method" />
                </SelectTrigger>
                <SelectContent>
                  {savedMethods.map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.label} — {m.destination}
                    </SelectItem>
                  ))}
                  <SelectItem value="_manual">Enter manually…</SelectItem>
                </SelectContent>
              </Select>
            </div>
          ) : null}

          <div className="space-y-1.5">
            <Label>Method</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stripe">Stripe (instant)</SelectItem>
                <SelectItem value="bank">Bank transfer (ACH)</SelectItem>
                <SelectItem value="paypal">PayPal</SelectItem>
                <SelectItem value="wire">Wire transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="payout-dest">Destination (last 4 / email)</Label>
            <Input
              id="payout-dest"
              placeholder="e.g. •••• 4242 or you@email.com"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="payout-note">Note (optional)</Label>
            <Textarea
              id="payout-note"
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <SxyButton
            variant="outline"
            size="sm"
            onClick={() => onOpenChange(false)}
            type="button"
          >
            Cancel
          </SxyButton>
          <SxyButton
            variant="gold"
            size="sm"
            onClick={submit}
            disabled={submitting}
            type="button"
          >
            {submitting ? "Submitting…" : "Submit request"}
          </SxyButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
