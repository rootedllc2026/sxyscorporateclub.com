/**
 * SavedPayoutMethods — small CRUD card for /financials and the request modal.
 * Members can save reusable destinations (Stripe, ACH, PayPal, wire) and
 * mark one as default. RLS scopes everything to the current user.
 */
import * as React from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2, Star } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Tag } from "@/components/sxy/Tag";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  type PayoutMethodKind,
  type PayoutMethodRow,
} from "@/lib/financials/shared";

const METHOD_LABEL: Record<PayoutMethodKind, string> = {
  stripe: "Stripe",
  bank: "Bank (ACH)",
  paypal: "PayPal",
  wire: "Wire transfer",
};

export function usePayoutMethods() {
  const { currentUser } = useAuth();
  return useQuery({
    queryKey: ["financials", "payoutMethods", currentUser?.id],
    enabled: !!currentUser,
    queryFn: async () => {
      const { data } = await supabase
        .from("payout_methods")
        .select("*")
        .eq("user_id", currentUser!.id)
        .order("is_default", { ascending: false })
        .order("created_at", { ascending: false });
      return (data ?? []) as PayoutMethodRow[];
    },
  });
}

export function SavedPayoutMethods() {
  const { data: methods = [], isLoading } = usePayoutMethods();
  const [open, setOpen] = React.useState(false);
  const qc = useQueryClient();

  const setDefault = useMutation({
    mutationFn: async (id: string) => {
      // Clear current default first to satisfy unique-default constraint.
      await supabase
        .from("payout_methods")
        .update({ is_default: false })
        .eq("is_default", true);
      const { error } = await supabase
        .from("payout_methods")
        .update({ is_default: true })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Default payout method updated.");
      qc.invalidateQueries({ queryKey: ["financials", "payoutMethods"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("payout_methods")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Payout method removed.");
      qc.invalidateQueries({ queryKey: ["financials", "payoutMethods"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <SxyCard accent>
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg text-teal-light">
          Saved payout methods
        </h2>
        <SxyButton variant="outline" size="sm" onClick={() => setOpen(true)}>
          Add method
        </SxyButton>
      </div>
      <p className="mt-1 text-xs text-text-muted">
        Reusable destinations for payout requests. Mark one as default to
        pre-fill the request form.
      </p>

      <div className="mt-4 space-y-2">
        {isLoading ? (
          <p className="py-4 text-center text-sm text-text-dim">Loading…</p>
        ) : methods.length === 0 ? (
          <p className="rounded-lg border border-dashed border-border-base/40 p-6 text-center text-sm text-text-dim">
            No saved methods yet. Add one to speed up future requests.
          </p>
        ) : (
          methods.map((m) => (
            <div
              key={m.id}
              className="flex flex-wrap items-center gap-3 rounded-lg border border-border-base/40 bg-charcoal-soft/40 p-3"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-text-primary">{m.label}</p>
                  {m.is_default ? (
                    <Tag variant="gold">Default</Tag>
                  ) : null}
                </div>
                <p className="text-xs text-text-muted">
                  {METHOD_LABEL[m.method]} · {m.destination}
                </p>
              </div>
              {!m.is_default ? (
                <button
                  type="button"
                  onClick={() => setDefault.mutate(m.id)}
                  className="rounded-md p-1.5 text-text-dim hover:text-gold"
                  title="Set default"
                >
                  <Star className="h-4 w-4" />
                </button>
              ) : null}
              <button
                type="button"
                onClick={() => remove.mutate(m.id)}
                className="rounded-md p-1.5 text-text-dim hover:text-danger"
                title="Remove"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))
        )}
      </div>

      <AddPayoutMethodModal open={open} onOpenChange={setOpen} />
    </SxyCard>
  );
}

function AddPayoutMethodModal({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { currentUser } = useAuth();
  const qc = useQueryClient();
  const [label, setLabel] = React.useState("");
  const [method, setMethod] = React.useState<PayoutMethodKind>("stripe");
  const [destination, setDestination] = React.useState("");
  const [isDefault, setIsDefault] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  React.useEffect(() => {
    if (!open) {
      setLabel("");
      setMethod("stripe");
      setDestination("");
      setIsDefault(false);
    }
  }, [open]);

  async function submit() {
    if (!currentUser) return;
    if (!label.trim() || !destination.trim()) {
      toast.error("Label and destination are required.");
      return;
    }
    setSubmitting(true);
    if (isDefault) {
      // Clear existing default first.
      await supabase
        .from("payout_methods")
        .update({ is_default: false })
        .eq("user_id", currentUser.id)
        .eq("is_default", true);
    }
    const { error } = await supabase.from("payout_methods").insert({
      user_id: currentUser.id,
      label: label.trim(),
      method,
      destination: destination.trim(),
      is_default: isDefault,
    });
    setSubmitting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Payout method saved.");
    qc.invalidateQueries({ queryKey: ["financials", "payoutMethods"] });
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border-teal/40 bg-charcoal-card text-text-primary sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-teal-light">
            Save payout method
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="pm-label">Label</Label>
            <Input
              id="pm-label"
              placeholder="e.g. Personal Chase"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Method</Label>
            <Select
              value={method}
              onValueChange={(v) => setMethod(v as PayoutMethodKind)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stripe">Stripe</SelectItem>
                <SelectItem value="bank">Bank (ACH)</SelectItem>
                <SelectItem value="paypal">PayPal</SelectItem>
                <SelectItem value="wire">Wire transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pm-dest">Destination</Label>
            <Input
              id="pm-dest"
              placeholder="•••• 4242 / you@email.com / IBAN…"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border-base/40 bg-charcoal-soft/40 p-3">
            <div>
              <p className="text-sm font-medium text-text-primary">
                Set as default
              </p>
              <p className="text-xs text-text-muted">
                Pre-fills the request form with this method.
              </p>
            </div>
            <Switch checked={isDefault} onCheckedChange={setIsDefault} />
          </div>
        </div>
        <DialogFooter>
          <SxyButton
            variant="outline"
            size="sm"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            Cancel
          </SxyButton>
          <SxyButton
            variant="gold"
            size="sm"
            onClick={submit}
            disabled={submitting}
          >
            {submitting ? "Saving…" : "Save method"}
          </SxyButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
