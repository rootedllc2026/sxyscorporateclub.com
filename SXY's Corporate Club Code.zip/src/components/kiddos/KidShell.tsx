import * as React from "react";
import { Link, useRouterState } from "@tanstack/react-router";

const NAV = [
  { to: "/kiddos/hub", label: "Hub", icon: "🏠" },
  { to: "/kiddos/money", label: "Money", icon: "💰" },
  { to: "/kiddos/videos", label: "Learn", icon: "🎬" },
  { to: "/kiddos/directory", label: "Trade", icon: "🛍️" },
  { to: "/kiddos/games", label: "Games", icon: "🎮" },
  { to: "/kiddos/parent", label: "Parent", icon: "👤" },
] as const;

/**
 * Kid-safe shell: light, rounded, big touch targets, bottom nav on mobile.
 * Wraps every /kiddos/* route so the brand and a11y rules stay consistent.
 */
export function KidShell({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="kid-shell">
      <header className="px-4 sm:px-8 py-5 flex items-center justify-between max-w-5xl mx-auto">
        <Link to="/kiddos/hub" className="flex items-center gap-2">
          <span aria-hidden className="text-2xl">✨</span>
          <span className="font-semibold text-[var(--kid-teal)]">
            SXY's Corporate Kiddos
          </span>
        </Link>
        <Link to="/" className="kid-btn kid-btn-ghost" style={{ minHeight: 40, padding: "0.5rem 1rem" }}>
          ← Adult mode
        </Link>
      </header>

      <main className="px-4 sm:px-8 pb-32 max-w-5xl mx-auto">
        <h1 className="text-3xl sm:text-4xl mb-6">{title}</h1>
        {children}
      </main>

      <nav
        aria-label="Kiddos main"
        className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur border-t border-[rgba(10,92,107,0.1)] py-2 px-2"
        style={{ paddingBottom: "calc(0.5rem + env(safe-area-inset-bottom))" }}
      >
        <ul className="flex justify-around max-w-5xl mx-auto">
          {NAV.map((item) => {
            const active = pathname === item.to;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className="flex flex-col items-center justify-center px-3"
                  style={{
                    minHeight: 48,
                    minWidth: 48,
                    color: active ? "var(--kid-teal)" : "var(--kid-ink-muted)",
                    fontWeight: active ? 700 : 500,
                  }}
                >
                  <span aria-hidden className="text-xl">{item.icon}</span>
                  <span className="text-xs mt-1">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
