import creditImg from "@/assets/kiddos-credits.png.asset.json";

/**
 * Inline credit chip — uses the C4K coin/note artwork as the unit icon so
 * "credits" feel like a tangible currency throughout the app.
 */
export function CreditBadge({
  amount,
  size = 22,
  blur = false,
  className = "",
}: {
  amount: number | string;
  size?: number;
  blur?: boolean;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 align-middle ${className}`}
      style={{ fontFamily: "var(--font-kid-money)", fontWeight: 600 }}
    >
      <img
        src={creditImg.url}
        alt=""
        aria-hidden
        width={size}
        height={size}
        style={{ width: size, height: size, objectFit: "cover", borderRadius: "50%" }}
      />
      <span className={blur ? "kid-money-blur" : ""}>{amount}</span>
    </span>
  );
}

export const CREDIT_IMAGE_URL = creditImg.url;
