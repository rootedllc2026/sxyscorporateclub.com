import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Circular avatar with initials. Background is a soft brand gradient picked by
 * `colorKey` (mirrors profile.avatar_color so each member gets a stable look).
 */

const gradients: Record<string, string> = {
  teal: "linear-gradient(135deg, var(--teal-deep), var(--teal-mid))",
  gold: "linear-gradient(135deg, var(--gold), var(--gold-light))",
  plum: "linear-gradient(135deg, oklch(0.45 0.12 320), oklch(0.65 0.14 330))",
  emerald:
    "linear-gradient(135deg, oklch(0.5 0.12 160), oklch(0.7 0.14 155))",
  sunset:
    "linear-gradient(135deg, oklch(0.62 0.16 35), oklch(0.78 0.14 60))",
};

export const AVATAR_COLORS = Object.keys(gradients) as Array<
  keyof typeof gradients
>;

export interface AvatarBadgeProps {
  name?: string | null;
  email?: string | null;
  colorKey?: string | null;
  size?: number;
  className?: string;
}

function getInitials(name?: string | null, email?: string | null) {
  const source = (name?.trim() || email?.split("@")[0] || "M").trim();
  const parts = source.split(/\s+/).filter(Boolean);
  const first = parts[0]?.[0] ?? "M";
  const second = parts[1]?.[0] ?? "";
  return (first + second).toUpperCase();
}

export function AvatarBadge({
  name,
  email,
  colorKey,
  size = 80,
  className,
}: AvatarBadgeProps) {
  const initials = getInitials(name, email);
  const gradient = gradients[colorKey ?? "teal"] ?? gradients.teal;
  return (
    <div
      className={cn(
        "grid place-items-center rounded-full font-display text-text-primary shadow-[var(--shadow-card)] ring-2 ring-border-teal",
        className,
      )}
      style={{
        width: size,
        height: size,
        backgroundImage: gradient,
        fontSize: size * 0.36,
      }}
      aria-label={name ?? email ?? "Member avatar"}
    >
      {initials}
    </div>
  );
}
