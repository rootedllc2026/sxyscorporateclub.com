import * as React from "react";
import { ProtectedRoute } from "@/integrations/supabase/ProtectedRoute";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { AppTopbar, type AppTopbarProps } from "@/components/layout/AppTopbar";
import { MobileBottomNav } from "@/components/layout/MobileBottomNav";

/**
 * Authenticated app shell — gates the route on auth, renders the persistent
 * left sidebar + page topbar, and slots the page body in the right column.
 *
 * QueryClientProvider lives at the root route (src/routes/__root.tsx) so all
 * routes share a single cache regardless of layout.
 */

export interface AppLayoutProps extends AppTopbarProps {
  children: React.ReactNode;
}

export function AppLayout({ title, actions, children }: AppLayoutProps) {
  return (
    <ProtectedRoute>
      <div className="flex min-h-screen w-full bg-charcoal text-text-primary">
        <AppSidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <AppTopbar title={title} actions={actions} />
          <main className="flex-1 px-4 pb-24 pt-6 sm:px-6 sm:py-8 lg:px-10 lg:py-10 md:pb-8">
            {children}
          </main>
        </div>
        <MobileBottomNav />
      </div>
    </ProtectedRoute>
  );
}
