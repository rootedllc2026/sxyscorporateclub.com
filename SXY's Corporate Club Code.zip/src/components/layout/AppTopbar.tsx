import * as React from "react";
import { Link } from "@tanstack/react-router";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { SxyButton } from "@/components/sxy/SxyButton";

/**
 * Page topbar. The page title is supplied by each route; on the right we always
 * show the notification dot + admin / global actions. Slots are kept loose so
 * individual pages can drop in their own action buttons (e.g. "+ Post Project"
 * on the dashboard).
 */
export interface AppTopbarProps {
  title: string;
  actions?: React.ReactNode;
}

export function AppTopbar({ title, actions }: AppTopbarProps) {
  const { isAdmin, signOut, currentUser } = useAuth();

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border-base/60 bg-charcoal-soft/95 px-6 backdrop-blur">
      <h1 className="font-display text-xl text-text-primary">{title}</h1>

      <div className="flex items-center gap-3">
        {/* Notification bell with unread dot */}
        <button
          type="button"
          aria-label="Notifications"
          className="relative grid h-9 w-9 place-items-center rounded-full border border-border-base/60 text-text-muted transition-colors hover:border-border-teal hover:text-teal-light"
        >
          <span aria-hidden className="text-base">
            🔔
          </span>
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-gold ring-2 ring-charcoal-soft" />
        </button>

        {isAdmin ? (
          <SxyButton variant="outline" size="sm">
            Admin View
          </SxyButton>
        ) : null}

        <SxyButton variant="gold" size="sm" asChild>
          <Link to="/kiddos/hub">🧒 Kiddos App</Link>
        </SxyButton>

        {actions}

        <span className="hidden text-xs text-text-dim sm:inline">
          {currentUser?.email}
        </span>

        <SxyButton variant="ghost" size="sm" onClick={signOut}>
          Sign out
        </SxyButton>
      </div>
    </header>
  );
}
