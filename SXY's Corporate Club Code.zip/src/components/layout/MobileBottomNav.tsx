import * as React from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Tag } from "@/components/sxy/Tag";

/**
 * SXY's Corporate Club — mobile bottom navigation.
 *
 * Visible only on screens <md (under 768px). Replaces the desktop AppSidebar.
 * Renders every nav item in a single horizontally scrollable bar so members
 * can reach any section in one tap. Active route gets the teal-glow pill.
 *
 * Sits fixed at the bottom of the viewport, with safe-area inset padding for
 * notched devices. The body of authed pages already has bottom padding from
 * AppLayout's `pb-20 md:pb-0` so content never sits underneath the bar.
 */

type NavItem = {
  label: string;
  to: string;
  glyph: string;
  badge?: { value: number | string; tone: "teal" | "gold" };
  adminOnly?: boolean;
};

const ITEMS: NavItem[] = [
  { label: "Dashboard", to: "/dashboard", glyph: "◈" },
  { label: "Market", to: "/bidding", glyph: "⚡" },
  { label: "Directory", to: "/referrals", glyph: "🔗" },
  { label: "Apprentice", to: "/apprenticeship", glyph: "🎓" },
  { label: "Boutique", to: "/club-boutique", glyph: "✦" },
  { label: "Hub", to: "/community", glyph: "◎" },
  { label: "Kiddos", to: "/kiddos/hub", glyph: "🧒" },
  { label: "Events", to: "/events", glyph: "📅" },
  { label: "Bites", to: "/economy-bites", glyph: "▣", badge: { value: "NEW", tone: "gold" } },
  { label: "Financials", to: "/financials", glyph: "$" },
  { label: "Profile", to: "/profile", glyph: "◉" },
  { label: "Admin", to: "/admin", glyph: "⚙", adminOnly: true },
];

export function MobileBottomNav() {
  const { isAdmin } = useAuth();
  const location = useLocation();

  const { data: openProjectsCount } = useQuery({
    queryKey: ["badge", "openProjects"],
    queryFn: async () => {
      const { count } = await supabase
        .from("projects")
        .select("id", { count: "exact", head: true })
        .eq("status", "open");
      return count ?? 0;
    },
    staleTime: 60_000,
  });

  const items = ITEMS.filter((i) => !i.adminOnly || isAdmin).map((i) =>
    i.to === "/bidding" && openProjectsCount
      ? { ...i, badge: { value: openProjectsCount, tone: "teal" as const } }
      : i,
  );

  return (
    <nav
      aria-label="Primary mobile navigation"
      className={cn(
        "fixed inset-x-0 bottom-0 z-40 border-t border-border-base/60 bg-charcoal-soft/95 backdrop-blur",
        "pb-[env(safe-area-inset-bottom)] md:hidden",
      )}
    >
      <ul
        className="flex gap-1 overflow-x-auto px-2 py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        role="list"
      >
        {items.map((item) => {
          const isActive =
            location.pathname === item.to ||
            location.pathname.startsWith(item.to + "/");
          return (
            <li key={item.to} className="shrink-0">
              <Link
                to={item.to}
                aria-label={item.label}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "relative flex min-w-[68px] flex-col items-center gap-0.5 rounded-lg px-3 py-1.5 text-[11px] font-medium text-text-muted transition-colors",
                  "hover:bg-charcoal-card hover:text-text-primary",
                  isActive &&
                    "bg-[color:var(--teal-glow)] text-teal-light hover:bg-[color:var(--teal-glow)] hover:text-teal-light",
                )}
              >
                <span aria-hidden className="text-base leading-none">
                  {item.glyph}
                </span>
                <span className="leading-none">{item.label}</span>
                {item.badge ? (
                  <Tag
                    variant={item.badge.tone}
                    className="absolute -right-1 -top-1 px-1 py-0 text-[9px] leading-none"
                  >
                    {item.badge.value}
                  </Tag>
                ) : null}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
