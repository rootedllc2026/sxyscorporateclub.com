import * as React from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Tag } from "@/components/sxy/Tag";

/**
 * SXY's Corporate Club — left rail navigation.
 *
 * Sections (Main / Opportunity / Community / Account / Admin) come from the
 * product spec. Each item carries a glyph + optional live badge; badge values
 * are pulled from Supabase via TanStack Query so they stay current.
 *
 * The active route is highlighted with teal-light text, a teal-mid left border
 * and the teal-glow background — see `linkActiveClass`.
 */

type NavItem = {
  label: string;
  to: string;
  glyph: string;
  badge?: { value: number | string; tone: "teal" | "gold" };
};

type NavSection = { heading: string; items: NavItem[]; adminOnly?: boolean };

const linkBase =
  "group flex items-center gap-3 rounded-lg border-l-2 border-transparent px-3 py-2 text-sm font-medium text-text-muted transition-colors hover:bg-charcoal-card hover:text-text-primary";
const linkActiveClass =
  "border-teal-mid bg-[color:var(--teal-glow)] text-teal-light hover:bg-[color:var(--teal-glow)] hover:text-teal-light";

export function AppSidebar() {
  const { isAdmin, currentUser, userProfile } = useAuth();
  const location = useLocation();

  // Live badge data — open projects + unread messages count.
  // We use TanStack Query so values dedupe across sidebar mounts.
  const { data: openProjectsCount } = useQuery({
    queryKey: ["badge", "openProjects"],
    queryFn: async () => {
      const { count } = await supabase
        .from("projects")
        .select("id", { count: "exact", head: true })
        .eq("status", "open");
      return count ?? 0;
    },
    staleTime: 60_000,
  });

  const { data: messagesCount } = useQuery({
    queryKey: ["badge", "messages", currentUser?.id],
    queryFn: async () => {
      // Until we wire per-user read receipts we surface the most recent activity
      // count across the Exchange so the badge feels alive.
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const { count } = await supabase
        .from("messages")
        .select("id", { count: "exact", head: true })
        .gt("created_at", since);
      return count ?? 0;
    },
    enabled: !!currentUser,
    staleTime: 30_000,
  });

  const sections: NavSection[] = [
    {
      heading: "Main",
      items: [
        { label: "Dashboard", to: "/dashboard", glyph: "◈" },
        { label: "Kiddos App", to: "/kiddos/hub", glyph: "🧒" },
      ],
    },
    {
      heading: "Opportunity",
      items: [
        {
          label: "Club Market",
          to: "/bidding",
          glyph: "⚡",
          badge: openProjectsCount
            ? { value: openProjectsCount, tone: "teal" }
            : undefined,
        },
        { label: "Club Directory", to: "/referrals", glyph: "🔗" },
        { label: "Apprenticeship", to: "/apprenticeship", glyph: "🎓" },
        { label: "Club Boutique", to: "/club-boutique", glyph: "✦" },
      ],
    },
    {
      heading: "Community",
      items: [
        {
          label: "Club Hub",
          to: "/community",
          glyph: "◎",
          badge: messagesCount
            ? { value: messagesCount, tone: "teal" }
            : undefined,
        },
        { label: "Events & Webinars", to: "/events", glyph: "📅" },
        {
          label: "Economy Bites",
          to: "/economy-bites",
          glyph: "▣",
          badge: { value: "NEW", tone: "gold" },
        },
      ],

    },
    {
      heading: "Account",
      items: [{ label: "Club Financials", to: "/financials", glyph: "$" }],
    },
    {
      heading: "Admin",
      adminOnly: true,
      items: [
        { label: "Admin Console", to: "/admin", glyph: "⚙" },
        { label: "Upload Content", to: "/economy-bites/upload", glyph: "↑" },
        { label: "Create Event", to: "/events/create", glyph: "✦" },
      ],
    },
  ];

  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-border-base/60 bg-charcoal-soft lg:flex">
      <div className="flex h-16 items-center gap-2 border-b border-border-base/60 px-5">
        <span className="font-display text-lg italic text-gold">SXY's</span>
        <span className="font-editorial text-base text-text-muted">
          Corporate Club
        </span>
      </div>

      <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-6">
        {sections.map((section) => {
          if (section.adminOnly && !isAdmin) return null;
          return (
            <div key={section.heading}>
              <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim">
                {section.heading}
              </p>
              <ul className="space-y-1">
                {section.items.map((item) => {
                  const isActive =
                    location.pathname === item.to ||
                    location.pathname.startsWith(item.to + "/");
                  return (
                    <li key={item.to}>
                      <Link
                        to={item.to}
                        className={cn(linkBase, isActive && linkActiveClass)}
                      >
                        <span
                          aria-hidden
                          className="w-5 text-center text-base leading-none"
                        >
                          {item.glyph}
                        </span>
                        <span className="flex-1">{item.label}</span>
                        {item.badge ? (
                          <Tag
                            variant={item.badge.tone}
                            className="px-1.5 py-0 text-[10px]"
                          >
                            {item.badge.value}
                          </Tag>
                        ) : null}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      <div className="space-y-2 border-t border-border-base/60 px-5 py-4 text-[10px] leading-relaxed text-text-dim">
        <p className="font-semibold uppercase tracking-[0.18em]">
          {userProfile?.business_name?.trim() || "Your business"}
        </p>
        <p className="normal-case tracking-normal text-text-dim/80">
          Content is educational only and does not constitute legal, financial,
          or investment advice.
        </p>
      </div>
    </aside>
  );
}
