import * as React from "react";
import { Lock, Play, Bookmark, BookmarkCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tag } from "@/components/sxy/Tag";
import {
  formatDuration,
  isNewVideo,
  type VideoRow,
} from "@/lib/videos/shared";

export interface VideoCardProps {
  video: VideoRow;
  locked?: boolean;
  progressPct?: number;
  saved?: boolean;
  onClick?: () => void;
  onToggleSave?: () => void;
  showRemove?: boolean;
}

/**
 * Video grid card. Used on /economy-bites (all videos) and /economy-bites/saved.
 * The thumbnail is a colored block with the icon emoji when no `thumbnail_url`
 * is provided (most launch content will be emoji-only).
 */
export function VideoCard({
  video,
  locked,
  progressPct = 0,
  saved,
  onClick,
  onToggleSave,
  showRemove,
}: VideoCardProps) {
  const isNew = isNewVideo(video.created_at);

  return (
    <article
      className={cn(
        "group relative overflow-hidden rounded-2xl border border-border-base/60 bg-charcoal-card transition-all",
        !locked && "cursor-pointer hover:-translate-y-0.5 hover:border-border-teal",
      )}
      onClick={(e) => {
        if ((e.target as HTMLElement).closest("[data-no-card-click]")) return;
        if (onClick) onClick();
      }}
      role="button"
      tabIndex={0}
    >
      {/* Thumbnail */}
      <div
        className="relative grid aspect-video place-items-center"
        style={{
          background: video.thumbnail_url
            ? `url(${video.thumbnail_url}) center/cover`
            : video.access_level === "vip"
              ? "linear-gradient(135deg, oklch(0.42 0.09 85 / 0.85), oklch(0.18 0.025 85 / 0.95))"
              : "linear-gradient(135deg, oklch(0.55 0.085 210 / 0.55), oklch(0.22 0.035 215 / 0.95))",
        }}
      >
        {!video.thumbnail_url ? (
          <span aria-hidden className="text-5xl opacity-90">
            {video.icon_emoji}
          </span>
        ) : null}

        {/* Play / lock overlay */}
        <span
          aria-hidden
          className={cn(
            "absolute inset-0 grid place-items-center bg-black/30 opacity-0 transition-opacity",
            !locked && "group-hover:opacity-100",
            locked && "opacity-100",
          )}
        >
          {locked ? (
            <span className="grid h-12 w-12 place-items-center rounded-full border border-border-gold bg-charcoal/80 text-gold">
              <Lock className="h-5 w-5" />
            </span>
          ) : (
            <span className="grid h-12 w-12 place-items-center rounded-full bg-teal-mid/90 text-charcoal">
              <Play className="h-5 w-5 translate-x-0.5" fill="currentColor" />
            </span>
          )}
        </span>

        {/* Top-left badges */}
        <div className="absolute left-2 top-2 flex gap-1.5">
          {isNew ? (
            <Tag variant="gold" className="px-1.5 py-0 text-[9px]">
              NEW
            </Tag>
          ) : null}
          {video.access_level === "vip" ? (
            <Tag variant="gold" className="px-1.5 py-0 text-[9px]">
              VIP
            </Tag>
          ) : null}
        </div>

        {/* Duration badge */}
        <span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 font-mono text-[10px] text-white">
          {formatDuration(video.duration_seconds)}
        </span>

        {/* Progress bar */}
        {progressPct > 0 ? (
          <span
            aria-hidden
            className="absolute bottom-0 left-0 h-1 bg-teal-mid"
            style={{ width: `${Math.min(100, progressPct)}%` }}
          />
        ) : null}
      </div>

      {/* Body */}
      <div className="space-y-2 p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="line-clamp-2 font-display text-base text-text-primary">
            {video.title}
          </h3>
          {onToggleSave ? (
            <button
              type="button"
              data-no-card-click
              onClick={(e) => {
                e.stopPropagation();
                onToggleSave();
              }}
              aria-label={saved ? "Remove saved" : "Save video"}
              className="grid h-8 w-8 place-items-center rounded-full border border-border-base/60 text-text-muted transition-colors hover:border-border-teal hover:text-teal-light"
            >
              {saved ? (
                <BookmarkCheck className="h-4 w-4 text-teal-light" />
              ) : (
                <Bookmark className="h-4 w-4" />
              )}
            </button>
          ) : null}
        </div>

        <div className="flex items-center justify-between text-[11px] text-text-dim">
          <Tag variant={video.access_level === "vip" ? "gold" : "teal"}>
            {video.category ?? video.series.replace("-", " ")}
          </Tag>
          <span>
            {video.view_count.toLocaleString()} views ·{" "}
            {video.save_count.toLocaleString()} saves
          </span>
        </div>

        {showRemove ? (
          <button
            type="button"
            data-no-card-click
            onClick={(e) => {
              e.stopPropagation();
              onToggleSave?.();
            }}
            className="mt-1 w-full rounded-md border border-border-base/60 px-3 py-1.5 text-xs text-text-muted transition-colors hover:border-[oklch(0.72_0.18_25/0.4)] hover:text-danger"
          >
            Remove
          </button>
        ) : null}
      </div>
    </article>
  );
}
