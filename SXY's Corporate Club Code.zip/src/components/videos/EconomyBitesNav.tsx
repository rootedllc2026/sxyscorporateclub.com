import * as React from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Tag } from "@/components/sxy/Tag";

/**
 * Section nav rail for the Economy Bites area. Sits at the top of every
 * /economy-bites page so members can jump between All Videos, the Series
 * overview, their saved list and (admins only) Upload Content / Create Event.
 */

type Item = {
  label: string;
  to: string;
  glyph: string;
  badge?: { value: string | number; tone: "teal" | "gold" } | null;
  exact?: boolean;
  adminOnly?: boolean;
};

export function EconomyBitesNav() {
  const { isAdmin, currentUser } = useAuth();
  const location = useLocation();

  // NEW = at least one video published in the past 7 days.
  const { data: newCount } = useQuery({
    queryKey: ["videos", "newCount"],
    queryFn: async () => {
      const since = new Date(Date.now() - 7 * 86400_000).toISOString();
      const { count } = await supabase
        .from("videos")
        .select("id", { count: "exact", head: true })
        .eq("is_published", true)
        .gt("created_at", since);
      return count ?? 0;
    },
    staleTime: 60_000,
  });

  const { data: savedCount } = useQuery({
    queryKey: ["videos", "savedCount", currentUser?.id],
    queryFn: async () => {
      const { count } = await supabase
        .from("video_saves")
        .select("id", { count: "exact", head: true })
        .eq("user_id", currentUser!.id);
      return count ?? 0;
    },
    enabled: !!currentUser,
    staleTime: 30_000,
  });

  const items: Item[] = [
    {
      label: "All Videos",
      to: "/economy-bites",
      glyph: "▣",
      exact: true,
      badge: newCount ? { value: "NEW", tone: "gold" } : null,
    },
    { label: "Economy Bites", to: "/economy-bites/series", glyph: "◈" },
    {
      label: "Saved Videos",
      to: "/economy-bites/saved",
      glyph: "♡",
      badge: savedCount ? { value: savedCount, tone: "teal" } : null,
    },
    { label: "Upload Content", to: "/economy-bites/upload", glyph: "↑", adminOnly: true },
    { label: "Create Event", to: "/events/create", glyph: "✦", adminOnly: true },
  ];

  const isActive = (item: Item) => {
    if (item.exact) return location.pathname === item.to;
    return (
      location.pathname === item.to || location.pathname.startsWith(item.to + "/")
    );
  };

  return (
    <nav
      aria-label="Economy Bites navigation"
      className="flex flex-wrap items-center gap-2 border-b border-border-base/50 pb-4"
    >
      {items.map((item) => {
        if (item.adminOnly && !isAdmin) return null;
        const active = isActive(item);
        return (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-xs font-medium transition-colors",
              active
                ? "border-teal-mid bg-[color:var(--teal-glow)] text-teal-light"
                : "border-border bg-charcoal-card text-text-muted hover:border-border-teal hover:text-text-primary",
            )}
          >
            <span aria-hidden className="text-base leading-none">
              {item.glyph}
            </span>
            <span>{item.label}</span>
            {item.badge ? (
              <Tag
                variant={item.badge.tone}
                className="ml-1 px-1.5 py-0 text-[10px]"
              >
                {item.badge.value}
              </Tag>
            ) : null}
          </Link>
        );
      })}
    </nav>
  );
}
