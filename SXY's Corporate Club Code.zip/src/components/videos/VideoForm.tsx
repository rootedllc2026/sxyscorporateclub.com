/**
 * Shared video form used by both /economy-bites/upload (create) and
 * /economy-bites/$id/edit (update). Submits insert or update against the
 * `videos` table depending on whether `initial` is provided.
 */
import * as React from "react";
import { useNavigate } from "@tanstack/react-router";
import { SxyButton } from "@/components/sxy/SxyButton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/integrations/supabase/AuthContext";
import {
  CATEGORY_FILTERS,
  type VideoAccess,
  type VideoRow,
  type VideoSeries,
} from "@/lib/videos/shared";

export interface VideoFormProps {
  /** When provided the form runs in edit mode and updates this row. */
  initial?: VideoRow;
}

export function VideoForm({ initial }: VideoFormProps) {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [pending, setPending] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const isEdit = !!initial;

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setPending(true);
    try {
      const f = new FormData(e.currentTarget);
      const payload = {
        title: String(f.get("title") ?? "").trim(),
        description: String(f.get("description") ?? ""),
        icon_emoji: String(f.get("icon_emoji") ?? "▣"),
        video_url: String(f.get("video_url") ?? ""),
        thumbnail_url: String(f.get("thumbnail_url") ?? "") || null,
        duration_seconds: Number(f.get("duration_seconds") ?? 0),
        series: String(f.get("series") ?? "business-bites") as VideoSeries,
        category: String(f.get("category") ?? "Strategy"),
        access_level: String(f.get("access_level") ?? "free") as VideoAccess,
        is_featured: f.get("is_featured") === "on",
        notify_on_publish: f.get("notify_on_publish") === "on",
        is_published: f.get("is_published") === "on",
      };

      if (isEdit) {
        const { error: err } = await supabase
          .from("videos")
          .update(payload)
          .eq("id", initial!.id);
        if (err) throw err;
        navigate({ to: "/economy-bites/$id", params: { id: initial!.id } });
      } else {
        const { data, error: err } = await supabase
          .from("videos")
          .insert({ ...payload, created_by: currentUser?.id ?? null })
          .select("id")
          .maybeSingle();
        if (err) throw err;
        navigate({ to: "/economy-bites/$id", params: { id: data!.id as string } });
      }
    } catch (e) {
      setError((e as Error).message ?? "Save failed.");
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5">
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Title">
          <Input
            name="title"
            required
            placeholder="The Pricing Power Playbook"
            defaultValue={initial?.title ?? ""}
          />
        </Field>
        <Field label="Icon emoji">
          <Input
            name="icon_emoji"
            defaultValue={initial?.icon_emoji ?? "▣"}
            maxLength={4}
          />
        </Field>
      </div>

      <Field label="Description">
        <Textarea
          name="description"
          rows={4}
          placeholder="What members will learn in this bite…"
          defaultValue={initial?.description ?? ""}
        />
      </Field>

      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Video URL (YouTube / Vimeo / Storage)">
          <Input
            name="video_url"
            placeholder="https://www.youtube.com/watch?v=…"
            defaultValue={initial?.video_url ?? ""}
          />
        </Field>
        <Field label="Thumbnail URL (optional)">
          <Input
            name="thumbnail_url"
            placeholder="https://…"
            defaultValue={initial?.thumbnail_url ?? ""}
          />
        </Field>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Field label="Duration (seconds)">
          <Input
            type="number"
            name="duration_seconds"
            min={0}
            defaultValue={initial?.duration_seconds ?? 0}
          />
        </Field>
        <Field label="Series">
          <Select name="series" defaultValue={initial?.series ?? "business-bites"}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="business-bites">Business Bites</SelectItem>
              <SelectItem value="market-bites">Market Bites</SelectItem>
              <SelectItem value="bankruptcy-bites">Bankruptcy Bites</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Access level">
          <Select name="access_level" defaultValue={initial?.access_level ?? "free"}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="free">Free</SelectItem>
              <SelectItem value="paid">Paid / Annual</SelectItem>
              <SelectItem value="vip">VIP Only</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      </div>

      <Field label="Category">
        <Select name="category" defaultValue={initial?.category ?? "Strategy"}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {CATEGORY_FILTERS.filter((c) => c !== "All" && c !== "Free Only").map(
              (c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ),
            )}
          </SelectContent>
        </Select>
      </Field>

      <div className="grid gap-4 md:grid-cols-3">
        <Toggle
          name="is_featured"
          label="Feature on Economy Bites home"
          defaultChecked={initial?.is_featured}
        />
        <Toggle
          name="notify_on_publish"
          label="Notify eligible members"
          defaultChecked={initial?.notify_on_publish ?? true}
        />
        <Toggle
          name="is_published"
          label="Publish now"
          defaultChecked={initial?.is_published ?? true}
        />
      </div>

      {error ? (
        <p className="rounded-md border border-[oklch(0.72_0.18_25/0.4)] bg-[oklch(0.72_0.18_25/0.1)] p-3 text-xs text-danger">
          {error}
        </p>
      ) : null}

      <div className="flex justify-end gap-2">
        <SxyButton
          type="button"
          variant="ghost"
          size="sm"
          onClick={() =>
            isEdit
              ? navigate({
                  to: "/economy-bites/$id",
                  params: { id: initial!.id },
                })
              : navigate({ to: "/economy-bites" })
          }
        >
          Cancel
        </SxyButton>
        <SxyButton type="submit" disabled={pending}>
          {pending ? "Saving…" : isEdit ? "Save changes" : "Publish video"}
        </SxyButton>
      </div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-text-muted">
        {label}
      </Label>
      {children}
    </label>
  );
}

function Toggle({
  name,
  label,
  defaultChecked,
}: {
  name: string;
  label: string;
  defaultChecked?: boolean;
}) {
  const [on, setOn] = React.useState(!!defaultChecked);
  return (
    <label className="flex items-center justify-between gap-3 rounded-xl border border-border-base/60 bg-charcoal-card-2 px-4 py-3 text-sm text-text-primary">
      <span>{label}</span>
      <input type="hidden" name={name} value={on ? "on" : ""} />
      <Switch checked={on} onCheckedChange={setOn} />
    </label>
  );
}
