import * as React from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Pings the Supabase auth endpoint at mount. If it can't be reached at all
 * (network / DNS / wrong URL), shows a fixed banner so the failure mode is
 * obvious instead of every page silently throwing "Failed to fetch".
 *
 * Invalid sessions are NOT errors here — only true network failures trip it.
 */
export function BackendHealthBanner() {
  const [unreachable, setUnreachable] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    (async () => {
      try {
        // getSession() hits the auth endpoint over the network.
        await supabase.auth.getSession();
        if (!cancelled) setUnreachable(false);
      } catch (err) {
        // TypeError: Failed to fetch / AbortError / network down
        if (!cancelled) {
          const msg = err instanceof Error ? err.message : String(err);
          if (
            msg.toLowerCase().includes("failed to fetch") ||
            msg.toLowerCase().includes("network") ||
            msg.toLowerCase().includes("abort")
          ) {
            setUnreachable(true);
            // eslint-disable-next-line no-console
            console.error("[BackendHealth] Supabase unreachable:", err);
          }
        }
      } finally {
        clearTimeout(timeout);
      }
    })();

    return () => {
      cancelled = true;
      controller.abort();
      clearTimeout(timeout);
    };
  }, []);

  if (!unreachable) return null;

  return (
    <div
      role="alert"
      className="fixed inset-x-0 top-0 z-[100] border-b border-red-500/40 bg-red-950/95 px-4 py-2 text-center text-xs font-medium text-red-100 backdrop-blur"
    >
      Backend unreachable. Check Lovable Cloud status — if this persists, the
      app may be pointing at a stale backend URL.
    </div>
  );
}
