import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Dark-themed text input that matches the SXY brand. Use inside <label> or
 * with an external <Label>. Supports all native input props.
 */
export const AuthInput = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement>
>(({ className, ...props }, ref) => {
  return (
    <input
      ref={ref}
      className={cn(
        "block w-full rounded-xl border border-border-base bg-charcoal px-4 py-3 text-sm text-text-primary placeholder:text-text-dim",
        "transition focus:border-teal-mid focus:outline-none focus:ring-2 focus:ring-teal-mid/30",
        "disabled:cursor-not-allowed disabled:opacity-60",
        className,
      )}
      {...props}
    />
  );
});
AuthInput.displayName = "AuthInput";

/**
 * Dark-themed select. Same brand treatment as AuthInput.
 */
export const AuthSelect = React.forwardRef<
  HTMLSelectElement,
  React.SelectHTMLAttributes<HTMLSelectElement>
>(({ className, children, ...props }, ref) => {
  return (
    <select
      ref={ref}
      className={cn(
        "block w-full rounded-xl border border-border-base bg-charcoal px-4 py-3 text-sm text-text-primary",
        "transition focus:border-teal-mid focus:outline-none focus:ring-2 focus:ring-teal-mid/30",
        "disabled:cursor-not-allowed disabled:opacity-60",
        className,
      )}
      {...props}
    >
      {children}
    </select>
  );
});
AuthSelect.displayName = "AuthSelect";

/**
 * Field group wrapper: label above input.
 */
export function Field({
  label,
  htmlFor,
  children,
  hint,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label
        htmlFor={htmlFor}
        className="block text-xs font-semibold uppercase tracking-wider text-text-muted"
      >
        {label}
      </label>
      {children}
      {hint && <p className="text-xs text-text-dim">{hint}</p>}
    </div>
  );
}
