import * as React from "react";
import { Link } from "@tanstack/react-router";

/**
 * Centered card layout shared by every auth page (signup / login / reset / etc).
 * Renders the brand wordmark above a charcoal card with subtle radial teal glow
 * behind it. Children are the page-specific form/content.
 */
export function AuthShell({
  title,
  subtitle,
  children,
  footer,
  wide,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  /** Use a wider card (e.g. signup with tier selector). */
  wide?: boolean;
}) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-charcoal px-4 py-12">
      {/* Radial teal glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 40%, oklch(0.55 0.085 210 / 0.18), transparent 70%)",
        }}
      />
      {/* Subtle gold accent bottom-right */}
      <div
        aria-hidden
        className="pointer-events-none absolute bottom-0 right-0 h-96 w-96"
        style={{
          background:
            "radial-gradient(circle, oklch(0.74 0.115 85 / 0.07), transparent 70%)",
        }}
      />

      <div
        className={
          "relative z-10 w-full " + (wide ? "max-w-3xl" : "max-w-md")
        }
      >
        {/* Brand wordmark */}
        <div className="mb-6 text-center">
          <Link
            to="/"
            className="inline-block font-editorial text-2xl tracking-wide text-gold transition hover:text-gold-light"
            style={{ fontStyle: "italic" }}
          >
            SXY's Corporate Club
          </Link>
        </div>

        {/* Card */}
        <div
          className="rounded-3xl border border-border-base/60 bg-charcoal-card p-8 sm:p-10"
          style={{ boxShadow: "var(--shadow-card)" }}
        >
          <h1 className="font-editorial text-[28px] leading-tight text-text-primary">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-2 text-[13px] text-text-muted">{subtitle}</p>
          )}

          <div className="mt-7">{children}</div>
        </div>

        {footer && (
          <div className="mt-6 text-center text-sm text-text-muted">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Inline error banner used below auth forms.
 */
export function AuthError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div
      role="alert"
      className="mt-4 rounded-xl border border-danger/40 bg-danger/10 px-4 py-3 text-sm text-danger"
    >
      {message}
    </div>
  );
}

/**
 * Inline success banner.
 */
export function AuthSuccess({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div
      role="status"
      className="mt-4 rounded-xl border border-success/40 bg-success/10 px-4 py-3 text-sm text-success"
    >
      {message}
    </div>
  );
}
