import * as React from "react";
import { Link } from "@tanstack/react-router";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SxyButton } from "@/components/sxy/SxyButton";

/**
 * Reusable VIP / paid upgrade prompt. Used wherever a member taps a locked
 * piece of content (Market Bites video, VIP webinar, etc.).
 */
export interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  body?: string;
  ctaLabel?: string;
}

export function UpgradeModal({
  open,
  onOpenChange,
  title = "VIP access required",
  body = "This content is reserved for VIP members. Upgrade to unlock the full Economy Bites and Events library.",
  ctaLabel = "View membership tiers",
}: UpgradeModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border-gold bg-charcoal-card">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-gold">
            {title}
          </DialogTitle>
          <DialogDescription className="text-text-muted">
            {body}
          </DialogDescription>
        </DialogHeader>

        <DialogFooter className="gap-2 sm:gap-3">
          <SxyButton
            variant="ghost"
            size="sm"
            onClick={() => onOpenChange(false)}
          >
            Maybe later
          </SxyButton>
          <SxyButton variant="gold" size="sm" asChild>
            <Link to="/membership">{ctaLabel}</Link>
          </SxyButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
