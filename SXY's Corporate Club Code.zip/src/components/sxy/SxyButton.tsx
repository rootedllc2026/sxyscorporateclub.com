import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const sxyButtonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full font-semibold transition-all duration-200 disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
  {
    variants: {
      variant: {
        primary:
          "bg-[image:var(--gradient-teal)] text-text-primary shadow-[var(--shadow-teal)] hover:-translate-y-0.5 hover:shadow-[0_10px_30px_oklch(0.55_0.085_210/0.45)]",
        gold: "bg-[image:var(--gradient-gold)] text-charcoal shadow-[var(--shadow-gold)] hover:-translate-y-0.5 hover:shadow-[0_10px_30px_oklch(0.74_0.115_85/0.55)]",
        outline:
          "border-2 border-teal-deep bg-transparent text-teal-light hover:bg-teal-deep hover:text-text-primary",
        danger:
          "bg-[oklch(0.72_0.18_25/0.15)] text-danger border border-[oklch(0.72_0.18_25/0.4)] hover:bg-[oklch(0.72_0.18_25/0.25)]",
        success:
          "bg-[oklch(0.78_0.18_145/0.15)] text-success border border-[oklch(0.78_0.18_145/0.4)] hover:bg-[oklch(0.78_0.18_145/0.25)]",
        ghost: "text-text-muted hover:bg-charcoal-card hover:text-text-primary",
      },
      size: {
        default: "h-11 px-7 text-[0.95rem]",
        sm: "h-9 px-4 text-xs",
        lg: "h-12 px-8 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  },
);

export interface SxyButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof sxyButtonVariants> {
  asChild?: boolean;
}

export const SxyButton = React.forwardRef<HTMLButtonElement, SxyButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        ref={ref}
        className={cn(sxyButtonVariants({ variant, size }), className)}
        {...props}
      />
    );
  },
);
SxyButton.displayName = "SxyButton";

export { sxyButtonVariants };
