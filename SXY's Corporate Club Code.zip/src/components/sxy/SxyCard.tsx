import * as React from "react";
import { cn } from "@/lib/utils";

export interface SxyCardProps extends React.HTMLAttributes<HTMLDivElement> {
  accent?: boolean;
  hoverable?: boolean;
}

export function SxyCard({
  className,
  accent,
  hoverable,
  ...props
}: SxyCardProps) {
  return (
    <div
      className={cn(
        "sxy-card",
        hoverable && "sxy-card-hover",
        accent && "sxy-card-accent",
        className,
      )}
      {...props}
    />
  );
}
