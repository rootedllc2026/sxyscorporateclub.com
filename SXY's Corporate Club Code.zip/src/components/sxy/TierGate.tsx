import * as React from "react";
import { Link } from "@tanstack/react-router";
import { useAuth } from "@/integrations/supabase/AuthContext";
import { isPaidTier } from "@/lib/apprenticeship/shared";
import { SxyCard } from "@/components/sxy/SxyCard";
import { SxyButton } from "@/components/sxy/SxyButton";

/**
 * Wrap a page (or section) to require a paid membership tier. Free members
 * see a polished upgrade screen with a link to the membership page; paid
 * members see the wrapped children.
 *
 * Admins always pass.
 */
export function TierGate({
  feature,
  children,
}: {
  feature: string;
  children: React.ReactNode;
}) {
  const { userTier, isAdmin, isLoading } = useAuth();
  if (isLoading) return null;
  if (isAdmin || isPaidTier(userTier)) return <>{children}</>;

  return (
    <div className="mx-auto max-w-2xl py-10">
      <SxyCard accent>
        <p className="sxy-section-label text-gold">Members only</p>
        <h2 className="mt-3 font-display text-3xl text-text-primary">
          {feature} is a paid-member benefit
        </h2>
        <p className="mt-3 text-sm text-text-muted">
          Upgrade to an Investing Member plan ($9/mo) to unlock the Club
          Market and submit bids on member-posted projects. Annual and VIP
          tiers include it too.
        </p>
        <ul className="mt-5 space-y-2 text-sm text-text-muted">
          <li>· Browse and bid on member projects</li>
          <li>· Be considered for awarded contracts</li>
          <li>· Connect directly with project owners</li>
        </ul>
        <div className="mt-6 flex flex-wrap gap-3">
          <SxyButton variant="gold" size="lg" asChild>
            <Link to="/membership">View membership tiers</Link>
          </SxyButton>
          <SxyButton variant="outline" size="lg" asChild>
            <Link to="/dashboard">Back to dashboard</Link>
          </SxyButton>
        </div>
      </SxyCard>
    </div>
  );
}
