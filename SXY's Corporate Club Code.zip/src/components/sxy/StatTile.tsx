import * as React from "react";
import { cn } from "@/lib/utils";

export interface StatTileProps extends React.HTMLAttributes<HTMLDivElement> {
  label: string;
  value: string | number;
  delta?: string;
  deltaTone?: "up" | "down" | "neutral";
}

const deltaToneClass: Record<NonNullable<StatTileProps["deltaTone"]>, string> =
  {
    up: "text-success",
    down: "text-danger",
    neutral: "text-text-dim",
  };

export function StatTile({
  label,
  value,
  delta,
  deltaTone = "neutral",
  className,
  ...props
}: StatTileProps) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-border bg-charcoal-card p-5 transition-colors hover:border-border-teal",
        className,
      )}
      {...props}
    >
      <p className="text-[9px] font-semibold uppercase tracking-[0.18em] text-text-dim">
        {label}
      </p>
      <p className="mt-2 font-display text-[26px] leading-none text-text-primary">
        {value}
      </p>
      {delta ? (
        <p
          className={cn(
            "mt-2 text-[10px] font-medium",
            deltaToneClass[deltaTone],
          )}
        >
          {delta}
        </p>
      ) : null}
    </div>
  );
}
