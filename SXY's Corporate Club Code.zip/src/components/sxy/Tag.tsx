import * as React from "react";
import { cn } from "@/lib/utils";

type TagVariant = "teal" | "gold" | "green" | "red" | "gray" | "amber";

const variantStyles: Record<TagVariant, string> = {
  teal: "bg-[color:var(--teal-glow)] text-teal-light border-border-teal",
  gold: "bg-[color:var(--gold-glow)] text-gold-light border-border-gold",
  green:
    "bg-[oklch(0.78_0.18_145/0.12)] text-success border-[oklch(0.78_0.18_145/0.35)]",
  red: "bg-[oklch(0.72_0.18_25/0.12)] text-danger border-[oklch(0.72_0.18_25/0.35)]",
  amber:
    "bg-[oklch(0.82_0.16_80/0.12)] text-warning border-[oklch(0.82_0.16_80/0.35)]",
  gray: "bg-charcoal-card-2 text-text-muted border-border",
};

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: TagVariant;
}

export function Tag({
  variant = "teal",
  className,
  children,
  ...props
}: TagProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider",
        variantStyles[variant],
        className,
      )}
      {...props}
    >
      {children}
    </span>
  );
}
