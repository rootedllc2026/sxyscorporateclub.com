import * as React from "react";
import { cn } from "@/lib/utils";

export interface FilterChipProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  active?: boolean;
}

export function FilterChip({
  active,
  className,
  children,
  ...props
}: FilterChipProps) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-xs font-medium transition-colors",
        active
          ? "border-teal-mid bg-[color:var(--teal-glow)] text-teal-light"
          : "border-border bg-charcoal-card text-text-muted hover:border-border-teal hover:text-text-primary",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}
