/**
 * Right column of the Community Exchange — Members / Pinned / Announcements
 * tabs with state filter chips on the Members tab.
 */
import * as React from "react";
import { cn } from "@/lib/utils";
import { AvatarBadge } from "@/components/layout/Avatar";
import { Tag } from "@/components/sxy/Tag";
import { FilterChip } from "@/components/sxy/FilterChip";
import { SxyButton } from "@/components/sxy/SxyButton";
import { presenceDot, formatRelativeTime, roleBadge } from "@/lib/community/format";
import type {
  CommunityProfileLite,
  MessageWithSender,
} from "@/lib/community/types";

export type RightTab = "members" | "pinned" | "announcements";

const STATE_OPTIONS: Array<{
  label: string;
  value: string;
}> = [
  { label: "All", value: "all" },
  { label: "🟦 NJ", value: "NJ" },
  { label: "🟨 PA", value: "PA" },
  { label: "🟥 GA", value: "GA" },
  { label: "Virtual", value: "VIRTUAL" },
];

export interface RightPanelProps {
  members: CommunityProfileLite[];
  pinned: MessageWithSender[];
  announcements: MessageWithSender[];
  isAdmin: boolean;
  onNewAnnouncement: () => void;
}

export function RightPanel({
  members,
  pinned,
  announcements,
  isAdmin,
  onNewAnnouncement,
}: RightPanelProps) {
  const [tab, setTab] = React.useState<RightTab>("members");
  const [stateFilter, setStateFilter] = React.useState("all");

  const filteredMembers = React.useMemo(() => {
    let list = members;
    if (stateFilter !== "all") {
      list =
        stateFilter === "VIRTUAL"
          ? list.filter((m) => !m.state)
          : list.filter((m) => m.state === stateFilter);
    }
    const rank = (m: CommunityProfileLite) =>
      m.is_admin ? 0 : m.tier === "vip" ? 1 : 2;
    return [...list].sort((a, b) => {
      const r = rank(a) - rank(b);
      if (r !== 0) return r;
      return (a.full_name ?? a.email ?? "").localeCompare(
        b.full_name ?? b.email ?? "",
      );
    });
  }, [members, stateFilter]);

  const tabBtn = (id: RightTab, label: string) => (
    <button
      key={id}
      type="button"
      onClick={() => setTab(id)}
      className={cn(
        "flex-1 border-b-2 px-2 py-2 text-xs font-semibold uppercase tracking-wider transition-colors",
        tab === id
          ? "border-teal-mid text-teal-light"
          : "border-transparent text-text-muted hover:text-text-primary",
      )}
    >
      {label}
    </button>
  );

  return (
    <aside className="hidden w-[260px] shrink-0 flex-col border-l border-border-base/60 bg-charcoal-soft xl:flex">
      <div className="flex border-b border-border-base/60">
        {tabBtn("members", `Members (${members.length})`)}
        {tabBtn("pinned", "Pinned")}
        {tabBtn("announcements", "Announce")}
      </div>

      <div className="flex-1 overflow-y-auto">
        {tab === "members" ? (
          <>
            <div className="flex flex-wrap gap-1.5 border-b border-border-base/60 px-3 py-3">
              {STATE_OPTIONS.map((opt) => (
                <FilterChip
                  key={opt.value}
                  active={stateFilter === opt.value}
                  onClick={() => setStateFilter(opt.value)}
                  className="px-2.5 py-1 text-[11px]"
                >
                  {opt.label}
                </FilterChip>
              ))}
            </div>
            <ul className="px-2 py-2">
              {filteredMembers.length === 0 ? (
                <li className="px-2 py-3 text-xs text-text-dim">
                  No members match this filter.
                </li>
              ) : (
                filteredMembers.map((m) => {
                  const presence = presenceDot(m.last_seen_at);
                  const badge = roleBadge({
                    isAdmin: m.is_admin,
                    tier: m.tier,
                  });
                  return (
                    <li
                      key={m.id}
                      className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-charcoal-card"
                    >
                      <div className="relative">
                        <AvatarBadge
                          name={m.full_name}
                          email={m.email}
                          colorKey={m.avatar_color}
                          size={28}
                        />
                        <span
                          aria-label={presence.label}
                          className={cn(
                            "absolute -bottom-0 -right-0 h-2.5 w-2.5 rounded-full ring-2 ring-charcoal-soft",
                            presence.className,
                          )}
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs text-text-primary">
                          {m.full_name ?? m.email ?? "Member"}
                        </p>
                        <p className="text-[10px] text-text-dim">
                          {m.state ?? "Virtual"}
                        </p>
                      </div>
                      <span
                        className={cn(
                          "rounded border px-1 py-0 text-[9px] uppercase tracking-wider",
                          badge.className,
                        )}
                      >
                        {badge.label}
                      </span>
                    </li>
                  );
                })
              )}
            </ul>
          </>
        ) : null}

        {tab === "pinned" ? (
          <ul className="space-y-2 p-3">
            {pinned.length === 0 ? (
              <li className="px-2 py-3 text-xs text-text-dim">
                No pinned messages in this channel yet.
              </li>
            ) : (
              pinned.map((p) => (
                <li
                  key={p.id}
                  className="rounded-md border border-[color:var(--border-gold)] bg-[color:var(--gold-glow)] p-3"
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-[11px] font-semibold text-gold-light">
                      📌 Pinned
                    </span>
                    <span className="text-[10px] text-text-dim">
                      {p.pinned_at
                        ? formatRelativeTime(p.pinned_at)
                        : formatRelativeTime(p.created_at)}
                    </span>
                  </div>
                  <p className="mt-1 line-clamp-3 text-xs text-text-muted">
                    {p.content ?? p.body}
                  </p>
                  <p className="mt-1 text-[10px] text-text-dim">
                    by {p.sender?.full_name ?? "Member"}
                  </p>
                </li>
              ))
            )}
          </ul>
        ) : null}

        {tab === "announcements" ? (
          <div className="p-3">
            {isAdmin ? (
              <SxyButton
                size="sm"
                variant="gold"
                className="mb-3 w-full"
                onClick={onNewAnnouncement}
              >
                + New Announcement
              </SxyButton>
            ) : null}
            <ul className="space-y-2">
              {announcements.length === 0 ? (
                <li className="px-1 py-3 text-xs text-text-dim">
                  No announcements yet.
                </li>
              ) : (
                announcements.map((a) => (
                  <li
                    key={a.id}
                    className="rounded-md border border-[color:var(--border-gold)] bg-[color:var(--gold-glow)] p-3"
                  >
                    {a.embed_title ? (
                      <p className="text-sm font-semibold text-gold-light">
                        {a.embed_title}
                      </p>
                    ) : null}
                    <p className="mt-1 whitespace-pre-wrap text-xs text-text-muted">
                      {a.content ?? a.body}
                    </p>
                    <p className="mt-2 text-[10px] text-text-dim">
                      {a.sender?.full_name ?? "Admin"} ·{" "}
                      {formatRelativeTime(a.created_at)}
                    </p>
                  </li>
                ))
              )}
            </ul>
          </div>
        ) : null}
      </div>
    </aside>
  );
}
