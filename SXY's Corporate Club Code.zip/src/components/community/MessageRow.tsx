/**
 * Single message row in the feed. Handles "continued" mode (consecutive
 * messages from the same sender), reactions, and admin pin action.
 */
import * as React from "react";
import { cn } from "@/lib/utils";
import { AvatarBadge } from "@/components/layout/Avatar";
import { Tag } from "@/components/sxy/Tag";
import { Pin, Smile } from "lucide-react";
import {
  formatRelativeTime,
  renderMessageBody,
  roleBadge,
} from "@/lib/community/format";
import type {
  CommunityReaction,
  MessageWithSender,
} from "@/lib/community/types";

const QUICK_EMOJI = ["👍", "❤️", "🔥", "🎉", "🙌", "💯"];

export interface MessageRowProps {
  message: MessageWithSender;
  continued: boolean;
  currentUserId: string;
  isAdmin: boolean;
  onToggleReaction: (messageId: string, emoji: string) => void;
  onTogglePin: (message: MessageWithSender) => void;
}

function groupReactions(reactions: CommunityReaction[]) {
  const map = new Map<string, { count: number; mine: boolean }>();
  return (currentUserId: string) => {
    map.clear();
    for (const r of reactions) {
      const cur = map.get(r.emoji) ?? { count: 0, mine: false };
      cur.count += 1;
      if (r.user_id === currentUserId) cur.mine = true;
      map.set(r.emoji, cur);
    }
    return Array.from(map.entries()).map(([emoji, v]) => ({
      emoji,
      count: v.count,
      mine: v.mine,
    }));
  };
}

export function MessageRow({
  message,
  continued,
  currentUserId,
  isAdmin,
  onToggleReaction,
  onTogglePin,
}: MessageRowProps) {
  const [pickerOpen, setPickerOpen] = React.useState(false);
  const sender = message.sender;
  const badge = roleBadge({
    isAdmin: sender?.is_admin,
    tier: sender?.tier,
  });
  const grouped = React.useMemo(
    () => groupReactions(message.reactions)(currentUserId),
    [message.reactions, currentUserId],
  );
  const text = message.content ?? message.body ?? "";

  return (
    <div
      className={cn(
        "group relative flex gap-3 px-6 py-1 hover:bg-charcoal-card/40",
        continued ? "pt-0.5" : "pt-3",
      )}
    >
      <div className="w-10 shrink-0 pt-1">
        {!continued ? (
          <AvatarBadge
            name={sender?.full_name}
            email={sender?.email}
            colorKey={sender?.avatar_color}
            size={36}
          />
        ) : (
          <span className="invisible block text-[10px] text-text-dim group-hover:visible">
            {new Date(message.created_at).toLocaleTimeString([], {
              hour: "numeric",
              minute: "2-digit",
            })}
          </span>
        )}
      </div>

      <div className="min-w-0 flex-1">
        {!continued ? (
          <div className="mb-1 flex items-baseline gap-2">
            <span className="font-display text-sm text-text-primary">
              {sender?.full_name ?? sender?.email ?? "Member"}
            </span>
            <span
              className={cn(
                "rounded border px-1.5 py-0 text-[9px] uppercase tracking-wider",
                badge.className,
              )}
            >
              {badge.label}
            </span>
            <span className="text-[11px] text-text-dim">
              {formatRelativeTime(message.created_at)}
            </span>
          </div>
        ) : null}

        <p className="whitespace-pre-wrap break-words text-sm text-text-muted">
          {renderMessageBody(text)}
        </p>

        {message.embed_title || message.embed_link ? (
          <a
            href={message.embed_link ?? "#"}
            target="_blank"
            rel="noreferrer noopener"
            className="mt-2 block max-w-md rounded-md border border-border-base bg-charcoal-card-2 px-3 py-2 hover:border-border-teal"
          >
            {message.embed_title ? (
              <p className="text-sm font-semibold text-text-primary">
                {message.embed_title}
              </p>
            ) : null}
            {message.embed_desc ? (
              <p className="mt-0.5 text-xs text-text-dim">
                {message.embed_desc}
              </p>
            ) : null}
            {message.embed_link ? (
              <p className="mt-1 truncate text-[11px] text-teal-light">
                {message.embed_link}
              </p>
            ) : null}
          </a>
        ) : null}

        {grouped.length > 0 ? (
          <div className="mt-1.5 flex flex-wrap gap-1">
            {grouped.map((g) => (
              <button
                key={g.emoji}
                type="button"
                onClick={() => onToggleReaction(message.id, g.emoji)}
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs transition-colors",
                  g.mine
                    ? "border-border-teal bg-[color:var(--teal-glow)] text-teal-light"
                    : "border-border-base bg-charcoal-card text-text-muted hover:border-border-teal",
                )}
              >
                <span>{g.emoji}</span>
                <span className="text-[11px]">{g.count}</span>
              </button>
            ))}
          </div>
        ) : null}
      </div>

      {/* Hover action bar */}
      <div className="absolute right-4 top-1 hidden gap-1 rounded-md border border-border-base bg-charcoal-card-2 px-1 py-0.5 shadow-lg group-hover:flex">
        <button
          type="button"
          onClick={() => setPickerOpen((v) => !v)}
          className="rounded p-1 text-text-muted hover:bg-charcoal-card hover:text-text-primary"
          aria-label="React"
        >
          <Smile className="h-3.5 w-3.5" />
        </button>
        {isAdmin ? (
          <button
            type="button"
            onClick={() => onTogglePin(message)}
            className={cn(
              "rounded p-1 hover:bg-charcoal-card",
              message.is_pinned
                ? "text-gold-light"
                : "text-text-muted hover:text-text-primary",
            )}
            aria-label={message.is_pinned ? "Unpin" : "Pin"}
          >
            <Pin className="h-3.5 w-3.5" />
          </button>
        ) : null}
      </div>

      {pickerOpen ? (
        <div className="absolute right-4 top-9 z-10 flex gap-1 rounded-md border border-border-base bg-charcoal-card-2 px-2 py-1.5 shadow-xl">
          {QUICK_EMOJI.map((e) => (
            <button
              key={e}
              type="button"
              onClick={() => {
                onToggleReaction(message.id, e);
                setPickerOpen(false);
              }}
              className="rounded px-1 py-0.5 text-base hover:bg-charcoal-card"
            >
              {e}
            </button>
          ))}
        </div>
      ) : null}

      {message.is_pinned && !continued ? (
        <Tag
          variant="gold"
          className="absolute right-4 top-1 px-1.5 py-0 text-[10px] group-hover:hidden"
        >
          📌 Pinned
        </Tag>
      ) : null}
    </div>
  );
}
