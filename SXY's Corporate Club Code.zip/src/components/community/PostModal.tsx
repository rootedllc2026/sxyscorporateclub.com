/**
 * "+ Post" modal: pick a post type (Message / Announcement / Resource / Poll)
 * and submit. Inserts into public.messages with the appropriate fields.
 */
import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SxyButton } from "@/components/sxy/SxyButton";
import { cn } from "@/lib/utils";
import { Plus, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type {
  CommunityChannel,
  PostType,
} from "@/lib/community/types";

export interface PostModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  channels: CommunityChannel[];
  defaultChannelId: string | null;
  defaultType?: PostType;
  currentUserId: string;
  isAdmin: boolean;
  onPosted: () => void;
}

const TYPE_OPTIONS: Array<{ id: PostType; label: string; desc: string }> = [
  { id: "message", label: "Message", desc: "Post to a channel" },
  { id: "announcement", label: "Announcement", desc: "Highlighted update" },
  { id: "resource", label: "Share Resource", desc: "Link / file with metadata" },
  { id: "poll", label: "Poll", desc: "Ask the community" },
];

export function PostModal({
  open,
  onOpenChange,
  channels,
  defaultChannelId,
  defaultType = "message",
  currentUserId,
  isAdmin,
  onPosted,
}: PostModalProps) {
  const [type, setType] = React.useState<PostType>(defaultType);
  const [channelId, setChannelId] = React.useState<string>(
    defaultChannelId ?? channels[0]?.id ?? "",
  );
  const [content, setContent] = React.useState("");
  const [title, setTitle] = React.useState("");
  const [link, setLink] = React.useState("");
  const [resourceCategory, setResourceCategory] = React.useState("Guide");
  const [resourceVisibility, setResourceVisibility] =
    React.useState<"all" | "vip">("all");
  const [pollOptions, setPollOptions] = React.useState<string[]>(["", ""]);
  const [pollDurationDays, setPollDurationDays] = React.useState(3);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // Reset on open
  React.useEffect(() => {
    if (open) {
      setType(defaultType);
      setChannelId(defaultChannelId ?? channels[0]?.id ?? "");
      setContent("");
      setTitle("");
      setLink("");
      setPollOptions(["", ""]);
      setError(null);
    }
  }, [open, defaultType, defaultChannelId, channels]);

  async function handleSubmit() {
    setError(null);
    if (!currentUserId) return;
    if (!channelId && type !== "announcement") {
      setError("Pick a channel.");
      return;
    }
    if (type !== "poll" && !content.trim()) {
      setError("Write something first.");
      return;
    }
    setSubmitting(true);
    try {
      const base = {
        sender_id: currentUserId,
        channel_id: channelId || null,
        content: content.trim() || null,
        body: content.trim() || null, // legacy column non-null
        post_type: type,
      };

      let extra: Record<string, unknown> = {};
      if (type === "announcement") {
        extra = {
          is_announcement: true,
          embed_title: title.trim() || null,
        };
      } else if (type === "resource") {
        extra = {
          embed_title: title.trim() || null,
          embed_link: link.trim() || null,
          embed_desc: content.trim() || null,
          resource_category: resourceCategory,
          resource_visibility: resourceVisibility,
        };
      } else if (type === "poll") {
        const opts = pollOptions
          .map((o) => o.trim())
          .filter((o) => o.length > 0);
        if (opts.length < 2) {
          setError("Add at least 2 poll options.");
          setSubmitting(false);
          return;
        }
        const closes = new Date(
          Date.now() + pollDurationDays * 24 * 60 * 60 * 1000,
        ).toISOString();
        extra = {
          poll_options: opts.map((label) => ({ label, votes: 0 })),
          poll_closes_at: closes,
          embed_title: title.trim() || "Poll",
        };
      }

      const { error: err } = await supabase
        .from("messages")
        .insert({ ...base, ...extra });
      if (err) throw err;
      onPosted();
      onOpenChange(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to post";
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl border-border-base bg-charcoal-card text-text-primary">
        <DialogHeader>
          <DialogTitle className="font-display text-lg text-teal-light">
            New Post
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-2">
          {TYPE_OPTIONS.map((opt) => {
            if (opt.id === "announcement" && !isAdmin) return null;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => setType(opt.id)}
                className={cn(
                  "rounded-md border px-3 py-2 text-left transition-colors",
                  type === opt.id
                    ? "border-teal-mid bg-[color:var(--teal-glow)]"
                    : "border-border-base bg-charcoal-card-2 hover:border-border-teal",
                )}
              >
                <p className="text-sm font-semibold text-text-primary">
                  {opt.label}
                </p>
                <p className="text-[11px] text-text-dim">{opt.desc}</p>
              </button>
            );
          })}
        </div>

        <div className="space-y-3">
          <label className="block text-xs uppercase tracking-wider text-text-dim">
            Channel
            <select
              value={channelId}
              onChange={(e) => setChannelId(e.target.value)}
              className="mt-1 block w-full rounded-md border border-border-base bg-charcoal-card-2 px-3 py-2 text-sm text-text-primary focus:border-border-teal focus:outline-none"
            >
              {channels.map((c) => (
                <option key={c.id} value={c.id}>
                  #{c.name}
                </option>
              ))}
            </select>
          </label>

          {type === "resource" || type === "announcement" || type === "poll" ? (
            <label className="block text-xs uppercase tracking-wider text-text-dim">
              {type === "poll" ? "Question" : "Title"}
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={
                  type === "poll" ? "Ask something..." : "Headline"
                }
                className="mt-1 border-border-base bg-charcoal-card-2"
              />
            </label>
          ) : null}

          {type === "resource" ? (
            <label className="block text-xs uppercase tracking-wider text-text-dim">
              Link
              <Input
                value={link}
                onChange={(e) => setLink(e.target.value)}
                placeholder="https://..."
                className="mt-1 border-border-base bg-charcoal-card-2"
              />
            </label>
          ) : null}

          {type === "resource" ? (
            <div className="grid grid-cols-2 gap-3">
              <label className="block text-xs uppercase tracking-wider text-text-dim">
                Category
                <select
                  value={resourceCategory}
                  onChange={(e) => setResourceCategory(e.target.value)}
                  className="mt-1 block w-full rounded-md border border-border-base bg-charcoal-card-2 px-3 py-2 text-sm text-text-primary focus:border-border-teal focus:outline-none"
                >
                  {["Guide", "Template", "Video", "Tool", "Other"].map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block text-xs uppercase tracking-wider text-text-dim">
                Visibility
                <select
                  value={resourceVisibility}
                  onChange={(e) =>
                    setResourceVisibility(e.target.value as "all" | "vip")
                  }
                  className="mt-1 block w-full rounded-md border border-border-base bg-charcoal-card-2 px-3 py-2 text-sm text-text-primary focus:border-border-teal focus:outline-none"
                >
                  <option value="all">All members</option>
                  <option value="vip">VIP only</option>
                </select>
              </label>
            </div>
          ) : null}

          {type !== "poll" ? (
            <label className="block text-xs uppercase tracking-wider text-text-dim">
              {type === "resource" ? "Description" : "Message"}
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="What do you want to share?"
                rows={5}
                className="mt-1 border-border-base bg-charcoal-card-2"
              />
            </label>
          ) : (
            <div>
              <p className="text-xs uppercase tracking-wider text-text-dim">
                Options
              </p>
              <div className="mt-1 space-y-2">
                {pollOptions.map((opt, idx) => (
                  <div key={idx} className="flex gap-2">
                    <Input
                      value={opt}
                      onChange={(e) => {
                        const next = [...pollOptions];
                        next[idx] = e.target.value;
                        setPollOptions(next);
                      }}
                      placeholder={`Option ${idx + 1}`}
                      className="border-border-base bg-charcoal-card-2"
                    />
                    {pollOptions.length > 2 ? (
                      <button
                        type="button"
                        onClick={() =>
                          setPollOptions(
                            pollOptions.filter((_, i) => i !== idx),
                          )
                        }
                        className="rounded-md border border-border-base p-2 text-text-muted hover:text-text-primary"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    ) : null}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setPollOptions([...pollOptions, ""])}
                  className="inline-flex items-center gap-1 text-xs text-teal-light hover:text-teal-mid"
                >
                  <Plus className="h-3 w-3" /> Add option
                </button>
              </div>
              <label className="mt-3 block text-xs uppercase tracking-wider text-text-dim">
                Duration (days)
                <Input
                  type="number"
                  min={1}
                  max={30}
                  value={pollDurationDays}
                  onChange={(e) =>
                    setPollDurationDays(Number(e.target.value) || 1)
                  }
                  className="mt-1 border-border-base bg-charcoal-card-2"
                />
              </label>
            </div>
          )}

          {error ? (
            <p className="rounded-md border border-[oklch(0.72_0.18_25/0.4)] bg-[oklch(0.72_0.18_25/0.12)] px-3 py-2 text-xs text-danger">
              {error}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <SxyButton
            variant="ghost"
            size="sm"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            Cancel
          </SxyButton>
          <SxyButton size="sm" onClick={handleSubmit} disabled={submitting}>
            {submitting ? "Posting..." : "Post"}
          </SxyButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
