/**
 * Left rail of the Community Exchange — channels grouped by type with
 * unread badges, plus DM list. Replaces the standard nav while on /community.
 */
import * as React from "react";
import { cn } from "@/lib/utils";
import { Tag } from "@/components/sxy/Tag";
import { AvatarBadge } from "@/components/layout/Avatar";
import type {
  CommunityChannel,
  CommunityProfileLite,
} from "@/lib/community/types";

export interface DmThread {
  otherUser: CommunityProfileLite;
  lastMessageAt: string;
}

export interface ChannelSidebarProps {
  channels: CommunityChannel[];
  unreadByChannel: Record<string, number>;
  activeChannelId: string | null;
  activeDmUserId: string | null;
  dmThreads: DmThread[];
  canAccessVip: boolean;
  isAdmin: boolean;
  onSelectChannel: (channel: CommunityChannel) => void;
  onSelectDm: (otherUser: CommunityProfileLite) => void;
}

const sectionHeader =
  "px-3 pb-1 pt-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-text-dim";

function ChannelRow({
  channel,
  active,
  locked,
  unread,
  onSelect,
}: {
  channel: CommunityChannel;
  active: boolean;
  locked: boolean;
  unread: number;
  onSelect: () => void;
}) {
  const isPublic = channel.channel_type === "public";
  const glyph = isPublic ? "#" : (channel.icon ?? "#");
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "group flex w-full items-center gap-2 rounded-md border-l-2 border-transparent px-3 py-1.5 text-left text-sm transition-colors",
        active
          ? "border-teal-mid bg-[color:var(--teal-glow)] text-teal-light"
          : "text-text-muted hover:bg-charcoal-card hover:text-text-primary",
        locked && "opacity-70",
      )}
    >
      <span aria-hidden className="w-5 text-center text-base leading-none">
        {glyph}
      </span>
      <span className="flex-1 truncate">{channel.name}</span>
      {unread > 0 ? (
        <Tag variant="teal" className="px-1.5 py-0 text-[10px]">
          {unread}
        </Tag>
      ) : null}
    </button>
  );
}

export function ChannelSidebar({
  channels,
  unreadByChannel,
  activeChannelId,
  activeDmUserId,
  dmThreads,
  canAccessVip,
  isAdmin,
  onSelectChannel,
  onSelectDm,
}: ChannelSidebarProps) {
  const groups = React.useMemo(() => {
    const sorted = [...channels].sort(
      (a, b) => a.display_order - b.display_order,
    );
    return {
      public: sorted.filter((c) => c.channel_type === "public"),
      state: sorted.filter((c) => c.channel_type === "state"),
      vip: sorted.filter((c) => c.channel_type === "vip"),
    };
  }, [channels]);

  const showVipSection = canAccessVip || isAdmin || groups.vip.length > 0;

  return (
    <aside className="hidden w-[220px] shrink-0 flex-col border-r border-border-base/60 bg-charcoal-soft md:flex">
      <div className="flex h-12 items-center gap-2 border-b border-border-base/60 px-4">
        <span className="font-display text-sm italic text-gold">SXY's</span>
        <span className="font-editorial text-xs text-text-muted">
          Community
        </span>
      </div>

      <div className="flex-1 overflow-y-auto pb-6">
        <p className={sectionHeader}>Public Channels</p>
        <ul className="space-y-0.5 px-1">
          {groups.public.map((c) => (
            <li key={c.id}>
              <ChannelRow
                channel={c}
                active={activeChannelId === c.id}
                locked={false}
                unread={unreadByChannel[c.id] ?? 0}
                onSelect={() => onSelectChannel(c)}
              />
            </li>
          ))}
        </ul>

        {groups.state.length > 0 ? (
          <>
            <p className={sectionHeader}>By State</p>
            <ul className="space-y-0.5 px-1">
              {groups.state.map((c) => (
                <li key={c.id}>
                  <ChannelRow
                    channel={c}
                    active={activeChannelId === c.id}
                    locked={false}
                    unread={unreadByChannel[c.id] ?? 0}
                    onSelect={() => onSelectChannel(c)}
                  />
                </li>
              ))}
            </ul>
          </>
        ) : null}

        {showVipSection ? (
          <>
            <p className={sectionHeader}>VIP Only</p>
            <ul className="space-y-0.5 px-1">
              {groups.vip.map((c) => {
                const locked = !canAccessVip && !isAdmin;
                return (
                  <li key={c.id}>
                    <ChannelRow
                      channel={c}
                      active={activeChannelId === c.id}
                      locked={locked}
                      unread={
                        locked ? 0 : (unreadByChannel[c.id] ?? 0)
                      }
                      onSelect={() => onSelectChannel(c)}
                    />
                  </li>
                );
              })}
            </ul>
          </>
        ) : null}

        <p className={sectionHeader}>Direct Messages</p>
        {dmThreads.length === 0 ? (
          <p className="px-4 py-2 text-xs text-text-dim">
            No conversations yet
          </p>
        ) : (
          <ul className="space-y-0.5 px-1">
            {dmThreads.map((t) => {
              const active = activeDmUserId === t.otherUser.id;
              return (
                <li key={t.otherUser.id}>
                  <button
                    type="button"
                    onClick={() => onSelectDm(t.otherUser)}
                    className={cn(
                      "flex w-full items-center gap-2 rounded-md border-l-2 border-transparent px-3 py-1.5 text-left text-sm transition-colors",
                      active
                        ? "border-teal-mid bg-[color:var(--teal-glow)] text-teal-light"
                        : "text-text-muted hover:bg-charcoal-card hover:text-text-primary",
                    )}
                  >
                    <AvatarBadge
                      name={t.otherUser.full_name}
                      email={t.otherUser.email}
                      colorKey={t.otherUser.avatar_color}
                      size={22}
                    />
                    <span className="flex-1 truncate text-xs">
                      {t.otherUser.full_name ??
                        t.otherUser.email ??
                        "Member"}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </aside>
  );
}
