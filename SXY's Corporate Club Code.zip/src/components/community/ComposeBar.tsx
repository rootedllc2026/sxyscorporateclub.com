/**
 * Compose bar: formatting toolbar, auto-resizing textarea, send button.
 * Enter = send, Shift+Enter = newline.
 */
import * as React from "react";
import { cn } from "@/lib/utils";
import { SxyButton } from "@/components/sxy/SxyButton";
import {
  ArrowUp,
  Bold,
  Code,
  Image as ImageIcon,
  Italic,
  Paperclip,
  Smile,
} from "lucide-react";

export interface ComposeBarProps {
  placeholder: string;
  disabled?: boolean;
  onSend: (text: string) => Promise<void> | void;
}

export function ComposeBar({ placeholder, disabled, onSend }: ComposeBarProps) {
  const [value, setValue] = React.useState("");
  const [sending, setSending] = React.useState(false);
  const ref = React.useRef<HTMLTextAreaElement>(null);

  const autosize = React.useCallback(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }, []);

  React.useEffect(autosize, [value, autosize]);

  function wrapSelection(prefix: string, suffix = prefix) {
    const el = ref.current;
    if (!el) return;
    const start = el.selectionStart ?? 0;
    const end = el.selectionEnd ?? 0;
    const next =
      value.slice(0, start) +
      prefix +
      value.slice(start, end) +
      suffix +
      value.slice(end);
    setValue(next);
    requestAnimationFrame(() => {
      el.focus();
      const cursor = end + prefix.length + suffix.length;
      el.setSelectionRange(cursor, cursor);
    });
  }

  async function handleSend() {
    const text = value.trim();
    if (!text || sending || disabled) return;
    setSending(true);
    try {
      await onSend(text);
      setValue("");
    } finally {
      setSending(false);
    }
  }

  function handleKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  }

  const btnClass =
    "rounded p-1.5 text-text-muted hover:bg-charcoal-card hover:text-text-primary disabled:opacity-40";

  return (
    <div className="border-t border-border-base/60 bg-charcoal-soft px-6 py-3">
      <div className="rounded-lg border border-border-base bg-charcoal-card focus-within:border-border-teal">
        <div className="flex items-center gap-1 border-b border-border-base px-2 py-1.5">
          <button
            type="button"
            className={btnClass}
            onClick={() => wrapSelection("**")}
            aria-label="Bold"
          >
            <Bold className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            className={btnClass}
            onClick={() => wrapSelection("*")}
            aria-label="Italic"
          >
            <Italic className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            className={btnClass}
            onClick={() => wrapSelection("`")}
            aria-label="Code"
          >
            <Code className="h-3.5 w-3.5" />
          </button>
          <span className="mx-1 h-4 w-px bg-border-base" aria-hidden />
          <button
            type="button"
            className={btnClass}
            disabled
            aria-label="Attach file (coming soon)"
            title="Coming soon"
          >
            <Paperclip className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            className={btnClass}
            disabled
            aria-label="Image (coming soon)"
            title="Coming soon"
          >
            <ImageIcon className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            className={btnClass}
            disabled
            aria-label="GIF (coming soon)"
            title="Coming soon"
          >
            <span className="text-[10px] font-semibold">GIF</span>
          </button>
          <button
            type="button"
            className={btnClass}
            disabled
            aria-label="Emoji"
          >
            <Smile className="h-3.5 w-3.5" />
          </button>
        </div>

        <textarea
          ref={ref}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKey}
          placeholder={placeholder}
          rows={1}
          disabled={disabled}
          className={cn(
            "block w-full resize-none border-0 bg-transparent px-3 py-2 text-sm text-text-primary placeholder:text-text-dim focus:outline-none",
          )}
        />

        <div className="flex items-center justify-between gap-2 border-t border-border-base px-3 py-2">
          <span className="text-[11px] text-text-dim">
            <kbd className="rounded border border-border-base bg-charcoal-card-2 px-1 py-0.5 text-[10px]">
              Enter
            </kbd>{" "}
            to send ·{" "}
            <kbd className="rounded border border-border-base bg-charcoal-card-2 px-1 py-0.5 text-[10px]">
              Shift+Enter
            </kbd>{" "}
            for new line
          </span>
          <SxyButton
            type="button"
            size="sm"
            disabled={!value.trim() || sending || disabled}
            onClick={handleSend}
          >
            <ArrowUp className="h-3.5 w-3.5" />
            Send
          </SxyButton>
        </div>
      </div>
    </div>
  );
}
