import { toast } from "sonner";
import type { PostgrestError } from "@supabase/supabase-js";

/**
 * Centralized error handler for Supabase queries and mutations.
 *
 * - Auth errors (expired JWT, invalid session) → sign out + redirect to /login
 *   with a toast explaining what happened.
 * - Network errors (offline, fetch failed) → toast and let caller decide.
 * - PostgREST errors (RLS denial, constraint violations) → toast a friendly
 *   message and return the original error so callers can branch on `.code`.
 *
 * Usage:
 *   const { data, error } = await supabase.from("posts").select();
 *   if (error) return handleSupabaseError(error, "Failed to load posts");
 */

const AUTH_ERROR_CODES = new Set([
  "PGRST301", // JWT expired
  "PGRST302", // JWT invalid
  "401",
]);

const AUTH_ERROR_MESSAGES = [
  "jwt expired",
  "invalid jwt",
  "invalid token",
  "no api key found",
  "session_not_found",
  "user_not_found",
];

export function isAuthError(error: unknown): boolean {
  if (!error) return false;
  const err = error as { code?: string; status?: number; message?: string };

  if (err.code && AUTH_ERROR_CODES.has(err.code)) return true;
  if (err.status === 401) return true;
  if (err.message) {
    const msg = err.message.toLowerCase();
    return AUTH_ERROR_MESSAGES.some((m) => msg.includes(m));
  }
  return false;
}

export function isNetworkError(error: unknown): boolean {
  if (!error) return false;
  const err = error as { message?: string; name?: string };
  if (err.name === "TypeError" && err.message?.includes("fetch")) return true;
  if (err.message) {
    const msg = err.message.toLowerCase();
    return (
      msg.includes("failed to fetch") ||
      msg.includes("network request failed") ||
      msg.includes("networkerror")
    );
  }
  return false;
}

/**
 * Show an appropriate toast for a Supabase error and, when the failure looks
 * like an auth issue, redirect the user to /login. Returns the original error
 * so callers can still branch on it.
 */
export function handleSupabaseError(
  error: PostgrestError | Error | unknown,
  fallbackMessage = "Something went wrong",
): unknown {
  if (!error) return error;

  // Auth: hard-redirect, the AuthContext listener will clean up state.
  if (isAuthError(error)) {
    toast.error("Your session expired. Please sign in again.");
    if (typeof window !== "undefined") {
      const here = window.location.pathname + window.location.search;
      // Avoid loops if we're already on a public auth page.
      if (!/^\/(login|signup|reset-password|update-password|auth\/callback)/.test(window.location.pathname)) {
        window.location.href = `/login?redirect=${encodeURIComponent(here)}`;
      }
    }
    return error;
  }

  // Network: friendly toast, caller stays put.
  if (isNetworkError(error)) {
    toast.error("Network error — check your connection and try again.");
    return error;
  }

  // Everything else: show the message if it looks user-friendly,
  // otherwise the fallback.
  const err = error as { message?: string };
  const msg = err.message ?? "";
  // PostgREST messages like "duplicate key value violates unique constraint"
  // are too technical for end users — use fallback unless message is short.
  const friendly = msg && msg.length < 120 && !/violates|constraint|relation/i.test(msg);
  toast.error(friendly ? msg : fallbackMessage);
  return error;
}
