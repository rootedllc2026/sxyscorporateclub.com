import * as React from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

/**
 * Profile row matching public.profiles after the 0001 migration.
 */
export type MembershipTier = "free" | "paid" | "annual" | "vip";

export interface UserProfile {
  id: string;
  email: string | null;
  full_name: string | null;
  state: string | null;
  tier: MembershipTier;
  bio: string | null;
  business_name: string | null;
  city: string | null;
  industry: string | null;
  website_url: string | null;
  avatar_color: string;
  created_at: string;
  updated_at: string;
}

export interface AuthContextValue {
  session: Session | null;
  currentUser: User | null;
  userProfile: UserProfile | null;
  userTier: MembershipTier | null;
  isAdmin: boolean;
  isAuthenticated: boolean;
  isLoading: boolean;
  /** Refetch the profile + role from the database. */
  refreshProfile: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = React.createContext<AuthContextValue | undefined>(
  undefined,
);

/**
 * Wrap the entire app in this provider so any page can read the current user,
 * profile, role and signOut function. Subscribes to Supabase auth changes so
 * login / logout / token refresh propagates automatically.
 */
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = React.useState<Session | null>(null);
  const [userProfile, setUserProfile] = React.useState<UserProfile | null>(
    null,
  );
  const [isAdmin, setIsAdmin] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(true);

  const loadProfileAndRole = React.useCallback(async (userId: string) => {
    // Fetch profile + admin role in parallel. Using maybeSingle so a brand-new
    // signup that hasn't fired the trigger yet doesn't crash.
    const [{ data: profile }, { data: roles }] = await Promise.all([
      supabase
        .from("profiles")
        .select(
          "id, email, full_name, state, tier, bio, business_name, city, industry, website_url, avatar_color, created_at, updated_at",
        )
        .eq("id", userId)
        .maybeSingle(),
      supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .eq("role", "admin"),
    ]);

    setUserProfile((profile as UserProfile | null) ?? null);
    setIsAdmin((roles?.length ?? 0) > 0);
  }, []);

  React.useEffect(() => {
    let mounted = true;

    // 1) Subscribe FIRST so we never miss an auth event.
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, nextSession) => {
      if (!mounted) return;
      setSession(nextSession);

      // Defer DB calls so we don't block the auth callback (avoids deadlocks).
      if (nextSession?.user) {
        setTimeout(() => {
          if (!mounted) return;
          void loadProfileAndRole(nextSession.user.id);
        }, 0);
      } else {
        setUserProfile(null);
        setIsAdmin(false);
      }

      // If the session is invalidated server-side (token revoked, password
      // reset elsewhere, etc.), bounce the user to /login from any protected
      // page. Public auth pages are excluded so we don't loop.
      if (event === "SIGNED_OUT" && typeof window !== "undefined") {
        const path = window.location.pathname;
        const isPublicAuthPage =
          /^\/(login|signup|reset-password|update-password|auth\/callback|$)/.test(
            path,
          );
        if (!isPublicAuthPage && path !== "/") {
          window.location.href = `/login?redirect=${encodeURIComponent(
            path + window.location.search,
          )}`;
        }
      }
    });

    // 2) Then hydrate the initial session from storage.
    void supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      if (data.session?.user) {
        await loadProfileAndRole(data.session.user.id);
      }
      setIsLoading(false);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [loadProfileAndRole]);

  const refreshProfile = React.useCallback(async () => {
    if (session?.user) await loadProfileAndRole(session.user.id);
  }, [session, loadProfileAndRole]);

  const signOut = React.useCallback(async () => {
    await supabase.auth.signOut();
    // Hard nav clears any stale state and lands the user back on /login.
    if (typeof window !== "undefined") {
      window.location.href = "/login";
    }
  }, []);

  const value = React.useMemo<AuthContextValue>(
    () => ({
      session,
      currentUser: session?.user ?? null,
      userProfile,
      userTier: userProfile?.tier ?? null,
      isAdmin,
      isAuthenticated: !!session?.user,
      isLoading,
      refreshProfile,
      signOut,
    }),
    [session, userProfile, isAdmin, isLoading, refreshProfile, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = React.useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used inside <AuthProvider>");
  }
  return ctx;
}
