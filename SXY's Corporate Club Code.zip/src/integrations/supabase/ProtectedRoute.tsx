import * as React from "react";
import { Navigate, useLocation } from "@tanstack/react-router";
import { useAuth } from "@/integrations/supabase/AuthContext";

/**
 * Centered teal spinner used while we wait for auth to resolve. Uses
 * role="status" + aria-live so screen readers announce the loading state
 * and an sr-only label so the spinner conveys meaning beyond its color.
 */
function AuthLoading() {
  return (
    <div
      className="flex min-h-screen items-center justify-center bg-charcoal"
      role="status"
      aria-live="polite"
    >
      <div
        className="h-12 w-12 animate-spin rounded-full border-4 border-teal-deep/30 border-t-teal-mid"
        aria-hidden="true"
      />
      <span className="sr-only">Loading…</span>
    </div>
  );
}

/**
 * Wrap any route's component with <ProtectedRoute> to require an authenticated
 * Supabase session. While we're checking, we show a teal spinner. If there's
 * no session once loading resolves, we redirect to /login and remember the
 * page they were trying to reach so we can send them back after sign-in.
 */
export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();
  const redirectTo =
    typeof window === "undefined"
      ? location.pathname
      : window.location.pathname + window.location.search;

  if (isLoading) return <AuthLoading />;

  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        search={{ redirect: redirectTo }}
        replace
      />
    );
  }

  return <>{children}</>;
}

/**
 * Same as ProtectedRoute but additionally requires the admin role.
 */
export function AdminRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isAdmin, isLoading } = useAuth();
  const location = useLocation();
  const redirectTo =
    typeof window === "undefined"
      ? location.pathname
      : window.location.pathname + window.location.search;

  if (isLoading) return <AuthLoading />;

  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        search={{ redirect: redirectTo }}
        replace
      />
    );
  }

  if (!isAdmin) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}
