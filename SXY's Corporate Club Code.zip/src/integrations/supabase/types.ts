export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_password_set_log: {
        Row: {
          admin_user_id: string
          created_at: string
          id: string
          reason: string | null
          target_email: string
          target_user_id: string
        }
        Insert: {
          admin_user_id: string
          created_at?: string
          id?: string
          reason?: string | null
          target_email: string
          target_user_id: string
        }
        Update: {
          admin_user_id?: string
          created_at?: string
          id?: string
          reason?: string | null
          target_email?: string
          target_user_id?: string
        }
        Relationships: []
      }
      apprenticeship_applications: {
        Row: {
          applicant_id: string
          cover_note: string | null
          created_at: string
          decided_at: string | null
          decision_note: string | null
          id: string
          portfolio_links: Json
          program_id: string
          resume_path: string | null
          status: string
          structured_answers: Json
          updated_at: string
          video_path: string | null
        }
        Insert: {
          applicant_id: string
          cover_note?: string | null
          created_at?: string
          decided_at?: string | null
          decision_note?: string | null
          id?: string
          portfolio_links?: Json
          program_id: string
          resume_path?: string | null
          status?: string
          structured_answers?: Json
          updated_at?: string
          video_path?: string | null
        }
        Update: {
          applicant_id?: string
          cover_note?: string | null
          created_at?: string
          decided_at?: string | null
          decision_note?: string | null
          id?: string
          portfolio_links?: Json
          program_id?: string
          resume_path?: string | null
          status?: string
          structured_answers?: Json
          updated_at?: string
          video_path?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "apprenticeship_applications_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "apprenticeship_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      apprenticeship_messages: {
        Row: {
          apprenticeship_id: string
          body: string
          created_at: string
          id: string
          sender_id: string
        }
        Insert: {
          apprenticeship_id: string
          body: string
          created_at?: string
          id?: string
          sender_id: string
        }
        Update: {
          apprenticeship_id?: string
          body?: string
          created_at?: string
          id?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "apprenticeship_messages_apprenticeship_id_fkey"
            columns: ["apprenticeship_id"]
            isOneToOne: false
            referencedRelation: "apprenticeships"
            referencedColumns: ["id"]
          },
        ]
      }
      apprenticeship_milestones: {
        Row: {
          apprenticeship_id: string
          approved_at: string | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          sort_order: number
          status: string
          submitted_at: string | null
          title: string
          updated_at: string
        }
        Insert: {
          apprenticeship_id: string
          approved_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          sort_order?: number
          status?: string
          submitted_at?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          apprenticeship_id?: string
          approved_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          sort_order?: number
          status?: string
          submitted_at?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "apprenticeship_milestones_apprenticeship_id_fkey"
            columns: ["apprenticeship_id"]
            isOneToOne: false
            referencedRelation: "apprenticeships"
            referencedColumns: ["id"]
          },
        ]
      }
      apprenticeship_programs: {
        Row: {
          created_at: string
          description: string
          duration_weeks: number | null
          id: string
          industry: string | null
          location: string | null
          owner_id: string
          require_cover_note: boolean
          require_portfolio: boolean
          require_resume: boolean
          require_video: boolean
          start_date: string | null
          status: string
          stipend_description: string | null
          structured_questions: Json
          summary: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description: string
          duration_weeks?: number | null
          id?: string
          industry?: string | null
          location?: string | null
          owner_id: string
          require_cover_note?: boolean
          require_portfolio?: boolean
          require_resume?: boolean
          require_video?: boolean
          start_date?: string | null
          status?: string
          stipend_description?: string | null
          structured_questions?: Json
          summary: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string
          duration_weeks?: number | null
          id?: string
          industry?: string | null
          location?: string | null
          owner_id?: string
          require_cover_note?: boolean
          require_portfolio?: boolean
          require_resume?: boolean
          require_video?: boolean
          start_date?: string | null
          status?: string
          stipend_description?: string | null
          structured_questions?: Json
          summary?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      apprenticeships: {
        Row: {
          application_id: string
          apprentice_id: string
          completed_at: string | null
          created_at: string
          id: string
          owner_id: string
          program_id: string
          started_at: string
          status: string
          updated_at: string
        }
        Insert: {
          application_id: string
          apprentice_id: string
          completed_at?: string | null
          created_at?: string
          id?: string
          owner_id: string
          program_id: string
          started_at?: string
          status?: string
          updated_at?: string
        }
        Update: {
          application_id?: string
          apprentice_id?: string
          completed_at?: string | null
          created_at?: string
          id?: string
          owner_id?: string
          program_id?: string
          started_at?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "apprenticeships_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: true
            referencedRelation: "apprenticeship_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "apprenticeships_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "apprenticeship_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      bids: {
        Row: {
          amount: number | null
          available_from: string | null
          bidder_id: string
          cover_letter: string | null
          created_at: string
          documents: string[]
          id: string
          portfolio_url: string | null
          project_id: string
          proposal: string | null
          proposed_price: number | null
          status: Database["public"]["Enums"]["bid_status"]
          timeline: string | null
          updated_at: string
          years_experience: string | null
        }
        Insert: {
          amount?: number | null
          available_from?: string | null
          bidder_id: string
          cover_letter?: string | null
          created_at?: string
          documents?: string[]
          id?: string
          portfolio_url?: string | null
          project_id: string
          proposal?: string | null
          proposed_price?: number | null
          status?: Database["public"]["Enums"]["bid_status"]
          timeline?: string | null
          updated_at?: string
          years_experience?: string | null
        }
        Update: {
          amount?: number | null
          available_from?: string | null
          bidder_id?: string
          cover_letter?: string | null
          created_at?: string
          documents?: string[]
          id?: string
          portfolio_url?: string | null
          project_id?: string
          proposal?: string | null
          proposed_price?: number | null
          status?: Database["public"]["Enums"]["bid_status"]
          timeline?: string | null
          updated_at?: string
          years_experience?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bids_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "open_projects_with_bids"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bids_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      booking_documents: {
        Row: {
          booking_id: string
          created_at: string
          doc_type: string
          file_name: string
          id: string
          mime_type: string | null
          note: string | null
          size_bytes: number | null
          storage_path: string
          uploaded_by: string
        }
        Insert: {
          booking_id: string
          created_at?: string
          doc_type?: string
          file_name: string
          id?: string
          mime_type?: string | null
          note?: string | null
          size_bytes?: number | null
          storage_path: string
          uploaded_by: string
        }
        Update: {
          booking_id?: string
          created_at?: string
          doc_type?: string
          file_name?: string
          id?: string
          mime_type?: string | null
          note?: string | null
          size_bytes?: number | null
          storage_path?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "booking_documents_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      bookings: {
        Row: {
          booked_date: string
          booked_time: string | null
          business_page_id: string
          buyer_id: string
          created_at: string
          id: string
          net_to_provider: number
          notes: string | null
          paid_at: string | null
          payment_intent_id: string | null
          payment_method: string
          platform_fee: number
          provider_id: string
          service_amount: number
          service_id: string | null
          status: Database["public"]["Enums"]["booking_status"]
          total_amount: number
          updated_at: string
        }
        Insert: {
          booked_date: string
          booked_time?: string | null
          business_page_id: string
          buyer_id: string
          created_at?: string
          id?: string
          net_to_provider?: number
          notes?: string | null
          paid_at?: string | null
          payment_intent_id?: string | null
          payment_method?: string
          platform_fee?: number
          provider_id: string
          service_amount?: number
          service_id?: string | null
          status?: Database["public"]["Enums"]["booking_status"]
          total_amount?: number
          updated_at?: string
        }
        Update: {
          booked_date?: string
          booked_time?: string | null
          business_page_id?: string
          buyer_id?: string
          created_at?: string
          id?: string
          net_to_provider?: number
          notes?: string | null
          paid_at?: string | null
          payment_intent_id?: string | null
          payment_method?: string
          platform_fee?: number
          provider_id?: string
          service_amount?: number
          service_id?: string | null
          status?: Database["public"]["Enums"]["booking_status"]
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_business_page_id_fkey"
            columns: ["business_page_id"]
            isOneToOne: false
            referencedRelation: "business_pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_business_page_id_fkey"
            columns: ["business_page_id"]
            isOneToOne: false
            referencedRelation: "referrals_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "referral_services"
            referencedColumns: ["id"]
          },
        ]
      }
      business_pages: {
        Row: {
          allow_virtual: boolean
          available_days: string[]
          avg_rating: number | null
          banner_color: string | null
          booking_lead_hours: number | null
          business_name: string
          category: Database["public"]["Enums"]["referral_category"]
          created_at: string
          description: string | null
          end_time: string | null
          icon_emoji: string | null
          id: string
          is_featured: boolean
          logo_url: string | null
          owner_id: string
          platform_fee_pct: number
          require_deposit: boolean
          require_intake_form: boolean
          service_area: string | null
          session_length_min: number | null
          start_time: string | null
          starting_price: number | null
          status: Database["public"]["Enums"]["business_page_status"]
          total_bookings: number
          total_revenue: number
          total_reviews: number
          updated_at: string
          website_url: string | null
        }
        Insert: {
          allow_virtual?: boolean
          available_days?: string[]
          avg_rating?: number | null
          banner_color?: string | null
          booking_lead_hours?: number | null
          business_name: string
          category?: Database["public"]["Enums"]["referral_category"]
          created_at?: string
          description?: string | null
          end_time?: string | null
          icon_emoji?: string | null
          id?: string
          is_featured?: boolean
          logo_url?: string | null
          owner_id: string
          platform_fee_pct?: number
          require_deposit?: boolean
          require_intake_form?: boolean
          service_area?: string | null
          session_length_min?: number | null
          start_time?: string | null
          starting_price?: number | null
          status?: Database["public"]["Enums"]["business_page_status"]
          total_bookings?: number
          total_revenue?: number
          total_reviews?: number
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          allow_virtual?: boolean
          available_days?: string[]
          avg_rating?: number | null
          banner_color?: string | null
          booking_lead_hours?: number | null
          business_name?: string
          category?: Database["public"]["Enums"]["referral_category"]
          created_at?: string
          description?: string | null
          end_time?: string | null
          icon_emoji?: string | null
          id?: string
          is_featured?: boolean
          logo_url?: string | null
          owner_id?: string
          platform_fee_pct?: number
          require_deposit?: boolean
          require_intake_form?: boolean
          service_area?: string | null
          session_length_min?: number | null
          start_time?: string | null
          starting_price?: number | null
          status?: Database["public"]["Enums"]["business_page_status"]
          total_bookings?: number
          total_revenue?: number
          total_reviews?: number
          updated_at?: string
          website_url?: string | null
        }
        Relationships: []
      }
      channel_visits: {
        Row: {
          channel_id: string
          last_visited: string
          user_id: string
        }
        Insert: {
          channel_id: string
          last_visited?: string
          user_id: string
        }
        Update: {
          channel_id?: string
          last_visited?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "channel_visits_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      channels: {
        Row: {
          channel_type: Database["public"]["Enums"]["channel_type"]
          created_at: string
          description: string | null
          display_order: number
          icon: string | null
          id: string
          is_system: boolean
          name: string
          slug: string
          state_code: string | null
        }
        Insert: {
          channel_type?: Database["public"]["Enums"]["channel_type"]
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          is_system?: boolean
          name: string
          slug: string
          state_code?: string | null
        }
        Update: {
          channel_type?: Database["public"]["Enums"]["channel_type"]
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          is_system?: boolean
          name?: string
          slug?: string
          state_code?: string | null
        }
        Relationships: []
      }
      chores: {
        Row: {
          approved_at: string | null
          child_user_id: string
          created_at: string
          description: string | null
          due_at: string | null
          id: string
          parent_user_id: string
          reward_credits: number
          status: Database["public"]["Enums"]["chore_status"]
          title: string
          updated_at: string
        }
        Insert: {
          approved_at?: string | null
          child_user_id: string
          created_at?: string
          description?: string | null
          due_at?: string | null
          id?: string
          parent_user_id: string
          reward_credits: number
          status?: Database["public"]["Enums"]["chore_status"]
          title: string
          updated_at?: string
        }
        Update: {
          approved_at?: string | null
          child_user_id?: string
          created_at?: string
          description?: string | null
          due_at?: string | null
          id?: string
          parent_user_id?: string
          reward_credits?: number
          status?: Database["public"]["Enums"]["chore_status"]
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      credit_ledger: {
        Row: {
          chore_id: string | null
          counterparty_user_id: string | null
          created_at: string
          delta_credits: number
          id: string
          note: string | null
          reason: Database["public"]["Enums"]["ledger_reason"]
          redeemable_id: string | null
          user_id: string
        }
        Insert: {
          chore_id?: string | null
          counterparty_user_id?: string | null
          created_at?: string
          delta_credits: number
          id?: string
          note?: string | null
          reason: Database["public"]["Enums"]["ledger_reason"]
          redeemable_id?: string | null
          user_id: string
        }
        Update: {
          chore_id?: string | null
          counterparty_user_id?: string | null
          created_at?: string
          delta_credits?: number
          id?: string
          note?: string | null
          reason?: Database["public"]["Enums"]["ledger_reason"]
          redeemable_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      event_registrations: {
        Row: {
          created_at: string
          event_id: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_registrations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          access_level: Database["public"]["Enums"]["event_access"]
          archive_recording: boolean
          created_at: string
          created_by: string | null
          description: string | null
          duration_min: number | null
          ends_at: string | null
          host_name: string | null
          icon_emoji: string
          id: string
          join_url: string | null
          location: string | null
          meeting_url: string | null
          notify_members: boolean
          platform: string | null
          post_to_general: boolean
          recording_access: Database["public"]["Enums"]["event_access"] | null
          recording_url: string | null
          registrant_count: number
          starts_at: string
          status: Database["public"]["Enums"]["event_status"]
          title: string
        }
        Insert: {
          access_level?: Database["public"]["Enums"]["event_access"]
          archive_recording?: boolean
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration_min?: number | null
          ends_at?: string | null
          host_name?: string | null
          icon_emoji?: string
          id?: string
          join_url?: string | null
          location?: string | null
          meeting_url?: string | null
          notify_members?: boolean
          platform?: string | null
          post_to_general?: boolean
          recording_access?: Database["public"]["Enums"]["event_access"] | null
          recording_url?: string | null
          registrant_count?: number
          starts_at: string
          status?: Database["public"]["Enums"]["event_status"]
          title: string
        }
        Update: {
          access_level?: Database["public"]["Enums"]["event_access"]
          archive_recording?: boolean
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration_min?: number | null
          ends_at?: string | null
          host_name?: string | null
          icon_emoji?: string
          id?: string
          join_url?: string | null
          location?: string | null
          meeting_url?: string | null
          notify_members?: boolean
          platform?: string | null
          post_to_general?: boolean
          recording_access?: Database["public"]["Enums"]["event_access"] | null
          recording_url?: string | null
          registrant_count?: number
          starts_at?: string
          status?: Database["public"]["Enums"]["event_status"]
          title?: string
        }
        Relationships: []
      }
      game_progress: {
        Row: {
          completed_at: string | null
          created_at: string
          game_key: string
          id: string
          metadata: Json
          score: number
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          game_key: string
          id?: string
          metadata?: Json
          score?: number
          user_id: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          game_key?: string
          id?: string
          metadata?: Json
          score?: number
          user_id?: string
        }
        Relationships: []
      }
      intake_submissions: {
        Row: {
          business_name: string | null
          email: string
          full_name: string
          id: string
          message: string | null
          phone: string | null
          preferred_contact: string
          service_interest: string
          status: string
          submitted_at: string
        }
        Insert: {
          business_name?: string | null
          email: string
          full_name: string
          id?: string
          message?: string | null
          phone?: string | null
          preferred_contact?: string
          service_interest: string
          status?: string
          submitted_at?: string
        }
        Update: {
          business_name?: string | null
          email?: string
          full_name?: string
          id?: string
          message?: string | null
          phone?: string | null
          preferred_contact?: string
          service_interest?: string
          status?: string
          submitted_at?: string
        }
        Relationships: []
      }
      invoices: {
        Row: {
          amount: number
          client_name: string
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          invoice_number: string
          issued_at: string
          notes: string | null
          paid_at: string | null
          status: Database["public"]["Enums"]["invoice_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          client_name: string
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          invoice_number?: string
          issued_at?: string
          notes?: string | null
          paid_at?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          client_name?: string
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          invoice_number?: string
          issued_at?: string
          notes?: string | null
          paid_at?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      kid_business_pages: {
        Row: {
          admin_approved_at: string | null
          admin_approved_by: string | null
          category: string | null
          created_at: string
          description: string | null
          emoji: string | null
          id: string
          name: string
          owner_user_id: string
          parent_approved_at: string | null
          parent_approved_by: string | null
          rejection_reason: string | null
          status: Database["public"]["Enums"]["kid_business_status"]
          tagline: string | null
          updated_at: string
          youtube_url: string | null
        }
        Insert: {
          admin_approved_at?: string | null
          admin_approved_by?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          emoji?: string | null
          id?: string
          name: string
          owner_user_id: string
          parent_approved_at?: string | null
          parent_approved_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["kid_business_status"]
          tagline?: string | null
          updated_at?: string
          youtube_url?: string | null
        }
        Update: {
          admin_approved_at?: string | null
          admin_approved_by?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          emoji?: string | null
          id?: string
          name?: string
          owner_user_id?: string
          parent_approved_at?: string | null
          parent_approved_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["kid_business_status"]
          tagline?: string | null
          updated_at?: string
          youtube_url?: string | null
        }
        Relationships: []
      }
      kiddo_profiles: {
        Row: {
          age_band: Database["public"]["Enums"]["kiddo_age_band"]
          avatar_emoji: string | null
          created_at: string
          date_of_birth: string
          display_name: string
          id: string
          parental_consent_at: string | null
          privacy_mode: boolean
          updated_at: string
        }
        Insert: {
          age_band: Database["public"]["Enums"]["kiddo_age_band"]
          avatar_emoji?: string | null
          created_at?: string
          date_of_birth: string
          display_name: string
          id: string
          parental_consent_at?: string | null
          privacy_mode?: boolean
          updated_at?: string
        }
        Update: {
          age_band?: Database["public"]["Enums"]["kiddo_age_band"]
          avatar_emoji?: string | null
          created_at?: string
          date_of_birth?: string
          display_name?: string
          id?: string
          parental_consent_at?: string | null
          privacy_mode?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      kiddo_video_views: {
        Row: {
          created_at: string
          credits_awarded: number
          id: string
          video_id: string
          viewer_user_id: string
        }
        Insert: {
          created_at?: string
          credits_awarded?: number
          id?: string
          video_id: string
          viewer_user_id: string
        }
        Update: {
          created_at?: string
          credits_awarded?: number
          id?: string
          video_id?: string
          viewer_user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "kiddo_video_views_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "kiddo_videos"
            referencedColumns: ["id"]
          },
        ]
      }
      kiddo_videos: {
        Row: {
          admin_approved_at: string | null
          admin_approved_by: string | null
          created_at: string
          creator_user_id: string | null
          credits_per_view: number
          description: string | null
          duration_seconds: number
          id: string
          is_published: boolean
          kind: Database["public"]["Enums"]["kiddo_video_kind"]
          parent_approved_at: string | null
          parent_approved_by: string | null
          rejection_reason: string | null
          status: Database["public"]["Enums"]["kiddo_video_status"]
          storage_path: string | null
          thumbnail_url: string | null
          title: string
          topic: string | null
          updated_at: string
          video_url: string | null
          view_count: number
        }
        Insert: {
          admin_approved_at?: string | null
          admin_approved_by?: string | null
          created_at?: string
          creator_user_id?: string | null
          credits_per_view?: number
          description?: string | null
          duration_seconds?: number
          id?: string
          is_published?: boolean
          kind?: Database["public"]["Enums"]["kiddo_video_kind"]
          parent_approved_at?: string | null
          parent_approved_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["kiddo_video_status"]
          storage_path?: string | null
          thumbnail_url?: string | null
          title: string
          topic?: string | null
          updated_at?: string
          video_url?: string | null
          view_count?: number
        }
        Update: {
          admin_approved_at?: string | null
          admin_approved_by?: string | null
          created_at?: string
          creator_user_id?: string | null
          credits_per_view?: number
          description?: string | null
          duration_seconds?: number
          id?: string
          is_published?: boolean
          kind?: Database["public"]["Enums"]["kiddo_video_kind"]
          parent_approved_at?: string | null
          parent_approved_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["kiddo_video_status"]
          storage_path?: string | null
          thumbnail_url?: string | null
          title?: string
          topic?: string | null
          updated_at?: string
          video_url?: string | null
          view_count?: number
        }
        Relationships: []
      }
      kiddo_wallets: {
        Row: {
          balance_credits: number
          created_at: string
          lifetime_earned: number
          lifetime_spent: number
          updated_at: string
          user_id: string
        }
        Insert: {
          balance_credits?: number
          created_at?: string
          lifetime_earned?: number
          lifetime_spent?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          balance_credits?: number
          created_at?: string
          lifetime_earned?: number
          lifetime_spent?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          body: string | null
          channel: string
          channel_id: string | null
          content: string | null
          created_at: string
          dm_recipient_id: string | null
          embed_desc: string | null
          embed_link: string | null
          embed_title: string | null
          id: string
          is_announcement: boolean
          is_pinned: boolean
          pinned_at: string | null
          pinned_by: string | null
          poll_closes_at: string | null
          poll_options: Json | null
          post_type: Database["public"]["Enums"]["post_type"]
          resource_category: string | null
          resource_visibility: string | null
          sender_id: string
        }
        Insert: {
          body?: string | null
          channel?: string
          channel_id?: string | null
          content?: string | null
          created_at?: string
          dm_recipient_id?: string | null
          embed_desc?: string | null
          embed_link?: string | null
          embed_title?: string | null
          id?: string
          is_announcement?: boolean
          is_pinned?: boolean
          pinned_at?: string | null
          pinned_by?: string | null
          poll_closes_at?: string | null
          poll_options?: Json | null
          post_type?: Database["public"]["Enums"]["post_type"]
          resource_category?: string | null
          resource_visibility?: string | null
          sender_id: string
        }
        Update: {
          body?: string | null
          channel?: string
          channel_id?: string | null
          content?: string | null
          created_at?: string
          dm_recipient_id?: string | null
          embed_desc?: string | null
          embed_link?: string | null
          embed_title?: string | null
          id?: string
          is_announcement?: boolean
          is_pinned?: boolean
          pinned_at?: string | null
          pinned_by?: string | null
          poll_closes_at?: string | null
          poll_options?: Json | null
          post_type?: Database["public"]["Enums"]["post_type"]
          resource_category?: string | null
          resource_visibility?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      parent_child_links: {
        Row: {
          child_user_id: string
          created_at: string
          id: string
          parent_user_id: string
          relationship: string | null
          status: Database["public"]["Enums"]["parent_link_status"]
          updated_at: string
        }
        Insert: {
          child_user_id: string
          created_at?: string
          id?: string
          parent_user_id: string
          relationship?: string | null
          status?: Database["public"]["Enums"]["parent_link_status"]
          updated_at?: string
        }
        Update: {
          child_user_id?: string
          created_at?: string
          id?: string
          parent_user_id?: string
          relationship?: string | null
          status?: Database["public"]["Enums"]["parent_link_status"]
          updated_at?: string
        }
        Relationships: []
      }
      payout_audit_log: {
        Row: {
          actor_id: string | null
          created_at: string
          from_status: string | null
          id: string
          note: string | null
          payout_id: string
          to_status: string
        }
        Insert: {
          actor_id?: string | null
          created_at?: string
          from_status?: string | null
          id?: string
          note?: string | null
          payout_id: string
          to_status: string
        }
        Update: {
          actor_id?: string | null
          created_at?: string
          from_status?: string | null
          id?: string
          note?: string | null
          payout_id?: string
          to_status?: string
        }
        Relationships: [
          {
            foreignKeyName: "payout_audit_log_payout_id_fkey"
            columns: ["payout_id"]
            isOneToOne: false
            referencedRelation: "payouts"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_methods: {
        Row: {
          created_at: string
          destination: string
          id: string
          is_default: boolean
          label: string
          method: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          destination: string
          id?: string
          is_default?: boolean
          label: string
          method: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          destination?: string
          id?: string
          is_default?: boolean
          label?: string
          method?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      payouts: {
        Row: {
          amount: number
          bulk_action_id: string | null
          created_at: string
          destination: string | null
          id: string
          method: string | null
          notes: string | null
          processed_at: string | null
          processed_by: string | null
          requested_at: string
          status: Database["public"]["Enums"]["payout_status"]
          user_id: string
        }
        Insert: {
          amount: number
          bulk_action_id?: string | null
          created_at?: string
          destination?: string | null
          id?: string
          method?: string | null
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          requested_at?: string
          status?: Database["public"]["Enums"]["payout_status"]
          user_id: string
        }
        Update: {
          amount?: number
          bulk_action_id?: string | null
          created_at?: string
          destination?: string | null
          id?: string
          method?: string | null
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          requested_at?: string
          status?: Database["public"]["Enums"]["payout_status"]
          user_id?: string
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          admin_notification_emails: string[]
          fee_pct_basic: number
          fee_pct_featured: number
          fee_pct_standard: number
          id: number
          notify_on_approval: boolean
          notify_on_new_request: boolean
          payout_default_method: string
          payout_min_threshold: number
          payout_window_days: number
          updated_at: string
          weekly_digest: boolean
        }
        Insert: {
          admin_notification_emails?: string[]
          fee_pct_basic?: number
          fee_pct_featured?: number
          fee_pct_standard?: number
          id?: number
          notify_on_approval?: boolean
          notify_on_new_request?: boolean
          payout_default_method?: string
          payout_min_threshold?: number
          payout_window_days?: number
          updated_at?: string
          weekly_digest?: boolean
        }
        Update: {
          admin_notification_emails?: string[]
          fee_pct_basic?: number
          fee_pct_featured?: number
          fee_pct_standard?: number
          id?: number
          notify_on_approval?: boolean
          notify_on_new_request?: boolean
          payout_default_method?: string
          payout_min_threshold?: number
          payout_window_days?: number
          updated_at?: string
          weekly_digest?: boolean
        }
        Relationships: []
      }
      profiles: {
        Row: {
          available_balance: number
          avatar_color: string
          bio: string | null
          business_name: string | null
          city: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          industry: string | null
          is_active: boolean
          last_seen_at: string | null
          next_billing_date: string | null
          payment_method_last4: string | null
          phone: string | null
          state: string | null
          stripe_customer_id: string | null
          stripe_price_id: string | null
          stripe_subscription_id: string | null
          subscription_status: string | null
          tier: Database["public"]["Enums"]["membership_tier"]
          updated_at: string
          website_url: string | null
        }
        Insert: {
          available_balance?: number
          avatar_color?: string
          bio?: string | null
          business_name?: string | null
          city?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          industry?: string | null
          is_active?: boolean
          last_seen_at?: string | null
          next_billing_date?: string | null
          payment_method_last4?: string | null
          phone?: string | null
          state?: string | null
          stripe_customer_id?: string | null
          stripe_price_id?: string | null
          stripe_subscription_id?: string | null
          subscription_status?: string | null
          tier?: Database["public"]["Enums"]["membership_tier"]
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          available_balance?: number
          avatar_color?: string
          bio?: string | null
          business_name?: string | null
          city?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          industry?: string | null
          is_active?: boolean
          last_seen_at?: string | null
          next_billing_date?: string | null
          payment_method_last4?: string | null
          phone?: string | null
          state?: string | null
          stripe_customer_id?: string | null
          stripe_price_id?: string | null
          stripe_subscription_id?: string | null
          subscription_status?: string | null
          tier?: Database["public"]["Enums"]["membership_tier"]
          updated_at?: string
          website_url?: string | null
        }
        Relationships: []
      }
      projects: {
        Row: {
          budget: number | null
          budget_max: number | null
          budget_min: number | null
          category: Database["public"]["Enums"]["project_category"]
          closes_at: string | null
          contract_value: number | null
          created_at: string
          deadline: string | null
          description: string | null
          id: string
          posted_by: string | null
          requirements: string[]
          rfp_url: string | null
          status: Database["public"]["Enums"]["project_status"]
          summary: string | null
          title: string
          updated_at: string
          winner_bid_id: string | null
          winner_id: string | null
        }
        Insert: {
          budget?: number | null
          budget_max?: number | null
          budget_min?: number | null
          category?: Database["public"]["Enums"]["project_category"]
          closes_at?: string | null
          contract_value?: number | null
          created_at?: string
          deadline?: string | null
          description?: string | null
          id?: string
          posted_by?: string | null
          requirements?: string[]
          rfp_url?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          summary?: string | null
          title: string
          updated_at?: string
          winner_bid_id?: string | null
          winner_id?: string | null
        }
        Update: {
          budget?: number | null
          budget_max?: number | null
          budget_min?: number | null
          category?: Database["public"]["Enums"]["project_category"]
          closes_at?: string | null
          contract_value?: number | null
          created_at?: string
          deadline?: string | null
          description?: string | null
          id?: string
          posted_by?: string | null
          requirements?: string[]
          rfp_url?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          summary?: string | null
          title?: string
          updated_at?: string
          winner_bid_id?: string | null
          winner_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "projects_winner_bid_id_fkey"
            columns: ["winner_bid_id"]
            isOneToOne: false
            referencedRelation: "bids"
            referencedColumns: ["id"]
          },
        ]
      }
      reactions: {
        Row: {
          created_at: string
          emoji: string
          id: string
          message_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          id?: string
          message_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          id?: string
          message_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reactions_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      redeemables: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          id: string
          image_emoji: string | null
          owner_user_id: string
          price_credits: number
          quantity: number
          status: Database["public"]["Enums"]["redeemable_status"]
          title: string
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_emoji?: string | null
          owner_user_id: string
          price_credits: number
          quantity?: number
          status?: Database["public"]["Enums"]["redeemable_status"]
          title: string
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          image_emoji?: string | null
          owner_user_id?: string
          price_credits?: number
          quantity?: number
          status?: Database["public"]["Enums"]["redeemable_status"]
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      redemptions: {
        Row: {
          buyer_user_id: string
          created_at: string
          fulfilled_at: string | null
          id: string
          price_credits: number
          redeemable_id: string
          seller_user_id: string
          status: Database["public"]["Enums"]["redemption_status"]
          updated_at: string
        }
        Insert: {
          buyer_user_id: string
          created_at?: string
          fulfilled_at?: string | null
          id?: string
          price_credits: number
          redeemable_id: string
          seller_user_id: string
          status?: Database["public"]["Enums"]["redemption_status"]
          updated_at?: string
        }
        Update: {
          buyer_user_id?: string
          created_at?: string
          fulfilled_at?: string | null
          id?: string
          price_credits?: number
          redeemable_id?: string
          seller_user_id?: string
          status?: Database["public"]["Enums"]["redemption_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "redemptions_redeemable_id_fkey"
            columns: ["redeemable_id"]
            isOneToOne: false
            referencedRelation: "redeemables"
            referencedColumns: ["id"]
          },
        ]
      }
      referral_reviews: {
        Row: {
          body: string | null
          business_page_id: string
          created_at: string
          id: string
          rating: number
          reviewer_id: string
        }
        Insert: {
          body?: string | null
          business_page_id: string
          created_at?: string
          id?: string
          rating: number
          reviewer_id: string
        }
        Update: {
          body?: string | null
          business_page_id?: string
          created_at?: string
          id?: string
          rating?: number
          reviewer_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "referral_reviews_business_page_id_fkey"
            columns: ["business_page_id"]
            isOneToOne: false
            referencedRelation: "business_pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referral_reviews_business_page_id_fkey"
            columns: ["business_page_id"]
            isOneToOne: false
            referencedRelation: "referrals_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      referral_services: {
        Row: {
          business_page_id: string
          created_at: string
          description: string | null
          duration_min: number | null
          id: string
          is_active: boolean
          name: string
          price: number
          sort_order: number
        }
        Insert: {
          business_page_id: string
          created_at?: string
          description?: string | null
          duration_min?: number | null
          id?: string
          is_active?: boolean
          name: string
          price?: number
          sort_order?: number
        }
        Update: {
          business_page_id?: string
          created_at?: string
          description?: string | null
          duration_min?: number | null
          id?: string
          is_active?: boolean
          name?: string
          price?: number
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "referral_services_business_page_id_fkey"
            columns: ["business_page_id"]
            isOneToOne: false
            referencedRelation: "business_pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referral_services_business_page_id_fkey"
            columns: ["business_page_id"]
            isOneToOne: false
            referencedRelation: "referrals_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      savings_goals: {
        Row: {
          achieved_at: string | null
          created_at: string
          id: string
          saved_credits: number
          target_credits: number
          target_date: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          achieved_at?: string | null
          created_at?: string
          id?: string
          saved_credits?: number
          target_credits: number
          target_date?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          achieved_at?: string | null
          created_at?: string
          id?: string
          saved_credits?: number
          target_credits?: number
          target_date?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      scheduled_emails: {
        Row: {
          attempts: number
          created_at: string
          id: string
          kind: string
          last_error: string | null
          payload: Json
          recipient: string
          reference_id: string | null
          send_at: string
          sent_at: string | null
          status: Database["public"]["Enums"]["scheduled_email_status"]
        }
        Insert: {
          attempts?: number
          created_at?: string
          id?: string
          kind: string
          last_error?: string | null
          payload?: Json
          recipient: string
          reference_id?: string | null
          send_at: string
          sent_at?: string | null
          status?: Database["public"]["Enums"]["scheduled_email_status"]
        }
        Update: {
          attempts?: number
          created_at?: string
          id?: string
          kind?: string
          last_error?: string | null
          payload?: Json
          recipient?: string
          reference_id?: string | null
          send_at?: string
          sent_at?: string | null
          status?: Database["public"]["Enums"]["scheduled_email_status"]
        }
        Relationships: []
      }
      trade_agreements: {
        Row: {
          booking_id: string
          buyer_accepted_at: string | null
          completed_at: string | null
          created_at: string
          decline_reason: string | null
          declined_at: string | null
          declined_by_user_id: string | null
          estimated_value_usd: number | null
          id: string
          offered_description: string
          proposed_by_user_id: string
          provider_accepted_at: string | null
          requested_description: string
          updated_at: string
        }
        Insert: {
          booking_id: string
          buyer_accepted_at?: string | null
          completed_at?: string | null
          created_at?: string
          decline_reason?: string | null
          declined_at?: string | null
          declined_by_user_id?: string | null
          estimated_value_usd?: number | null
          id?: string
          offered_description: string
          proposed_by_user_id: string
          provider_accepted_at?: string | null
          requested_description: string
          updated_at?: string
        }
        Update: {
          booking_id?: string
          buyer_accepted_at?: string | null
          completed_at?: string | null
          created_at?: string
          decline_reason?: string | null
          declined_at?: string | null
          declined_by_user_id?: string | null
          estimated_value_usd?: number | null
          id?: string
          offered_description?: string
          proposed_by_user_id?: string
          provider_accepted_at?: string | null
          requested_description?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "trade_agreements_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: true
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      transactions: {
        Row: {
          amount: number
          created_at: string
          description: string | null
          fee_amount: number
          gross_amount: number | null
          id: string
          net_amount: number | null
          reference_id: string | null
          refund_reason: string | null
          refund_txn_id: string | null
          refunded_at: string | null
          refunded_by: string | null
          source: string | null
          status: string
          stripe_payment_intent_id: string | null
          txn_type: Database["public"]["Enums"]["txn_type"]
          user_id: string
        }
        Insert: {
          amount?: number
          created_at?: string
          description?: string | null
          fee_amount?: number
          gross_amount?: number | null
          id?: string
          net_amount?: number | null
          reference_id?: string | null
          refund_reason?: string | null
          refund_txn_id?: string | null
          refunded_at?: string | null
          refunded_by?: string | null
          source?: string | null
          status?: string
          stripe_payment_intent_id?: string | null
          txn_type: Database["public"]["Enums"]["txn_type"]
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string | null
          fee_amount?: number
          gross_amount?: number | null
          id?: string
          net_amount?: number | null
          reference_id?: string | null
          refund_reason?: string | null
          refund_txn_id?: string | null
          refunded_at?: string | null
          refunded_by?: string | null
          source?: string | null
          status?: string
          stripe_payment_intent_id?: string | null
          txn_type?: Database["public"]["Enums"]["txn_type"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_refund_txn_id_fkey"
            columns: ["refund_txn_id"]
            isOneToOne: false
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      video_progress: {
        Row: {
          completed: boolean
          id: string
          notes: string | null
          progress_pct: number
          progress_seconds: number
          updated_at: string
          user_id: string
          video_id: string
        }
        Insert: {
          completed?: boolean
          id?: string
          notes?: string | null
          progress_pct?: number
          progress_seconds?: number
          updated_at?: string
          user_id: string
          video_id: string
        }
        Update: {
          completed?: boolean
          id?: string
          notes?: string | null
          progress_pct?: number
          progress_seconds?: number
          updated_at?: string
          user_id?: string
          video_id?: string
        }
        Relationships: []
      }
      video_saves: {
        Row: {
          created_at: string
          id: string
          user_id: string
          video_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          user_id: string
          video_id: string
        }
        Update: {
          created_at?: string
          id?: string
          user_id?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "video_saves_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      videos: {
        Row: {
          access_level: Database["public"]["Enums"]["video_access"]
          category: string | null
          created_at: string
          created_by: string | null
          description: string | null
          duration_seconds: number
          icon_emoji: string
          id: string
          is_featured: boolean
          is_published: boolean
          notify_on_publish: boolean
          save_count: number
          series: Database["public"]["Enums"]["video_series"]
          thumbnail_url: string | null
          title: string
          updated_at: string
          video_url: string | null
          view_count: number
        }
        Insert: {
          access_level?: Database["public"]["Enums"]["video_access"]
          category?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration_seconds?: number
          icon_emoji?: string
          id?: string
          is_featured?: boolean
          is_published?: boolean
          notify_on_publish?: boolean
          save_count?: number
          series?: Database["public"]["Enums"]["video_series"]
          thumbnail_url?: string | null
          title: string
          updated_at?: string
          video_url?: string | null
          view_count?: number
        }
        Update: {
          access_level?: Database["public"]["Enums"]["video_access"]
          category?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration_seconds?: number
          icon_emoji?: string
          id?: string
          is_featured?: boolean
          is_published?: boolean
          notify_on_publish?: boolean
          save_count?: number
          series?: Database["public"]["Enums"]["video_series"]
          thumbnail_url?: string | null
          title?: string
          updated_at?: string
          video_url?: string | null
          view_count?: number
        }
        Relationships: []
      }
    }
    Views: {
      member_financial_summary: {
        Row: {
          available_balance: number | null
          avatar_color: string | null
          booking_count: number | null
          email: string | null
          fees_paid: number | null
          full_name: string | null
          gross_earned: number | null
          member_id: string | null
          net_earned: number | null
          pending_payouts: number | null
          tier: Database["public"]["Enums"]["membership_tier"] | null
        }
        Relationships: []
      }
      open_projects_with_bids: {
        Row: {
          bid_count: number | null
          budget: number | null
          budget_max: number | null
          budget_min: number | null
          category: Database["public"]["Enums"]["project_category"] | null
          closes_at: string | null
          created_at: string | null
          deadline: string | null
          description: string | null
          id: string | null
          posted_by: string | null
          posted_by_name: string | null
          requirements: string[] | null
          rfp_url: string | null
          status: Database["public"]["Enums"]["project_status"] | null
          summary: string | null
          title: string | null
          updated_at: string | null
        }
        Relationships: []
      }
      platform_revenue_summary: {
        Row: {
          membership_mtd: number | null
          membership_revenue_total: number | null
          pending_payouts_count: number | null
          pending_payouts_total: number | null
          referral_fee_mtd: number | null
          referral_fee_revenue_total: number | null
          revenue_mtd: number | null
          total_revenue: number | null
        }
        Relationships: []
      }
      referrals_directory: {
        Row: {
          avg_rating: number | null
          banner_color: string | null
          business_name: string | null
          category: Database["public"]["Enums"]["referral_category"] | null
          created_at: string | null
          description: string | null
          icon_emoji: string | null
          id: string | null
          is_featured: boolean | null
          logo_url: string | null
          owner_avatar_color: string | null
          owner_city: string | null
          owner_id: string | null
          owner_name: string | null
          owner_state: string | null
          platform_fee_pct: number | null
          service_area: string | null
          starting_price: number | null
          status: Database["public"]["Enums"]["business_page_status"] | null
          total_bookings: number | null
          total_revenue: number | null
          total_reviews: number | null
          website_url: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      event_rank: {
        Args: { _access: Database["public"]["Enums"]["event_access"] }
        Returns: number
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_parent_of: { Args: { _child: string }; Returns: boolean }
      tier_rank: {
        Args: { _tier: Database["public"]["Enums"]["membership_tier"] }
        Returns: number
      }
      tier_video_rank: { Args: { _t: string }; Returns: number }
      user_tier: { Args: { _user_id: string }; Returns: string }
      video_access_rank: {
        Args: { _a: Database["public"]["Enums"]["video_access"] }
        Returns: number
      }
    }
    Enums: {
      app_role: "admin" | "member"
      bid_status: "draft" | "submitted" | "shortlisted" | "awarded" | "rejected"
      booking_status:
        | "pending_payment"
        | "confirmed"
        | "completed"
        | "cancelled"
        | "refunded"
        | "pending_agreement"
        | "agreement_declined"
      business_page_status: "pending" | "live" | "draft" | "archived"
      channel_type: "public" | "state" | "vip"
      chore_status: "open" | "submitted" | "approved" | "rejected"
      event_access: "free" | "paid" | "annual" | "vip"
      event_status: "scheduled" | "live" | "completed" | "canceled"
      invoice_status: "draft" | "sent" | "paid" | "overdue" | "cancelled"
      kid_business_status:
        | "pending_parent"
        | "pending_admin"
        | "approved"
        | "rejected"
      kiddo_age_band: "under_13" | "teen"
      kiddo_video_kind: "official" | "kid_submission"
      kiddo_video_status:
        | "draft"
        | "pending_parent"
        | "pending_admin"
        | "approved"
        | "rejected"
      ledger_reason:
        | "parent_load"
        | "allowance"
        | "chore_reward"
        | "redemption_buy"
        | "redemption_sell"
        | "refund"
        | "adjustment"
      membership_tier: "free" | "paid" | "annual" | "vip"
      parent_link_status: "pending" | "active" | "revoked"
      payout_status:
        | "requested"
        | "processing"
        | "paid"
        | "rejected"
        | "approved"
        | "sent"
        | "pending"
        | "held"
      post_type: "message" | "announcement" | "resource" | "poll"
      project_category:
        | "strategy"
        | "contractor"
        | "cleaning"
        | "marketing"
        | "legal"
        | "trades"
        | "tech_ai"
        | "other"
      project_status: "open" | "in_review" | "awarded" | "closed" | "reviewing"
      redeemable_status: "active" | "sold" | "removed"
      redemption_status: "pending" | "fulfilled" | "disputed" | "refunded"
      referral_category:
        | "cleaning"
        | "contractor"
        | "strategy"
        | "marketing"
        | "legal"
        | "tech_ai"
        | "other"
      scheduled_email_status: "pending" | "sent" | "failed" | "cancelled"
      txn_type:
        | "referral"
        | "bid_award"
        | "payout"
        | "refund"
        | "other"
        | "consulting"
        | "membership"
        | "fee"
      video_access: "free" | "paid" | "vip"
      video_series: "business-bites" | "market-bites" | "bankruptcy-bites"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "member"],
      bid_status: ["draft", "submitted", "shortlisted", "awarded", "rejected"],
      booking_status: [
        "pending_payment",
        "confirmed",
        "completed",
        "cancelled",
        "refunded",
        "pending_agreement",
        "agreement_declined",
      ],
      business_page_status: ["pending", "live", "draft", "archived"],
      channel_type: ["public", "state", "vip"],
      chore_status: ["open", "submitted", "approved", "rejected"],
      event_access: ["free", "paid", "annual", "vip"],
      event_status: ["scheduled", "live", "completed", "canceled"],
      invoice_status: ["draft", "sent", "paid", "overdue", "cancelled"],
      kid_business_status: [
        "pending_parent",
        "pending_admin",
        "approved",
        "rejected",
      ],
      kiddo_age_band: ["under_13", "teen"],
      kiddo_video_kind: ["official", "kid_submission"],
      kiddo_video_status: [
        "draft",
        "pending_parent",
        "pending_admin",
        "approved",
        "rejected",
      ],
      ledger_reason: [
        "parent_load",
        "allowance",
        "chore_reward",
        "redemption_buy",
        "redemption_sell",
        "refund",
        "adjustment",
      ],
      membership_tier: ["free", "paid", "annual", "vip"],
      parent_link_status: ["pending", "active", "revoked"],
      payout_status: [
        "requested",
        "processing",
        "paid",
        "rejected",
        "approved",
        "sent",
        "pending",
        "held",
      ],
      post_type: ["message", "announcement", "resource", "poll"],
      project_category: [
        "strategy",
        "contractor",
        "cleaning",
        "marketing",
        "legal",
        "trades",
        "tech_ai",
        "other",
      ],
      project_status: ["open", "in_review", "awarded", "closed", "reviewing"],
      redeemable_status: ["active", "sold", "removed"],
      redemption_status: ["pending", "fulfilled", "disputed", "refunded"],
      referral_category: [
        "cleaning",
        "contractor",
        "strategy",
        "marketing",
        "legal",
        "tech_ai",
        "other",
      ],
      scheduled_email_status: ["pending", "sent", "failed", "cancelled"],
      txn_type: [
        "referral",
        "bid_award",
        "payout",
        "refund",
        "other",
        "consulting",
        "membership",
        "fee",
      ],
      video_access: ["free", "paid", "vip"],
      video_series: ["business-bites", "market-bites", "bankruptcy-bites"],
    },
  },
} as const
