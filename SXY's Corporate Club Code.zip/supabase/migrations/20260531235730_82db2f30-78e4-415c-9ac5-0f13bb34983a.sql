do $$ begin
  create type public.membership_tier as enum ('free', 'paid', 'annual', 'vip');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.app_role as enum ('admin', 'member');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key,
  email text,
  full_name text,
  state text,
  tier public.membership_tier not null default 'free',
  bio text,
  business_name text,
  city text,
  industry text,
  website_url text,
  avatar_color text not null default 'teal',
  stripe_customer_id text,
  stripe_subscription_id text,
  stripe_price_id text,
  subscription_status text,
  next_billing_date timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

grant select, insert, update, delete on public.profiles to authenticated;
grant all on public.profiles to service_role;

alter table public.profiles enable row level security;

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;

alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id and role = _role
  );
$$;

create or replace function public.tier_rank(_tier public.membership_tier)
returns int
language sql
immutable
as $$
  select case _tier
    when 'free' then 1
    when 'paid' then 2
    when 'annual' then 3
    when 'vip' then 4
  end;
$$;

create or replace function public.user_tier(_user_id uuid)
returns public.membership_tier
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select tier from public.profiles where id = _user_id), 'free'::public.membership_tier);
$$;

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop policy if exists "Profiles are viewable by owner" on public.profiles;
create policy "Profiles are viewable by owner"
  on public.profiles
  for select
  to authenticated
  using (auth.uid() = id or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Profiles insertable by owner" on public.profiles;
create policy "Profiles insertable by owner"
  on public.profiles
  for insert
  to authenticated
  with check (auth.uid() = id);

drop policy if exists "Profiles updatable by owner" on public.profiles;
create policy "Profiles updatable by owner"
  on public.profiles
  for update
  to authenticated
  using (auth.uid() = id or public.has_role(auth.uid(), 'admin'))
  with check (auth.uid() = id or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users read own roles" on public.user_roles;
create policy "Users read own roles"
  on public.user_roles
  for select
  to authenticated
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Only admins manage roles" on public.user_roles;
create policy "Only admins manage roles"
  on public.user_roles
  for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at
  before update on public.profiles
  for each row
  execute function public.touch_updated_at();

create or replace function public.prevent_self_tier_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if current_setting('role', true) = 'service_role' then
    return new;
  end if;

  if public.has_role(auth.uid(), 'admin') then
    return new;
  end if;

  if new.tier is distinct from old.tier then
    raise exception 'Tier changes are not permitted from the client. Use checkout to upgrade or contact support to downgrade.' using errcode = '42501';
  end if;

  return new;
end;
$$;

drop trigger if exists profiles_prevent_tier_change on public.profiles;
create trigger profiles_prevent_tier_change
  before update on public.profiles
  for each row
  execute function public.prevent_self_tier_change();

notify pgrst, 'reload schema';