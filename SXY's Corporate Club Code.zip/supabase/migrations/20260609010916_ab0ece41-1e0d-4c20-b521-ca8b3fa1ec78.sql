
-- ============ ENUMS ============
CREATE TYPE public.kiddo_age_band AS ENUM ('under_13', 'teen');
CREATE TYPE public.parent_link_status AS ENUM ('pending', 'active', 'revoked');
CREATE TYPE public.ledger_reason AS ENUM ('parent_load', 'allowance', 'chore_reward', 'redemption_buy', 'redemption_sell', 'refund', 'adjustment');
CREATE TYPE public.redeemable_status AS ENUM ('active', 'sold', 'removed');
CREATE TYPE public.redemption_status AS ENUM ('pending', 'fulfilled', 'disputed', 'refunded');
CREATE TYPE public.chore_status AS ENUM ('open', 'submitted', 'approved', 'rejected');

-- ============ updated_at helper (reuse if exists) ============
CREATE OR REPLACE FUNCTION public.kiddos_touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- ============ kiddo_profiles ============
CREATE TABLE public.kiddo_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL CHECK (char_length(display_name) BETWEEN 1 AND 40),
  date_of_birth DATE NOT NULL,
  age_band public.kiddo_age_band NOT NULL,
  avatar_emoji TEXT DEFAULT '🧒',
  privacy_mode BOOLEAN NOT NULL DEFAULT true,
  parental_consent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.kiddo_profiles TO authenticated;
GRANT ALL ON public.kiddo_profiles TO service_role;
ALTER TABLE public.kiddo_profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER kp_touch BEFORE UPDATE ON public.kiddo_profiles FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- ============ parent_child_links ============
CREATE TABLE public.parent_child_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  relationship TEXT,
  status public.parent_link_status NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (parent_user_id, child_user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.parent_child_links TO authenticated;
GRANT ALL ON public.parent_child_links TO service_role;
ALTER TABLE public.parent_child_links ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_pcl_parent ON public.parent_child_links(parent_user_id) WHERE status = 'active';
CREATE INDEX idx_pcl_child ON public.parent_child_links(child_user_id) WHERE status = 'active';
CREATE TRIGGER pcl_touch BEFORE UPDATE ON public.parent_child_links FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- helper: is the current user the parent of the given child?
CREATE OR REPLACE FUNCTION public.is_parent_of(_child UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.parent_child_links
    WHERE parent_user_id = auth.uid()
      AND child_user_id = _child
      AND status = 'active'
  );
$$;
REVOKE EXECUTE ON FUNCTION public.is_parent_of(UUID) FROM anon;

-- ============ kiddo_wallets ============
CREATE TABLE public.kiddo_wallets (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  balance_credits INTEGER NOT NULL DEFAULT 0 CHECK (balance_credits >= 0),
  lifetime_earned INTEGER NOT NULL DEFAULT 0,
  lifetime_spent INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.kiddo_wallets TO authenticated;
GRANT ALL ON public.kiddo_wallets TO service_role;
ALTER TABLE public.kiddo_wallets ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER kw_touch BEFORE UPDATE ON public.kiddo_wallets FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- block client-side wallet writes (server-only via service role)
CREATE OR REPLACE FUNCTION public.kiddo_wallets_block_client()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF current_setting('role', true) = 'service_role' THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Wallet balance can only be changed by the server.' USING ERRCODE = '42501';
END; $$;
CREATE TRIGGER kw_block_client BEFORE INSERT OR UPDATE OR DELETE ON public.kiddo_wallets
FOR EACH ROW EXECUTE FUNCTION public.kiddo_wallets_block_client();

-- ============ credit_ledger ============
CREATE TABLE public.credit_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  delta_credits INTEGER NOT NULL,
  reason public.ledger_reason NOT NULL,
  counterparty_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  redeemable_id UUID,
  chore_id UUID,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.credit_ledger TO authenticated;
GRANT ALL ON public.credit_ledger TO service_role;
ALTER TABLE public.credit_ledger ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_ledger_user ON public.credit_ledger(user_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.credit_ledger_block_client()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF current_setting('role', true) = 'service_role' THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Ledger entries can only be created by the server.' USING ERRCODE = '42501';
END; $$;
CREATE TRIGGER ledger_block_client BEFORE INSERT OR UPDATE OR DELETE ON public.credit_ledger
FOR EACH ROW EXECUTE FUNCTION public.credit_ledger_block_client();

-- ============ redeemables (peer-to-peer marketplace) ============
CREATE TABLE public.redeemables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 1 AND 80),
  description TEXT CHECK (description IS NULL OR char_length(description) <= 500),
  category TEXT,
  price_credits INTEGER NOT NULL CHECK (price_credits > 0 AND price_credits <= 100000),
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 0),
  status public.redeemable_status NOT NULL DEFAULT 'active',
  image_emoji TEXT DEFAULT '🎁',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.redeemables TO authenticated;
GRANT ALL ON public.redeemables TO service_role;
ALTER TABLE public.redeemables ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_redeemables_active ON public.redeemables(status, created_at DESC);
CREATE TRIGGER red_touch BEFORE UPDATE ON public.redeemables FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- PII guard: block phone numbers, emails, and long digit runs in title/description
CREATE OR REPLACE FUNCTION public.redeemables_pii_guard()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
DECLARE blob TEXT;
BEGIN
  blob := coalesce(NEW.title,'') || ' ' || coalesce(NEW.description,'');
  IF blob ~* '[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}' THEN
    RAISE EXCEPTION 'Email addresses are not allowed in listings.' USING ERRCODE = '22023';
  END IF;
  IF blob ~ '(\+?\d[\s\-().]*){7,}' THEN
    RAISE EXCEPTION 'Phone numbers are not allowed in listings.' USING ERRCODE = '22023';
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER red_pii BEFORE INSERT OR UPDATE ON public.redeemables FOR EACH ROW EXECUTE FUNCTION public.redeemables_pii_guard();

-- ============ redemptions ============
CREATE TABLE public.redemptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  redeemable_id UUID NOT NULL REFERENCES public.redeemables(id) ON DELETE CASCADE,
  buyer_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  seller_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  price_credits INTEGER NOT NULL CHECK (price_credits > 0),
  status public.redemption_status NOT NULL DEFAULT 'pending',
  fulfilled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.redemptions TO authenticated;
GRANT ALL ON public.redemptions TO service_role;
ALTER TABLE public.redemptions ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_redemptions_buyer ON public.redemptions(buyer_user_id, created_at DESC);
CREATE INDEX idx_redemptions_seller ON public.redemptions(seller_user_id, created_at DESC);
CREATE TRIGGER rdm_touch BEFORE UPDATE ON public.redemptions FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

CREATE OR REPLACE FUNCTION public.redemptions_block_client()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF current_setting('role', true) = 'service_role' THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Redemptions must go through the server.' USING ERRCODE = '42501';
END; $$;
CREATE TRIGGER rdm_block_client BEFORE INSERT OR UPDATE OR DELETE ON public.redemptions
FOR EACH ROW EXECUTE FUNCTION public.redemptions_block_client();

-- ============ chores ============
CREATE TABLE public.chores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 1 AND 120),
  description TEXT CHECK (description IS NULL OR char_length(description) <= 500),
  reward_credits INTEGER NOT NULL CHECK (reward_credits > 0 AND reward_credits <= 10000),
  status public.chore_status NOT NULL DEFAULT 'open',
  due_at TIMESTAMPTZ,
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chores TO authenticated;
GRANT ALL ON public.chores TO service_role;
ALTER TABLE public.chores ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_chores_child ON public.chores(child_user_id, status);
CREATE TRIGGER ch_touch BEFORE UPDATE ON public.chores FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- ============ savings_goals ============
CREATE TABLE public.savings_goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 1 AND 80),
  target_credits INTEGER NOT NULL CHECK (target_credits > 0),
  saved_credits INTEGER NOT NULL DEFAULT 0 CHECK (saved_credits >= 0),
  target_date DATE,
  achieved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.savings_goals TO authenticated;
GRANT ALL ON public.savings_goals TO service_role;
ALTER TABLE public.savings_goals ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_goals_user ON public.savings_goals(user_id);
CREATE TRIGGER sg_touch BEFORE UPDATE ON public.savings_goals FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- ============ game_progress ============
CREATE TABLE public.game_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  game_key TEXT NOT NULL CHECK (char_length(game_key) BETWEEN 1 AND 50),
  score INTEGER NOT NULL DEFAULT 0,
  completed_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.game_progress TO authenticated;
GRANT ALL ON public.game_progress TO service_role;
ALTER TABLE public.game_progress ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_game_user ON public.game_progress(user_id, game_key);

-- ============ POLICIES ============

-- kiddo_profiles: own row + linked parents
CREATE POLICY "kp_self_select" ON public.kiddo_profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_parent_of(id));
CREATE POLICY "kp_self_upsert" ON public.kiddo_profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid() OR public.is_parent_of(id));
CREATE POLICY "kp_self_update" ON public.kiddo_profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.is_parent_of(id))
  WITH CHECK (id = auth.uid() OR public.is_parent_of(id));

-- parent_child_links: parent or child can read; parent creates; either revokes
CREATE POLICY "pcl_read" ON public.parent_child_links FOR SELECT TO authenticated
  USING (parent_user_id = auth.uid() OR child_user_id = auth.uid());
CREATE POLICY "pcl_parent_insert" ON public.parent_child_links FOR INSERT TO authenticated
  WITH CHECK (parent_user_id = auth.uid());
CREATE POLICY "pcl_update" ON public.parent_child_links FOR UPDATE TO authenticated
  USING (parent_user_id = auth.uid() OR child_user_id = auth.uid())
  WITH CHECK (parent_user_id = auth.uid() OR child_user_id = auth.uid());

-- kiddo_wallets: read self or linked child (writes blocked by trigger)
CREATE POLICY "kw_read" ON public.kiddo_wallets FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_parent_of(user_id));

-- credit_ledger: read self or linked child
CREATE POLICY "ledger_read" ON public.credit_ledger FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_parent_of(user_id));

-- redeemables: everyone (authenticated) sees active; owner manages own
CREATE POLICY "red_read_active" ON public.redeemables FOR SELECT TO authenticated
  USING (status = 'active' OR owner_user_id = auth.uid() OR public.is_parent_of(owner_user_id));
CREATE POLICY "red_owner_insert" ON public.redeemables FOR INSERT TO authenticated
  WITH CHECK (owner_user_id = auth.uid());
CREATE POLICY "red_owner_update" ON public.redeemables FOR UPDATE TO authenticated
  USING (owner_user_id = auth.uid()) WITH CHECK (owner_user_id = auth.uid());
CREATE POLICY "red_owner_delete" ON public.redeemables FOR DELETE TO authenticated
  USING (owner_user_id = auth.uid());

-- redemptions: buyer, seller, or either parent (writes blocked by trigger)
CREATE POLICY "rdm_read" ON public.redemptions FOR SELECT TO authenticated
  USING (
    buyer_user_id = auth.uid() OR seller_user_id = auth.uid()
    OR public.is_parent_of(buyer_user_id) OR public.is_parent_of(seller_user_id)
  );

-- chores: parent manages, child reads + submits
CREATE POLICY "ch_read" ON public.chores FOR SELECT TO authenticated
  USING (parent_user_id = auth.uid() OR child_user_id = auth.uid());
CREATE POLICY "ch_parent_insert" ON public.chores FOR INSERT TO authenticated
  WITH CHECK (parent_user_id = auth.uid() AND public.is_parent_of(child_user_id));
CREATE POLICY "ch_update" ON public.chores FOR UPDATE TO authenticated
  USING (parent_user_id = auth.uid() OR child_user_id = auth.uid())
  WITH CHECK (parent_user_id = auth.uid() OR child_user_id = auth.uid());
CREATE POLICY "ch_parent_delete" ON public.chores FOR DELETE TO authenticated
  USING (parent_user_id = auth.uid());

-- savings_goals: self + linked parent
CREATE POLICY "sg_read" ON public.savings_goals FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_parent_of(user_id));
CREATE POLICY "sg_self_insert" ON public.savings_goals FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() OR public.is_parent_of(user_id));
CREATE POLICY "sg_self_update" ON public.savings_goals FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.is_parent_of(user_id))
  WITH CHECK (user_id = auth.uid() OR public.is_parent_of(user_id));
CREATE POLICY "sg_self_delete" ON public.savings_goals FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR public.is_parent_of(user_id));

-- game_progress: self + linked parent reads; self inserts
CREATE POLICY "gp_read" ON public.game_progress FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_parent_of(user_id));
CREATE POLICY "gp_self_insert" ON public.game_progress FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
