
-- ============================================================
-- Kiddos: videos + kid business pages
-- ============================================================

-- ---------- kiddo_videos ----------
CREATE TYPE public.kiddo_video_kind AS ENUM ('official', 'kid_submission');
CREATE TYPE public.kiddo_video_status AS ENUM (
  'draft','pending_parent','pending_admin','approved','rejected'
);

CREATE TABLE public.kiddo_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  kind public.kiddo_video_kind NOT NULL DEFAULT 'kid_submission',
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 120),
  description text CHECK (description IS NULL OR char_length(description) <= 1000),
  topic text,
  video_url text,
  storage_path text,
  thumbnail_url text,
  duration_seconds integer NOT NULL DEFAULT 0 CHECK (duration_seconds >= 0 AND duration_seconds <= 600),
  status public.kiddo_video_status NOT NULL DEFAULT 'pending_parent',
  parent_approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  parent_approved_at timestamptz,
  admin_approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  admin_approved_at timestamptz,
  rejection_reason text,
  view_count integer NOT NULL DEFAULT 0,
  credits_per_view integer NOT NULL DEFAULT 5 CHECK (credits_per_view >= 0 AND credits_per_view <= 100),
  is_published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (video_url IS NOT NULL OR storage_path IS NOT NULL)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.kiddo_videos TO authenticated;
GRANT ALL ON public.kiddo_videos TO service_role;

ALTER TABLE public.kiddo_videos ENABLE ROW LEVEL SECURITY;

-- Read: published+approved visible to all signed-in; creator/parent/admin always.
CREATE POLICY kv_read ON public.kiddo_videos FOR SELECT TO authenticated
USING (
  (is_published = true AND status = 'approved')
  OR creator_user_id = auth.uid()
  OR (creator_user_id IS NOT NULL AND public.is_parent_of(creator_user_id))
  OR public.has_role(auth.uid(), 'admin')
);

-- Kids/parents/admins can insert; status/approval/view_count must use defaults.
CREATE POLICY kv_insert ON public.kiddo_videos FOR INSERT TO authenticated
WITH CHECK (
  (creator_user_id = auth.uid())
  OR (creator_user_id IS NOT NULL AND public.is_parent_of(creator_user_id))
  OR public.has_role(auth.uid(), 'admin')
);

-- Creators can edit their own drafts; parents & admins can manage too.
CREATE POLICY kv_update ON public.kiddo_videos FOR UPDATE TO authenticated
USING (
  creator_user_id = auth.uid()
  OR (creator_user_id IS NOT NULL AND public.is_parent_of(creator_user_id))
  OR public.has_role(auth.uid(), 'admin')
)
WITH CHECK (
  creator_user_id = auth.uid()
  OR (creator_user_id IS NOT NULL AND public.is_parent_of(creator_user_id))
  OR public.has_role(auth.uid(), 'admin')
);

CREATE POLICY kv_delete ON public.kiddo_videos FOR DELETE TO authenticated
USING (
  creator_user_id = auth.uid()
  OR (creator_user_id IS NOT NULL AND public.is_parent_of(creator_user_id))
  OR public.has_role(auth.uid(), 'admin')
);

CREATE TRIGGER kv_touch BEFORE UPDATE ON public.kiddo_videos
FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- PII guard for kid-submitted videos
CREATE OR REPLACE FUNCTION public.kiddo_videos_pii_guard()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE blob text;
BEGIN
  IF NEW.kind = 'official' THEN RETURN NEW; END IF;
  blob := coalesce(NEW.title,'') || ' ' || coalesce(NEW.description,'');
  IF blob ~* '[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}' THEN
    RAISE EXCEPTION 'Email addresses are not allowed in submissions.' USING ERRCODE = '22023';
  END IF;
  IF blob ~ '(\+?\d[\s\-().]*){7,}' THEN
    RAISE EXCEPTION 'Phone numbers are not allowed in submissions.' USING ERRCODE = '22023';
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER kv_pii BEFORE INSERT OR UPDATE ON public.kiddo_videos
FOR EACH ROW EXECUTE FUNCTION public.kiddo_videos_pii_guard();

-- ---------- kiddo_video_views ----------
CREATE TABLE public.kiddo_video_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid NOT NULL REFERENCES public.kiddo_videos(id) ON DELETE CASCADE,
  viewer_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  credits_awarded integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (video_id, viewer_user_id)
);

GRANT SELECT ON public.kiddo_video_views TO authenticated;
GRANT ALL ON public.kiddo_video_views TO service_role;

ALTER TABLE public.kiddo_video_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY kvv_read ON public.kiddo_video_views FOR SELECT TO authenticated
USING (
  viewer_user_id = auth.uid()
  OR public.has_role(auth.uid(), 'admin')
);

-- Writes go through server fn (service_role). Block direct client writes:
CREATE OR REPLACE FUNCTION public.kiddo_video_views_block_client()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF current_setting('role', true) = 'service_role' THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'Video views must go through the server.' USING ERRCODE = '42501';
END $$;
CREATE TRIGGER kvv_block_client BEFORE INSERT OR UPDATE OR DELETE
ON public.kiddo_video_views FOR EACH ROW
EXECUTE FUNCTION public.kiddo_video_views_block_client();

-- ---------- kid_business_pages ----------
CREATE TYPE public.kid_business_status AS ENUM (
  'pending_parent','pending_admin','approved','rejected'
);

CREATE TABLE public.kid_business_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 80),
  tagline text CHECK (tagline IS NULL OR char_length(tagline) <= 160),
  description text CHECK (description IS NULL OR char_length(description) <= 1000),
  emoji text DEFAULT '🏪',
  category text,
  youtube_url text,
  status public.kid_business_status NOT NULL DEFAULT 'pending_parent',
  parent_approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  parent_approved_at timestamptz,
  admin_approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  admin_approved_at timestamptz,
  rejection_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.kid_business_pages TO authenticated;
GRANT ALL ON public.kid_business_pages TO service_role;

ALTER TABLE public.kid_business_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY kbp_read ON public.kid_business_pages FOR SELECT TO authenticated
USING (
  status = 'approved'
  OR owner_user_id = auth.uid()
  OR public.is_parent_of(owner_user_id)
  OR public.has_role(auth.uid(), 'admin')
);

CREATE POLICY kbp_insert ON public.kid_business_pages FOR INSERT TO authenticated
WITH CHECK (
  owner_user_id = auth.uid()
  OR public.is_parent_of(owner_user_id)
  OR public.has_role(auth.uid(), 'admin')
);

CREATE POLICY kbp_update ON public.kid_business_pages FOR UPDATE TO authenticated
USING (
  owner_user_id = auth.uid()
  OR public.is_parent_of(owner_user_id)
  OR public.has_role(auth.uid(), 'admin')
)
WITH CHECK (
  owner_user_id = auth.uid()
  OR public.is_parent_of(owner_user_id)
  OR public.has_role(auth.uid(), 'admin')
);

CREATE POLICY kbp_delete ON public.kid_business_pages FOR DELETE TO authenticated
USING (
  owner_user_id = auth.uid()
  OR public.is_parent_of(owner_user_id)
  OR public.has_role(auth.uid(), 'admin')
);

CREATE TRIGGER kbp_touch BEFORE UPDATE ON public.kid_business_pages
FOR EACH ROW EXECUTE FUNCTION public.kiddos_touch_updated_at();

-- PII guard on business pages
CREATE OR REPLACE FUNCTION public.kid_business_pages_pii_guard()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE blob text;
BEGIN
  blob := coalesce(NEW.name,'') || ' ' || coalesce(NEW.tagline,'') || ' ' || coalesce(NEW.description,'');
  IF blob ~* '[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}' THEN
    RAISE EXCEPTION 'Email addresses are not allowed in business pages.' USING ERRCODE = '22023';
  END IF;
  IF blob ~ '(\+?\d[\s\-().]*){7,}' THEN
    RAISE EXCEPTION 'Phone numbers are not allowed in business pages.' USING ERRCODE = '22023';
  END IF;
  -- youtube_url must be a YouTube link if present
  IF NEW.youtube_url IS NOT NULL AND NEW.youtube_url !~* '^https?://(www\.)?(youtube\.com|youtu\.be)/' THEN
    RAISE EXCEPTION 'YouTube link must be a youtube.com or youtu.be URL.' USING ERRCODE = '22023';
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER kbp_pii BEFORE INSERT OR UPDATE ON public.kid_business_pages
FOR EACH ROW EXECUTE FUNCTION public.kid_business_pages_pii_guard();
