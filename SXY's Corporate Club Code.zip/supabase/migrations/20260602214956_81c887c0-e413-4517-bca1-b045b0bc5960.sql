-- 1. Profile additions
alter table public.profiles
  add column if not exists bio           text,
  add column if not exists business_name text,
  add column if not exists city          text,
  add column if not exists industry      text,
  add column if not exists website_url   text,
  add column if not exists avatar_color  text not null default 'teal';

-- 2. Projects
do $$ begin
  create type public.project_status as enum ('open', 'in_review', 'awarded', 'closed');
exception when duplicate_object then null; end $$;

create table if not exists public.projects (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  summary       text,
  description   text,
  budget_min    numeric(12,2),
  budget_max    numeric(12,2),
  status        public.project_status not null default 'open',
  posted_by     uuid references auth.users(id) on delete set null,
  closes_at     timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists projects_status_idx   on public.projects (status);
create index if not exists projects_closes_at_ix on public.projects (closes_at);

grant select, insert, update, delete on public.projects to authenticated;
grant all on public.projects to service_role;

alter table public.projects enable row level security;

drop policy if exists "Members read open projects" on public.projects;
create policy "Members read open projects"
  on public.projects for select to authenticated
  using (status <> 'closed' or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins manage projects" on public.projects;
create policy "Admins manage projects"
  on public.projects for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 3. Bids
do $$ begin
  create type public.bid_status as enum ('draft', 'submitted', 'shortlisted', 'awarded', 'rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.bids (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references public.projects(id) on delete cascade,
  bidder_id   uuid not null references auth.users(id) on delete cascade,
  amount      numeric(12,2),
  proposal    text,
  status      public.bid_status not null default 'submitted',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (project_id, bidder_id)
);

create index if not exists bids_bidder_idx  on public.bids (bidder_id);
create index if not exists bids_project_idx on public.bids (project_id);
create index if not exists bids_status_idx  on public.bids (status);

grant select, insert, update, delete on public.bids to authenticated;
grant all on public.bids to service_role;

alter table public.bids enable row level security;

drop policy if exists "Bidders read own bids" on public.bids;
create policy "Bidders read own bids" on public.bids for select to authenticated
  using (bidder_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Bidders insert own bids" on public.bids;
create policy "Bidders insert own bids" on public.bids for insert to authenticated
  with check (bidder_id = auth.uid());

drop policy if exists "Bidders update own bids" on public.bids;
create policy "Bidders update own bids" on public.bids for update to authenticated
  using (bidder_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (bidder_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins delete bids" on public.bids;
create policy "Admins delete bids" on public.bids for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- 4. Transactions
do $$ begin
  create type public.txn_type as enum ('referral', 'bid_award', 'payout', 'refund', 'other');
exception when duplicate_object then null; end $$;

create table if not exists public.transactions (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  txn_type     public.txn_type not null,
  amount       numeric(12,2) not null default 0,
  description  text,
  reference_id uuid,
  created_at   timestamptz not null default now()
);

create index if not exists transactions_user_idx on public.transactions (user_id);
create index if not exists transactions_type_idx on public.transactions (txn_type);

grant select, insert, update, delete on public.transactions to authenticated;
grant all on public.transactions to service_role;

alter table public.transactions enable row level security;

drop policy if exists "Users read own transactions" on public.transactions;
create policy "Users read own transactions" on public.transactions for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins manage transactions" on public.transactions;
create policy "Admins manage transactions" on public.transactions for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 5. Messages
create table if not exists public.messages (
  id          uuid primary key default gen_random_uuid(),
  channel     text not null default 'general',
  sender_id   uuid not null references auth.users(id) on delete cascade,
  body        text not null,
  created_at  timestamptz not null default now()
);

alter table public.messages
  add column if not exists channel    text not null default 'general',
  add column if not exists sender_id  uuid references auth.users(id) on delete cascade,
  add column if not exists body       text not null default '',
  add column if not exists created_at timestamptz not null default now();

create index if not exists messages_channel_idx on public.messages (channel, created_at desc);
create index if not exists messages_sender_idx  on public.messages (sender_id);

grant select, insert, update, delete on public.messages to authenticated;
grant all on public.messages to service_role;

alter table public.messages enable row level security;

drop policy if exists "Members read messages" on public.messages;
create policy "Members read messages" on public.messages for select to authenticated using (true);

drop policy if exists "Members write own messages" on public.messages;
create policy "Members write own messages" on public.messages for insert to authenticated
  with check (sender_id = auth.uid());

drop policy if exists "Members edit own messages" on public.messages;
create policy "Members edit own messages" on public.messages for update to authenticated
  using (sender_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (sender_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Members delete own messages" on public.messages;
create policy "Members delete own messages" on public.messages for delete to authenticated
  using (sender_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- 6. Video progress
create table if not exists public.video_progress (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  video_id     uuid not null,
  progress_pct numeric(5,2) not null default 0,
  completed    boolean not null default false,
  updated_at   timestamptz not null default now(),
  unique (user_id, video_id)
);

create index if not exists video_progress_user_idx on public.video_progress (user_id);

grant select, insert, update, delete on public.video_progress to authenticated;
grant all on public.video_progress to service_role;

alter table public.video_progress enable row level security;

drop policy if exists "Users read own video progress" on public.video_progress;
create policy "Users read own video progress" on public.video_progress for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users upsert own video progress" on public.video_progress;
create policy "Users upsert own video progress" on public.video_progress for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Users update own video progress" on public.video_progress;
create policy "Users update own video progress" on public.video_progress for update to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- 7. Events
do $$ begin
  create type public.event_access as enum ('free', 'paid', 'annual', 'vip');
exception when duplicate_object then null; end $$;

create table if not exists public.events (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  description   text,
  starts_at     timestamptz not null,
  ends_at       timestamptz,
  location      text,
  meeting_url   text,
  access_level  public.event_access not null default 'free',
  created_by    uuid references auth.users(id) on delete set null,
  created_at    timestamptz not null default now()
);

create index if not exists events_starts_at_idx on public.events (starts_at);
create index if not exists events_access_idx    on public.events (access_level);

grant select, insert, update, delete on public.events to authenticated;
grant all on public.events to service_role;

alter table public.events enable row level security;

create or replace function public.event_rank(_access public.event_access)
returns int language sql immutable as $$
  select case _access when 'free' then 1 when 'paid' then 2 when 'annual' then 3 when 'vip' then 4 end;
$$;

drop policy if exists "Members read events for their tier" on public.events;
create policy "Members read events for their tier" on public.events for select to authenticated
  using (
    public.event_rank(access_level) <= public.tier_rank(public.user_tier(auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  );

drop policy if exists "Admins manage events" on public.events;
create policy "Admins manage events" on public.events for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- 8. Touch updated_at on projects + bids
drop trigger if exists projects_touch_updated_at on public.projects;
create trigger projects_touch_updated_at before update on public.projects
  for each row execute function public.touch_updated_at();

drop trigger if exists bids_touch_updated_at on public.bids;
create trigger bids_touch_updated_at before update on public.bids
  for each row execute function public.touch_updated_at();

-- ── 0003: bidding extensions ─────────────────────────────────────────────────
do $$ begin
  create type public.project_category as enum (
    'strategy', 'contractor', 'cleaning', 'marketing',
    'legal', 'trades', 'tech_ai', 'other'
  );
exception when duplicate_object then null; end $$;

alter table public.projects
  add column if not exists category       public.project_category not null default 'other',
  add column if not exists summary        text,
  add column if not exists description    text,
  add column if not exists budget         numeric(12,2),
  add column if not exists budget_min     numeric(12,2),
  add column if not exists budget_max     numeric(12,2),
  add column if not exists deadline       timestamptz,
  add column if not exists closes_at      timestamptz,
  add column if not exists requirements   text[] not null default '{}',
  add column if not exists rfp_url        text,
  add column if not exists posted_by      uuid references auth.users(id) on delete set null,
  add column if not exists winner_id      uuid references auth.users(id) on delete set null,
  add column if not exists winner_bid_id  uuid references public.bids(id) on delete set null,
  add column if not exists contract_value numeric(12,2);

do $$ begin alter type public.project_status add value if not exists 'reviewing'; exception when others then null; end $$;
do $$ begin alter type public.project_status add value if not exists 'awarded'; exception when others then null; end $$;

create index if not exists projects_category_idx on public.projects (category);
create index if not exists projects_winner_idx   on public.projects (winner_id);

alter table public.bids
  add column if not exists proposed_price   numeric(12,2),
  add column if not exists timeline         text,
  add column if not exists cover_letter     text,
  add column if not exists years_experience text,
  add column if not exists available_from   date,
  add column if not exists portfolio_url    text,
  add column if not exists documents        text[] not null default '{}';

-- Channels
create table if not exists public.channels (
  id          uuid primary key default gen_random_uuid(),
  slug        text not null unique,
  name        text not null,
  description text,
  is_system   boolean not null default false,
  created_at  timestamptz not null default now()
);

alter table public.channels
  add column if not exists slug        text,
  add column if not exists name        text,
  add column if not exists description text,
  add column if not exists is_system   boolean not null default false,
  add column if not exists created_at  timestamptz not null default now();

update public.channels
   set slug = coalesce(slug, lower(regexp_replace(coalesce(name, id::text), '\s+', '-', 'g')));

alter table public.channels alter column slug set not null;

do $$ begin
  alter table public.channels add constraint channels_slug_key unique (slug);
exception when duplicate_table then null; when duplicate_object then null; end $$;

grant select, insert, update, delete on public.channels to authenticated;
grant all on public.channels to service_role;

alter table public.channels enable row level security;

drop policy if exists "Members read channels" on public.channels;
create policy "Members read channels" on public.channels for select to authenticated using (true);

drop policy if exists "Admins manage channels" on public.channels;
create policy "Admins manage channels" on public.channels for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- Browse view
drop view if exists public.open_projects_with_bids;
create view public.open_projects_with_bids as
select
  p.id, p.title, p.summary, p.description, p.category, p.status,
  p.budget, p.budget_min, p.budget_max, p.deadline, p.closes_at,
  p.requirements, p.rfp_url, p.posted_by, p.created_at, p.updated_at,
  poster.full_name as posted_by_name,
  coalesce(bid_counts.total, 0) as bid_count
from public.projects p
left join public.profiles poster on poster.id = p.posted_by
left join (
  select project_id, count(*)::int as total from public.bids group by project_id
) bid_counts on bid_counts.project_id = p.id;

grant select on public.open_projects_with_bids to authenticated;

-- Storage: bid-documents RLS
drop policy if exists "Bidders upload to own folder" on storage.objects;
create policy "Bidders upload to own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'bid-documents' and (storage.foldername(name))[2] = auth.uid()::text);

drop policy if exists "Bidders read own documents" on storage.objects;
create policy "Bidders read own documents" on storage.objects for select to authenticated
  using (bucket_id = 'bid-documents' and (
    (storage.foldername(name))[2] = auth.uid()::text or public.has_role(auth.uid(), 'admin')
  ));

drop policy if exists "Bidders update own documents" on storage.objects;
create policy "Bidders update own documents" on storage.objects for update to authenticated
  using (bucket_id = 'bid-documents' and (storage.foldername(name))[2] = auth.uid()::text);

drop policy if exists "Bidders delete own documents" on storage.objects;
create policy "Bidders delete own documents" on storage.objects for delete to authenticated
  using (bucket_id = 'bid-documents' and (
    (storage.foldername(name))[2] = auth.uid()::text or public.has_role(auth.uid(), 'admin')
  ));

-- ── 0004: Referral portal ───────────────────────────────────────────────────
do $$ begin
  create type public.referral_category as enum ('cleaning', 'contractor', 'strategy', 'marketing', 'legal', 'tech_ai', 'other');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.business_page_status as enum ('pending', 'live', 'draft', 'archived');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.booking_status as enum ('pending_payment', 'confirmed', 'completed', 'cancelled', 'refunded');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.payout_status as enum ('requested', 'processing', 'paid', 'rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.business_pages (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  business_name text not null,
  category public.referral_category not null default 'other',
  icon_emoji text,
  description text,
  service_area text,
  website_url text,
  logo_url text,
  banner_color text,
  starting_price numeric(12,2),
  platform_fee_pct numeric(5,2) not null default 10.0,
  available_days text[] not null default '{}',
  start_time time,
  end_time time,
  session_length_min int default 60,
  booking_lead_hours int default 24,
  require_intake_form boolean not null default false,
  allow_virtual boolean not null default true,
  require_deposit boolean not null default false,
  is_featured boolean not null default false,
  status public.business_page_status not null default 'pending',
  total_bookings int not null default 0,
  total_reviews int not null default 0,
  avg_rating numeric(3,2),
  total_revenue numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists business_pages_owner_idx    on public.business_pages (owner_id);
create index if not exists business_pages_status_idx   on public.business_pages (status);
create index if not exists business_pages_category_idx on public.business_pages (category);

grant select, insert, update, delete on public.business_pages to authenticated;
grant all on public.business_pages to service_role;

alter table public.business_pages enable row level security;

drop policy if exists "Anyone reads live business pages" on public.business_pages;
create policy "Anyone reads live business pages" on public.business_pages for select to authenticated
  using (status = 'live' or owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Members create own business page" on public.business_pages;
create policy "Members create own business page" on public.business_pages for insert to authenticated
  with check (owner_id = auth.uid());

drop policy if exists "Owners update own business page" on public.business_pages;
create policy "Owners update own business page" on public.business_pages for update to authenticated
  using (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins delete business pages" on public.business_pages;
create policy "Admins delete business pages" on public.business_pages for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

create table if not exists public.referral_services (
  id uuid primary key default gen_random_uuid(),
  business_page_id uuid not null references public.business_pages(id) on delete cascade,
  name text not null,
  description text,
  price numeric(12,2) not null default 0,
  duration_min int,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists referral_services_page_idx on public.referral_services (business_page_id);

grant select, insert, update, delete on public.referral_services to authenticated;
grant all on public.referral_services to service_role;

alter table public.referral_services enable row level security;

drop policy if exists "Anyone reads services of live pages" on public.referral_services;
create policy "Anyone reads services of live pages" on public.referral_services for select to authenticated
  using (exists (
    select 1 from public.business_pages bp where bp.id = business_page_id
      and (bp.status = 'live' or bp.owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  ));

drop policy if exists "Owners manage own services" on public.referral_services;
create policy "Owners manage own services" on public.referral_services for all to authenticated
  using (exists (select 1 from public.business_pages bp where bp.id = business_page_id
      and (bp.owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))))
  with check (exists (select 1 from public.business_pages bp where bp.id = business_page_id
      and (bp.owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))));

create table if not exists public.referral_reviews (
  id uuid primary key default gen_random_uuid(),
  business_page_id uuid not null references public.business_pages(id) on delete cascade,
  reviewer_id uuid not null references auth.users(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  body text,
  created_at timestamptz not null default now(),
  unique (business_page_id, reviewer_id)
);

create index if not exists referral_reviews_page_idx on public.referral_reviews (business_page_id);

grant select, insert, update, delete on public.referral_reviews to authenticated;
grant all on public.referral_reviews to service_role;

alter table public.referral_reviews enable row level security;

drop policy if exists "Anyone reads reviews of live pages" on public.referral_reviews;
create policy "Anyone reads reviews of live pages" on public.referral_reviews for select to authenticated
  using (exists (select 1 from public.business_pages bp where bp.id = business_page_id and bp.status = 'live')
    or reviewer_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Reviewers insert own reviews" on public.referral_reviews;
create policy "Reviewers insert own reviews" on public.referral_reviews for insert to authenticated
  with check (reviewer_id = auth.uid());

drop policy if exists "Reviewers update own reviews" on public.referral_reviews;
create policy "Reviewers update own reviews" on public.referral_reviews for update to authenticated
  using (reviewer_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (reviewer_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Reviewers delete own reviews" on public.referral_reviews;
create policy "Reviewers delete own reviews" on public.referral_reviews for delete to authenticated
  using (reviewer_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  business_page_id uuid not null references public.business_pages(id) on delete cascade,
  service_id uuid references public.referral_services(id) on delete set null,
  buyer_id uuid not null references auth.users(id) on delete cascade,
  provider_id uuid not null references auth.users(id) on delete cascade,
  booked_date date not null,
  booked_time time,
  notes text,
  service_amount numeric(12,2) not null default 0,
  platform_fee numeric(12,2) not null default 0,
  net_to_provider numeric(12,2) not null default 0,
  total_amount numeric(12,2) not null default 0,
  status public.booking_status not null default 'pending_payment',
  payment_intent_id text,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists bookings_page_idx     on public.bookings (business_page_id);
create index if not exists bookings_buyer_idx    on public.bookings (buyer_id);
create index if not exists bookings_provider_idx on public.bookings (provider_id);
create index if not exists bookings_date_idx     on public.bookings (booked_date);
create index if not exists bookings_status_idx   on public.bookings (status);
create index if not exists bookings_payment_intent_idx
  on public.bookings (payment_intent_id) where payment_intent_id is not null;

grant select, insert, update, delete on public.bookings to authenticated;
grant all on public.bookings to service_role;

alter table public.bookings enable row level security;

drop policy if exists "Buyer + provider read bookings" on public.bookings;
create policy "Buyer + provider read bookings" on public.bookings for select to authenticated
  using (buyer_id = auth.uid() or provider_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Buyers create own bookings" on public.bookings;
create policy "Buyers create own bookings" on public.bookings for insert to authenticated
  with check (buyer_id = auth.uid());

drop policy if exists "Buyer provider admin update bookings" on public.bookings;
create policy "Buyer provider admin update bookings" on public.bookings for update to authenticated
  using (buyer_id = auth.uid() or provider_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (buyer_id = auth.uid() or provider_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

create table if not exists public.payouts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount numeric(12,2) not null check (amount >= 0),
  method text,
  destination text,
  notes text,
  status public.payout_status not null default 'requested',
  requested_at timestamptz not null default now(),
  processed_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists payouts_user_idx   on public.payouts (user_id);
create index if not exists payouts_status_idx on public.payouts (status);

grant select, insert, update, delete on public.payouts to authenticated;
grant all on public.payouts to service_role;

alter table public.payouts enable row level security;

drop policy if exists "Users read own payouts" on public.payouts;
create policy "Users read own payouts" on public.payouts for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users request own payouts" on public.payouts;
create policy "Users request own payouts" on public.payouts for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Admins manage payouts" on public.payouts;
create policy "Admins manage payouts" on public.payouts for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

drop trigger if exists business_pages_touch_updated_at on public.business_pages;
create trigger business_pages_touch_updated_at before update on public.business_pages
  for each row execute function public.touch_updated_at();

drop trigger if exists bookings_touch_updated_at on public.bookings;
create trigger bookings_touch_updated_at before update on public.bookings
  for each row execute function public.touch_updated_at();

drop view if exists public.referrals_directory;
create view public.referrals_directory as
select
  bp.id, bp.owner_id, bp.business_name, bp.category, bp.icon_emoji,
  bp.description, bp.service_area, bp.website_url, bp.logo_url, bp.banner_color,
  bp.starting_price, bp.platform_fee_pct, bp.is_featured, bp.status,
  bp.total_bookings, bp.total_reviews, bp.avg_rating, bp.total_revenue, bp.created_at,
  owner.full_name as owner_name,
  owner.city as owner_city,
  owner.state as owner_state,
  owner.avatar_color as owner_avatar_color
from public.business_pages bp
left join public.profiles owner on owner.id = bp.owner_id;

grant select on public.referrals_directory to authenticated;

-- Storage RLS for business-pages
drop policy if exists "Owners upload to own folder business-pages" on storage.objects;
create policy "Owners upload to own folder business-pages" on storage.objects for insert to authenticated
  with check (bucket_id = 'business-pages' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Anyone reads business-pages assets" on storage.objects;
create policy "Anyone reads business-pages assets" on storage.objects for select to authenticated
  using (bucket_id = 'business-pages');

drop policy if exists "Owners update own business-pages assets" on storage.objects;
create policy "Owners update own business-pages assets" on storage.objects for update to authenticated
  using (bucket_id = 'business-pages' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Owners delete own business-pages assets" on storage.objects;
create policy "Owners delete own business-pages assets" on storage.objects for delete to authenticated
  using (bucket_id = 'business-pages' and (
    (storage.foldername(name))[1] = auth.uid()::text or public.has_role(auth.uid(), 'admin')
  ));
