ALTER TABLE public.business_pages ALTER COLUMN platform_fee_pct SET DEFAULT 3;
UPDATE public.business_pages SET platform_fee_pct = 3 WHERE platform_fee_pct IS DISTINCT FROM 3;