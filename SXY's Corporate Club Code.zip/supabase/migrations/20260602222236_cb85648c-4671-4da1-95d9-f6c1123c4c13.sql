
do $$ begin alter type public.payout_status add value if not exists 'pending'; exception when others then null; end $$;
do $$ begin alter type public.payout_status add value if not exists 'held'; exception when others then null; end $$;

alter table public.invoices alter column invoice_number set default '';

-- FK aliases for PostgREST relationship hints (profiles.id == auth.users.id).
do $$ begin
  alter table public.business_pages
    add constraint business_pages_owner_id_fkey
    foreign key (owner_id) references public.profiles(id) on delete cascade;
exception when duplicate_object then null; when others then null; end $$;

do $$ begin
  alter table public.referral_reviews
    add constraint referral_reviews_reviewer_id_fkey
    foreign key (reviewer_id) references public.profiles(id) on delete cascade;
exception when duplicate_object then null; when others then null; end $$;

notify pgrst, 'reload schema';
