
alter table public.profiles add column if not exists phone text;

do $$ begin
  alter type public.payout_status add value if not exists 'approved';
exception when others then null; end $$;
do $$ begin
  alter type public.payout_status add value if not exists 'sent';
exception when others then null; end $$;

notify pgrst, 'reload schema';
