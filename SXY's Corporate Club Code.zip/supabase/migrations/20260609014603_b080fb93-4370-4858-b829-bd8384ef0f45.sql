
REVOKE EXECUTE ON FUNCTION public.kiddo_video_views_block_client() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.kiddo_videos_pii_guard() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.kid_business_pages_pii_guard() FROM PUBLIC, anon, authenticated;
