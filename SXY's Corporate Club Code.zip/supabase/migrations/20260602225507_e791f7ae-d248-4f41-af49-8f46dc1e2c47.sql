
-- 1) Fix Security Definer Views: switch to security_invoker
ALTER VIEW public.open_projects_with_bids SET (security_invoker = true);
ALTER VIEW public.referrals_directory SET (security_invoker = true);
ALTER VIEW public.platform_revenue_summary SET (security_invoker = true);
ALTER VIEW public.member_financial_summary SET (security_invoker = true);

-- 2) Fix mutable search_path on remaining functions
ALTER FUNCTION public.event_rank(event_access) SET search_path = public;
ALTER FUNCTION public.tier_rank(membership_tier) SET search_path = public;
ALTER FUNCTION public.tier_video_rank(text) SET search_path = public;
ALTER FUNCTION public.video_access_rank(video_access) SET search_path = public;

-- 3) Restrict SECURITY DEFINER trigger functions — not meant to be called via API.
REVOKE ALL ON FUNCTION public.prevent_self_tier_change() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.record_payout_status_change() FROM PUBLIC, anon, authenticated;
-- user_tier is only used internally; keep service_role only.
REVOKE ALL ON FUNCTION public.user_tier(uuid) FROM PUBLIC, anon, authenticated;
-- has_role is required by RLS policies; authenticated must be able to invoke.
-- (Keep default EXECUTE for has_role.)

-- 4) RLS enabled but no policy on scheduled_emails: add explicit deny-all for non-service roles.
-- service_role bypasses RLS, so admin/cron access still works.
CREATE POLICY "scheduled_emails service only"
  ON public.scheduled_emails
  FOR ALL
  TO authenticated, anon
  USING (false)
  WITH CHECK (false);
