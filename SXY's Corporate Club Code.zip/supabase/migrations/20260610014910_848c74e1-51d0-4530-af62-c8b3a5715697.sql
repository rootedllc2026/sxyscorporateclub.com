CREATE TABLE public.admin_password_set_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  target_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  target_email text NOT NULL,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.admin_password_set_log TO authenticated;
GRANT ALL ON public.admin_password_set_log TO service_role;
ALTER TABLE public.admin_password_set_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read admin password log" ON public.admin_password_set_log
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE INDEX idx_admin_pw_log_created ON public.admin_password_set_log(created_at DESC);