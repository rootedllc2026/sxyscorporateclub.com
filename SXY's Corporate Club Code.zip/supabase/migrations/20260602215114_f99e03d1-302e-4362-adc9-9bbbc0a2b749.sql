-- Stripe columns on profiles
alter table public.profiles
  add column if not exists stripe_customer_id     text,
  add column if not exists stripe_subscription_id text,
  add column if not exists subscription_status    text,
  add column if not exists stripe_price_id        text,
  add column if not exists next_billing_date      timestamptz,
  add column if not exists last_seen_at           timestamptz,
  add column if not exists is_active              boolean not null default true,
  add column if not exists available_balance      numeric(12,2) not null default 0,
  add column if not exists payment_method_last4   text;

create unique index if not exists profiles_stripe_customer_idx
  on public.profiles (stripe_customer_id) where stripe_customer_id is not null;
create index if not exists profiles_last_seen_idx on public.profiles (last_seen_at desc);
create index if not exists profiles_state_idx     on public.profiles (state);

-- user_tier: switch to text-returning to match v0007 expectations
drop function if exists public.user_tier(uuid) cascade;
create function public.user_tier(_user_id uuid)
returns text language sql stable security definer set search_path = public as $$
  select tier::text from public.profiles where id = _user_id;
$$;

-- Recreate events tier policy using text comparison
drop policy if exists "Members read events for their tier" on public.events;
create policy "Members read events for their tier"
  on public.events for select to authenticated
  using (
    case public.user_tier(auth.uid())
      when 'vip'    then true
      when 'annual' then access_level::text in ('free','paid','annual')
      when 'paid'   then access_level::text in ('free','paid')
      else access_level::text = 'free'
    end
    or public.has_role(auth.uid(), 'admin')
  );

-- Channels v2
do $$ begin
  create type public.channel_type as enum ('public', 'state', 'vip');
exception when duplicate_object then null; end $$;

alter table public.channels
  add column if not exists channel_type  public.channel_type not null default 'public',
  add column if not exists icon          text,
  add column if not exists state_code    text,
  add column if not exists display_order int not null default 0;

create index if not exists channels_type_order_idx on public.channels (channel_type, display_order);

drop policy if exists "Members read channels" on public.channels;
drop policy if exists "Members read accessible channels" on public.channels;
create policy "Members read accessible channels" on public.channels for select to authenticated
  using (
    channel_type in ('public', 'state')
    or public.has_role(auth.uid(), 'admin')
    or (channel_type = 'vip' and public.user_tier(auth.uid()) = 'vip')
  );

insert into public.channels (slug, name, description, channel_type, icon, state_code, display_order) values
  ('general','general','Town square for the community','public','#',null,10),
  ('introductions','introductions','New members say hello','public','#',null,20),
  ('opportunities','opportunities','Share leads & deals','public','#',null,30),
  ('wins','wins 🏆','Celebrate member wins','public','#',null,40),
  ('strategy-talk','strategy-talk','Long-form strategy threads','public','#',null,50),
  ('contractor-hub','contractor-hub','Service providers & subs','public','#',null,60),
  ('resources','resources','Templates, guides, links','public','#',null,70),
  ('new-jersey','new-jersey','NJ chapter','state','🟦','NJ',10),
  ('pennsylvania','pennsylvania','PA chapter','state','🟨','PA',20),
  ('georgia','georgia','GA chapter','state','🟥','GA',30),
  ('vip-lounge','vip-lounge','VIP members only','vip','🔒',null,10),
  ('deal-flow','deal-flow','Curated VIP deal flow','vip','🔒',null,20),
  ('inner-circle','inner-circle','Inner circle conversations','vip','🔒',null,30)
on conflict (slug) do nothing;

-- Extend messages
do $$ begin
  create type public.post_type as enum ('message','announcement','resource','poll');
exception when duplicate_object then null; end $$;

alter table public.messages
  add column if not exists channel_id          uuid references public.channels(id) on delete cascade,
  add column if not exists content             text,
  add column if not exists embed_title         text,
  add column if not exists embed_desc          text,
  add column if not exists embed_link          text,
  add column if not exists is_pinned           boolean not null default false,
  add column if not exists is_announcement     boolean not null default false,
  add column if not exists pinned_by           uuid references auth.users(id) on delete set null,
  add column if not exists pinned_at           timestamptz,
  add column if not exists dm_recipient_id     uuid references auth.users(id) on delete cascade,
  add column if not exists post_type           public.post_type not null default 'message',
  add column if not exists resource_category   text,
  add column if not exists resource_visibility text,
  add column if not exists poll_options        jsonb,
  add column if not exists poll_closes_at      timestamptz;

alter table public.messages alter column body drop not null;

update public.messages m set channel_id = c.id
  from public.channels c where m.channel_id is null and m.channel is not null and c.slug = m.channel;
update public.messages set content = body where content is null and body is not null;

create index if not exists messages_channel_id_idx   on public.messages (channel_id, created_at desc);
create index if not exists messages_dm_idx           on public.messages (dm_recipient_id, sender_id, created_at desc);

drop policy if exists "Members read messages" on public.messages;
create policy "Members read messages" on public.messages for select to authenticated
  using (
    (dm_recipient_id is not null and (sender_id = auth.uid() or dm_recipient_id = auth.uid() or public.has_role(auth.uid(), 'admin')))
    or (channel_id is not null and exists (
      select 1 from public.channels c where c.id = channel_id
        and (c.channel_type in ('public','state') or public.has_role(auth.uid(), 'admin') or (c.channel_type = 'vip' and public.user_tier(auth.uid()) = 'vip'))
    ))
    or (channel_id is null and dm_recipient_id is null)
  );

drop policy if exists "Members write own messages" on public.messages;
create policy "Members write own messages" on public.messages for insert to authenticated
  with check (sender_id = auth.uid());

-- Reactions
create table if not exists public.reactions (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  emoji text not null,
  created_at timestamptz not null default now(),
  unique (message_id, user_id, emoji)
);
create index if not exists reactions_message_idx on public.reactions (message_id);
grant select, insert, update, delete on public.reactions to authenticated;
grant all on public.reactions to service_role;
alter table public.reactions enable row level security;

drop policy if exists "Members read reactions" on public.reactions;
create policy "Members read reactions" on public.reactions for select to authenticated using (true);

drop policy if exists "Members add own reactions" on public.reactions;
create policy "Members add own reactions" on public.reactions for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists "Members remove own reactions" on public.reactions;
create policy "Members remove own reactions" on public.reactions for delete to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- Channel visits
create table if not exists public.channel_visits (
  user_id uuid not null references auth.users(id) on delete cascade,
  channel_id uuid not null references public.channels(id) on delete cascade,
  last_visited timestamptz not null default now(),
  primary key (user_id, channel_id)
);
create index if not exists channel_visits_user_idx on public.channel_visits (user_id);
grant select, insert, update, delete on public.channel_visits to authenticated;
grant all on public.channel_visits to service_role;
alter table public.channel_visits enable row level security;
drop policy if exists "Users manage own visits" on public.channel_visits;
create policy "Users manage own visits" on public.channel_visits for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Videos
do $$ begin create type public.video_series as enum ('business-bites','market-bites','bankruptcy-bites'); exception when duplicate_object then null; end $$;
do $$ begin create type public.video_access as enum ('free','paid','vip'); exception when duplicate_object then null; end $$;

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  icon_emoji text not null default '▣',
  thumbnail_url text,
  video_url text,
  duration_seconds int not null default 0,
  series public.video_series not null default 'business-bites',
  category text,
  access_level public.video_access not null default 'free',
  view_count int not null default 0,
  save_count int not null default 0,
  is_featured boolean not null default false,
  is_published boolean not null default false,
  notify_on_publish boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists videos_series_idx on public.videos (series);
create index if not exists videos_published_idx on public.videos (is_published, created_at desc);

grant select, insert, update, delete on public.videos to authenticated;
grant all on public.videos to service_role;
alter table public.videos enable row level security;

create or replace function public.video_access_rank(_a public.video_access)
returns int language sql immutable as $$
  select case _a when 'free' then 1 when 'paid' then 2 when 'vip' then 3 end;
$$;
create or replace function public.tier_video_rank(_t text)
returns int language sql immutable as $$
  select case _t when 'free' then 1 when 'paid' then 2 when 'annual' then 2 when 'vip' then 3 else 1 end;
$$;

drop policy if exists "Members read accessible videos" on public.videos;
create policy "Members read accessible videos" on public.videos for select to authenticated
  using (public.has_role(auth.uid(),'admin') or (is_published and public.video_access_rank(access_level) <= public.tier_video_rank(public.user_tier(auth.uid()))));

drop policy if exists "Admins manage videos" on public.videos;
create policy "Admins manage videos" on public.videos for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

drop trigger if exists videos_touch_updated_at on public.videos;
create trigger videos_touch_updated_at before update on public.videos
  for each row execute function public.touch_updated_at();

alter table public.video_progress
  add column if not exists progress_seconds int not null default 0,
  add column if not exists notes text;

create table if not exists public.video_saves (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, video_id)
);
create index if not exists video_saves_user_idx on public.video_saves (user_id);
grant select, insert, update, delete on public.video_saves to authenticated;
grant all on public.video_saves to service_role;
alter table public.video_saves enable row level security;

drop policy if exists "Users read own saves" on public.video_saves;
create policy "Users read own saves" on public.video_saves for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
drop policy if exists "Users insert own saves" on public.video_saves;
create policy "Users insert own saves" on public.video_saves for insert to authenticated
  with check (user_id = auth.uid());
drop policy if exists "Users delete own saves" on public.video_saves;
create policy "Users delete own saves" on public.video_saves for delete to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

-- Events extensions
do $$ begin create type public.event_status as enum ('scheduled','live','completed','canceled'); exception when duplicate_object then null; end $$;

alter table public.events
  add column if not exists icon_emoji text not null default '📅',
  add column if not exists host_name text,
  add column if not exists duration_min int,
  add column if not exists platform text,
  add column if not exists join_url text,
  add column if not exists recording_url text,
  add column if not exists recording_access public.event_access,
  add column if not exists registrant_count int not null default 0,
  add column if not exists archive_recording boolean not null default true,
  add column if not exists notify_members boolean not null default false,
  add column if not exists post_to_general boolean not null default false,
  add column if not exists status public.event_status not null default 'scheduled';

create table if not exists public.event_registrations (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (event_id, user_id)
);
create index if not exists event_reg_event_idx on public.event_registrations (event_id);
grant select, insert, update, delete on public.event_registrations to authenticated;
grant all on public.event_registrations to service_role;
alter table public.event_registrations enable row level security;

drop policy if exists "Users read own registrations" on public.event_registrations;
create policy "Users read own registrations" on public.event_registrations for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
drop policy if exists "Users register self" on public.event_registrations;
create policy "Users register self" on public.event_registrations for insert to authenticated
  with check (user_id = auth.uid());
drop policy if exists "Users cancel own registration" on public.event_registrations;
create policy "Users cancel own registration" on public.event_registrations for delete to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

-- Financials: transactions extensions
do $$ begin alter type public.txn_type add value if not exists 'consulting'; exception when duplicate_object then null; end $$;
do $$ begin alter type public.txn_type add value if not exists 'membership'; exception when duplicate_object then null; end $$;
do $$ begin alter type public.txn_type add value if not exists 'fee'; exception when duplicate_object then null; end $$;

alter table public.transactions
  add column if not exists gross_amount numeric(12,2),
  add column if not exists fee_amount numeric(12,2) not null default 0,
  add column if not exists net_amount numeric(12,2),
  add column if not exists status text not null default 'completed',
  add column if not exists source text,
  add column if not exists stripe_payment_intent_id text;

update public.transactions set gross_amount = coalesce(gross_amount, amount), net_amount = coalesce(net_amount, amount - coalesce(fee_amount, 0)) where gross_amount is null or net_amount is null;

create index if not exists transactions_status_idx on public.transactions (status);
create index if not exists transactions_created_idx on public.transactions (created_at desc);

-- Invoices
do $$ begin create type public.invoice_status as enum ('draft','sent','paid','overdue','cancelled'); exception when duplicate_object then null; end $$;

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_number text not null unique,
  user_id uuid not null references auth.users(id) on delete cascade,
  client_name text not null,
  description text,
  amount numeric(12,2) not null check (amount >= 0),
  due_date date,
  notes text,
  status public.invoice_status not null default 'draft',
  issued_at timestamptz not null default now(),
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists invoices_user_idx on public.invoices (user_id);
create index if not exists invoices_status_idx on public.invoices (status);
grant select, insert, update, delete on public.invoices to authenticated;
grant all on public.invoices to service_role;
alter table public.invoices enable row level security;

drop policy if exists "Users read own invoices" on public.invoices;
create policy "Users read own invoices" on public.invoices for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
drop policy if exists "Users create own invoices" on public.invoices;
create policy "Users create own invoices" on public.invoices for insert to authenticated
  with check (user_id = auth.uid());
drop policy if exists "Users update own invoices" on public.invoices;
create policy "Users update own invoices" on public.invoices for update to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'))
  with check (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
drop policy if exists "Admins delete invoices" on public.invoices;
create policy "Admins delete invoices" on public.invoices for delete to authenticated
  using (public.has_role(auth.uid(),'admin'));

drop trigger if exists invoices_touch_updated_at on public.invoices;
create trigger invoices_touch_updated_at before update on public.invoices
  for each row execute function public.touch_updated_at();

create or replace function public.generate_invoice_number()
returns trigger language plpgsql set search_path = public as $$
declare v_prefix text; v_next int;
begin
  if new.invoice_number is null or new.invoice_number = '' then
    v_prefix := 'INV-' || to_char(now(), 'YYYY-MM');
    v_next := (select coalesce(max(cast(regexp_replace(inv.invoice_number, '^' || v_prefix || '-', '') as int)), 0) + 1
      from public.invoices as inv where inv.invoice_number like v_prefix || '-%');
    new.invoice_number := v_prefix || '-' || lpad(v_next::text, 3, '0');
  end if;
  return new;
end $$;

drop trigger if exists invoices_autonumber on public.invoices;
create trigger invoices_autonumber before insert on public.invoices
  for each row execute function public.generate_invoice_number();

-- Platform settings
create table if not exists public.platform_settings (
  id int primary key default 1 check (id = 1),
  fee_pct_basic numeric(5,2) not null default 8,
  fee_pct_standard numeric(5,2) not null default 10,
  fee_pct_featured numeric(5,2) not null default 12,
  payout_window_days int not null default 7,
  payout_min_threshold numeric(12,2) not null default 50,
  payout_default_method text not null default 'stripe',
  notify_on_approval boolean not null default true,
  notify_on_new_request boolean not null default true,
  weekly_digest boolean not null default false,
  admin_notification_emails text[] not null default '{}'::text[],
  updated_at timestamptz not null default now()
);
insert into public.platform_settings (id) values (1) on conflict (id) do nothing;
grant select on public.platform_settings to authenticated;
grant all on public.platform_settings to service_role;
alter table public.platform_settings enable row level security;
drop policy if exists "Anyone reads platform settings" on public.platform_settings;
create policy "Anyone reads platform settings" on public.platform_settings for select to authenticated using (true);
drop policy if exists "Admins update platform settings" on public.platform_settings;
create policy "Admins update platform settings" on public.platform_settings for update to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- Summary views
drop view if exists public.platform_revenue_summary;
create view public.platform_revenue_summary as
select
  coalesce(sum(case when t.txn_type::text = 'membership' then t.gross_amount end), 0) as membership_revenue_total,
  coalesce(sum(case when t.txn_type::text = 'fee' then t.gross_amount end), 0) as referral_fee_revenue_total,
  coalesce(sum(case when t.txn_type::text in ('membership','fee') then t.gross_amount end), 0) as total_revenue,
  coalesce(sum(case when t.txn_type::text in ('membership','fee') and t.created_at >= date_trunc('month', now()) then t.gross_amount end), 0) as revenue_mtd,
  coalesce(sum(case when t.txn_type::text = 'membership' and t.created_at >= date_trunc('month', now()) then t.gross_amount end), 0) as membership_mtd,
  coalesce(sum(case when t.txn_type::text = 'fee' and t.created_at >= date_trunc('month', now()) then t.gross_amount end), 0) as referral_fee_mtd,
  (select coalesce(sum(amount), 0) from public.payouts where status in ('requested','processing')) as pending_payouts_total,
  (select count(*) from public.payouts where status in ('requested','processing')) as pending_payouts_count
from public.transactions t;
grant select on public.platform_revenue_summary to authenticated;

drop view if exists public.member_financial_summary;
create view public.member_financial_summary as
select
  p.id as member_id, p.full_name, p.email, p.tier, p.avatar_color, p.available_balance,
  coalesce(b.booking_count, 0) as booking_count,
  coalesce(t.gross_total, 0) as gross_earned,
  coalesce(t.fee_total, 0) as fees_paid,
  coalesce(t.net_total, 0) as net_earned,
  coalesce(po.pending_total, 0) as pending_payouts
from public.profiles p
left join (select provider_id, count(*) as booking_count from public.bookings where status in ('confirmed','completed') group by provider_id) b on b.provider_id = p.id
left join (select user_id,
    sum(case when txn_type::text in ('referral','consulting','bid_award') then gross_amount else 0 end) as gross_total,
    sum(fee_amount) as fee_total,
    sum(case when txn_type::text in ('referral','consulting','bid_award') then net_amount else 0 end) as net_total
  from public.transactions group by user_id) t on t.user_id = p.id
left join (select user_id, sum(amount) as pending_total from public.payouts where status in ('requested','processing') group by user_id) po on po.user_id = p.id;
grant select on public.member_financial_summary to authenticated;
