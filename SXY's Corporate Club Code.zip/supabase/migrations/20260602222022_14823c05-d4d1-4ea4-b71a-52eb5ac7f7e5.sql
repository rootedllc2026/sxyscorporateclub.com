
-- ============================================================================
-- Final restore: payout methods/audit, scheduled emails, intake, trade
-- agreements, booking documents, apprenticeship module.
-- ============================================================================

-- ── 1. Payouts: who acted ──
alter table public.payouts
  add column if not exists processed_by   uuid references auth.users(id) on delete set null,
  add column if not exists bulk_action_id uuid;
create index if not exists payouts_processed_by_idx on public.payouts (processed_by);

-- ── 2. payout_audit_log ──
create table if not exists public.payout_audit_log (
  id          uuid primary key default gen_random_uuid(),
  payout_id   uuid not null references public.payouts(id) on delete cascade,
  actor_id    uuid references auth.users(id) on delete set null,
  from_status text,
  to_status   text not null,
  note        text,
  created_at  timestamptz not null default now()
);
create index if not exists payout_audit_payout_idx on public.payout_audit_log (payout_id);
create index if not exists payout_audit_created_idx on public.payout_audit_log (created_at desc);
grant select, insert on public.payout_audit_log to authenticated;
grant all on public.payout_audit_log to service_role;
alter table public.payout_audit_log enable row level security;
create policy "Users read own payout audit" on public.payout_audit_log
  for select to authenticated using (
    public.has_role(auth.uid(), 'admin')
    or exists (select 1 from public.payouts p where p.id = payout_id and p.user_id = auth.uid())
  );
create policy "Admins write payout audit" on public.payout_audit_log
  for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));

create or replace function public.record_payout_status_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (tg_op = 'INSERT') then
    insert into public.payout_audit_log (payout_id, actor_id, from_status, to_status, note)
    values (new.id, coalesce(new.processed_by, auth.uid()), null, new.status::text, new.notes);
    return new;
  end if;
  if new.status is distinct from old.status then
    insert into public.payout_audit_log (payout_id, actor_id, from_status, to_status, note)
    values (new.id, coalesce(new.processed_by, auth.uid()), old.status::text, new.status::text, new.notes);
  end if;
  return new;
end $$;
drop trigger if exists payouts_record_audit_ins on public.payouts;
create trigger payouts_record_audit_ins after insert on public.payouts
  for each row execute function public.record_payout_status_change();
drop trigger if exists payouts_record_audit_upd on public.payouts;
create trigger payouts_record_audit_upd after update on public.payouts
  for each row execute function public.record_payout_status_change();

-- ── 3. payout_methods ──
create table if not exists public.payout_methods (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  label       text not null,
  method      text not null check (method in ('stripe','bank','paypal','wire')),
  destination text not null,
  is_default  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists payout_methods_user_idx on public.payout_methods (user_id);
create unique index if not exists payout_methods_one_default on public.payout_methods (user_id) where is_default;
grant select, insert, update, delete on public.payout_methods to authenticated;
grant all on public.payout_methods to service_role;
alter table public.payout_methods enable row level security;
create policy "Users read own payout methods" on public.payout_methods
  for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Users manage own payout methods" on public.payout_methods
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop trigger if exists payout_methods_touch_updated_at on public.payout_methods;
create trigger payout_methods_touch_updated_at before update on public.payout_methods
  for each row execute function public.touch_updated_at();

-- ── 4. transactions refund tracking ──
alter table public.transactions
  add column if not exists refunded_at   timestamptz,
  add column if not exists refunded_by   uuid references auth.users(id) on delete set null,
  add column if not exists refund_reason text,
  add column if not exists refund_txn_id uuid references public.transactions(id) on delete set null;
create index if not exists transactions_refunded_idx on public.transactions (refunded_at);

-- ── 5. scheduled_emails ──
do $$ begin
  create type public.scheduled_email_status as enum ('pending','sent','failed','cancelled');
exception when duplicate_object then null; end $$;
create table if not exists public.scheduled_emails (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null,
  reference_id uuid,
  recipient    text not null,
  payload      jsonb not null default '{}'::jsonb,
  send_at      timestamptz not null,
  status       public.scheduled_email_status not null default 'pending',
  attempts     int  not null default 0,
  last_error   text,
  sent_at      timestamptz,
  created_at   timestamptz not null default now()
);
create index if not exists scheduled_emails_due_idx on public.scheduled_emails (send_at) where status = 'pending';
create index if not exists scheduled_emails_reference_idx on public.scheduled_emails (reference_id);
grant all on public.scheduled_emails to service_role;
alter table public.scheduled_emails enable row level security;

-- ── 6. intake_submissions ──
create table if not exists public.intake_submissions (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  phone text,
  business_name text,
  service_interest text not null,
  message text,
  preferred_contact text not null default 'email',
  submitted_at timestamptz not null default now(),
  status text not null default 'new'
);
create index if not exists intake_submissions_submitted_at_idx on public.intake_submissions (submitted_at desc);
create index if not exists intake_submissions_status_idx on public.intake_submissions (status);
grant insert on public.intake_submissions to anon, authenticated;
grant select, update on public.intake_submissions to authenticated;
grant all on public.intake_submissions to service_role;
alter table public.intake_submissions enable row level security;
create policy "intake_submissions_public_insert" on public.intake_submissions
  for insert to anon, authenticated with check (true);
create policy "intake_submissions_admin_select" on public.intake_submissions
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "intake_submissions_admin_update" on public.intake_submissions
  for update to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- ── 7. bookings: payment_method + new status values ──
do $$ begin
  alter type public.booking_status add value if not exists 'pending_agreement';
exception when others then null; end $$;
do $$ begin
  alter type public.booking_status add value if not exists 'agreement_declined';
exception when others then null; end $$;
alter table public.bookings
  add column if not exists payment_method text not null default 'card'
    check (payment_method in ('card', 'trade'));
create index if not exists bookings_payment_method_idx on public.bookings (payment_method);

-- ── 8. trade_agreements ──
create table if not exists public.trade_agreements (
  id                    uuid primary key default gen_random_uuid(),
  booking_id            uuid not null unique references public.bookings(id) on delete cascade,
  proposed_by_user_id   uuid not null references auth.users(id) on delete cascade,
  offered_description   text not null,
  requested_description text not null,
  estimated_value_usd   numeric(12,2),
  buyer_accepted_at     timestamptz,
  provider_accepted_at  timestamptz,
  declined_at           timestamptz,
  declined_by_user_id   uuid references auth.users(id) on delete set null,
  decline_reason        text,
  completed_at          timestamptz,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create index if not exists trade_agreements_booking_idx on public.trade_agreements (booking_id);
grant select, insert, update, delete on public.trade_agreements to authenticated;
grant all on public.trade_agreements to service_role;
alter table public.trade_agreements enable row level security;
create policy "Participants + admin read trade agreements" on public.trade_agreements
  for select to authenticated using (
    exists (select 1 from public.bookings b where b.id = booking_id
      and (b.buyer_id = auth.uid() or b.provider_id = auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  );
create policy "Buyer creates own trade agreement" on public.trade_agreements
  for insert to authenticated with check (
    proposed_by_user_id = auth.uid()
    and exists (select 1 from public.bookings b where b.id = booking_id and b.buyer_id = auth.uid())
  );
create policy "Participants update trade agreement" on public.trade_agreements
  for update to authenticated
  using (
    exists (select 1 from public.bookings b where b.id = booking_id
      and (b.buyer_id = auth.uid() or b.provider_id = auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  )
  with check (
    exists (select 1 from public.bookings b where b.id = booking_id
      and (b.buyer_id = auth.uid() or b.provider_id = auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  );
drop trigger if exists trade_agreements_touch_updated_at on public.trade_agreements;
create trigger trade_agreements_touch_updated_at before update on public.trade_agreements
  for each row execute function public.touch_updated_at();

-- ── 9. booking_documents ──
create table if not exists public.booking_documents (
  id           uuid primary key default gen_random_uuid(),
  booking_id   uuid not null references public.bookings(id) on delete cascade,
  uploaded_by  uuid not null references auth.users(id) on delete cascade,
  storage_path text not null,
  file_name    text not null,
  mime_type    text,
  size_bytes   bigint,
  doc_type     text not null default 'other'
    check (doc_type in ('agreement','invoice','purchase_order','other')),
  note         text,
  created_at   timestamptz not null default now()
);
create index if not exists booking_documents_booking_idx on public.booking_documents (booking_id);
create index if not exists booking_documents_uploader_idx on public.booking_documents (uploaded_by);
grant select, insert, delete on public.booking_documents to authenticated;
grant all on public.booking_documents to service_role;
alter table public.booking_documents enable row level security;
create policy "Participants + admin read booking documents" on public.booking_documents
  for select to authenticated using (
    exists (select 1 from public.bookings b where b.id = booking_id
      and (b.buyer_id = auth.uid() or b.provider_id = auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  );
create policy "Participants insert booking documents" on public.booking_documents
  for insert to authenticated with check (
    uploaded_by = auth.uid()
    and exists (select 1 from public.bookings b where b.id = booking_id
      and (b.buyer_id = auth.uid() or b.provider_id = auth.uid()))
  );
create policy "Uploader or admin delete booking documents" on public.booking_documents
  for delete to authenticated using (
    uploaded_by = auth.uid() or public.has_role(auth.uid(), 'admin')
  );

-- ── 10. apprenticeship_programs ──
create table if not exists public.apprenticeship_programs (
  id                   uuid primary key default gen_random_uuid(),
  owner_id             uuid not null references auth.users(id) on delete cascade,
  title                text not null check (char_length(title) between 3 and 200),
  summary              text not null check (char_length(summary) between 10 and 500),
  description          text not null check (char_length(description) between 10 and 8000),
  industry             text,
  location             text,
  duration_weeks       int check (duration_weeks between 1 and 104),
  stipend_description  text,
  start_date           date,
  require_cover_note   boolean not null default true,
  require_resume       boolean not null default true,
  require_video        boolean not null default false,
  require_portfolio    boolean not null default false,
  structured_questions jsonb not null default '[]'::jsonb,
  status               text not null default 'open'
    check (status in ('draft','open','closed','archived')),
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index if not exists apprenticeship_programs_owner_idx on public.apprenticeship_programs (owner_id);
create index if not exists apprenticeship_programs_status_idx on public.apprenticeship_programs (status);
grant select, insert, update, delete on public.apprenticeship_programs to authenticated;
grant all on public.apprenticeship_programs to service_role;
alter table public.apprenticeship_programs enable row level security;
create policy "Anyone authed reads open programs" on public.apprenticeship_programs
  for select to authenticated using (
    status in ('open','closed') or owner_id = auth.uid() or public.has_role(auth.uid(), 'admin')
  );
create policy "Owners create programs" on public.apprenticeship_programs
  for insert to authenticated with check (owner_id = auth.uid());
create policy "Owners update own programs" on public.apprenticeship_programs
  for update to authenticated
  using (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Owners delete own programs" on public.apprenticeship_programs
  for delete to authenticated using (owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
drop trigger if exists apprenticeship_programs_touch on public.apprenticeship_programs;
create trigger apprenticeship_programs_touch before update on public.apprenticeship_programs
  for each row execute function public.touch_updated_at();

-- ── 11. apprenticeship_applications ──
create table if not exists public.apprenticeship_applications (
  id                 uuid primary key default gen_random_uuid(),
  program_id         uuid not null references public.apprenticeship_programs(id) on delete cascade,
  applicant_id       uuid not null references auth.users(id) on delete cascade,
  cover_note         text,
  resume_path        text,
  video_path         text,
  portfolio_links    jsonb not null default '[]'::jsonb,
  structured_answers jsonb not null default '[]'::jsonb,
  status             text not null default 'pending'
    check (status in ('pending','accepted','rejected','withdrawn')),
  decided_at         timestamptz,
  decision_note      text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  unique (program_id, applicant_id)
);
create index if not exists apprenticeship_applications_program_idx on public.apprenticeship_applications (program_id);
create index if not exists apprenticeship_applications_applicant_idx on public.apprenticeship_applications (applicant_id);
grant select, insert, update, delete on public.apprenticeship_applications to authenticated;
grant all on public.apprenticeship_applications to service_role;
alter table public.apprenticeship_applications enable row level security;
create policy "Applicant + program owner read apps" on public.apprenticeship_applications
  for select to authenticated using (
    applicant_id = auth.uid()
    or exists (select 1 from public.apprenticeship_programs p where p.id = program_id and p.owner_id = auth.uid())
    or public.has_role(auth.uid(), 'admin')
  );
create policy "Applicants insert own application" on public.apprenticeship_applications
  for insert to authenticated with check (applicant_id = auth.uid());
create policy "Applicant or owner update application" on public.apprenticeship_applications
  for update to authenticated
  using (
    applicant_id = auth.uid()
    or exists (select 1 from public.apprenticeship_programs p where p.id = program_id and p.owner_id = auth.uid())
    or public.has_role(auth.uid(), 'admin')
  )
  with check (
    applicant_id = auth.uid()
    or exists (select 1 from public.apprenticeship_programs p where p.id = program_id and p.owner_id = auth.uid())
    or public.has_role(auth.uid(), 'admin')
  );
drop trigger if exists apprenticeship_applications_touch on public.apprenticeship_applications;
create trigger apprenticeship_applications_touch before update on public.apprenticeship_applications
  for each row execute function public.touch_updated_at();

-- ── 12. apprenticeships (accepted) ──
create table if not exists public.apprenticeships (
  id             uuid primary key default gen_random_uuid(),
  program_id     uuid not null references public.apprenticeship_programs(id) on delete cascade,
  application_id uuid not null unique references public.apprenticeship_applications(id) on delete cascade,
  owner_id       uuid not null references auth.users(id) on delete cascade,
  apprentice_id  uuid not null references auth.users(id) on delete cascade,
  status         text not null default 'active' check (status in ('active','completed','ended')),
  started_at     timestamptz not null default now(),
  completed_at   timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists apprenticeships_owner_idx on public.apprenticeships (owner_id);
create index if not exists apprenticeships_apprentice_idx on public.apprenticeships (apprentice_id);
grant select, insert, update, delete on public.apprenticeships to authenticated;
grant all on public.apprenticeships to service_role;
alter table public.apprenticeships enable row level security;
create policy "Participants + admin read apprenticeship" on public.apprenticeships
  for select to authenticated using (
    owner_id = auth.uid() or apprentice_id = auth.uid() or public.has_role(auth.uid(), 'admin')
  );
create policy "Owner creates apprenticeship" on public.apprenticeships
  for insert to authenticated with check (owner_id = auth.uid());
create policy "Participants update apprenticeship" on public.apprenticeships
  for update to authenticated
  using (owner_id = auth.uid() or apprentice_id = auth.uid() or public.has_role(auth.uid(), 'admin'))
  with check (owner_id = auth.uid() or apprentice_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
drop trigger if exists apprenticeships_touch on public.apprenticeships;
create trigger apprenticeships_touch before update on public.apprenticeships
  for each row execute function public.touch_updated_at();

-- ── 13. apprenticeship_milestones ──
create table if not exists public.apprenticeship_milestones (
  id                uuid primary key default gen_random_uuid(),
  apprenticeship_id uuid not null references public.apprenticeships(id) on delete cascade,
  title             text not null check (char_length(title) between 1 and 200),
  description       text,
  due_date          date,
  status            text not null default 'pending'
    check (status in ('pending','in_progress','submitted','approved')),
  sort_order        int not null default 0,
  submitted_at      timestamptz,
  approved_at       timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists apprenticeship_milestones_appr_idx on public.apprenticeship_milestones (apprenticeship_id);
grant select, insert, update, delete on public.apprenticeship_milestones to authenticated;
grant all on public.apprenticeship_milestones to service_role;
alter table public.apprenticeship_milestones enable row level security;
create policy "Participants read milestones" on public.apprenticeship_milestones
  for select to authenticated using (
    exists (select 1 from public.apprenticeships a where a.id = apprenticeship_id
      and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  );
create policy "Owner inserts milestones" on public.apprenticeship_milestones
  for insert to authenticated with check (
    exists (select 1 from public.apprenticeships a where a.id = apprenticeship_id and a.owner_id = auth.uid())
  );
create policy "Participants update milestones" on public.apprenticeship_milestones
  for update to authenticated
  using (
    exists (select 1 from public.apprenticeships a where a.id = apprenticeship_id
      and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid()))
  )
  with check (
    exists (select 1 from public.apprenticeships a where a.id = apprenticeship_id
      and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid()))
  );
create policy "Owner deletes milestones" on public.apprenticeship_milestones
  for delete to authenticated using (
    exists (select 1 from public.apprenticeships a where a.id = apprenticeship_id and a.owner_id = auth.uid())
  );
drop trigger if exists apprenticeship_milestones_touch on public.apprenticeship_milestones;
create trigger apprenticeship_milestones_touch before update on public.apprenticeship_milestones
  for each row execute function public.touch_updated_at();

-- ── 14. apprenticeship_messages ──
create table if not exists public.apprenticeship_messages (
  id                uuid primary key default gen_random_uuid(),
  apprenticeship_id uuid not null references public.apprenticeships(id) on delete cascade,
  sender_id         uuid not null references auth.users(id) on delete cascade,
  body              text not null check (char_length(body) between 1 and 4000),
  created_at        timestamptz not null default now()
);
create index if not exists apprenticeship_messages_appr_idx
  on public.apprenticeship_messages (apprenticeship_id, created_at);
grant select, insert on public.apprenticeship_messages to authenticated;
grant all on public.apprenticeship_messages to service_role;
alter table public.apprenticeship_messages enable row level security;
create policy "Participants read messages" on public.apprenticeship_messages
  for select to authenticated using (
    exists (select 1 from public.apprenticeships a where a.id = apprenticeship_id
      and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid()))
    or public.has_role(auth.uid(), 'admin')
  );
create policy "Participants send messages" on public.apprenticeship_messages
  for insert to authenticated with check (
    sender_id = auth.uid()
    and exists (select 1 from public.apprenticeships a where a.id = apprenticeship_id
      and (a.owner_id = auth.uid() or a.apprentice_id = auth.uid()))
  );

-- ── 15. Storage policies (buckets already exist) ──
drop policy if exists "Booking participants read documents" on storage.objects;
create policy "Booking participants read documents" on storage.objects
  for select to authenticated using (
    bucket_id = 'booking-documents'
    and (
      exists (select 1 from public.bookings b
              where b.id::text = (storage.foldername(name))[1]
                and (b.buyer_id = auth.uid() or b.provider_id = auth.uid()))
      or public.has_role(auth.uid(), 'admin')
    )
  );
drop policy if exists "Booking participants upload documents" on storage.objects;
create policy "Booking participants upload documents" on storage.objects
  for insert to authenticated with check (
    bucket_id = 'booking-documents'
    and exists (select 1 from public.bookings b
                where b.id::text = (storage.foldername(name))[1]
                  and (b.buyer_id = auth.uid() or b.provider_id = auth.uid()))
  );
drop policy if exists "Uploader or admin delete booking documents storage" on storage.objects;
create policy "Uploader or admin delete booking documents storage" on storage.objects
  for delete to authenticated using (
    bucket_id = 'booking-documents'
    and (owner = auth.uid() or public.has_role(auth.uid(), 'admin'))
  );

drop policy if exists "Applicants upload own files" on storage.objects;
create policy "Applicants upload own files" on storage.objects
  for insert to authenticated with check (
    bucket_id = 'apprentice-uploads'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
drop policy if exists "Applicants + program owner read uploads" on storage.objects;
create policy "Applicants + program owner read uploads" on storage.objects
  for select to authenticated using (
    bucket_id = 'apprentice-uploads'
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or exists (
        select 1
        from public.apprenticeship_applications app
        join public.apprenticeship_programs p on p.id = app.program_id
        where (storage.foldername(name))[1] = app.applicant_id::text
          and (storage.foldername(name))[2] = p.id::text
          and p.owner_id = auth.uid()
      )
      or public.has_role(auth.uid(), 'admin')
    )
  );
drop policy if exists "Applicants delete own uploads" on storage.objects;
create policy "Applicants delete own uploads" on storage.objects
  for delete to authenticated using (
    bucket_id = 'apprentice-uploads'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

notify pgrst, 'reload schema';
