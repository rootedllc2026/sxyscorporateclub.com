
-- Path convention: {owner_user_id}/{filename}
CREATE POLICY kvid_owner_read ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'kiddo-videos' AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.is_parent_of(((storage.foldername(name))[1])::uuid)
    OR public.has_role(auth.uid(), 'admin')
  )
);

CREATE POLICY kvid_owner_insert ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'kiddo-videos' AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.is_parent_of(((storage.foldername(name))[1])::uuid)
    OR public.has_role(auth.uid(), 'admin')
  )
);

CREATE POLICY kvid_owner_update ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'kiddo-videos' AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.has_role(auth.uid(), 'admin')
  )
);

CREATE POLICY kvid_owner_delete ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'kiddo-videos' AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.is_parent_of(((storage.foldername(name))[1])::uuid)
    OR public.has_role(auth.uid(), 'admin')
  )
);
